# Tecelã — como continuar o projeto em uma nova conversa

## 1. O que enviar

- **Tecela-codigo-fonte.zip**: a pasta inteira do projeto. Dentro dela já estão este arquivo, o `README.md` e o `Tecelã — Especificação do projeto.docx`.
- (opcional) Um arquivo `.tecela` de **teste**, só com dados fictícios. Nunca envie dados reais de crianças: os arquivos reais ficam só no aparelho da professora.
- (opcional) A fonte `antrf___.ttf` (Antropos), só se for preciso redesenhar o logotipo.
- (opcional) O PDF "BNCC Computação — completo diagramado", só se for preciso gerar de novo as habilidades de Computação.

## 2. Texto para colar no início da conversa

> Atue como especialista em pedagogia Waldorf e Antroposofia, pedagogo, especialista em administração escolar e desenvolvedor web.
>
> Estou anexando o código-fonte da Tecelã ("Fio a fio, tecendo as linhas da vida escolar"), versão 1.7.1: um app em HTML único, offline, para a professora ou o professor de classe Waldorf (uma professora, uma turma, acompanhada do 1º ao 8º ano). Leia primeiro o `continuar.md` e o `README.md`.
>
> O que eu quero agora: [descreva a mudança, a correção ou a nova função]
>
> Ao terminar, me entregue o projeto todo em .zip (com `continuar.md`, `README.md` e a especificação .docx atualizados) e, à parte, o HTML único.

## 3. Regras do projeto

- HTML único, sem internet (só o envio por e-mail usa a rede), em português do Brasil.
- Tela inicial: Continuar, Abrir arquivo, Novo, Novo a partir de boletins anteriores, Modelo de demonstração e Computador de terceiros.
- Os dados ficam no IndexedDB (gravados a cada digitação) e num arquivo `.tecela` salvo pela professora; "💾 Salvar" (Ctrl+S) grava sempre no mesmo arquivo. O indicador no topo (`htmlEstadoSalvo`) e o texto `TEXTO_SALVAR` explicam a diferença.
- Senha opcional: AES-256-GCM com PBKDF2 (250.000 iterações) e chave de recuperação.
- LGPD: nada sai do aparelho sem ação da professora. Dados reais são processados só no aparelho dela, nunca na conversa.
- Documentos finalizados (atas e boletins) não mudam: usa-se "Em tempo" ou nova versão, com impressão digital SHA-256.
- Android: o `Tecela.html` aberto pelo gerenciador de arquivos fica em `content://`, e nesse modo o Chrome não entrega à página o arquivo escolhido (diagnóstico de 04/11/2026). A solução estável seria publicar o app em https e instalá-lo como aplicativo (ideia para depois).
- Seletor do `.tecela` (`ACEITA_TECELA` em `nucleo.js`): no Android, tipos de documento (`application/octet-stream`, JSON, texto), porque o sistema trata `.tecela` como "Arquivo em BIN"; filtrar só por `.tecela` deixa o arquivo cinza, e não filtrar faz o Chrome abrir só Câmera e Galeria. No iPhone e no iPad, sem filtro ("Escolher arquivo"). No computador, filtro pela extensão. O conteúdo é sempre conferido ao ler.
- Exportação em PDF (impressão do navegador), DOCX (biblioteca docx embutida), CSV e ZIP.
- Cada criança é comparada só com ela mesma; a turma, só com ela mesma.
- Pontos de atenção e anotações sigilosas nunca entram no boletim; em relatórios, só se a professora marcar.
- Cadastros: item sem uso é excluído; item com uso é arquivado, para não perder relações e histórico.
- Biblioteca: verbetes da professora podem ser excluídos; verbetes que vêm com o app são ocultados, não excluídos; a BNCC é só leitura.
- A professora deve trabalhar o mínimo possível: sugerir, pré-preencher e deixar desfazer.
- Fora do escopo: ditado por voz, banco de poemas, importação da planilha de observação e do calendário da escola.
- Logotipo: nome em Antropos (Lutz Baar) e slogan em Poppins, os dois já convertidos em curvas. O arquivo da Antropos não pode ser embutido (uso cultural, embutimento restrito).
- Modelo de demonstração: "Escola Waldorf Tecelã", com "(fictício)" após o nome da professora e de cada criança. Ao mudar o modelo, aumente `DEMO_VERSAO` em `src/demo.js`.
- Autor e idealizador: Márcio Willians Barreto de Andrade (marciowillians@gmail.com). Licença GNU GPL v3 com termos adicionais da seção 7 (arquivo `LICENSE`): o aviso de autoria (`AUTORIA`, em `nucleo.js`) tem de ficar visível na tela inicial e nos Créditos, e versões modificadas devem se identificar e isentar o autor original. O `build.py` embute o `LICENSE` no app (`__LICENCA__`).
- Os mínimos de dias letivos e de horas (`minDias()`, `minHoras()` em `rotina.js`) vêm de Ajustes; o padrão é o da LDB (200 e 800).
- 9º ano oculto por padrão (`seriesVisiveis()`; Ajustes → Anos mostrados): na tradição Waldorf, o 9º ano já é o início do ensino médio.
- Campos de data que redesenham a tela (`data-rr` ou `data-c`) só redesenham ao sair do campo: o navegador considera válido o ano parcial (0002…) enquanto se digita.
- **Partilha pedagógica (regra permanente):** a cada atualização, revise `PARTILHA` em `src/partilha.js`. Toda coleção de `STORES` tem de estar em `PARTILHA.pode` (com cada campo em `vai` ou `fica`, inclusive as seções dos documentos e as informações da vivência) ou em `PARTILHA.nunca`. Coleção ou campo novo fica fora da partilha até ser incluído de propósito; dados de pessoas, da escola, de saúde, datas do calendário e vínculos nunca vão. O `teste-partilha.js` falha se algo ficar sem classificação. Em cada entrega, informe o que foi classificado e em qual lista.
- A partilha só acrescenta: nada existente é alterado; repetidos são pulados; mesmo nome com conteúdo diferente ganha "(recebido)"; cada importação tem uma etiqueta (`partilha: {id, de, em}`) e "Remover o que veio desta partilha" apaga só os itens dela. Planejamento anual, plano de época e modelo de boletim recebidos não tomam o lugar dos da professora (`anualDe`, `planoEpocaDe` e `modeloDaSerie` dão preferência aos próprios).
- **Numeração das versões (versionamento semântico, MAIOR.MENOR.CORREÇÃO):**
  - MAIOR (1 → 2): mudança que quebra a compatibilidade, como um formato de arquivo que versões anteriores não abrem, ou uma reorganização grande do app.
  - MENOR (1.6 → 1.7): qualquer função nova, mesmo pequena, ou mudança visível no comportamento; o terceiro número volta a zero e não é escrito (1.7, não 1.7.0).
  - CORREÇÃO (1.7 → 1.7.1): só correções, ajustes de texto, avisos e documentação, sem função nova.
  - Atualizar sempre juntos: `VERSAO` e `DATA_VERSAO` em `nucleo.js`, README, este arquivo (texto para colar e tabela de versões), a Especificação (cabeçalho e histórico) e a tag da versão no GitHub (`v1.7.1`).
- Distribuição: GitHub, em <https://github.com/MarcioWillians/tecela/releases> (`LINK_VERSOES` em `nucleo.js` aponta para `releases/latest`). Cada versão é publicada como uma Release com o `Tecela.html` e o zip do projeto (a GPL pede o código-fonte junto). GitHub Pages fica desligado: o app é baixado e aberto no computador.
- Contato e avisos: `contatoHtml()` (Ajuda → Sobre, sugestões e versões; link da tela inicial; rodapé do menu) e `avisoBnccHtml()` (aba BNCC e verbete da Biblioteca), com o texto `NAO_ENVIE`. A BNCC não é editável no app; mudanças do MEC entram numa versão nova, extraída do documento oficial pelos scripts de `ferramentas/`.
- Sempre gere de novo o HTML com `python3 build.py` e rode todos os testes.

## 4. Como o código está organizado

| Arquivo | O que faz |
|---|---|
| `build.py` | Junta tudo em `dist/Tecela.html`, na ordem da lista `ORDEM`, e injeta os logotipos e o texto da licença |
| `src/index.html`, `src/estilo.css` | Página-modelo e estilos (paleta, celular, impressão) |
| `src/nucleo.js` | Utilidades, criptografia, IndexedDB (versão 5), salvar/apagar com "Desfazer", diálogos, vínculo de campos (`data-rec` + `data-b`), arquivo `.tecela`, ZIP, impressão, e-mail |
| `src/cadastros.js` | Listas personalizáveis, "onde é usado" (`ondeUsado`), excluir/arquivar, migrações únicas (`mig12`, `mig13`) |
| `src/bncc-dados.js` | 1.304 habilidades da BNCC (gerado por `ferramentas/extrair_bncc.py`) |
| `src/bncc-computacao-dados.js` | 104 habilidades de Computação (83 por ano e 21 por etapa) com eixo, objeto, explicação e exemplos, e as 7 competências (gerado por `ferramentas/extrair_computacao.py`) |
| `src/bncc-computacao.js` | Liga e desliga a Computação (`aplicarComputacao`), eixos e blocos de documento |
| `src/docmotor.js` | Documentos editáveis com seções (`TIPOS_DOC`): editor, ↻ por seção, versões com impressão digital, exportação |
| `src/apoio.js` | Aniversariantes, poemas, pauta da reunião, reforço e bilhete, informações completas da vivência |
| `src/turmadocs.js` | Combinados da turma (com versões e “repetir o do ano anterior”) e PEI |
| `src/planejamento.js` | Conteúdo programático, horário semanal (aulas com horário, Aula principal, impressão em tabela), Planejamento anual e Plano de época (com repertório, avaliação da época e notas de quem já deu a época) |
| `src/partilha.js` | Partilha pedagógica: classificação `PARTILHA` (o que pode ir, campo a campo, e o que nunca vai), troca de nomes conhecidos por marcadores, tela Conferir a partilha (edição só para o arquivo), arquivo `.tecela-partilha` com senha opcional, importação seletiva sem alterar nada, Material recebido e desfazer |
| `src/familia.js` | Saúde e segurança do aluno, ficha de emergência e autorização da vivência, entrevista com a família, estudo de criança, contatos com as famílias (tela Acompanhamento) e comunicados com modelos |
| `src/repertorio.js` | Repertório da turma (versos, canções, histórias…), com usos e épocas; acompanha a turma de ano em ano |
| `src/rotina.js` | Chamada rápida no Painel, roteiro do professor substituto, dias letivos e carga horária, festas do ano, lista de materiais, conferência dos textos do boletim |
| `src/planejamento-dados.js`, `src/programa-dados.js` | Textos de base de cada ano, épocas de referência e o conteúdo programático de referência (gerado por `ferramentas/extrair_programa.py`, sem identificar a escola) |
| `src/documentos.js` | Blocos de documento → HTML/PDF e DOCX; ata, boletim, timbrado, grade do mês |
| `src/biblioteca.js` | Verbetes da Biblioteca Waldorf (`BIBLIO`), com fontes |
| `src/telas-base.js` | Casca (montada uma vez; a cada mudança só `#corpo` e o topo são redesenhados, e o menu guarda a rolagem), menu (`GRUPOS`, grupos recolhíveis, Recentes), atalhos de teclado, indicador de salvamento, tela inicial (versão e autoria), senha, Painel, Turma e alunos (arquivar e excluir turma), virada do ano (com pendências) |
| `src/telas-docs.js` | Anotações, Atas, Boletins (rascunho da observação, poema do ano, ZIP, finalizar os prontos) |
| `src/telas-perfis.js` | Perfil do aluno, perfil e evolução da turma, Biblioteca (com a categoria BNCC, novo verbete, ocultar) |
| `src/observacao.js` | Observação do período: roteiro, períodos, rascunho do boletim, sugestão do perfil |
| `src/conselho.js` | Conselho de classe: pré-conselho, registro, pós-conselho |
| `src/rapido.js` | ✎ Anotar, grade de faltas, busca, pendências do Painel |
| `src/calendario.js` | Calendário (repetição e exceções), vivências, tarefas, avisos, `.ics` |
| `src/curriculo.js` | Currículo da escola, consulta à BNCC, sugestões, comparação |
| `src/relatorios.js` | Ficha da criança, observação, perfil e evolução da turma e demais relatórios |
| `src/telas-config.js` | Papel timbrado, Ajustes, Ajuda |
| `src/importar.js` | Importador de boletins `.docx`, dentro do app |
| `src/ajuda.js` | Manual, créditos e licenças, privacidade, sobre |
| `src/demo.js`, `src/app.js` | Modelo de demonstração e inicialização |
| `vendor/` | docx 9.7.1 (MIT) e sua licença |
| `assets/` | Logotipos, ícone e prancha; `gera.py` e `palavra.py` redesenham o logotipo |
| `ferramentas/` | `extrair_bncc.py`, `extrair_computacao.py` e `extrair_programa.py` |
| `testes/` | Testes com Playwright (ver o `README.md`) |

**Dados.** Bancos IndexedDB `tecela` (dados) e `tecela-demo` (modelo). Coleções: config, timbrado, turmas, alunos, matriculas, anotacoes, atas, marcacoes, modelosBoletim, boletins, perfisAluno, perfisTurma, biblioteca, cadastros, eventos, vivencias, tarefas, curriculo, observacoes, conselhos, documentos, reforcos, programa, repertorio, contatos, comunicados (IndexedDB versão 5). Com senha, cada registro é gravado como `{ id, _e: { iv, d } }`. Arquivo `.tecela`: `{ app: "Tecela", formato: 1, versao, guardado, cripto?, dados }`.

Campos que merecem atenção:
- `observacoes`: `{ id: 'obs:turma:aluno:2026-S1', marcas: { item: 'c'|'d'|'a' }, notas }`.
- `conselhos`: `{ id: 'cons:turma:periodo', alunos: { aluno: { situacao, fala, proposta, resp, prazo } } }`.
- `eventos`: `repete`, `repeteAte`, `excecoes`, `origemSerie`.
- `documentos`: `{ tipo: 'combinados'|'pei'|'anual'|'epoca'|'refAnual'|'refEpoca'|'entrevista'|'estudo'|'materiais', turmaId?, alunoId?, serie?, epocaId?, titulo, cab, secoes, versoes }`. Seção com `manual: true` não tem ↻; com `naoImprimir: true` fica fora do impresso.
- `reforcos`: `{ turmaId, alunos, componente, topico, datas, encontros: { data: 'realizado'|'faltou'|'cancelado' }, hora, saida: 'HH:MM', situacao }`; só as datas sem marcação de um reforço previsto vão à agenda (`datasPendentesRef`).
- `turmas.materias`: `[{ nome, quem: 'PC'|'PM', prof }]`; `turmas.grade`: `{ 1..6: { itens: [{ m, ini, fim }] } }` e `turmas.gradeObs`; os formatos antigos (`{ aulas, pc }` e `{ lista, obs }`) são convertidos por `gradeDe`. “Aula principal” (`AULA_PRINCIPAL`) é sempre PC. `turmas.arquivada` tira a turma do seletor.
- `alunos.seg`: `{ alergias, medicamentos, plano, emergencia, buscam }` (sai impresso na ficha de emergência e no roteiro do substituto). `matriculas.ausencias`: datas marcadas na chamada (cada uma soma 1 em `faltas[período]`).
- `repertorio`: `{ turmaId, tipo, titulo, autor, epocaId, rotina, texto, obs, usos: [datas] }`; `contatos`: `{ turmaId, alunoId, data, meio, quem, assunto, texto, combinados, sigilo }`; `comunicados`: modelos editados ou próprios `{ chave, nome, texto }`.
- Eventos de festa: `festa` (chave da festa, para não repetir). Festas do ano: `CFG.prefs.festas` = `[{ k, nome, quando: 'MM-DD'|'pascoa:±n'|'advento:±n', passos: [[dias antes, texto]] }]`; nula = lista padrão (`FESTAS_PADRAO`, em `rotina.js`).
- `biblioteca`: `origem` (original, editado, branco, proprio) e `oculto`.
- BNCC: `[código, componente, anos, texto, meta?]`. Na Computação, `meta = { e, o, x, ex, etapa?, eq? }`; as habilidades por etapa ficam fora das sugestões e da comparação.

**Nova tela.** `T.nome = () => html`; botões com `data-a="acao"` e `A.acao = (dataset, el) => {}`; campos com `data-rec` e `data-b`; `data-i` só para o gatilho de `C_` no evento input. Inclua a tela em `GRUPOS` e uma parte no manual.

## 5. Ideias para depois

- Quando a Federação das Escolas Waldorf no Brasil publicar a parte do Ensino Fundamental do documento sobre Pedagogia Waldorf e BNCC (em novembro de 2026, a versão pública ia só até a Educação Infantil), conferir de novo os verbetes `serie-1` a `serie-9`. Mudar `BIBLIO` atualiza sozinho os verbetes que a professora não editou.

## 6. Versões

| Versão | Data | Principais mudanças |
|---|---|---|
| 1.7.1 | 06/11/2026 | Avisos de contato: "Sugestões e novas versões" (tela inicial, rodapé do menu e Ajuda → Sobre, sugestões e versões) com o e-mail do autor, o link das versões no GitHub e como atualizar; aviso da BNCC na aba BNCC e no verbete da Biblioteca; regra de numeração das versões registrada. Teste `teste-v171.js` |
| 1.7 | 06/11/2026 | Partilha pedagógica: compartilhar planejamentos, repertório, biblioteca própria, modelos, comunicados, vivências e festas sem dados de pessoas ou da escola (lista fechada do que pode sair, nomes trocados por marcadores, revisão com destaque do que conferir, assinatura e senha opcionais); receber sem alterar nada, com repetidos pulados, "(recebido)" nos nomes iguais, avisos resumidos, resumo da importação e desfazer por partilha. Teste `teste-partilha.js` com a classificação obrigatória de toda coleção e campo |
| 1.6.2 | 06/11/2026 | Festas do ano editáveis: editar, incluir e excluir festas, com data fixa ou ligada à Páscoa ou ao Advento, e os passos da preparação (`CFG.prefs.festas`; sem ela, vale `FESTAS_PADRAO`); correção: o botão “Autorização” da vivência não abria (bloco `centro` sem `linhas`) |
| 1.6.1 | 06/11/2026 | Mínimo de dias letivos e mínimo de horas em Ajustes → Ano letivo (`minDias`, `minHoras`; definidos pela legislação, hoje 200 e 800); “Grade semanal” passa a “Horário semanal” em todo o app, no manual e nos documentos (os nomes internos `grade`, `gradeDe` e `gradeObs` continuam); vídeo de apresentação refeito com as telas da 1.6 |
| 1.6 | 06/11/2026 | Correções: ano da data de nascimento (e da vivência) ao digitar; menu mantém a rolagem; saída do reforço em campo de horário; encontro de reforço realizado, com falta ou cancelado sai da agenda; PDF com o nome do documento. Pedidos: versão e autoria na tela inicial; “Guardar” vira “💾 Salvar”, com indicador e explicação do salvamento automático; finalizar os boletins prontos; arquivar e excluir turma; virada mostra pendências e cria tarefas; 9º ano oculto por padrão; horário semanal nova (horários, Aula principal, PC/PM, observações, impressão em tabela com matérias em folha separada); licença GPL v3 com termos adicionais. Interface: editor de documentos mais limpo, caixas que crescem, menu recolhível com Recentes, atalhos (Ctrl+S, Ctrl+K, Alt+N), prévia antes de exportar, áreas de toque maiores, redesenho só do conteúdo. Novas: chamada rápida, roteiro do substituto, ficha de emergência e autorização, saúde e segurança, entrevista com a família, estudo de criança, contatos com as famílias, comunicados, repertório, avaliação da época, dias letivos e carga horária, festas do ano, lista de materiais, conferência dos textos do boletim |
| 1.5.2 | 05/11/2026 | Revisão geral: busca também nos documentos (planos, diários, PEI, combinados), nos reforços e no currículo; “Ir para o diário” e contagem de dias preenchidos na lista de épocas; a virada do ano leva as matérias do horário semanal; a Biblioteca acrescenta verbetes novos que faltam em arquivos antigos; teste de tela vazia em todas as telas e relatórios; manual (30 partes) e especificação atualizados |
| 1.5.1 | 05/11/2026 | Rascunhos de todos os anos de uma vez; links do plano de época para Currículo e BNCC e para colar épocas; matérias do ano com Professor de Classe ou de Matéria e horário semanal impressa; período anual na observação e no conselho; lista dos alunos com colunas escolhidas; vivência separada em antes (famílias) e depois (relatório) |
| 1.5 | 05/11/2026 | Planejamento anual e Plano de época (referência por ano e documento da turma, datas e diário pelo calendário, horário semanal); conteúdo programático de referência; épocas de referência do 1º ao 9º ano; PEI; reforço com bilhete; combinados da turma com versões; aniversariantes; poemas; pauta da reunião; informações completas da vivência; fontes dos documentos impressos; nome do arquivo com data e hora; Biblioteca com “Para a estruturação do ensino” |
| 1.4.2 | 04/11/2026 | Android: o seletor abre direto os arquivos do sistema (tipos de documento), em vez de Câmera e Galeria, com o `.tecela` habilitado |
| 1.4.1 | 04/11/2026 | Correção: no celular (Android, iPhone, iPad), o arquivo `.tecela` aparecia cinza e não podia ser aberto; agora o seletor mostra todos os arquivos e a Tecelã confere o conteúdo |
| 1.4 | 04/11/2026 | Computação com o texto oficial, objeto de conhecimento, explicação e exemplos, mais as habilidades por etapa; BNCC como categoria de leitura na Biblioteca; novo verbete com "Inserir na Biblioteca" e escolha de categoria; excluir (próprios) e ocultar (originais) verbetes; Cadastros com botão Excluir/Arquivar e "onde é usado"; `continuar.md` e `README.md` no lugar dos `.txt` |
| 1.3 | 03/11/2026 | Currículo da Biblioteca conferido; Computação (resumida); exceções em eventos que se repetem; slogan nos logotipos |
| 1.2 | 03/11/2026 | Tela inicial e arquivo `.tecela`; importador dentro do app; observação do período; poema do ano; conselho de classe; relatórios reorganizados; atalhos; revisão geral |
| 1.1 | 03/11/2026 | Cadastros, pontos de atenção, calendário, vivências, tarefas, currículo e BNCC, relatórios de evolução |
| 1.0 | 02/11/2026 | Primeira versão completa |
