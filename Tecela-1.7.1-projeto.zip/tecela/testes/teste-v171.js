// Testes da versão 1.7.1: avisos de contato (sugestões, novas versões e BNCC) e link das versões.
// Uso: LOG=log.txt node testes/teste-v171.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), p = await (await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR' })).newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const LINK = 'https://github.com/MarcioWillians/tecela/releases/latest', NAO = 'Não envie dados de crianças, seus ou da entidade, nem prints com nomes.';
  await p.goto(APP); await p.waitForTimeout(400);
  certo(/Versão 1\.7\.1/.test(await p.textContent('.versao')), 'tela inicial mostra a versão 1.7.1');
  await p.click('[data-a=contatoApp]'); await p.waitForSelector('#modais .modal'); let m = p.locator('#modais .modal').last(), t = await m.textContent();
  certo(/Sugestões e novas versões/.test(t) && t.includes('marciowillians@gmail.com') && t.includes(NAO) && /Para atualizar/.test(t) && /mesma pasta, com o mesmo nome/.test(t), 'link da tela inicial abre o aviso de sugestões e novas versões');
  certo(await m.locator('a[href="' + LINK + '"][target=_blank]').count() === 1 && await m.locator('a[href^="mailto:marciowillians@gmail.com"]').count() === 1, 'aviso com o link das versões (abre em outra aba) e o e-mail');
  await m.locator('button.pri').click(); await p.waitForTimeout(200);
  await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  await p.evaluate(() => { UI.aba.curric = 'bncc'; ir('curric'); }); t = await p.textContent('#app');
  certo(/Sobre a BNCC nesta versão/.test(t) && /homologada \(2017\/2018\)/.test(t) && t.includes(NAO), 'aviso da BNCC no alto da aba BNCC');
  await p.evaluate(() => ir('biblio', 'bncc:sobre')); t = await p.textContent('#app');
  certo(/Sobre a BNCC nesta versão/.test(t) && t.includes('marciowillians@gmail.com'), 'aviso da BNCC no verbete “Como ler a BNCC na Tecelã”');
  await p.evaluate(() => ir('ajuda', null, 'sobre')); t = await p.textContent('#app');
  certo(/Sobre, sugestões e versões/.test(t) && /Você está usando a versão 1\.7\.1/.test(t) && t.includes(NAO) && await p.locator('#app a[href="' + LINK + '"]').count() >= 1, 'Ajuda → Sobre, sugestões e versões com o aviso');
  certo(await p.locator('nav a[data-aba=sobre], .rodape a[data-aba=sobre], a[data-aba=sobre]').count() >= 1, 'link “Sugestões e novas versões” no rodapé do menu');
  await p.evaluate(() => { UI.aba.ajuda = 'manual'; ir('ajuda'); }); t = await p.textContent('#app');
  certo(/Como envio uma sugestão ou vejo se há versão nova\?/.test(t) && await p.locator('#txtAjuda a[href="' + LINK + '"]').count() >= 1, 'manual com a pergunta sobre sugestões e novas versões');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
