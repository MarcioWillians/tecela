/* ==========================================================================
   Tecelã — casca, entrada (boas-vindas, senha, saída), painel e turma/alunos.
   ========================================================================== */
'use strict';
const UI = { tela: 'painel', aba: {}, sub: null, filtro: {} };
const GRUPOS = [
  ['Dia a dia', [['painel', 'Painel', '✿'], ['anot', 'Anotações', '✎'], ['obs', 'Observação do período', '◎'], ['faltas', 'Faltas', '✓']]],
  ['Documentos', [['bol', 'Boletins', '❦'], ['atas', 'Atas', '❏'], ['conselho', 'Conselho de classe', '⚖'], ['perfis', 'Perfil do aluno', '☺'], ['pei', 'PEI', '✦'], ['acomp', 'Acompanhamento', '❂'], ['relat', 'Relatórios', '▥']]],
  ['Planejar', [['planej', 'Planejamento', '◫'], ['repert', 'Repertório', '♫'], ['curric', 'Currículo e BNCC', '❖'], ['agenda', 'Calendário', '▦'], ['tarefas', 'Tarefas', '☑']]],
  ['A turma', [['turma', 'Turma e alunos', '◍'], ['viv', 'Vivências', '✺'], ['reforco', 'Reforço', '✚'], ['comunic', 'Comunicados', '✉'], ['combinados', 'Combinados', '❀']]],
  ['Ajustar', [['biblio', 'Biblioteca', '❧'], ['cadastros', 'Cadastros', '☰'], ['timbrado', 'Papel timbrado', '▤'], ['ajustes', 'Ajustes e arquivo', '⚙'], ['ajuda', 'Ajuda', '?']]]];
const TELAS = GRUPOS.flatMap(g => g[1]);
const MOVEL = ['painel', 'anot', 'obs', 'bol'];
const SVG_LOGO = { h: '__LOGO_H__', v: '__LOGO_V__', i: '__LOGO_I__' };
const PRINCIPIO = 'O perfil não é um rótulo nem um diagnóstico fechado. É um retrato vivo, revisto periodicamente, que serve para o professor compreender a criança e o grupo e, a partir disso, ajustar a sua atuação pedagógica.';
const AVISO_LGPD = '<b>Seus dados ficam só neste aparelho.</b> A Tecelã guarda as informações apenas neste navegador, protege-as com senha e criptografia e não as envia para nenhum servidor. O app funciona assim para preservar dados sensíveis de crianças e de suas famílias, em respeito à Lei Geral de Proteção de Dados (Lei nº 13.709/2018). Por isso, use “💾 Salvar” com frequência e mantenha o arquivo .tecela em local protegido: se este navegador for limpo, os dados só poderão ser recuperados a partir dele.';

/* ---------- ajudantes de dados ---------- */
const turmaAtual = () => IX.turmas[CFG.prefs.turmaId] || null;
const rotuloTurma = t => t ? t.serie + 'º ano ' + (t.letra || '') + ' de ' + t.ano : '';
const matsDaTurma = tid => D.matriculas.filter(m => m.turmaId === tid);
const alunosDaTurma = tid => matsDaTurma(tid).map(m => IX.alunos[m.alunoId]).filter(Boolean).sort(ordemNome);
const matricula = (tid, aid) => D.matriculas.find(m => m.turmaId === tid && m.alunoId === aid);
const refTurma = t => t && t.ano < new Date().getFullYear() ? t.ano + '-12-01' : hojeISO();
function turmasOrdenadas() { return D.turmas.slice().sort((a, b) => b.ano - a.ano || a.serie - b.serie || String(a.letra).localeCompare(String(b.letra))); }
function cadeiaTurmas(t) { const c = []; let x = t; const vis = {}; while (x && !vis[x.id]) { vis[x.id] = 1; c.unshift(x); x = IX.turmas[x.origemId]; } return c; }
function ir(tela, sub, aba) { UI.tela = tela; UI.sub = sub || null; if (aba) UI.aba[tela] = aba; render(); window.scrollTo(0, 0); }
A.ir = d => ir(d.t, d.sub || null, d.aba);
A.aba = d => { UI.aba[UI.tela] = d.v; UI.sub = null; render(); };
const abas = (lista, atual) => '<div class="abas">' + lista.map(([k, r]) => '<button data-a="aba" data-v="' + k + '" class="' + (atual === k ? 'on' : '') + '">' + r + '</button>').join('') + '</div>';
const vazio = (txt, btn) => '<div class="vazio"><div class="aq"></div><p>' + txt + '</p>' + (btn || '') + '</div>';

/* ---------- casca ----------
   A casca (menu lateral, topo) é montada uma vez; a cada mudança só o conteúdo da tela é redesenhado. O menu
   mantém a posição da rolagem, e grupos recolhidos e telas recentes ficam no menu. */
const htmlNav = () => {
  const fech = CFG.prefs.navFechados || [], rec = (UI.recentes || []).filter(k => k !== UI.tela && TELAS.some(x => x[0] === k)).slice(0, 4);
  const bt = ([k, r, ic]) => '<button data-a="ir" data-t="' + k + '" class="' + (UI.tela === k ? 'on' : '') + '" title="' + r + '"><span class="ic">' + ic + '</span><span class="rot">' + r + '</span></button>';
  return GRUPOS.map(([g, xs]) => { const aberto = !fech.includes(g) || xs.some(x => x[0] === UI.tela); return '<button class="grupo' + (aberto ? '' : ' fechado') + '" data-a="navGrupo" data-g="' + e(g) + '" aria-expanded="' + aberto + '">' + g + '</button>' + (aberto ? xs.map(bt).join('') : ''); }).join('') +
    (rec.length ? '<div class="grupo">Recentes</div>' + rec.map(k => bt(TELAS.find(x => x[0] === k))).join('') : '');
};
A.navGrupo = async d => { const f = (CFG.prefs.navFechados || []).slice(), i = f.indexOf(d.g); if (i < 0) f.push(d.g); else f.splice(i, 1); await prefs({ navFechados: f }); render(); };
const htmlTopo = t => '<div class="turma">' + (turmasVisiveis().length ? '<select data-c="trocaTurma" aria-label="Turma">' + turmasVisiveis().map(x => '<option value="' + x.id + '"' + (t && x.id === t.id ? ' selected' : '') + '>' + e(rotuloTurma(x)) + '</option>').join('') + '</select>' : '') + '</div>' +
  '<div class="linha"><input type="search" class="busca" data-c="busca" placeholder="Buscar…  (Ctrl+K)" aria-label="Buscar em tudo" value="' + e(UI.tela === 'busca' ? UI.filtro.busca || '' : '') + '"><button class="btn peq" data-a="manualEm" data-id="m-' + UI.tela + '" title="Ajuda desta tela">?</button><button class="btn peq' + (CFG.prefs.pendente && !SE.demo ? ' pri' : '') + '" data-a="copia" title="' + e((CFG.prefs.arquivoNome ? 'Salvar em ' + CFG.prefs.arquivoNome : 'Salvar em um arquivo') + ' (Ctrl+S)') + '">💾 Salvar</button><button class="btn peq" data-a="sair">Sair</button></div>' + htmlEstadoSalvo();
/* indicador discreto: o que se digita é gravado sozinho neste aparelho; o arquivo é a cópia que vale */
function htmlEstadoSalvo() {
  if (SE.demo) return '<button class="estado-salvo" data-a="sobreSalvar">Modelo de demonstração: nada é salvo em arquivo</button>';
  const hm = d => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), u = CFG.prefs.ultimaCopia;
  const arq = !u ? 'ainda não salvo em arquivo' : 'arquivo salvo ' + quandoFoi(u);
  return '<button class="estado-salvo' + (CFG.prefs.pendente ? ' pend' : '') + '" data-a="sobreSalvar" title="Como a Tecelã salva o seu trabalho"><span class="ponto"></span>' + (SE.memoria ? 'Só na memória (computador de terceiros)' : '✓ Salvo neste aparelho' + (SE.salvoAs ? ' às ' + hm(SE.salvoAs) : '')) + ' · ' + arq + (CFG.prefs.pendente ? ' · falta salvar no arquivo' : '') + '</button>';
}
function quandoFoi(iso) { const d = new Date(iso), h = new Date(), dias = Math.floor((new Date(h.toDateString()) - new Date(d.toDateString())) / 864e5); return dias <= 0 ? 'hoje às ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : dias === 1 ? 'ontem' : 'há ' + dias + ' dias'; }
const atualizarEstadoSalvo = () => { const b = $('.estado-salvo'); if (b) b.outerHTML = htmlEstadoSalvo(); const c = $('.topo [data-a=copia]'); if (c) c.classList.toggle('pri', !!CFG.prefs.pendente && !SE.demo); };
const TEXTO_SALVAR = '<p><b>O que você digita é gravado sozinho, neste aparelho.</b> Não há botão para isso: cada campo é gravado no armazenamento do navegador (o IndexedDB) assim que você digita. Por isso, ao sair sem salvar no arquivo, nada se perde de imediato: ao abrir a Tecelã de novo, neste mesmo navegador, tudo estará lá.</p>' +
  '<p><b>Mas essa cópia do navegador pode se perder</b> se os dados de navegação forem limpos (“limpar histórico”, “limpar dados dos sites”), se você usar janela anônima, trocar de navegador ou de computador, se o aparelho ficar sem espaço ou, no iPhone e no iPad, se a Tecelã ficar vários dias sem ser aberta (o Safari apaga os dados de sites pouco usados).</p>' +
  '<p><b>O arquivo .tecela é a cópia que vale.</b> Use 💾 Salvar (ou Ctrl+S) ao terminar o trabalho: o arquivo pode ficar no pendrive ou na nuvem, ser aberto em outro aparelho e é o que permite recuperar tudo. Com a senha ligada, ele vai criptografado.</p>';
A.sobreSalvar = () => informar('Como a Tecelã salva o seu trabalho', TEXTO_SALVAR);
const htmlMovel = () => MOVEL.map(k => { const [, r, ic] = TELAS.find(x => x[0] === k); return '<button data-a="ir" data-t="' + k + '" class="' + (UI.tela === k ? 'on' : '') + '"><span class="ic">' + ic + '</span><span>' + r.split(' ')[0] + '</span></button>'; }).join('') + '<button data-a="mais" class="' + (MOVEL.includes(UI.tela) ? '' : 'on') + '"><span class="ic">☰</span><span>Mais</span></button>';
const htmlRodape = () => 'Tecelã ' + VERSAO + '<br>' + (SE.memoria ? 'Modo computador de terceiros<br>' : '') + (SE.demo ? '' : '<a href="#" data-a="abrirModelo">Modelo de demonstração</a><br>') + '<a href="#" data-a="ir" data-t="ajuda" data-aba="creditos">Créditos e licenças</a><br><a href="#" data-a="ir" data-t="ajuda" data-aba="sobre">Sugestões e novas versões</a>';
function render() {
  if (!SE.app) return;
  const chave = UI.tela + '|' + UI.sub + '|' + UI.aba[UI.tela], y = window.scrollY, mesma = render._ult === chave; render._ult = chave;
  if (UI.recentes === undefined) UI.recentes = [];
  if (UI.recentes[0] !== UI.tela) { UI.recentes = [UI.tela].concat(UI.recentes.filter(k => k !== UI.tela)).slice(0, 5); }
  aplicarTema();
  const t = turmaAtual();
  let corpo; try { corpo = (T[UI.tela] || T.painel)(); } catch (x) { console.error(x); corpo = '<div class="alerta verm">Erro ao montar a tela: ' + e(x.message) + '</div>'; }
  if (!$('#app > .casca') || render._demo !== SE.demo) {
    render._demo = SE.demo; render._nav = null;
    document.body.classList.toggle('com-faixa', !!SE.demo);
    $('#app').innerHTML = (SE.demo ? '<div class="faixa-demo">Modelo de demonstração — dados fictícios <button class="btn peq" data-a="restaurarDemo">Restaurar o modelo</button><button class="btn peq" data-a="apagarDemo">Apagar o modelo</button><button class="btn peq" data-a="sairDemo">Sair do modelo</button></div>' : '') +
      '<div class="casca"><aside class="lado"><div class="marca" title="Tecelã">' + SVG_LOGO.h + '</div><nav class="nav"></nav><div class="rodape"></div></aside><nav class="barra-movel"></nav><button class="fab" data-a="anotar" title="Anotar rapidamente (Alt+N)">✎ <span>Anotar</span></button><main class="principal"><div class="topo"></div><div id="corpo"></div></main></div>';
    if (SE.demo) document.documentElement.style.setProperty('--faixa', $('.faixa-demo').offsetHeight + 'px');
  }
  const nav = $('.lado .nav'), lado = $('.lado'), sl = lado.scrollTop, hn = htmlNav();
  if (render._nav !== hn) { nav.innerHTML = hn; render._nav = hn; lado.scrollTop = sl; }
  const rod = htmlRodape(); if (render._rod !== rod) { $('.lado .rodape').innerHTML = rod; render._rod = rod; }
  $('.barra-movel').innerHTML = htmlMovel();
  $('.fab').hidden = !(UI.tela !== 'anot' && t);
  $('.principal .topo').innerHTML = htmlTopo(t);
  $('#corpo').innerHTML = corpo; autoTamanho($('#corpo'));
  if (mesma) window.scrollTo(0, y);
  const on = $('.lado .nav button.on'); if (on && !mesma) { const r = on.getBoundingClientRect(), rl = lado.getBoundingClientRect(); if (r.top < rl.top || r.bottom > rl.bottom) on.scrollIntoView({ block: 'nearest' }); }
  if (T[UI.tela + '_pos']) T[UI.tela + '_pos']();
}
/* caixas de texto crescem com o texto (até 70% da altura da tela) */
const ajustarAltura = ta => { if (!ta.offsetParent) return; ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight + 2, innerHeight * .7) + 'px'; ta.style.overflowY = ta.scrollHeight + 2 > innerHeight * .7 ? 'auto' : 'hidden'; };
function autoTamanho(raiz) { const ts = [...(raiz || document).querySelectorAll('textarea')].filter(ta => ta.offsetParent), lim = innerHeight * .7; ts.forEach(ta => { ta.classList.add('auto'); ta.style.height = 'auto'; }); const hs = ts.map(ta => ta.scrollHeight + 2); ts.forEach((ta, i) => { ta.style.height = Math.min(hs[i], lim) + 'px'; ta.style.overflowY = hs[i] > lim ? 'auto' : 'hidden'; }); }
document.addEventListener('input', ev => { if (ev.target.tagName === 'TEXTAREA' && ev.target.classList.contains('auto')) ajustarAltura(ev.target); });
document.addEventListener('toggle', ev => { if (ev.target.tagName === 'DETAILS') autoTamanho(ev.target); }, true);
/* turmas arquivadas não aparecem no seletor (a não ser a atual) */
const turmasVisiveis = () => turmasOrdenadas().filter(x => !x.arquivada || x.id === CFG.prefs.turmaId);
/* atalhos de teclado */
document.addEventListener('keydown', ev => {
  if (!SE.app || $('#modais .modal')) return; const k = ev.key.toLowerCase();
  if ((ev.ctrlKey || ev.metaKey) && k === 's') { ev.preventDefault(); descarregarFila().then(() => fazerCopia()); }
  else if ((ev.ctrlKey || ev.metaKey) && k === 'k') { ev.preventDefault(); const b = $('.busca'); if (b) { b.focus(); b.select(); } }
  else if (ev.altKey && k === 'n' && turmaAtual()) { ev.preventDefault(); A.anotar({}); }
});
/* o botão ✎ Anotar encolhe enquanto se rola a página, para não cobrir botões */
let tFab = null;
window.addEventListener('scroll', () => { const f = $('.fab'); if (!f) return; f.classList.add('compacto'); clearTimeout(tFab); tFab = setTimeout(() => f.classList.remove('compacto'), 900); }, { passive: true });
A.mais = () => dlg({ titulo: 'Menu', ok: false, cancelar: 'Fechar', corpo: GRUPOS.map(([g, xs]) => '<p class="dica" style="margin:.6rem 0 .2rem">' + g + '</p><div class="menu-mais">' + xs.map(([k, r, ic]) => '<button type="button" class="btn" data-x="c" data-a="ir" data-t="' + k + '"><span class="ic">' + ic + '</span> ' + r + '</button>').join('') + '</div>').join('') });
C_.busca = el => { UI.filtro.busca = el.value.trim(); if (UI.filtro.busca.length < 2) return; if (UI.tela !== 'busca') { UI.voltarBusca = UI.tela; } ir('busca'); const i = $('.busca'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } };
C_.trocaTurma = async el => { await prefs({ turmaId: el.value }); UI.sub = null; render(); };
A.copia = () => fazerCopia();
A.sair = async () => {
  await descarregarFila();
  if (SE.demo) return A.sairDemo();
  const v = await dlg({ titulo: 'Sair da Tecelã', ok: false, cancelar: 'Voltar', corpo: (CFG.prefs.pendente ? '<p>Há alterações que ainda não foram salvas no arquivo' + (CFG.prefs.arquivoNome ? ' em <b>' + e(CFG.prefs.arquivoNome) + '</b>' : '') + '.</p>' : '<p>Tudo está salvo' + (CFG.prefs.arquivoNome ? ' em <b>' + e(CFG.prefs.arquivoNome) + '</b>' : '') + '.</p>'), extra: '<button type="button" class="btn" data-x="sem">Sair' + (CFG.prefs.pendente ? ' sem salvar no arquivo' : '') + '</button>' + (CFG.prefs.pendente ? '<button type="button" class="btn pri" data-x="com">Salvar e sair</button>' : '') });
  if (!v) return;
  if (v._botao === 'com') { const ok = await fazerCopia(); if (!ok) return; }
  telaSaiu();
};

/* ---------- entrada ---------- */
function telaEntrada(html) { SE.app = false; $('#app').innerHTML = '<div class="entrada"><div class="caixa">' + html + '</div></div>'; }
/* tela inicial, como no PazNoBolso: continuar, abrir arquivo, novo, modelo */
function telaInicio(temDados) {
  SE.temDados = temDados; const p = CFG.prefs;
  telaEntrada('<div class="logo">' + SVG_LOGO.v + '</div><p class="versao">Versão ' + VERSAO + ' · ' + DATA_VERSAO + ' · <a href="#" data-a="contatoApp">Sugestões e novas versões</a></p>' + (!p.lgpdOk ? '<p style="text-align:center">Boas-vindas! A Tecelã ajuda a professora e o professor de classe a registrar anotações, atas, observações e perfis e a tecer, com esses fios, o Boletim Descritivo de cada criança.</p><div class="aviso-lgpd">' + AVISO_LGPD + '</div><label class="ck"><input type="checkbox" id="ckLgpd"> <span>Li e entendi como meus dados são guardados.</span></label>' : '') +
    (SE.semBanco ? '<p class="alerta verm">Este navegador não permitiu guardar dados nesta página. A Tecelã vai funcionar só na memória: salve o arquivo antes de fechar.</p>' : '') +
    '<div class="opcoes">' + (temDados ? '<button class="btn pri" data-a="continuar">Continuar' + (p.arquivoNome ? ': ' + e(p.arquivoNome) : '') + '</button>' + (p.ultimaCopia ? '<p class="dica" style="text-align:center;margin:-.3rem 0 .2rem">salvo em ' + new Date(p.ultimaCopia).toLocaleString('pt-BR') + (p.pendente ? ' · há alterações ainda não salvas no arquivo' : '') + '</p>' : '') : '') +
    '<button class="btn' + (temDados ? '' : ' pri') + '" data-a="abrirArquivo">Abrir um arquivo da Tecelã</button>' +
    '<button class="btn" data-a="novo">Novo</button><button class="btn" data-a="novo" data-bol="1">Novo a partir de boletins anteriores (.docx)</button>' +
    '<button class="btn" data-a="entrarDemo">Modelo de demonstração</button><button class="btn" data-a="terceiros">Computador de terceiros: abrir um arquivo sem gravar neste aparelho</button></div><p class="autoria">' + e(AUTORIA) + ' <a href="#" data-a="verLicenca">Licença</a></p>');
}
A.verLicenca = () => informar('Licença da Tecelã', TEXTO_LICENCA);
const lgpdMarcado = () => { const c = $('#ckLgpd'); if (c && !c.checked) { aviso('Marque que leu o aviso sobre os dados.'); return false; } return true; };
A.continuar = async () => { if (CFG.cripto) return telaSenha(); await carregarTudo(); await depoisDeCarregar(); };
const avisoSubstituir = async (oque) => !SE.temDados || await confirmar(oque, 'Os dados que estão neste aparelho' + (CFG.prefs.arquivoNome ? ' (' + e(CFG.prefs.arquivoNome) + ')' : '') + ' serão substituídos.' + (CFG.prefs.pendente ? ' <b>Há alterações que ainda não foram salvas no arquivo</b>: se precisar delas, toque em Cancelar, entre em “Continuar” e use “💾 Salvar”.' : ' Eles estão salvos no arquivo.'), 'Continuar');
A.abrirArquivo = async () => { if (!lgpdMarcado()) return; if (!(await avisoSubstituir('Abrir outro arquivo?'))) return; if (await restaurarCopia(false)) { await prefs({ lgpdOk: true }); await entrarNoApp(); } };
A.novo = async d => {
  if (!lgpdMarcado()) return; if (!(await avisoSubstituir('Começar um arquivo novo?'))) return;
  if (DB) for (const s of STORES) await idbLimpar(s); zerarMemoria(); CFG = { prefs: Object.assign({}, PREFS_PADRAO, { lgpdOk: true }), escola: {}, cripto: null }; SE.dk = null; SE.arq = null; await gravarConfig('prefs');
  const s = await dlg({ titulo: 'Proteger com senha?', ok: 'Ligar a senha', cancelar: 'Agora não', corpo: '<p>A senha criptografa todos os dados deste aparelho e do arquivo guardado. É o recomendado para dados de crianças.</p><p class="dica">Se escolher “Agora não”, a Tecelã vai lembrar você no Painel.</p>' });
  if (s) await ligarSenha();
  await primeiraConfiguracao({ importar: !!(d && d.bol) });
};
async function primeiraConfiguracao(opc) {
  opc = opc || {};
  const b = await dlg({ titulo: 'Biblioteca Waldorf', ok: 'Continuar', cancelar: false, corpo: '<p>A biblioteca reúne conhecimentos e princípios da pedagogia Waldorf e da Antroposofia que servem de base para os relatórios e para o perfil do aluno.</p><label class="ck"><input type="radio" name="b" value="pronta" checked> <span><b>Começar com a biblioteca pronta</b> (editável)</span></label><label class="ck"><input type="radio" name="b" value="branco"> <span><b>Começar em branco</b>, com os tópicos para escrever</span></label>' });
  carregarBiblioteca(b && b.b === 'branco' ? 'branco' : 'pronta'); for (const r of D.biblioteca) await salvar('biblioteca', r);
  await prefs({ biblio: b && b.b === 'branco' ? 'branco' : 'pronta' });
  if (opc.importar) {
    const v = await dlg({ titulo: 'Sua escola', ok: 'Continuar', cancelar: false, corpo: campo('Nome da escola', '<input name="escola" autofocus>') + '<p class="dica">A seguir, escolha os boletins .docx dos anos anteriores. As turmas e os alunos serão criados a partir deles.</p>' });
    CFG.escola = { nome: v.escola.trim() }; await gravarConfig('escola');
    await salvar('timbrado', { id: 'atas', cab: CFG.escola.nome, rod: '', papel: 'A4', margens: { s: 20, i: 20, e: 25, d: 20 }, logoPos: 'esquerda', logoAlt: 18 });
    SE.app = true; UI.tela = 'importar'; UI.sub = null; render(); return;
  }
  const t = await dlg({ titulo: 'Sua escola e sua turma', ok: 'Criar turma', cancelar: false, corpo: campo('Nome da escola', '<input name="escola" autofocus>') + '<div class="duas">' + campo('Série', '<select name="serie">' + seriesVisiveis().map(n => '<option value="' + n + '">' + n + 'º ano</option>').join('') + '</select>') + campo('Letra da turma', '<input name="letra" value="A">') + '</div><div class="duas">' + campo('Ano letivo', '<input name="ano" type="number" value="' + new Date().getFullYear() + '">') + campo('Nome', '<input name="prof">') + '</div>' + campo('Professora ou professor', '<select name="gen" required><option value="">— escolha —</option><option value="a">Professora</option><option value="o">Professor</option></select>', 'Usado nos documentos: “Professora:” ou “Professor:”, “a professora” ou “o professor”.'), validar: v => !v.gen ? 'Escolha professora ou professor.' : v.ano > 1990 ? null : 'Informe o ano letivo.' });
  CFG.escola = { nome: t.escola.trim() }; await gravarConfig('escola');
  const tu = await salvar('turmas', { serie: Number(t.serie), letra: t.letra.trim(), ano: Number(t.ano), professora: t.prof.trim(), genProf: t.gen, boletim: { textos: {} } });
  await salvar('timbrado', { id: 'atas', cab: CFG.escola.nome, rod: '', papel: 'A4', margens: { s: 20, i: 20, e: 25, d: 20 }, logoPos: 'esquerda', logoAlt: 18 });
  await prefs({ turmaId: tu.id });
  entrarNoApp('turma');
}
A.terceiros = async () => {
  if (!lgpdMarcado()) return;
  SE.memoria = true; const f = await escolherArquivo(ACEITA_TECELA); if (!f) { SE.memoria = false; return; }
  try { const r = await lerCopia(await f.text()); if (!r) { SE.memoria = false; return; } await aplicarCopia(r); entrarNoApp(); aviso('Modo computador de terceiros: nada será gravado neste aparelho.'); }
  catch (x) { SE.memoria = false; informar('Não foi possível abrir', '<p>' + e(x.message) + '</p>'); }
};
function telaSenha(msg) {
  const c = CFG.cripto;
  telaEntrada('<div class="logo">' + SVG_LOGO.v + '</div><p class="versao">Versão ' + VERSAO + ' · ' + DATA_VERSAO + ' · <a href="#" data-a="contatoApp">Sugestões e novas versões</a></p>' + (msg ? '<p class="alerta">' + e(msg) + '</p>' : '') + (c.dica ? '<p class="dica">Dica da senha: ' + e(c.dica) + '</p>' : '') +
    '<form id="fSenha">' + campo('Senha', '<input type="password" id="senha" autofocus autocomplete="current-password">') + '<label class="ck"><input type="checkbox" id="ckRec"> <span>Esqueci a senha, vou usar a chave de recuperação</span></label><label class="cp oculto" id="cpRec"><span class="r">Chave de recuperação</span><input id="chaveRec"></label><p class="erro" id="erroSenha" style="color:var(--verm)"></p><div class="opcoes"><button class="btn pri">Entrar</button></div></form>' +
    '<p class="dica" style="margin-top:1rem"><a href="#" data-a="voltarInicio">← Voltar à tela inicial</a></p>');
  $('#ckRec').addEventListener('change', ev => $('#cpRec').classList.toggle('oculto', !ev.target.checked));
  $('#fSenha').addEventListener('submit', async ev => {
    ev.preventDefault(); const rec = $('#ckRec').checked;
    try { SE.dk = await abrirComSenha(c, $('#senha').value, rec ? $('#chaveRec').value : null); }
    catch (x) { $('#erroSenha').textContent = rec ? 'Chave incorreta.' : 'Senha incorreta.'; return; }
    SE.travado = false; await carregarTudo();
    if (rec) { const v = await definirSenha('Definir nova senha', 'A chave de recuperação foi aceita. Defina uma senha nova. A chave continua a mesma.'); if (v) { const a = await embrulhar(SE.dk, v.s1); CFG.cripto.s1 = a.s; CFG.cripto.w1 = a.w; CFG.cripto.dica = v.dica.trim(); await gravarConfig('cripto'); } }
    await depoisDeCarregar(); tocar(true);
  });
  setTimeout(() => $('#senha') && $('#senha').focus(), 50);
}
A.voltarInicio = () => iniciar();
function telaSaiu() {
  SE.saiu = true; zerarMemoria(); SE.dk = null; CHAVE_CACHE = null;
  telaEntrada('<div class="logo">' + SVG_LOGO.v + '</div><h2 style="text-align:center">Até breve!</h2><p style="text-align:center">Você saiu da Tecelã. ' + (SE.memoria ? 'Nada ficou gravado neste aparelho.' : 'Já pode fechar esta aba.') + '</p><div class="opcoes"><button class="btn pri" data-a="reentrar">Entrar de novo</button></div>');
}
A.reentrar = () => { SE.saiu = false; SE.memoria = false; iniciar(); };
async function entrarNoApp(tela) {
  SE.app = true; SE.saiu = false; if (tela) UI.tela = tela;
  if (!IX.turmas[CFG.prefs.turmaId] && D.turmas.length) CFG.prefs.turmaId = turmasOrdenadas()[0].id;
  if (!D.biblioteca.length && CFG.prefs.biblio !== 'branco' && !SE.demo) { carregarBiblioteca('pronta'); for (const r of D.biblioteca) await salvar('biblioteca', r); }
  for (const r of garantirCadastros()) await salvar('cadastros', r);
  if (SE.gravarPrefs) { SE.gravarPrefs = false; await gravarConfig('prefs'); }
  for (const r of sincronizarBiblioteca()) await salvar('biblioteca', r);
  aplicarComputacao();
  render(); tocar(true);
  for (const t of D.turmas.filter(t => !t.genProf)) {
    const v = await dlg({ titulo: 'Professora ou professor?', cancelar: false, ok: 'Confirmar', corpo: '<p>Na turma <b>' + e(rotuloTurma(t)) + '</b>' + (t.professora ? ', de ' + e(t.professora) : '') + ', quem dá aula é:</p><label class="ck"><input type="radio" name="g" value="a"> Professora</label><label class="ck"><input type="radio" name="g" value="o"> Professor</label><p class="dica">A Tecelã usa essa informação nos documentos.</p>', validar: v => v.g ? null : 'Escolha uma opção.' });
    t.genProf = v.g; await salvar('turmas', t);
  }
  if (D.turmas.length) render();
  setTimeout(verificarAvisos, 1500);
  if (!SE.demo && !SE.memoria && DB) { try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (x) { } }
}

/* ---------- PAINEL ---------- */
T.painel = () => {
  const t = turmaAtual(); let h = '<h1>Olá' + (t && t.professora ? ', ' + e(t.professora.split(' ')[0]) : '') + '</h1>';
  if (!SE.demo && !CFG.cripto && !SE.memoria) h += '<div class="alerta verm">A senha está desligada: os dados das crianças ficam legíveis para quem usar este aparelho. <button class="btn peq" data-a="ligarSenha">Ligar a senha</button></div>';
  if (!t) return h + vazio('Nenhuma turma cadastrada ainda.', '<button class="btn pri" data-a="ir" data-t="turma" data-aba="turma">Cadastrar turma</button>');
  const al = alunosDaTurma(t.id), atasR = D.atas.filter(a => a.turmaId === t.id && a.estado !== 'finalizado'), bols = boletinsAtuais(t.id), bolInc = al.filter(a => { const b = bols[a.id]; return !b || statusBoletim(b).incompleto; });
  const semPerfil = al.filter(a => { const p = ultimoPerfil(a.id); return !p || (Date.now() - new Date(p.data + 'T12:00')) > 183 * 864e5; });
  h += '<div class="grade"><div class="cartao"><div class="dica">Turma</div><div class="kpi">' + e(t.serie + 'º ano ' + (t.letra || '')) + '</div><div>' + t.ano + ' · ' + al.length + ' aluno' + (al.length === 1 ? '' : 's') + '</div></div>' +
    '<div class="cartao"><div class="dica">Arquivo</div><div class="kpi" style="font-size:1.1rem;word-break:break-all">' + (SE.demo ? 'modelo' : e(CFG.prefs.arquivoNome || 'ainda não salvo')) + '</div><div class="dica">' + (SE.demo ? '' : CFG.prefs.ultimaCopia ? 'salvo em ' + new Date(CFG.prefs.ultimaCopia).toLocaleString('pt-BR') : '') + (CFG.prefs.pendente && !SE.demo ? ' · há alterações não salvas no arquivo' : '') + '</div><button class="btn peq' + (CFG.prefs.pendente && !SE.demo ? ' pri' : '') + '" data-a="copia" style="margin-top:.4rem">💾 Salvar</button></div>' +
    '<div class="cartao"><div class="dica">Lançamento rápido</div><p style="margin:.2rem 0 .5rem">Registre uma observação sobre uma ou mais crianças, de qualquer tela.</p><div class="linha"><button class="btn pri peq" data-a="anotar">✎ Anotar</button><button class="btn peq" data-a="ir" data-t="obs">◎ Observar</button><button class="btn peq" data-a="ir" data-t="faltas">✓ Faltas</button><button class="btn peq" data-a="substituto" title="Roteiro do dia para quem vai substituir você">Roteiro para substituto</button></div></div></div>';
  h += cartaoChamada(t);
  h += painelProximos(t);
  const extras = pendenciasExtras(t);
  h += '<div class="cartao"><h3>Pendências</h3><ul>' + extras.map(x => '<li>' + x + '</li>').join('') +
    (atasR.length ? '<li><a href="#" data-a="ir" data-t="atas">' + atasR.length + ' ata' + (atasR.length > 1 ? 's' : '') + ' em rascunho</a></li>' : '') +
    (bolInc.length ? '<li><a href="#" data-a="ir" data-t="bol" data-aba="alunos">' + bolInc.length + (bolInc.length > 1 ? ' boletins' : ' boletim') + ' incompleto' + (bolInc.length > 1 ? 's' : '') + '</a></li>' : '') +
    (semPerfil.length ? '<li><a href="#" data-a="ir" data-t="perfis">' + semPerfil.length + ' perfi' + (semPerfil.length > 1 ? 's' : 'l') + ' sem revisão há mais de um semestre</a>: ' + e(semPerfil.map(primeiroNome).join(', ')) + '</li>' : '') +
    (!atasR.length && !bolInc.length && !semPerfil.length && !extras.length ? '<li>Nenhuma pendência.</li>' : '') + '</ul></div>';
  const prox = []; const hoje = new Date();
  al.forEach(a => { if (!a.nasc) return; [9, 12].forEach(n => { const d = new Date(a.nasc + 'T12:00'); d.setFullYear(d.getFullYear() + n); const dias = (d - hoje) / 864e5; if (dias >= -30 && dias <= 60) prox.push([a, n, d, dias]); }); });
  if (prox.length) h += '<div class="cartao"><h3>Passagens biográficas</h3><ul>' + prox.map(([a, n, d, dias]) => '<li><b>' + e(primeiroNome(a)) + '</b> ' + (dias < 0 ? 'fez' : 'faz') + ' ' + n + ' anos em ' + d.toLocaleDateString('pt-BR') + ' — ' + (n === 9 ? '<a href="#" data-a="verBib" data-id="rubicao">o Rubicão</a>' : '<a href="#" data-a="verBib" data-id="doze-anos">a passagem dos 12 anos</a>') + '</li>').join('') + '</ul></div>';
  const lim = (CFG.prefs.prazoEgressos || 5) * 365.25 * 864e5, velhos = D.alunos.filter(a => a.situacao !== 'ativo' && a.saida && Date.now() - new Date(a.saida + 'T12:00') > lim);
  if (velhos.length) h += '<div class="alerta">' + velhos.length + ' registro(s) de ex-alunos com mais de ' + CFG.prefs.prazoEgressos + ' anos. Avalie se ainda precisam ser guardados. <a href="#" data-a="ir" data-t="turma" data-aba="arquivo">Ver arquivo</a></div>';
  return h;
};
A.ligarSenha = async () => { if (await ligarSenha()) render(); };

/* ---------- TURMA E ALUNOS ---------- */
T.turma = () => {
  const aba = UI.aba.turma || 'alunos';
  let h = '<h1>Turma e alunos</h1>' + abas([['alunos', 'Alunos'], ['turma', 'Escola e turmas'], ['grade', 'Horário semanal'], ['virada', 'Virada do ano'], ['arquivo', 'Arquivo']], aba);
  return h + ({ alunos: abaAlunos, turma: abaTurma, grade: abaGrade, virada: abaVirada, arquivo: abaArquivo }[aba] || abaAlunos)();
};
function abaAlunos() {
  const t = turmaAtual(); if (!t) return vazio('Cadastre uma turma primeiro.', '<button class="btn pri" data-a="aba" data-v="turma">Cadastrar turma</button>');
  if (UI.sub && IX.alunos[UI.sub]) return formAluno(IX.alunos[UI.sub], t);
  const al = alunosDaTurma(t.id), ref = refTurma(t);
  let h = '<div class="linha"><button class="btn pri" data-a="novoAluno">+ Novo aluno</button><button class="btn" data-a="importarCSV">Importar planilha (CSV)</button><button class="btn" data-a="modeloCSV">Baixar modelo de planilha</button><button class="btn" data-a="exportarAlunos">Imprimir ou exportar a lista</button><button class="btn" data-a="ir" data-t="importar">Importar boletins anteriores (.docx)</button></div><p class="dica">' + e(rotuloTurma(t)) + ' · idades calculadas em ' + dataBR(ref) + '</p>';
  if (!al.length) return h + vazio('Nenhum aluno nesta turma ainda.');
  h += '<div class="cartao rolagem"><table class="tabela"><tr><th>Nome</th><th>Idade</th><th>Setênio</th><th>Responsáveis</th><th>Apoio</th></tr>' + al.map(a => { const m = idadeEm(a.nasc, ref); return '<tr class="clic" data-a="editarAluno" data-id="' + a.id + '"><td><b>' + e(a.nome) + '</b>' + (a.chamada ? ' <span class="dica">(' + e(a.chamada) + ')</span>' : '') + '</td><td>' + idadeTxt(m) + '</td><td>' + setenio(m) + '</td><td>' + e((a.responsaveis || []).map(r => r.nome).filter(Boolean).join(', ')) + '</td><td>' + (a.nee ? '<span class="etq viol">NEE</span> ' : '') + (a.acomp ? '<span class="etq">acomp. externo</span>' : '') + '</td></tr>'; }).join('') + '</table></div>';
  return h;
}
A.editarAluno = d => { UI.sub = d.id; render(); window.scrollTo(0, 0); };
A.novoAluno = async () => { const t = turmaAtual(); const a = await salvar('alunos', { nome: 'Novo aluno', genero: 'm', situacao: 'ativo', entrada: hojeISO(), responsaveis: [{ nome: '', parentesco: '', email: '', tel: '' }] }); await salvar('matriculas', { alunoId: a.id, turmaId: t.id, faltas: [] }); UI.sub = a.id; render(); setTimeout(() => { const i = $('[data-b="nome"]'); if (i) { i.focus(); i.select(); } }, 50); };
function formAluno(a, t) {
  const m = matricula(t.id, a.id) || {}, per = CFG.prefs.periodos || [];
  let h = '<div class="linha"><button class="btn" data-a="voltarSub">← Voltar à lista</button><span class="espaco"></span><button class="btn perigo" data-a="excluirAluno" data-id="' + a.id + '">Excluir aluno</button></div>';
  h += '<div class="cartao" data-rec="alunos:' + a.id + '"><h2>' + e(a.nome) + '</h2><div class="duas">' + campo('Nome completo', inp('nome', a.nome)) + campo('Nome de chamada', inp('chamada', a.chamada), 'Usado no marcador {nome} dos textos') + '</div><div class="duas">' + campo('Data de nascimento', inp('nasc', a.nasc, 'date', 'data-rr="1"')) + campo('Gênero (para os marcadores de texto)', sel('genero', a.genero, [['m', 'Masculino'], ['f', 'Feminino']])) + '</div>' +
    (a.nasc ? '<p class="dica">Idade em ' + dataBR(refTurma(t)) + ': ' + idadeTxt(idadeEm(a.nasc, refTurma(t))) + ' · ' + setenio(idadeEm(a.nasc, refTurma(t))) + '</p>' : '') +
    '<div class="duas">' + campo('Data de entrada na escola', inp('entrada', a.entrada, 'date')) + '<div>' + ck('nee', a.nee, 'Necessidades educacionais especiais') + ck('acomp', a.acomp, 'Acompanhamento externo (terapias, especialistas)') + '</div></div>' + campo('Observações', area('obs', a.obs)) +
    '<h3>Responsáveis</h3>' + (a.responsaveis || []).map((r, i) => '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:.5rem">' + campo('Nome', inp('responsaveis.' + i + '.nome', r.nome)) + campo('Parentesco', inp('responsaveis.' + i + '.parentesco', r.parentesco)) + campo('E-mail', inp('responsaveis.' + i + '.email', r.email, 'email')) + campo('Telefone', inp('responsaveis.' + i + '.tel', r.tel, 'tel')) + '</div>').join('') +
    '<button class="btn peq" data-a="addResp" data-id="' + a.id + '">+ Responsável</button></div>';
  h += cartaoSaude(a);
  h += '<div class="cartao" data-rec="alunos:' + a.id + '"><h3>Pontos de atenção</h3><p class="dica">Saúde, alergias, sono, acompanhamento terapêutico, família… São <b>sigilosos por padrão</b>: aparecem para você no boletim e no perfil, mas nunca são impressos. Desmarque “sigiloso” para permitir que apareçam na ficha individual exportada. Os tipos se ajustam em Cadastros.</p>' +
    (a.atencao || []).map((x, i) => '<div class="grade" style="grid-template-columns:1.3fr 2.4fr 1fr 1fr auto auto;gap:.5rem;align-items:end">' + campo('Tipo', sel('atencao.' + i + '.tipo', x.tipo, opcoesLista('atencao', '', x.tipo))) + campo('Descrição', inp('atencao.' + i + '.descricao', x.descricao)) + campo('Desde', inp('atencao.' + i + '.desde', x.desde, 'date')) + campo('Situação', sel('atencao.' + i + '.situacao', x.situacao || 'ativo', [['ativo', 'Ativo'], ['resolvido', 'Resolvido']])) + ck('atencao.' + i + '.sigiloso', x.sigiloso !== false, 'sigiloso') + '<button type="button" class="icone-btn" style="margin-bottom:.8rem" data-a="remAtencao" data-id="' + a.id + '" data-i="' + i + '" title="Remover">✕</button></div>').join('') +
    '<button class="btn peq" data-a="addAtencao" data-id="' + a.id + '">+ Ponto de atenção</button></div>';
  if (m.id) h += '<div class="cartao" data-rec="matriculas:' + m.id + '"><h3>Faltas em ' + t.ano + '</h3><p class="dica">Digite o total de faltas de cada período, ou use a tela <a href="#" data-a="ir" data-t="faltas">Faltas</a>, com a turma toda.</p><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))">' + per.map((p, i) => campo(e(p), inp('faltas.' + i, (m.faltas || [])[i], 'number', 'min="0"'))).join('') + '</div></div>';
  const pms = poemasDe(a.id);
  h += '<div class="cartao"><h3>Poemas do ano</h3>' + (pms.length ? pms.map(x => '<details><summary style="cursor:pointer">' + x.turma.serie + 'º ano (' + x.turma.ano + '): <i>' + e(x.titulo || 'sem título') + '</i></summary><p class="mao" style="white-space:pre-line">' + e(x.texto) + '</p></details>').join('') : '<p class="dica">Nenhum poema ainda. Escreva o deste ano em Boletins → Poema do ano.</p>') + '</div>';
  return h;
}
A.voltarSub = () => { UI.sub = null; render(); };
A.addAtencao = async d => { const a = IX.alunos[d.id]; a.atencao = (a.atencao || []).concat([{ id: uid(), tipo: (itensLista('atencao')[0] || {}).chave || 'outro', descricao: '', desde: hojeISO(), situacao: 'ativo', sigiloso: true }]); await salvar('alunos', a); render(); };
A.remAtencao = async d => { const a = IX.alunos[d.id]; if (!(await confirmar('Remover o ponto de atenção?', 'Se ele apenas deixou de ser necessário, prefira marcar a situação como “Resolvido”, para manter o histórico.', 'Remover'))) return; a.atencao.splice(Number(d.i), 1); await salvar('alunos', a); render(); };
A.abrirModelo = async () => { if (!(await confirmar('Abrir o modelo de demonstração?', 'Seus dados serão fechados com segurança enquanto você vê o modelo, que tem só dados fictícios. Ao sair do modelo, você volta a eles' + (CFG.cripto ? ' digitando a senha' : '') + '.', 'Abrir o modelo'))) return; A.entrarDemo(); };
A.addResp = async d => { const a = IX.alunos[d.id]; a.responsaveis = (a.responsaveis || []).concat([{ nome: '', parentesco: '', email: '', tel: '' }]); await salvar('alunos', a); render(); };
A.excluirAluno = async d => {
  const a = IX.alunos[d.id]; const ok = await confirmar('Excluir ' + e(a.nome) + '?', 'Serão apagados o cadastro, as matrículas, o perfil e as anotações que se referem só a esta criança. Atas e boletins finalizados são registros escolares e ficam guardados.', 'Excluir'); if (!ok) return;
  for (const m of D.matriculas.filter(m => m.alunoId === a.id)) await apagar('matriculas', m.id);
  for (const p of D.perfisAluno.filter(p => p.alunoId === a.id)) await apagar('perfisAluno', p.id);
  for (const n of D.anotacoes.filter(n => (n.alunos || []).includes(a.id))) { if (n.alunos.length === 1) await apagar('anotacoes', n.id); else { n.alunos = n.alunos.filter(x => x !== a.id); await salvar('anotacoes', n); } }
  for (const b of D.boletins.filter(b => b.alunoId === a.id && b.estado !== 'finalizado')) await apagar('boletins', b.id);
  if (D.boletins.some(b => b.alunoId === a.id) || D.atas.some(x => x.estado === 'finalizado')) { a.situacao = 'excluido'; a.saida = hojeISO(); a.responsaveis = []; a.obs = ''; await salvar('alunos', a); } else await apagar('alunos', a.id);
  UI.sub = null; render(); aviso('Aluno excluído.');
};
/* CSV */
/* lista dos alunos para imprimir ou exportar: o nome completo sempre; as outras colunas a professora escolhe */
const COLS_LISTA = [['chamada', 'Nome de chamada'], ['nasc', 'Data de nascimento'], ['idade', 'Idade'], ['genero', 'Gênero'], ['resp', 'Responsável'], ['tel', 'Telefone do responsável'], ['email', 'E-mail do responsável'], ['nee', 'Necessidades educacionais especiais'], ['acomp', 'Acompanhamento externo (terapias, especialistas)'], ['atencao', 'Pontos de atenção'], ['faltas', 'Faltas no ano']];
A.exportarAlunos = async () => {
  const t = turmaAtual(), al = alunosDaTurma(t.id), ref = refTurma(t), ant = UI.filtro.listaCols || ['chamada', 'nasc', 'resp', 'tel'];
  const v = await dlg({ titulo: 'Lista dos alunos', ok: 'Continuar', corpo: '<p>O nome completo entra sempre. Escolha as outras colunas:</p>' + COLS_LISTA.map(([k, r]) => '<label class="ck"><input type="checkbox" name="c" data-multi="1" value="' + k + '"' + (ant.includes(k) ? ' checked' : '') + '> <span>' + r + '</span></label>').join('') + '<p class="dica">Necessidades especiais, acompanhamento externo e pontos de atenção são dados sigilosos: use só quando a lista for para quem precisa deles.</p>' });
  if (!v) return; const cs = v.c || []; UI.filtro.listaCols = cs;
  const resp = a => (a.responsaveis || []).filter(r => r.nome || r.tel || r.email), val = {
    chamada: a => a.chamada || primeiroNome(a), nasc: a => dataBR(a.nasc), idade: a => idadeTxt(idadeEm(a.nasc, ref)), genero: a => a.genero === 'f' ? 'Feminino' : a.genero === 'm' ? 'Masculino' : '',
    resp: a => resp(a).map(r => r.nome + (r.parentesco ? ' (' + r.parentesco + ')' : '')).join('; '), tel: a => resp(a).map(r => r.tel).filter(Boolean).join('; '), email: a => resp(a).map(r => r.email).filter(Boolean).join('; '),
    nee: a => a.nee ? 'Sim' : '', acomp: a => a.acomp ? 'Sim' : '', atencao: a => (a.atencao || []).filter(x => x.situacao !== 'resolvido').map(x => nomeItem('atencao', x.tipo) + (x.descricao ? ': ' + x.descricao : '')).join('; '),
    faltas: a => String(((matricula(t.id, a.id) || {}).faltas || []).reduce((s, x) => s + (Number(x) || 0), 0)) };
  const cab = ['Nº', 'Nome completo'].concat(cs.map(k => COLS_LISTA.find(x => x[0] === k)[1])), linhas = al.map((a, i) => [String(i + 1), a.nome].concat(cs.map(k => val[k](a))));
  saidaDocumento({ nome: 'Alunos_' + t.serie + 'ano' + (t.letra || '') + '_' + t.ano, titulo: 'Alunos — ' + rotuloTurma(t), paisagem: cs.length > 4, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Alunos — ' + rotuloTurma(t) }, { t: 'p', txt: (t.professora ? profTit(t) + ': ' + t.professora + ' · ' : '') + al.length + ' alunos · ' + dataBR(hojeISO()) }, { t: 'tabela', cab, linhas }] }, { csv: { cab, linhas }, assunto: 'Lista de alunos — ' + rotuloTurma(t) });
};
A.modeloCSV = () => baixar('Tecela_modelo_alunos.csv', '﻿nome;chamada;nascimento;genero;responsavel;email;telefone\nAna Maria Exemplo;Ana;14/03/2017;F;Joana Exemplo;joana@exemplo.com;(11) 90000-0000\n', 'text/csv');
function lerCSV(txt) {
  txt = txt.replace(/^﻿/, ''); const sep = (txt.split('\n')[0].match(/;/g) || []).length >= (txt.split('\n')[0].match(/,/g) || []).length ? ';' : ',';
  const linhas = []; let cur = [], c = '', q = false;
  for (let i = 0; i < txt.length; i++) { const ch = txt[i]; if (q) { if (ch === '"' && txt[i + 1] === '"') { c += '"'; i++; } else if (ch === '"') q = false; else c += ch; } else if (ch === '"') q = true; else if (ch === sep) { cur.push(c); c = ''; } else if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; cur.push(c); c = ''; if (cur.some(x => x.trim())) linhas.push(cur); cur = []; } else c += ch; }
  cur.push(c); if (cur.some(x => x.trim())) linhas.push(cur); return linhas;
}
function dataCSV(s) { s = (s || '').trim(); let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); if (m) return m[3] + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0'); m = s.match(/^\d{4}-\d{2}-\d{2}$/); return m ? s : ''; }
A.importarCSV = async () => {
  const f = await escolherArquivo('.csv,text/csv,text/plain'); if (!f) return; const ls = lerCSV(await f.text()); if (ls.length < 2) return informar('Planilha vazia', '<p>Não encontrei alunos no arquivo.</p>');
  const cab = ls[0].map(x => x.trim().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')), ix = k => cab.findIndex(c => c.startsWith(k));
  const it = ls.slice(1).map(l => ({ nome: (l[ix('nome')] || '').trim(), chamada: (l[ix('chamada')] || '').trim(), nasc: dataCSV(l[ix('nasc')]), genero: /^f/i.test(l[ix('gen')] || '') ? 'f' : 'm', resp: (l[ix('respons')] || '').trim(), email: (l[ix('email')] || '').trim(), tel: (l[ix('tel')] || '').trim() })).filter(x => x.nome);
  const ok = await dlg({ titulo: 'Importar ' + it.length + ' aluno(s)', largo: true, ok: 'Importar', corpo: '<div class="rolagem"><table class="tabela"><tr><th>Nome</th><th>Chamada</th><th>Nascimento</th><th>Gênero</th><th>Responsável</th><th>E-mail</th></tr>' + it.map(x => '<tr><td>' + e(x.nome) + '</td><td>' + e(x.chamada) + '</td><td>' + dataBR(x.nasc) + '</td><td>' + x.genero.toUpperCase() + '</td><td>' + e(x.resp) + '</td><td>' + e(x.email) + '</td></tr>').join('') + '</table></div><p class="dica">Os alunos entram na turma ' + e(rotuloTurma(turmaAtual())) + '.</p>' });
  if (!ok) return; const t = turmaAtual();
  for (const x of it) { const a = await salvar('alunos', { nome: x.nome, chamada: x.chamada, nasc: x.nasc, genero: x.genero, situacao: 'ativo', entrada: hojeISO(), responsaveis: [{ nome: x.resp, parentesco: '', email: x.email, tel: x.tel }] }); await salvar('matriculas', { alunoId: a.id, turmaId: t.id, faltas: [] }); }
  render(); aviso(it.length + ' aluno(s) importado(s).');
};
function abaTurma() {
  const t = turmaAtual();
  let h = '<div class="cartao"><h3>Escola</h3>' + campo('Nome da escola', '<input data-c="escolaNome" value="' + e(CFG.escola.nome) + '">') + '</div>';
  if (t) h += '<div class="cartao" data-rec="turmas:' + t.id + '"><h3>Turma atual</h3><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr))">' + campo('Série', sel('serie', t.serie, seriesVisiveis().map(n => [n, n + 'º ano']), 'data-rr="1"')) + campo('Letra', inp('letra', t.letra)) + campo('Ano letivo', inp('ano', t.ano, 'number', 'data-rr="1"')) + campo('Nome de quem dá aula', inp('professora', t.professora)) + campo('Professora ou professor', sel('genProf', t.genProf || '', [['', '— escolha —'], ['a', 'Professora'], ['o', 'Professor']], 'data-rr="1"')) + '</div>' + (!t.genProf ? '<p class="alerta verm">Escolha “Professora” ou “Professor”: a Tecelã usa essa informação nos documentos.</p>' : '') + '</div>';
  h += '<div class="cartao"><h3>Todas as turmas</h3><div class="rolagem"><table class="tabela"><tr><th>Turma</th><th>Professora ou professor</th><th>Alunos</th><th></th></tr>' + turmasOrdenadas().map(x => '<tr' + (x.arquivada ? ' style="opacity:.65"' : '') + '><td>' + e(rotuloTurma(x)) + (x.arquivada ? ' <span class="etq">arquivada</span>' : '') + '</td><td>' + e(x.professora) + '</td><td>' + matsDaTurma(x.id).length + '</td><td style="white-space:nowrap">' + (x.id === (t && t.id) ? '<span class="etq fin">atual</span> ' : '<button class="btn peq" data-a="usarTurma" data-id="' + x.id + '">Usar</button> ') + '<button class="btn peq" data-a="arquivarTurma" data-id="' + x.id + '">' + (x.arquivada ? 'Desarquivar' : 'Arquivar') + '</button> <button class="icone-btn" data-a="excluirTurma" data-id="' + x.id + '" title="Excluir a turma">✕</button></td></tr>').join('') + '</table></div><p class="dica">Arquivar tira a turma do seletor, sem apagar nada. Excluir apaga a turma e tudo o que é dela.</p><button class="btn" data-a="novaTurma" style="margin-top:.6rem">+ Nova turma</button></div>';
  return h;
}
C_.escolaNome = async el => { CFG.escola.nome = el.value; await gravarConfig('escola'); };
/* dados que pertencem a uma turma (para excluir) */
const STORES_TURMA = [['matriculas', 'matrículas'], ['anotacoes', 'anotações'], ['atas', 'atas'], ['boletins', 'boletins'], ['perfisAluno', 'revisões de perfil'], ['perfisTurma', 'perfis da turma'], ['observacoes', 'observações do período'], ['conselhos', 'conselhos de classe'], ['documentos', 'planos, PEI e combinados'], ['reforcos', 'reforços'], ['vivencias', 'vivências'], ['eventos', 'eventos da turma']];
A.arquivarTurma = async d => { const x = IX.turmas[d.id]; x.arquivada = !x.arquivada; await salvar('turmas', x); render(); aviso(x.arquivada ? 'Turma arquivada: ela saiu do seletor e continua guardada.' : 'Turma de volta ao seletor.'); };
A.excluirTurma = async d => {
  await descarregarFila(); const x = IX.turmas[d.id]; if (!x) return;
  const cont = STORES_TURMA.map(([st, n]) => [st, n, D[st].filter(r => r.turmaId === x.id).length]).filter(c => c[2]);
  const so = alunosDaTurma(x.id).filter(a => !D.matriculas.some(m => m.alunoId === a.id && m.turmaId !== x.id));
  const v = await dlg({ titulo: 'Excluir ' + rotuloTurma(x) + '?', ok: 'Excluir a turma', corpo: (cont.length ? '<p>Vão junto com a turma:</p><ul>' + cont.map(([, n, k]) => '<li>' + k + ' ' + n + '</li>').join('') + '</ul>' : '<p>A turma está vazia.</p>') + (so.length ? '<label class="ck"><input type="checkbox" name="alunos" checked> <span>Excluir também ' + (so.length === 1 ? 'a criança que só está nesta turma' : 'as ' + so.length + ' crianças que só estão nesta turma') + ' (' + e(so.map(primeiroNome).join(', ')) + ')</span></label>' : '') + '<p class="dica">Crianças que estão em outras turmas continuam cadastradas. ' + (cont.length ? '<b>Não há como desfazer.</b> Se tiver dúvida, use “Arquivar”, ou salve o arquivo antes.' : '') + '</p>', extra: cont.length && !SE.demo ? '<button type="button" class="btn" data-x="salvar">💾 Salvar o arquivo antes</button>' : '' });
  if (!v) return; if (v._botao === 'salvar') { if (await fazerCopia()) A.excluirTurma(d); return; }
  const atas = new Set(D.atas.filter(a => a.turmaId === x.id).map(a => a.id));
  for (const m of D.marcacoes.filter(m => atas.has(m.ataId))) await apagar('marcacoes', m.id);
  for (const [st] of STORES_TURMA) for (const r of D[st].filter(r => r.turmaId === x.id)) await apagar(st, r.id);
  if (v.alunos) for (const a of so) await apagar('alunos', a.id);
  for (const o of D.turmas.filter(o => o.origemId === x.id)) { o.origemId = null; await salvar('turmas', o); }
  await apagar('turmas', x.id);
  if (CFG.prefs.turmaId === x.id) await prefs({ turmaId: (turmasVisiveis()[0] || {}).id || null });
  render(); aviso('Turma excluída.');
};
A.usarTurma = async d => { await prefs({ turmaId: d.id }); render(); };
A.novaTurma = async () => {
  const v = await dlg({ titulo: 'Nova turma', ok: 'Criar', corpo: '<div class="duas">' + campo('Série', '<select name="serie">' + seriesVisiveis().map(n => '<option value="' + n + '">' + n + 'º ano</option>').join('') + '</select>') + campo('Letra', '<input name="letra" value="A">') + '</div><div class="duas">' + campo('Ano letivo', '<input name="ano" type="number" value="' + new Date().getFullYear() + '">') + campo('Nome de quem dá aula', '<input name="prof" value="' + e((turmaAtual() || {}).professora) + '">') + '</div>' + campo('Professora ou professor', '<select name="gen" required><option value="">— escolha —</option><option value="a">Professora</option><option value="o">Professor</option></select>', 'Usado nos documentos: “Professora:” ou “Professor:”, “a professora” ou “o professor”.'), validar: v => v.gen ? null : 'Escolha professora ou professor.' });
  if (!v) return; const t = await salvar('turmas', { serie: Number(v.serie), letra: v.letra, ano: Number(v.ano), professora: v.prof, genProf: v.gen, boletim: { textos: {} } }); await prefs({ turmaId: t.id }); render();
};
/* o que ficou por fazer no ano que termina: continua editável depois da virada */
function pendenciasTurma(t) {
  const r = [], bols = boletinsAtuais(t.id);
  alunosDaTurma(t.id).forEach(a => { const b = bols[a.id]; if (b && b.estado !== 'finalizado') r.push('Finalizar o boletim de ' + primeiroNome(a)); else if (!b) r.push('Fazer o boletim de ' + primeiroNome(a)); });
  D.atas.filter(a => a.turmaId === t.id && a.estado !== 'finalizado' && !D.atas.some(x => x.origemId === a.id)).forEach(a => r.push('Finalizar a ata ' + (a.numero || '') + ' (' + nomeReuniao(a) + (a.data ? ', ' + dataBR(a.data) : '') + ')'));
  D.documentos.filter(d => d.tipo === 'pei' && d.turmaId === t.id).forEach(d => { const a = IX.alunos[d.alunoId]; if (a) r.push('Revisar o PEI de ' + primeiroNome(a) + ' para o novo ano'); });
  D.reforcos.filter(x => x.turmaId === t.id && datasPendentesRef(x).length).forEach(x => r.push('Marcar os encontros de reforço de ' + (x.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')));
  return r;
}
const pendHtml = t => { const ps = pendenciasTurma(t); return '<div class="alerta" style="margin:.8rem 0"><p style="margin-top:0"><b>Depois da virada, o ano de ' + t.ano + ' continua aberto.</b> Tudo o que não foi finalizado (boletins, atas, planos, PEI, reforços) pode ser editado e finalizado normalmente: basta escolher “' + e(rotuloTurma(t)) + '” no seletor de turma. Só o que já foi finalizado fica travado, como sempre.</p>' + (ps.length ? '<p><b>Pendências de ' + t.ano + ' (' + ps.length + '):</b></p><ul style="max-height:12rem;overflow:auto">' + ps.map(x => '<li>' + e(x) + '</li>').join('') + '</ul><label class="ck"><input type="checkbox" name="tarefas" checked> <span>Criar uma tarefa para cada pendência na agenda do novo ano, com prazo em</span> <input type="date" name="prazo" value="' + (t.ano + 1) + '-02-15" style="width:auto"></label>' : '<p>Não há pendências: todos os boletins e atas estão finalizados.</p>') + '</div>'; };
function abaVirada() {
  const t = turmaAtual(); if (!t) return vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id), fim = t.serie >= 9;
  return '<div class="cartao"><h3>Virada do ano letivo</h3><p>A turma <b>' + e(rotuloTurma(t)) + '</b> ' + (fim ? 'conclui o Ensino Fundamental.' : 'passa a ser <b>' + (t.serie + 1) + 'º ano ' + e(t.letra) + ' de ' + (t.ano + 1) + '</b>.') + ' O ano de ' + t.ano + ' continua guardado para consulta.</p>' +
    '<form id="fVirada">' + campo('Quem dá aula no novo ano', '<input name="prof" value="' + e(t.professora) + '">') +
    '<div class="rolagem"><table class="tabela"><tr><th>Aluno</th><th>Situação para ' + (t.ano + 1) + '</th></tr>' + al.map(a => '<tr><td>' + e(a.nome) + '</td><td><select name="r_' + a.id + '">' + (fim ? '<option value="concluiu">Concluiu o 9º ano (vai para egressos)</option>' : '<option value="segue">Segue com a turma</option>') + '<option value="retido">Retido (sai desta turma)</option><option value="transferido">Transferido (vai para o arquivo)</option></select></td></tr>').join('') + '</table></div>' +
    pendHtml(t) + '<p class="dica">Alunos novos podem ser incluídos depois, na aba Alunos da nova turma.</p><button class="btn pri">Fazer a virada do ano</button></form></div>';
}
T.turma_pos = () => { const f = $('#fVirada'); if (f) f.addEventListener('submit', async ev => { ev.preventDefault(); await fazerVirada(new FormData(f)); }); };
async function fazerVirada(fd) {
  const t = turmaAtual(), fim = t.serie >= 9;
  if (!(await confirmar('Confirmar a virada do ano?', 'Recomendamos salvar o arquivo antes. A nova turma herda a citação e as assinaturas do boletim, os dias letivos ficam em branco. Continuar?', 'Fazer a virada'))) return;
  let nova = null; if (!fim) nova = await salvar('turmas', { serie: t.serie + 1, letra: t.letra, ano: t.ano + 1, professora: fd.get('prof') || t.professora, genProf: t.genProf, origemId: t.id, materias: clone(t.materias || []), boletim: { textos: {}, citacao: (t.boletim || {}).citacao || '', citacaoAutor: (t.boletim || {}).citacaoAutor || '', assinaturas: clone((t.boletim || {}).assinaturas || {}) } });
  for (const a of alunosDaTurma(t.id)) {
    const r = fd.get('r_' + a.id), m = matricula(t.id, a.id); m.resultado = r; await salvar('matriculas', m);
    if (r === 'segue' && nova) await salvar('matriculas', { alunoId: a.id, turmaId: nova.id, faltas: [] });
    else if (r === 'transferido' || r === 'concluiu') { a.situacao = r === 'concluiu' ? 'egresso' : 'transferido'; a.saida = hojeISO(); await salvar('alunos', a); }
  }
  if (fd.get('tarefas')) { const prazo = fd.get('prazo') || ''; for (const x of pendenciasTurma(t)) await salvar('tarefas', { titulo: x + ' (' + rotuloTurma(t) + ')', data: prazo, obs: 'Pendência da virada do ano de ' + t.ano + '.', avisar: 7, feita: false }); }
  if (nova) await prefs({ turmaId: nova.id });
  UI.aba.turma = 'alunos'; render(); aviso(nova ? 'Nova turma criada: ' + rotuloTurma(nova) : 'Turma concluída. Os alunos foram para o arquivo de egressos.');
}
function abaArquivo() {
  const xs = D.alunos.filter(a => a.situacao && a.situacao !== 'ativo').sort(ordemNome), lim = (CFG.prefs.prazoEgressos || 5) * 365.25 * 864e5;
  if (!xs.length) return vazio('O arquivo está vazio. Aqui ficam egressos e transferidos.');
  return '<div class="cartao rolagem"><p class="dica">Registros guardados por ' + CFG.prefs.prazoEgressos + ' anos. Depois disso a Tecelã lembra você de avaliar a exclusão, mas nunca apaga sozinha.</p><table class="tabela"><tr><th>Nome</th><th>Situação</th><th>Saída</th><th></th></tr>' + xs.map(a => '<tr><td>' + e(a.nome) + '</td><td>' + ({ egresso: 'Egresso', transferido: 'Transferido', excluido: 'Excluído (dados mínimos)' }[a.situacao] || a.situacao) + '</td><td>' + dataBR(a.saida) + (a.saida && Date.now() - new Date(a.saida + 'T12:00') > lim ? ' <span class="etq sig">prazo vencido</span>' : '') + '</td><td><button class="btn peq perigo" data-a="apagarArquivo" data-id="' + a.id + '">Apagar</button></td></tr>').join('') + '</table></div>';
}
A.apagarArquivo = async d => {
  const a = IX.alunos[d.id]; if (!(await confirmar('Apagar o registro?', 'Apagar definitivamente os dados de <b>' + e(a.nome) + '</b>, incluindo perfis, anotações e boletins em rascunho? Atas finalizadas continuam guardadas.', 'Apagar'))) return;
  for (const s of ['matriculas', 'perfisAluno']) for (const r of D[s].filter(r => r.alunoId === a.id)) await apagar(s, r.id);
  for (const b of D.boletins.filter(b => b.alunoId === a.id)) await apagar('boletins', b.id);
  for (const n of D.anotacoes.filter(n => (n.alunos || []).includes(a.id))) { if (n.alunos.length === 1) await apagar('anotacoes', n.id); else { n.alunos = n.alunos.filter(x => x !== a.id); await salvar('anotacoes', n); } }
  await apagar('alunos', a.id); render();
};

A.contatoApp = () => dlg({ titulo: 'Sugestões e novas versões', corpo: contatoHtml().replace(/^<div class="cartao contato"[^>]*><h3>[^<]*<\/h3>/, '').replace(/<\/div>$/, ''), cancelar: false, ok: 'Fechar' });
