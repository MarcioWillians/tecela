/* ==========================================================================
   Tecelã — perfil do aluno (com histórico), relatório da turma, evolução
   e Biblioteca Waldorf.
   ========================================================================== */
'use strict';
const TEMPS = [['', '—'], ['colerico', 'Colérico'], ['sanguineo', 'Sanguíneo'], ['fleumatico', 'Fleumático'], ['melancolico', 'Melancólico']];
const NIVEIS = [['', '—'], ['fortalecido', 'Fortalecido'], ['equilibrado', 'Equilibrado'], ['cuidado', 'Pede cuidado']];
const opSimples = xs => [['', '—']].concat(xs.map(x => [x, x]));
const INSTRUMENTOS = ['Anamnese', 'Entrevista com os pais', 'Observação contínua', 'Diário do professor', 'Estudo de criança', 'Visita domiciliar', 'Avaliação descritiva', 'Portfólio'];
const PERFIL = [
  { bloco: '1. Constituição e corpo', crit: ['constituicao', 'sentidos'], campos: [
    ['aspecto', 'Aspecto físico: cabeça e membros, postura, marcha, gestos, tônus, coordenação', 't', null, 'quatro-membros'],
    ['polCosmica', 'Criança cósmica ou terrena', 's', opSimples(['Mais cósmica', 'Equilibrada', 'Mais terrena']), 'polaridades'],
    ['polFantasia', 'Fantasia', 's', opSimples(['Rica em fantasia', 'Equilibrada', 'Pobre em fantasia']), 'polaridades'],
    ['polMemoria', 'Memória', 's', opSimples(['Boa memória', 'Equilibrada', 'Memória fraca']), 'polaridades'],
    ['sono', 'Sono', 's', opSimples(['Leve', 'Equilibrado', 'Pesado']), 'polaridades'],
    ['sentidos', 'Os quatro sentidos básicos: tato, vital, movimento e equilíbrio', 't', null, 'sentidos-basicos'],
    ['lateralidade', 'Lateralidade', 's', opSimples(['Destro(a)', 'Canhoto(a)', 'Cruzada', 'Ainda indefinida'])],
    ['motricidade', 'Motricidade fina e ampla', 't'],
    ['maturidade', 'Maturidade escolar: troca de dentes, desenho da figura humana, imitação ou autoridade', 't', null, 'setenio-2']] },
  { bloco: '2. Temperamento', crit: ['temperamento'], campos: [
    ['tempPred', 'Temperamento predominante', 's', TEMPS, 'temperamentos'], ['tempSec', 'Temperamento secundário', 's', TEMPS, 'temperamentos'],
    ['tempManif', 'Como aparece: ritmo de trabalho, reações, relação com o grupo, alimentação', 't', null, 'temperamentos']] },
  { bloco: '3. Trimembração anímica', crit: ['pensar', 'sentir', 'querer'], campos: [
    ['pensarNivel', 'Pensar', 's', NIVEIS, 'pensar'], ['pensar', 'Atenção, memória, imaginação, compreensão, capacidade de fazer conexões', 't', null, 'pensar'],
    ['sentirNivel', 'Sentir', 's', NIVEIS, 'sentir'], ['sentir', 'Vida emocional, sensibilidade artística, empatia, medos e alegrias', 't', null, 'sentir'],
    ['quererNivel', 'Querer', 's', NIVEIS, 'querer'], ['querer', 'Iniciativa, persistência, hábitos, capacidade de concluir tarefas', 't', null, 'querer']] },
  { bloco: '4. Momento biográfico', crit: ['biografia'], campos: [
    ['passagens', 'Passagens marcantes: Rubicão (por volta dos 9 anos), crise dos 12 anos', 't', null, 'rubicao'],
    ['historico', 'Histórico: gestação, nascimento, primeira infância, doenças, acontecimentos marcantes', 't'],
    ['familia', 'Constelação familiar: lugar entre os irmãos, rotina, sono, alimentação, telas', 't']] },
  { bloco: '5. Aprendizagem e expressão', crit: ['aprendizagem'], campos: [
    ['desempenho', 'Desempenho nas épocas e disciplinas', 't', null, 'aula-principal'], ['cadernos', 'Cadernos de época: forma, cor, cuidado, evolução', 't', null, 'artistico'],
    ['facilidades', 'Facilidades', 't'], ['dificuldades', 'Dificuldades e sinais que pedem atenção especializada (TEA, TDAH, dislexia, altas habilidades)', 't']] },
  { bloco: '6. Dimensão social e moral', crit: ['social'], campos: [
    ['relacao', 'Relação com colegas e adultos; como lida com regras e conflitos', 't'], ['papel', 'Papel que costuma assumir no grupo', 's', () => papeis(), 'social'], ['moral', 'Senso de responsabilidade, de verdade e de reverência', 't', null, 'social']] },
  { bloco: '7. Instrumentos e registros', crit: [], campos: [['instrumentos', 'Instrumentos usados', 'm', INSTRUMENTOS, 'estudo-crianca'], ['obsRegistros', 'Observações', 't']] }];
const slug = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-');
const rotTemp = k => (TEMPS.find(x => x[0] === k) || ['', ''])[1];
const rotNivel = k => (NIVEIS.find(x => x[0] === k) || ['', ''])[1];
const rotPapel = k => k ? nomeItem('papeis', k) : '';
const opsDe = (ops, atual) => { const o = typeof ops === 'function' ? ops() : ops; return atual && !o.some(x => x[0] === atual) && typeof ops === 'function' ? o.concat([[atual, rotPapel(atual) + ' (arquivado)']]) : o; };
const perfisDe = aid => D.perfisAluno.filter(p => p.alunoId === aid).sort((a, b) => (b.data || '').localeCompare(a.data || '') || (b.criado || '').localeCompare(a.criado || ''));
const ultimoPerfil = (aid, ate) => perfisDe(aid).find(p => !ate || (p.data || '') <= ate) || (ate ? perfisDe(aid).slice(-1)[0] : null) || null;

T.perfis = () => {
  return '<h1>Perfil do aluno</h1><p class="dica">O perfil da turma e a evolução da turma ficam em <a href="#" data-a="ir" data-t="relat">Relatórios</a>.</p>' + abaPerfilAluno();
};
function abaPerfilAluno() {
  const t = turmaAtual(); if (!t) return vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id); if (!al.length) return vazio('Cadastre os alunos da turma.');
  const aid = IX.alunos[UI.filtro.perfilAluno] && al.some(a => a.id === UI.filtro.perfilAluno) ? UI.filtro.perfilAluno : al[0].id, a = IX.alunos[aid], ps = perfisDe(aid);
  const p = (UI.sub && IX.perfisAluno[UI.sub] && IX.perfisAluno[UI.sub].alunoId === aid) ? IX.perfisAluno[UI.sub] : ps[0], antigo = p && ps[0] && p.id !== ps[0].id;
  let h = '<div class="principio"><b>Princípio orientador:</b> ' + PRINCIPIO + '</div>';
  h += '<div class="linha"><select data-c="perfilAluno">' + al.map(x => '<option value="' + x.id + '"' + (x.id === aid ? ' selected' : '') + '>' + e(x.nome) + '</option>').join('') + '</select>' + (p ? '<button class="btn" data-a="novaRevisao" data-al="' + aid + '">+ Nova revisão</button>' : '<button class="btn pri" data-a="novoPerfil" data-al="' + aid + '">Criar perfil</button>') + (p ? '<button class="btn" data-a="exportarPerfil" data-id="' + p.id + '">Exportar</button><span class="espaco"></span><button class="btn perigo" data-a="apagarRevisao" data-id="' + p.id + '">Excluir esta revisão</button>' : '') + '</div>';
  const m = idadeEm(a.nasc, refTurma(t)); h += '<p class="dica">' + e(a.nome) + ' · ' + idadeTxt(m) + ' · ' + setenio(m) + '</p>';
  const pts = (a.atencao || []).filter(x => x.situacao !== 'resolvido');
  if (pts.length) h += '<div class="alerta" style="background:var(--violC)"><b>Pontos de atenção</b> <a href="#" data-a="ir" data-t="turma" data-aba="alunos" data-sub="' + a.id + '">editar no cadastro</a><ul style="margin:.3rem 0 0">' + pts.map(x => '<li><b>' + e(nomeItem('atencao', x.tipo)) + ':</b> ' + e(x.descricao) + (x.sigiloso !== false ? ' <span class="etq sig">sigiloso</span>' : '') + '</li>').join('') + '</ul></div>';
  if (!p) return h + vazio('Ainda não há perfil para ' + e(primeiroNome(a)) + '.');
  if (ps.length > 1) h += '<div class="cartao suave"><b>Histórico:</b> ' + ps.map(x => '<a href="#" data-a="verRevisao" data-id="' + x.id + '" style="' + (x.id === p.id ? 'font-weight:700' : '') + '">' + dataBR(x.data) + '</a>').join(' · ') + '</div>';
  if (antigo) h += '<p class="alerta">Você está vendo uma revisão anterior (' + dataBR(p.data) + '). Ela fica guardada como registro e não pode ser editada.</p>';
  h += '<fieldset style="border:0;padding:0;margin:0" ' + (antigo ? 'disabled' : '') + ' data-rec="perfisAluno:' + p.id + '"><div class="cartao">' + campo('Data desta revisão', inp('data', p.data, 'date')) + '</div>';
  PERFIL.forEach(bl => {
    const notas = D.anotacoes.filter(n => (n.alunos || []).includes(aid) && bl.crit.includes(n.criterio)).sort((x, y) => (y.data || '').localeCompare(x.data || ''));
    const sug = bl.crit.includes('pensar') && !antigo ? sugestaoPerfil(aid) : null;
    h += '<div class="cartao"><h3>' + bl.bloco + '</h3>' + (sug ? '<div class="alerta" style="background:var(--azulC)">◎ Pela observação do ' + e(rotPeriodo(sug.periodo)) + ': ' + Object.entries(sug.niveis).map(([k, v]) => '<b>' + k + '</b> ' + rotNivel(v).toLowerCase()).join(' · ') + '. <button type="button" class="btn peq" data-a="aplicarSugPerfil" data-id="' + p.id + '">Usar nos campos vazios</button><div class="dica">É só uma sugestão, calculada pelas marcas do roteiro. Seu olhar decide.</div></div>' : '') + '<div class="' + (notas.length ? 'duas' : '') + '"><div>' + bl.campos.map(([k, rot, tipo, ops, bib]) => {
      const ic = bib ? ' <button type="button" class="icone-btn" data-a="verBib" data-id="' + bib + '" title="Ver na Biblioteca Waldorf">📖</button>' : '', v = (p.campos || {})[k];
      if (tipo === 's') return '<label class="cp"><span class="r">' + rot + ic + '</span>' + sel('campos.' + k, v, opsDe(ops, v)) + '</label>';
      if (tipo === 'm') return '<div class="cp"><span class="r">' + rot + ic + '</span>' + ops.map(o => ck('campos.' + k + '.' + slug(o), v && v[slug(o)], o)).join('') + '</div>';
      return '<label class="cp"><span class="r">' + rot + ic + '</span>' + area('campos.' + k, v, 'style="min-height:4.5rem"') + '</label>';
    }).join('') + '</div>' + (notas.length ? '<div><span class="dica">Anotações relacionadas</span><div class="lista-sel" style="max-height:24rem">' + notas.map(n => '<p style="margin:.3rem 0;font-size:.9rem"><span class="etq">' + dataBR(n.data) + '</span> <span class="etq viol">' + e(nomeCrit(n.criterio)) + '</span><br>' + e(n.texto) + '</p>').join('') + '</div></div>' : '') + '</div></div>';
  });
  return h + '</fieldset>';
}
A.aplicarSugPerfil = async d => { await descarregarFila(); const p = IX.perfisAluno[d.id], s = sugestaoPerfil(p.alunoId); if (!s) return; p.campos = p.campos || {}; let n = 0; Object.entries(s.niveis).forEach(([k, v]) => { if (!p.campos[k + 'Nivel']) { p.campos[k + 'Nivel'] = v; n++; } }); await salvar('perfisAluno', p); render(); aviso(n ? n + ' nível(is) preenchido(s).' : 'Os níveis já estavam preenchidos; nada foi mudado.'); };
C_.perfilAluno = el => { UI.filtro.perfilAluno = el.value; UI.sub = null; render(); };
A.verRevisao = d => { UI.sub = d.id; render(); };
A.novoPerfil = async d => { const p = await salvar('perfisAluno', { alunoId: d.al, turmaId: turmaAtual().id, data: hojeISO(), campos: {} }); UI.sub = p.id; render(); };
A.novaRevisao = async d => { await descarregarFila(); const ult = perfisDe(d.al)[0], p = await salvar('perfisAluno', { alunoId: d.al, turmaId: turmaAtual().id, data: hojeISO(), campos: clone((ult && ult.campos) || {}) }); UI.sub = p.id; render(); aviso('Nova revisão criada a partir da anterior. A anterior fica guardada no histórico.'); };
A.apagarRevisao = async d => { if (!(await confirmar('Excluir esta revisão do perfil?', 'As demais revisões continuam guardadas.', 'Excluir'))) return; await apagar('perfisAluno', d.id); UI.sub = null; render(); };
A.exportarPerfil = async d => {
  await descarregarFila(); const p = IX.perfisAluno[d.id], a = IX.alunos[p.alunoId], b = [{ t: 'tit', txt: 'Perfil do aluno — ' + a.nome }, { t: 'centro', linhas: ['Revisão de ' + dataBR(p.data)], peq: true }, { t: 'nota', txt: 'Princípio orientador: ' + PRINCIPIO }];
  PERFIL.forEach(bl => { b.push({ t: 'h', txt: bl.bloco }); bl.campos.forEach(([k, rot, tipo, ops]) => { let v = (p.campos || {})[k]; if (tipo === 's') v = (opsDe(ops, v).find(o => o[0] === v) || ['', ''])[1]; if (tipo === 'm') v = ops.filter(o => v && v[slug(o)]).join(', '); if (v) b.push({ t: 'p', txt: rot + ': ' + v }); }); });
  saidaDocumento({ nome: 'Perfil_' + a.nome + '_' + p.data, titulo: 'Perfil do aluno — ' + a.nome, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b }, { assunto: 'Perfil do aluno — ' + a.nome });
};

/* ---------- dados consolidados da turma ---------- */
function dadosTurma(t) {
  const al = alunosDaTurma(t.id), ref = refTurma(t), ate = t.ano + '-12-31', n = al.length;
  const idades = al.map(a => idadeEm(a.nasc, ref)).filter(x => x != null);
  const perfis = al.map(a => ultimoPerfil(a.id, ate)).filter(Boolean), c = p => p.campos || {};
  const conta = (lista, f) => { const r = {}; lista.forEach(x => { const k = f(x); if (k) r[k] = (r[k] || 0) + 1; }); return r; };
  const per = CFG.prefs.periodos || [], faltas = per.map((_, i) => matsDaTurma(t.id).reduce((s, m) => s + (Number((m.faltas || [])[i]) || 0), 0));
  const atas = D.atas.filter(a => a.turmaId === t.id && !D.atas.some(x => x.origemId === a.id));
  return {
    t, al, n, ref, perfis: perfis.length,
    idadeMedia: idades.length ? idades.reduce((a, b) => a + b, 0) / idades.length : null, idadeMin: idades.length ? Math.min(...idades) : null, idadeMax: idades.length ? Math.max(...idades) : null,
    maisNovo: al.find(a => idadeEm(a.nasc, ref) === Math.min(...idades)), maisVelho: al.find(a => idadeEm(a.nasc, ref) === Math.max(...idades)),
    nove: idades.filter(m => m >= 108).length, doze: idades.filter(m => m >= 144).length,
    meninas: al.filter(a => a.genero === 'f').length, meninos: al.filter(a => a.genero !== 'f').length,
    tempPred: conta(perfis, p => c(p).tempPred), tempSec: conta(perfis, p => c(p).tempSec),
    pensar: conta(perfis, p => c(p).pensarNivel), sentir: conta(perfis, p => c(p).sentirNivel), querer: conta(perfis, p => c(p).quererNivel),
    papeis: conta(perfis, p => c(p).papel),
    faltas, faltasTotal: faltas.reduce((a, b) => a + b, 0), nee: al.filter(a => a.nee).length, acomp: al.filter(a => a.acomp).length,
    atencao: (() => { const r = {}; al.forEach(a => (a.atencao || []).filter(x => x.situacao !== 'resolvido' && (!x.desde || x.desde <= ate)).forEach(x => r[x.tipo] = (r[x.tipo] || 0) + 1)); return r; })(),
    anotSecao: conta(D.anotacoes.filter(x => x.turmaId === t.id), x => x.secao), anotCrit: conta(D.anotacoes.filter(x => x.turmaId === t.id), x => x.criterio), anotTotal: D.anotacoes.filter(x => x.turmaId === t.id).length,
    atas: conta(atas, a => nomeReuniao(a)), estudos: atas.filter(a => a.subtipo === 'Estudo de criança').length
  };
}
const maior = obj => Object.entries(obj).sort((a, b) => b[1] - a[1])[0];
function referenciasTurma(d) {
  const ids = ['setenio-2', 'serie-' + d.t.serie];
  if (d.nove || (d.idadeMedia && d.idadeMedia >= 96 && d.idadeMedia <= 126)) ids.push('rubicao');
  if (d.doze || (d.idadeMedia && d.idadeMedia >= 132)) ids.push('doze-anos');
  const tp = maior(d.tempPred); if (tp) ids.push('temp-' + tp[0]);
  if (Object.keys(d.tempPred).length > 1) ids.push('temperamentos');
  const cuid = [['pensar', d.pensar.cuidado || 0], ['sentir', d.sentir.cuidado || 0], ['querer', d.querer.cuidado || 0]].sort((a, b) => b[1] - a[1]);
  if (cuid[0][1]) ids.push(cuid[0][0]);
  if (d.papeis.isolado || d.papeis.provocador) ids.push('social');
  return [...new Set(ids)].map(id => IX.biblioteca[id]).filter(x => x && !x.oculto && (x.texto || '').trim());
}
/* gráficos SVG (cores fixas, boas para tela e impressão) */
const CORES_T = { colerico: '#C8452F', sanguineo: '#E9B93A', fleumatico: '#4F8FCC', melancolico: '#8A62A8' };
const CORES_N = { fortalecido: '#2F6AA8', equilibrado: '#7DAA6E', cuidado: '#EA6A55' };
function svgBarras(itens, titulo) {
  const max = Math.max(1, ...itens.map(i => i.v)), L = 640, ph = 30, top = titulo ? 34 : 8, H = top + itens.length * ph + 8;
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + L + ' ' + H + '" width="' + L + '" height="' + H + '" font-family="Segoe UI,Arial,sans-serif" font-size="13">' + (titulo ? '<text x="0" y="18" font-size="14" font-weight="700" fill="#2B4460">' + e(titulo) + '</text>' : '') +
    itens.map((it, i) => { const y = top + i * ph, w = Math.max(2, (L - 200) * it.v / max); return '<text x="0" y="' + (y + 18) + '" fill="#2B4460">' + e(it.rot) + '</text><rect x="150" y="' + (y + 5) + '" width="' + w + '" height="18" rx="5" fill="' + (it.cor || '#4F8FCC') + '" opacity=".85"/><text x="' + (156 + w) + '" y="' + (y + 18) + '" fill="#2B4460" font-weight="700">' + it.v + '</text>'; }).join('') + '</svg>';
}
function svgEmpilhado(linhas, ordem, cores, rotulos, titulo) {
  const L = 640, ph = 34, top = 34, H = top + linhas.length * ph + 30;
  let s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + L + ' ' + H + '" width="' + L + '" height="' + H + '" font-family="Segoe UI,Arial,sans-serif" font-size="13"><text x="0" y="18" font-size="14" font-weight="700" fill="#2B4460">' + e(titulo) + '</text>';
  linhas.forEach((l, i) => { const y = top + i * ph, tot = Math.max(1, ordem.reduce((a, k) => a + (l.v[k] || 0), 0)); let x = 150; s += '<text x="0" y="' + (y + 18) + '" fill="#2B4460">' + e(l.rot) + '</text>'; ordem.forEach(k => { const w = (L - 170) * (l.v[k] || 0) / tot; if (w > 0) { s += '<rect x="' + x + '" y="' + (y + 4) + '" width="' + w + '" height="20" fill="' + cores[k] + '" opacity=".85"/>' + (w > 18 ? '<text x="' + (x + w / 2) + '" y="' + (y + 18) + '" text-anchor="middle" fill="#fff" font-weight="700">' + l.v[k] + '</text>' : ''); x += w; } }); });
  let lx = 150; ordem.forEach(k => { s += '<rect x="' + lx + '" y="' + (H - 18) + '" width="12" height="12" fill="' + cores[k] + '"/><text x="' + (lx + 17) + '" y="' + (H - 8) + '" fill="#2B4460">' + e(rotulos[k]) + '</text>'; lx += 30 + rotulos[k].length * 7.5; });
  return s + '</svg>';
}
function docRelatorioTurma(d, pt) {
  const t = d.t, b = [{ t: 'tit', txt: 'Perfil da turma — ' + rotuloTurma(t) }, { t: 'centro', linhas: ['Relatório de análise · ' + dataBR(hojeISO())], peq: true }];
  b.push({ t: 'h', txt: '1. Etapa de desenvolvimento' }, { t: 'p', txt: d.n + ' alunos (' + d.meninas + ' meninas e ' + d.meninos + ' meninos). Idade média em ' + dataBR(d.ref) + ': ' + idadeTxt(Math.round(d.idadeMedia)) + '. Mais novo: ' + (d.maisNovo ? primeiroNome(d.maisNovo) + ', ' + idadeTxt(d.idadeMin) : '—') + '; mais velho: ' + (d.maisVelho ? primeiroNome(d.maisVelho) + ', ' + idadeTxt(d.idadeMax) : '—') + '. Já passaram dos 9 anos: ' + d.nove + '; dos 12 anos: ' + d.doze + '. ' + (d.idadeMax != null && d.idadeMax >= 168 ? (d.al.filter(a => idadeEm(a.nasc, d.ref) >= 168).length + ' aluno(s) já entraram no 3º setênio; os demais estão no 2º.') : 'Toda a turma está no 2º setênio.') });
  b.push({ t: 'h', txt: '2. Temperamentos' }, { t: 'p', txt: 'Perfis considerados: ' + d.perfis + ' de ' + d.n + '.' });
  if (Object.keys(d.tempPred).length) b.push({ t: 'svg', svg: svgBarras(TEMPS.slice(1).map(([k, r]) => ({ rot: r, v: d.tempPred[k] || 0, cor: CORES_T[k] })), 'Temperamento predominante') });
  if (Object.keys(d.tempSec).length) b.push({ t: 'svg', svg: svgBarras(TEMPS.slice(1).map(([k, r]) => ({ rot: r, v: d.tempSec[k] || 0, cor: CORES_T[k] })), 'Temperamento secundário') });
  b.push({ t: 'h', txt: '3. Pensar, sentir e querer' }, { t: 'svg', svg: svgEmpilhado([{ rot: 'Pensar', v: d.pensar }, { rot: 'Sentir', v: d.sentir }, { rot: 'Querer', v: d.querer }], ['fortalecido', 'equilibrado', 'cuidado'], CORES_N, { fortalecido: 'Fortalecido', equilibrado: 'Equilibrado', cuidado: 'Pede cuidado' }, 'Distribuição da turma em cada aspecto') });
  b.push({ t: 'h', txt: '4. Dinâmica social' });
  if (Object.keys(d.papeis).length) b.push({ t: 'svg', svg: svgBarras(Object.keys(d.papeis).map(k => ({ rot: rotPapel(k), v: d.papeis[k], cor: '#8A62A8' })), 'Papel que costuma assumir no grupo') });
  b.push({ t: 'p', txt: 'Equilíbrio entre meninos e meninas: ' + d.meninos + ' meninos e ' + d.meninas + ' meninas.' });
  b.push({ t: 'h', txt: '5. Indicadores' }, { t: 'tabela', cab: ['Indicador', 'Valor'], linhas: [['Faltas no ano (total)', String(d.faltasTotal)], ['Média de faltas por aluno', d.n ? (d.faltasTotal / d.n).toFixed(1) : '—']].concat((CFG.prefs.periodos || []).map((p, i) => ['Faltas — ' + p, String(d.faltas[i] || 0)])).concat([['Alunos com necessidades educacionais especiais', String(d.nee)], ['Alunos com acompanhamento externo', String(d.acomp)]].concat(Object.entries(d.atencao).map(([k, v]) => ['Pontos de atenção ativos: ' + nomeItem('atencao', k), String(v)]))) });
  b.push({ t: 'h', txt: '6. Registros do ano' }, { t: 'tabela', cab: ['Registro', 'Quantidade'], linhas: [['Anotações', String(d.anotTotal)]].concat(Object.entries(d.anotSecao).map(([k, v]) => ['  na seção ' + nomeSecao(k, t.serie), String(v)])).concat(Object.entries(d.anotCrit).map(([k, v]) => ['  no critério ' + nomeCrit(k), String(v)])).concat(Object.entries(d.atas).map(([k, v]) => ['Atas: ' + k, String(v)])) });
  const refs = referenciasTurma(d);
  if (refs.length) { b.push({ t: 'h', txt: '7. Leitura à luz da Biblioteca Waldorf' }); refs.forEach(r => { b.push({ t: 'p', txt: r.titulo + '. ' + r.texto.replace(/\n+/g, ' ') }); if (r.fonte) b.push({ t: 'nota', txt: 'Fonte: ' + r.fonte }); }); }
  if (pt && (pt.analise || '').trim()) { b.push({ t: 'h', txt: '8. Análise da professora' }); nl2p(pt.analise).forEach(p => b.push({ t: 'p', txt: p })); }
  return { nome: 'Perfil_da_turma_' + t.serie + 'ano' + t.letra + '_' + t.ano, titulo: 'Perfil da turma — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
function perfilTurmaRec(t) { let p = D.perfisTurma.find(x => x.turmaId === t.id); if (!p) { p = { id: 'pt' + t.id, turmaId: t.id, ano: t.ano, analise: '' }; D.perfisTurma.push(p); IX.perfisTurma[p.id] = p; } return p; }
function abaPerfilTurma() {
  const t = turmaAtual(); if (!t) return vazio('Cadastre uma turma primeiro.');
  const d = dadosTurma(t); if (!d.n) return vazio('Cadastre os alunos da turma.');
  const pt = perfilTurmaRec(t), doc = docRelatorioTurma(d, null);
  let h = '<div class="principio"><b>Princípio orientador:</b> ' + PRINCIPIO + '</div><p class="dica">Relatório de análise, montado com os perfis, anotações, atas e faltas registrados.</p>';
  h += '<div class="grade" style="margin-top:1rem"><div class="cartao"><div class="dica">Alunos</div><div class="kpi">' + d.n + '</div><div class="dica">' + d.meninas + ' meninas · ' + d.meninos + ' meninos</div></div><div class="cartao"><div class="dica">Idade média</div><div class="kpi">' + idadeTxt(Math.round(d.idadeMedia)) + '</div><div class="dica">de ' + idadeTxt(d.idadeMin) + ' a ' + idadeTxt(d.idadeMax) + '</div></div><div class="cartao"><div class="dica">Perfis considerados</div><div class="kpi">' + d.perfis + '/' + d.n + '</div></div><div class="cartao"><div class="dica">Faltas no ano</div><div class="kpi">' + d.faltasTotal + '</div><div class="dica">' + (d.faltasTotal / d.n).toFixed(1) + ' por aluno</div></div></div>';
  h += '<div class="cartao">' + doc.blocos.slice(2).map(htmlBloco).join('') + '</div>';
  h += '<div class="cartao" data-rec="perfisTurma:' + pt.id + '"><h3>Análise da professora</h3>' + area('analise', pt.analise, 'class="alto" placeholder="Sua leitura do grupo, a partir dos dados acima."') + '</div>';
  return h;
}
function docEvolucao(ds) {
  const t = ds[ds.length - 1].t, b = [{ t: 'tit', txt: 'Evolução da turma — ' + rotuloTurma(t) }, { t: 'centro', linhas: [ds.map(d => d.t.ano).join(' · ')], peq: true }];
  b.push({ t: 'tabela', cab: ['Ano', 'Série', 'Alunos', 'Idade média', 'Faltas por aluno', 'Necessidades educacionais especiais', 'Pensar: pede cuidado', 'Sentir: pede cuidado', 'Querer: pede cuidado'], linhas: ds.map(d => [String(d.t.ano), d.t.serie + 'º', String(d.n), idadeTxt(Math.round(d.idadeMedia)), d.n ? (d.faltasTotal / d.n).toFixed(1) : '—', String(d.nee), String(d.pensar.cuidado || 0), String(d.sentir.cuidado || 0), String(d.querer.cuidado || 0)]) });
  b.push({ t: 'svg', svg: svgEmpilhado(ds.map(d => ({ rot: String(d.t.ano), v: d.tempPred })), TEMPS.slice(1).map(x => x[0]), CORES_T, { colerico: 'Colérico', sanguineo: 'Sanguíneo', fleumatico: 'Fleumático', melancolico: 'Melancólico' }, 'Temperamento predominante por ano') });
  ['pensar', 'sentir', 'querer'].forEach(k => b.push({ t: 'svg', svg: svgEmpilhado(ds.map(d => ({ rot: String(d.t.ano), v: d[k] })), ['fortalecido', 'equilibrado', 'cuidado'], CORES_N, { fortalecido: 'Fortalecido', equilibrado: 'Equilibrado', cuidado: 'Pede cuidado' }, k[0].toUpperCase() + k.slice(1) + ' por ano') }));
  b.push({ t: 'h', txt: 'Referências da Biblioteca para cada ano' });
  ds.forEach(d => { const r = IX.biblioteca['serie-' + d.t.serie]; if (r && !r.oculto && r.texto) { b.push({ t: 'p', txt: d.t.ano + ' — ' + r.titulo + '. ' + r.texto.replace(/\n+/g, ' ') }); } });
  return { nome: 'Evolucao_' + t.serie + 'ano' + t.letra + '_' + t.ano, titulo: 'Evolução da turma — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}

/* ---------- BIBLIOTECA ---------- */
function carregarBiblioteca(modo) {
  D.biblioteca = BIBLIO.map(x => Object.assign({}, x, { texto: modo === 'branco' ? '' : x.texto, origem: modo === 'branco' ? 'branco' : 'original' })); indexar('biblioteca');
}
/* versões novas da Tecelã atualizam os verbetes que a professora não editou (origem "original") */
function sincronizarBiblioteca() {
  if (!D.biblioteca.length || SE.demo && !D.biblioteca.length) return [];
  const mudou = [];
  BIBLIO.forEach(o => { const r = IX.biblioteca[o.id]; if (r && r.origem === 'original' && (r.texto !== o.texto || r.fonte !== o.fonte || r.titulo !== o.titulo)) { Object.assign(r, { titulo: o.titulo, texto: o.texto, fonte: o.fonte }); mudou.push(r); } });
  /* verbetes novos de uma versão nova entram na biblioteca de quem já usa a Tecelã */
  const branco = CFG.prefs.biblio === 'branco';
  BIBLIO.forEach(o => { if (!IX.biblioteca[o.id]) { const r = Object.assign({}, o, { texto: branco ? '' : o.texto, origem: branco ? 'branco' : 'original' }); D.biblioteca.push(r); IX.biblioteca[r.id] = r; mudou.push(r); } });
  return mudou;
}
A.verBib = d => { const r = IX.biblioteca[d.id]; if (!r) return aviso('Verbete não encontrado na biblioteca.'); informar(r.titulo, (r.texto ? r.texto.split(/\n+/).map(p => '<p>' + e(p) + '</p>').join('') : '<p class="dica">Este verbete está em branco. Escreva-o na Biblioteca.</p>') + (r.fonte ? '<p class="dica">Fonte: ' + e(r.fonte) + '</p>' : '') + '<p><a href="#" data-a="abrirBib" data-id="' + r.id + '">Abrir na Biblioteca</a></p>'); };
A.abrirBib = d => { $('#modais').innerHTML = ''; ir('biblio', d.id); };
/* ---------- verbetes da BNCC: montados na hora a partir das habilidades embutidas (somente leitura) ---------- */
const GRUPO_BNCC = 'BNCC — Ensino Fundamental';
const ORDEM_COMP = ['LP', 'MA', 'CI', 'HI', 'GE', 'AR', 'EF', 'LI', 'ER', 'CO'];
function verbetesBncc() {
  const r = [{ id: 'bncc:sobre', titulo: 'Como ler a BNCC na Tecelã', comp: '', ano: 0 }];
  if (BNCC_COMP.CO) r.push({ id: 'bncc:CO:sobre', titulo: 'Computação: competências e eixos', comp: 'CO', ano: 0 });
  ORDEM_COMP.filter(k => BNCC_COMP[k]).forEach(k => seriesVisiveis().forEach(a => { if (BNCC.some(h => h[1] === k && h[2].includes(a))) r.push({ id: 'bncc:' + k + ':' + a, titulo: BNCC_COMP[k].replace(/ \(.*\)$/, '') + ' — ' + a + 'º ano', comp: k, ano: a }); }));
  return r;
}
function blocosVerbeteBncc(id) {
  const [, k, a] = id.split(':'), usos = {}; D.curriculo.forEach(c => (c.bncc || []).forEach(cod => (usos[cod] = usos[cod] || []).push(c)));
  if (k === 'sobre') return { titulo: 'Como ler a BNCC na Tecelã', blocos: [{ t: 'nota', txt: 'Sobre a BNCC nesta versão. ' + AVISO_BNCC_TXT }, { t: 'p', txt: 'A Base Nacional Comum Curricular (BNCC) define as aprendizagens essenciais de cada ano do Ensino Fundamental. Cada habilidade tem um código: EF (Ensino Fundamental), o ano (01 a 09, ou 15 e 69 para as habilidades de um conjunto de anos), o componente (LP, MA, CI…) e o número.' }, { t: 'p', txt: 'Na pedagogia Waldorf, muitos conteúdos são trabalhados em outra idade ou de outro modo, de acordo com o desenvolvimento da criança. Por isso a Tecelã mostra, em cada habilidade, as épocas da escola ligadas a ela, e a comparação do currículo distingue “no mesmo ano”, “em outro ano” e “não contemplada”, sem tratar a diferença como falta.' }, { t: 'p', txt: 'Estes verbetes são de consulta: trazem o texto oficial e não podem ser editados. Para ligar habilidades às épocas, use Currículo e BNCC.' }, { t: 'nota', txt: 'Fonte: Base Nacional Comum Curricular, MEC (versão homologada)' + (BNCC_COMP.CO ? '; Normas sobre Computação na Educação Básica, complemento à BNCC (Parecer CNE/CEB nº 2/2022 e Resolução CNE/CEB nº 1/2022).' : '.') }] };
  if (a === 'sobre') return { titulo: 'Computação: competências e eixos', blocos: [{ t: 'p', txt: 'Desde 2022, a Computação faz parte da BNCC como complemento, organizada em três eixos:' }, { t: 'lista', itens: EIXOS_CO.map(([n, d]) => n + ': ' + d) }, { t: 'h', txt: 'Competências específicas da Computação no Ensino Fundamental' }, { t: 'lista', itens: BNCC_CO_COMPETENCIAS }, { t: 'p', txt: 'O texto de referência recomenda que, nos Anos Iniciais, o pensamento computacional seja trabalhado ao menos no início de forma desplugada, sem computadores, com experiências concretas: jogos, sequências de passos, organização de objetos, códigos e padrões. É um ponto de encontro com a pedagogia Waldorf, que valoriza o fazer concreto e o movimento antes da abstração.' }, { t: 'nota', txt: 'Fonte: Parecer CNE/CEB nº 2/2022 e Resolução CNE/CEB nº 1/2022 (Normas sobre Computação na Educação Básica, complemento à BNCC); explicações e exemplos do documento “BNCC Computação — completo diagramado”.' }] };
  const ano = Number(a), xs = BNCC.filter(h => h[1] === k && h[2].includes(ano)).sort((x, y) => ehEtapa(x) - ehEtapa(y) || x[0].localeCompare(y[0])), b = [{ t: 'p', txt: xs.filter(h => !ehEtapa(h)).length + ' habilidade(s) de ' + BNCC_COMP[k] + ' para o ' + ano + 'º ano.' }];
  let eixo = '';
  xs.forEach(h => {
    if (k === 'CO') { const m = h[4] || {}, g = m.etapa ? 'Habilidades por etapa (alternativa às do ano)' : m.e; if (g !== eixo) { eixo = g; b.push({ t: 'centro', linhas: [g], negrito: true, espaco: true }); } b.push(...blocosHabCO(h)); }
    else b.push({ t: 'h', txt: h[0] + (h[2].length > 1 ? ' (' + h[2][0] + 'º ao ' + h[2][h[2].length - 1] + 'º ano)' : '') }, { t: 'p', txt: h[3] });
    const us = usos[h[0]] || []; if (us.length) b.push({ t: 'nota', txt: 'Na escola: ' + us.map(c => c.serie + 'º ano, ' + c.titulo).join('; ') + '.' });
  });
  b.push({ t: 'nota', txt: k === 'CO' ? 'Fonte: complemento de Computação à BNCC (Parecer CNE/CEB nº 2/2022 e Resolução CNE/CEB nº 1/2022).' : 'Fonte: Base Nacional Comum Curricular, MEC (versão homologada).' });
  return { titulo: BNCC_COMP[k].replace(/ \(.*\)$/, '') + ' — ' + ano + 'º ano', blocos: b };
}
/* ---------- Biblioteca ---------- */
const bibVisiveis = () => D.biblioteca.filter(r => !r.oculto && (r.id !== 'serie-9' || seriesVisiveis().includes(9)));
const gruposBib = () => [...new Set(D.biblioteca.slice().sort((a, b) => (a.ordem || 999) - (b.ordem || 999)).map(r => r.grupo).concat(['Meus verbetes']))];
const rotOrigem = r => ({ original: 'original', editado: 'editado', branco: 'em branco', proprio: 'verbete próprio' }[r.origem] || r.origem);
T.biblio = () => {
  if (UI.sub && /^bncc:/.test(UI.sub)) {
    const v = blocosVerbeteBncc(UI.sub);
    return '<div class="linha"><button class="btn" data-a="voltarSub">← Biblioteca</button><span class="etq">' + GRUPO_BNCC + ' · somente leitura</span><span class="espaco"></span><button class="btn" data-a="exportarVerbeteBncc" data-id="' + UI.sub + '">Exportar</button>' + (UI.sub !== 'bncc:sobre' ? '<button class="btn" data-a="ir" data-t="curric" data-aba="bncc">Abrir em Currículo e BNCC</button>' : '') + '</div><div class="cartao"><h2>' + e(v.titulo) + '</h2>' + v.blocos.map(htmlBloco).join('') + '</div>';
  }
  if (UI.sub && IX.biblioteca[UI.sub]) return editorVerbete(IX.biblioteca[UI.sub]);
  const grupos = {}; bibVisiveis().sort((a, b) => (a.ordem || 999) - (b.ordem || 999)).forEach(r => (grupos[r.grupo] = grupos[r.grupo] || []).push(r));
  const ocultos = D.biblioteca.filter(r => r.oculto), t = turmaAtual(), anoB = UI.filtro.bibAno == null ? String((t && t.serie) || '') : UI.filtro.bibAno;
  let h = '<h1>Biblioteca Waldorf</h1><p>Conhecimentos e princípios da pedagogia Waldorf e da Antroposofia para o Ensino Fundamental, e a BNCC para consulta. Eles sustentam a leitura dos relatórios da turma e apoiam o perfil do aluno (ícone 📖). Os textos Waldorf são paráfrases, sempre com a fonte indicada.</p><div class="linha"><button class="btn pri" data-a="novoVerbete">+ Novo verbete</button><button class="btn" data-a="exportarBiblio">Exportar a biblioteca</button><button class="btn" data-a="bibPronta">Recomeçar com a biblioteca pronta</button><button class="btn" data-a="bibBranco">Esvaziar os textos (em branco)</button></div>';
  if (!D.biblioteca.length) h += vazio('A biblioteca está vazia.');
  Object.entries(grupos).forEach(([g, rs]) => { h += '<div class="cartao"><h3>' + e(g) + '</h3><ul>' + rs.map(r => '<li><a href="#" data-a="ir" data-t="biblio" data-sub="' + r.id + '">' + e(r.titulo) + '</a>' + (r.origem === 'editado' ? ' <span class="etq rasc">editado</span>' : r.origem === 'proprio' ? ' <span class="etq viol">próprio</span>' : !r.texto ? ' <span class="etq">em branco</span>' : '') + '</li>').join('') + '</ul></div>'; });
  const vb = verbetesBncc(), anos = [...new Set(vb.map(x => x.ano).filter(Boolean))];
  h += '<div class="cartao"><div class="linha"><h3 style="margin:0">' + GRUPO_BNCC + '</h3><span class="etq">consulta</span><span class="espaco"></span><select data-c="bibAno"><option value="">Todos os anos</option>' + anos.map(a => '<option value="' + a + '"' + (String(a) === anoB ? ' selected' : '') + '>' + a + 'º ano</option>').join('') + '</select></div><ul>' + vb.filter(x => !x.ano || !anoB || String(x.ano) === anoB).map(x => '<li><a href="#" data-a="ir" data-t="biblio" data-sub="' + x.id + '">' + e(x.titulo) + '</a></li>').join('') + '</ul><p class="dica">Texto oficial, só para leitura. A Computação aparece quando está ligada em Ajustes.</p></div>';
  if (ocultos.length) h += '<div class="cartao"><details><summary style="cursor:pointer"><b>Verbetes ocultos (' + ocultos.length + ')</b></summary><ul>' + ocultos.map(r => '<li>' + e(r.titulo) + ' <span class="dica">(' + e(r.grupo) + ')</span> <button class="btn peq" data-a="reexibirVerbete" data-id="' + r.id + '">Reexibir</button></li>').join('') + '</ul></details></div>';
  return h;
};
C_.bibAno = el => { UI.filtro.bibAno = el.value; render(); };
A.exportarVerbeteBncc = d => { const v = blocosVerbeteBncc(d.id); saidaDocumento({ nome: 'BNCC_' + v.titulo, titulo: v.titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: v.titulo }].concat(v.blocos) }, { assunto: v.titulo }); };
/* editar um verbete: campos soltos, gravados só em "Salvar alterações" */
function editorVerbete(r) {
  const orig = BIBLIO.find(x => x.id === r.id), proprio = r.origem === 'proprio';
  return '<div class="linha"><button class="btn" data-a="voltarVerbete">← Biblioteca</button><span class="etq ' + (r.origem === 'original' ? 'fin' : 'rasc') + '">' + rotOrigem(r) + '</span><span class="espaco"></span><button class="btn" data-a="exportarVerbete" data-id="' + r.id + '">Exportar</button>' + (orig && r.origem !== 'original' ? '<button class="btn" data-a="restaurarVerbete" data-id="' + r.id + '">Restaurar o texto original</button>' : '') + (proprio ? '<button class="btn perigo" data-a="apagarVerbete" data-id="' + r.id + '">Excluir verbete</button>' : '<button class="btn" data-a="ocultarVerbete" data-id="' + r.id + '" title="Os verbetes que vêm com a Tecelã não são excluídos: ficam ocultos e podem voltar">Ocultar verbete</button>') + '</div>' +
    '<form class="cartao" id="fVerbete">' + campo('Título', '<input name="titulo" value="' + e(r.titulo) + '">') + campo('Categoria', proprio ? selCategoria(r.grupo) : '<input value="' + e(r.grupo) + '" disabled>', proprio ? '' : 'Os verbetes que vêm com a Tecelã ficam na categoria original.') + campo('Texto', '<textarea name="texto" style="min-height:22rem">' + e(r.texto) + '</textarea>', 'Separe os parágrafos com uma linha em branco.') + campo('Fonte', '<input name="fonte" value="' + e(r.fonte) + '">') +
    '<div class="linha"><span class="espaco"></span><button type="button" class="btn" data-a="voltarVerbete">Cancelar</button><button class="btn pri">Salvar alterações</button></div></form>';
}
const selCategoria = atual => '<select name="grupo" data-c="bibCategoria">' + gruposBib().map(g => '<option' + (g === atual ? ' selected' : '') + '>' + e(g) + '</option>').join('') + '<option value="__nova">Nova categoria…</option></select><input name="grupoNovo" class="oculto" placeholder="Nome da nova categoria" style="margin-top:.4rem">';
C_.bibCategoria = el => { const n = el.parentNode.querySelector('[name=grupoNovo]') || el.closest('form').querySelector('[name=grupoNovo]'); if (n) { n.classList.toggle('oculto', el.value !== '__nova'); if (el.value === '__nova') n.focus(); } };
const grupoEscolhido = v => v.grupo === '__nova' ? (v.grupoNovo || '').trim() || 'Meus verbetes' : v.grupo;
T.biblio_pos = () => {
  const f = $('#fVerbete'); if (!f) return; SE.bibSujo = false;
  f.addEventListener('input', () => { SE.bibSujo = true; });
  f.addEventListener('submit', async ev => {
    ev.preventDefault(); const r = IX.biblioteca[UI.sub], v = Object.fromEntries(new FormData(f));
    if (!v.titulo.trim()) return aviso('Escreva o título do verbete.');
    Object.assign(r, { titulo: v.titulo.trim(), texto: v.texto, fonte: v.fonte.trim() }); if (r.origem === 'proprio') r.grupo = grupoEscolhido(v); else if (r.origem === 'original' || r.origem === 'branco') r.origem = 'editado';
    await salvar('biblioteca', r); SE.bibSujo = false; aviso('Alterações salvas em “' + r.titulo + '”.'); render();
  });
};
A.voltarVerbete = async () => { if (SE.bibSujo && !(await confirmar('Sair sem salvar?', 'As alterações deste verbete ainda não foram salvas.', 'Sair sem salvar'))) return; SE.bibSujo = false; UI.sub = null; render(); };
const blocosVerbete = r => [{ t: 'h', txt: r.titulo }].concat(nl2p(r.texto).map(p => ({ t: 'p', txt: p }))).concat(r.fonte ? [{ t: 'nota', txt: 'Fonte: ' + r.fonte }] : []);
A.exportarVerbete = async d => { const r = IX.biblioteca[d.id]; saidaDocumento({ nome: 'Verbete_' + r.titulo, titulo: r.titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: blocosVerbete(r) }, { assunto: r.titulo }); };
A.exportarBiblio = () => { const b = [{ t: 'tit', txt: 'Biblioteca Waldorf' }]; let g = ''; bibVisiveis().sort((a, b) => (a.ordem || 999) - (b.ordem || 999)).filter(r => r.texto).forEach(r => { if (r.grupo !== g) { g = r.grupo; b.push({ t: 'centro', linhas: [g], negrito: true, espaco: true }); } b.push(...blocosVerbete(r)); }); saidaDocumento({ nome: 'Biblioteca_Waldorf', titulo: 'Biblioteca Waldorf', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b }, { assunto: 'Biblioteca Waldorf' }); };
A.restaurarVerbete = async d => { const o = BIBLIO.find(x => x.id === d.id); if (!(await confirmar('Restaurar o original?', 'O texto atual deste verbete será substituído pelo original.', 'Restaurar'))) return; Object.assign(IX.biblioteca[d.id], { titulo: o.titulo, texto: o.texto, fonte: o.fonte, origem: 'original' }); await salvar('biblioteca', IX.biblioteca[d.id]); SE.bibSujo = false; render(); };
A.apagarVerbete = async d => { const r = IX.biblioteca[d.id]; if (!(await confirmar('Excluir “' + e(r.titulo) + '”?', 'O verbete sai da Biblioteca. Logo depois, o aviso embaixo oferece “Desfazer”.', 'Excluir'))) return; SE.bibSujo = false; await apagarComDesfazer('biblioteca', d.id, 'Verbete excluído.', () => { UI.sub = null; render(); }); };
A.ocultarVerbete = async d => { const r = IX.biblioteca[d.id]; if (!(await confirmar('Ocultar “' + e(r.titulo) + '”?', 'O verbete sai da lista, da exportação e da leitura dos relatórios. Ele continua guardado e pode voltar em “Verbetes ocultos”, no fim da Biblioteca.', 'Ocultar'))) return; r.oculto = true; await salvar('biblioteca', r); SE.bibSujo = false; UI.sub = null; render(); aviso('Verbete ocultado.', 'Desfazer', async () => { r.oculto = false; await salvar('biblioteca', r); render(); }); };
A.reexibirVerbete = async d => { const r = IX.biblioteca[d.id]; r.oculto = false; await salvar('biblioteca', r); render(); aviso('“' + r.titulo + '” voltou para a Biblioteca.'); };
/* novo verbete: formulário com "Inserir na Biblioteca"; nada é criado se a professora cancelar */
A.novoVerbete = async () => {
  const v = await dlg({ titulo: 'Novo verbete', largo: true, ok: 'Inserir na Biblioteca', corpo: campo('Título', '<input name="titulo" autofocus>') + campo('Categoria', selCategoria('Meus verbetes'), 'Escolha uma categoria que já existe, “Meus verbetes” ou crie uma nova.') + campo('Texto', '<textarea name="texto" style="min-height:14rem"></textarea>', 'Separe os parágrafos com uma linha em branco.') + campo('Fonte (opcional)', '<input name="fonte" placeholder="Livro, autor, ano">'),
    aoAbrir: f => { const s = f.querySelector('[name=grupo]'); s.addEventListener('change', () => C_.bibCategoria(s)); },
    validar: x => !x.titulo.trim() ? 'Escreva o título do verbete.' : x.grupo === '__nova' && !x.grupoNovo.trim() ? 'Escreva o nome da nova categoria.' : null });
  if (!v) return;
  const grupo = grupoEscolhido(v), ordem = Math.max(900, ...D.biblioteca.filter(r => r.grupo === grupo).map(r => (r.ordem || 0) + 1));
  const r = await salvar('biblioteca', { id: 'proprio-' + uid(), grupo, titulo: v.titulo.trim(), texto: v.texto, fonte: v.fonte.trim(), origem: 'proprio', ordem });
  UI.sub = null; render(); aviso('Verbete “' + r.titulo + '” inserido em ' + grupo + '.', 'Abrir', () => ir('biblio', r.id));
};
A.bibPronta = async () => { if (!(await confirmar('Recomeçar com a biblioteca pronta?', 'Todos os verbetes originais voltam ao texto original. Seus verbetes próprios são mantidos.', 'Recomeçar'))) return; const prop = D.biblioteca.filter(r => r.origem === 'proprio'); for (const r of D.biblioteca.slice()) if (r.origem !== 'proprio') await apagar('biblioteca', r.id); carregarBiblioteca('pronta'); prop.forEach(r => { D.biblioteca.push(r); }); indexar('biblioteca'); for (const r of D.biblioteca) await salvar('biblioteca', r); await prefs({ biblio: 'pronta' }); render(); };
A.bibBranco = async () => { if (!(await confirmar('Esvaziar os textos?', 'Os tópicos continuam, mas os textos originais e editados ficam em branco para você escrever. Dá para restaurar depois.', 'Esvaziar'))) return; for (const r of D.biblioteca) if (r.origem !== 'proprio') { r.texto = ''; r.origem = 'branco'; await salvar('biblioteca', r); } await prefs({ biblio: 'branco' }); render(); };
