/* ==========================================================================
   Tecelã — núcleo: utilidades, criptografia, banco (IndexedDB), estado,
   diálogos, vínculo de campos, cópia de segurança, senha e travamento.
   Padrões de criptografia e de arquivos adaptados do PazNoBolso 0.9.
   ========================================================================== */
'use strict';
const VERSAO = '1.7.1';
/* anos visíveis nas listas: o 9º ano fica oculto por padrão (na tradição Waldorf ele já é o início do ensino médio);
   uma turma de 9º ano que já exista continua aparecendo */
const seriesVisiveis = extra => { const r = [1, 2, 3, 4, 5, 6, 7, 8]; if (CFG.prefs.mostrar9 || (typeof D !== 'undefined' && D.turmas && D.turmas.some(t => t.serie === 9)) || extra === 9) r.push(9); return r; };
const DATA_VERSAO = '6 de novembro de 2026';
const AUTORIA = 'Tecelã — criada por Márcio Willians Barreto de Andrade. Software livre como ferramenta de inclusão social e digital. Contra a pirataria: use, estude e compartilhe dentro da licença.';
const SLOGAN = 'Fio a fio, tecendo as linhas da vida escolar';
const AUTOR = 'Márcio Willians Barreto de Andrade';
const CONTATO = 'marciowillians@gmail.com';
/* onde baixar a versão mais recente (sempre a última publicada) */
const LINK_VERSOES = 'https://github.com/MarcioWillians/tecela/releases/latest';
const NAO_ENVIE = 'Não envie dados de crianças, seus ou da entidade, nem prints com nomes.';
const lnkExt = (url, txt) => '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + (txt || url) + '</a>';
/* aviso da BNCC (aba BNCC do Currículo e verbete da Biblioteca) */
const AVISO_BNCC_TXT = 'A Tecelã traz a BNCC homologada (2017/2018) e o complemento de Computação (2022), sem alterações. Se o MEC publicar mudanças e a Tecelã ainda não estiver atualizada, avise por e-mail: ' + CONTATO + '. ' + NAO_ENVIE;
const avisoBnccHtml = () => '<div class="alerta aviso-bncc"><b>Sobre a BNCC nesta versão.</b> A Tecelã traz a BNCC homologada (2017/2018) e o complemento de Computação (2022), sem alterações. Se o MEC publicar mudanças e a Tecelã ainda não estiver atualizada, avise por e-mail: <a href="mailto:' + CONTATO + '?subject=Tecel%C3%A3%20-%20BNCC">' + CONTATO + '</a>. ' + NAO_ENVIE + '</div>';
/* sugestões e novas versões (Ajuda → Sobre, e o link da tela inicial) */
const contatoHtml = () => '<div class="cartao contato" id="m-contato-app"><h3>Sugestões e novas versões</h3><p>Tem uma sugestão, encontrou um problema ou precisa de algo novo? Escreva para <a href="mailto:' + CONTATO + '?subject=Tecel%C3%A3%20-%20sugest%C3%A3o">' + CONTATO + '</a>. ' + NAO_ENVIE + '</p><p>Para ver se há versão mais recente: ' + lnkExt(LINK_VERSOES, 'github.com/MarcioWillians/tecela') + '. Você está usando a versão ' + VERSAO + '.</p><p><b>Para atualizar:</b> salve o seu arquivo (💾 Salvar), baixe o novo <i>Tecela.html</i> e substitua o antigo na mesma pasta, com o mesmo nome.</p></div>';
const STORES = ['config', 'timbrado', 'turmas', 'alunos', 'matriculas', 'anotacoes', 'atas', 'marcacoes', 'modelosBoletim', 'boletins', 'perfisAluno', 'perfisTurma', 'biblioteca', 'cadastros', 'eventos', 'vivencias', 'tarefas', 'curriculo', 'observacoes', 'conselhos', 'documentos', 'reforcos', 'programa', 'repertorio', 'contatos', 'comunicados'];
const DADOS = STORES.filter(s => s !== 'config');

/* ---------- utilidades ---------- */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const e = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const hojeISO = (d) => { d = d || new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const dataBR = iso => iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4) : '';
const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
const clone = o => JSON.parse(JSON.stringify(o));
const ordemNome = (a, b) => (a.nome || '').localeCompare(b.nome || '', 'pt-BR');
const nl2p = t => String(t || '').split(/\n{1,}/).map(s => s.trim()).filter(Boolean);
function idadeEm(nasc, ref) {
  if (!nasc) return null; const n = new Date(nasc + 'T12:00'), r = ref ? new Date(ref + 'T12:00') : new Date();
  let m = (r.getFullYear() - n.getFullYear()) * 12 + (r.getMonth() - n.getMonth()); if (r.getDate() < n.getDate()) m--; return m; // em meses
}
const idadeTxt = m => m == null ? '—' : Math.floor(m / 12) + ' a ' + (m % 12) + ' m';
function setenio(meses) { if (meses == null) return ''; const a = meses / 12; return a < 7 ? '1º setênio' : a < 14 ? '2º setênio' : a < 21 ? '3º setênio' : '—'; }
function setP(o, p, v) { const ks = p.split('.'); let a = o; ks.slice(0, -1).forEach(k => { if (a[k] == null || typeof a[k] !== 'object') a[k] = {}; a = a[k]; }); a[ks[ks.length - 1]] = v; }
async function sha256(txt) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(txt)); return Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''); }

/* ---------- criptografia (senha opcional) ---------- */
const temCripto = () => !!(window.crypto && crypto.subtle);
const b64 = u => { let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s); };
const ub64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function kek(segredo, salt) { const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(segredo), 'PBKDF2', false, ['deriveKey']); return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); }
async function embrulhar(dk, segredo) { const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), k = await kek(segredo, salt), ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, dk)), w = new Uint8Array(12 + ct.length); w.set(iv); w.set(ct, 12); return { s: b64(salt), w: b64(w) }; }
async function desembrulhar(s, w, segredo) { const k = await kek(segredo, ub64(s)), b = ub64(w); return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b.subarray(0, 12) }, k, b.subarray(12))); }
let CHAVE_CACHE = null;
async function chaveAES(dk) { if (CHAVE_CACHE && CHAVE_CACHE.dk === dk) return CHAVE_CACHE.k; const k = await crypto.subtle.importKey('raw', dk, 'AES-GCM', false, ['encrypt', 'decrypt']); CHAVE_CACHE = { dk, k }; return k; }
async function cifrar(dk, texto) { const iv = crypto.getRandomValues(new Uint8Array(12)), ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await chaveAES(dk), new TextEncoder().encode(texto))); return { iv: b64(iv), d: b64(ct) }; }
async function decifrar(dk, iv, d) { return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ub64(iv) }, await chaveAES(dk), ub64(d))); }
function novaChave() { const al = '0123456789ABCDEFGHJKMNPQRSTVWXYZ', b = crypto.getRandomValues(new Uint8Array(20)); let bits = 0, n = 0, s = ''; for (const x of b) { bits = (bits << 8) | x; n += 8; while (n >= 5) { s += al[(bits >> (n - 5)) & 31]; n -= 5; } } return s.match(/.{4}/g).join('-'); }
function normChave(s) { return String(s || '').toUpperCase().replace(/O/g, '0').replace(/[IL]/g, '1').replace(/[^0-9A-Z]/g, ''); }

/* ---------- banco ---------- */
let BANCO = 'tecela', DB = null;
const D = {}, IX = {};
let CFG = { prefs: {}, escola: {}, cripto: null };
const SE = { dk: null, memoria: false, demo: false, travado: false, saiu: false, timers: {}, fila: new Map() };
const PREFS_PADRAO = { tema: 'claro', fs: 16, inativ: 10, lgpdOk: false, biblio: null, turmaId: null, pendente: false, ultimaCopia: null, periodos: ['1º bimestre', '2º bimestre', '3º bimestre', '4º bimestre'], prazoEgressos: 5, ataFormato: 'moderno', periodoObs: 'semestral', arquivoNome: null, copiaNova: false, fonteTexto: '', fonteTitulo: '', fontePoema: '', reforcoSaida: '15h' , mostrar9: false, navFechados: [], minDias: 200, minHoras: 800 };
function zerarMemoria() { DADOS.forEach(s => { D[s] = []; IX[s] = {}; }); }
zerarMemoria();

function abrirBanco(nome) {
  return new Promise((res, rej) => {
    if (!window.indexedDB) return rej(new Error('sem IndexedDB'));
    let r; try { r = indexedDB.open(nome, 5); } catch (x) { return rej(x); }
    r.onupgradeneeded = () => { const db = r.result; STORES.forEach(s => { if (!db.objectStoreNames.contains(s)) db.createObjectStore(s, { keyPath: 'id' }); }); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('banco bloqueado'));
  });
}
function tx(store, modo, fn) {
  return new Promise((res, rej) => { const t = DB.transaction(store, modo), s = t.objectStore(store); const out = fn(s); t.oncomplete = () => res(out && out.result); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); });
}
const idbTudo = store => DB ? tx(store, 'readonly', s => s.getAll()) : Promise.resolve([]);
const idbPor = (store, v) => DB ? tx(store, 'readwrite', s => s.put(v)) : Promise.resolve();
const idbApagar = (store, id) => DB ? tx(store, 'readwrite', s => s.delete(id)) : Promise.resolve();
const idbLimpar = store => DB ? tx(store, 'readwrite', s => s.clear()) : Promise.resolve();

async function lerConfig() {
  const c = { prefs: Object.assign({}, PREFS_PADRAO), escola: {}, cripto: null };
  if (!DB) return c;
  for (const r of await idbTudo('config')) { if (r.id === 'prefs') Object.assign(c.prefs, r.v); else if (r.id === 'escola') c.escola = r.v || {}; else if (r.id === 'cripto') c.cripto = r.v; }
  return c;
}
async function gravarConfig(id) { if (!DB || SE.memoria) return; await idbPor('config', { id, v: CFG[id] }); }
async function prefs(muda) { Object.assign(CFG.prefs, muda); await gravarConfig('prefs'); }

async function empacotarRegistro(r) { if (!SE.dk) return r; const c = await cifrar(SE.dk, JSON.stringify(r)); return { id: r.id, _e: c }; }
async function desempacotarRegistro(r) { if (!r || !r._e) return r; return JSON.parse(await decifrar(SE.dk, r._e.iv, r._e.d)); }
async function carregarTudo() {
  zerarMemoria();
  for (const s of DADOS) { const rs = await idbTudo(s); for (const r of rs) { const v = await desempacotarRegistro(r); D[s].push(v); IX[s][v.id] = v; } }
}
function indexar(s) { IX[s] = {}; D[s].forEach(r => IX[s][r.id] = r); }

/* gravação: memória na hora, disco logo depois (fila por registro) */
function marcarPendente() { SE.salvoAs = new Date(); const era = CFG.prefs.pendente; if (!CFG.prefs.pendente && !SE.demo && !SE.memoria) { CFG.prefs.pendente = true; gravarConfig('prefs'); } else CFG.prefs.pendente = true; if (SE.app && typeof atualizarEstadoSalvo === 'function') { clearTimeout(SE.tEstado); SE.tEstado = setTimeout(atualizarEstadoSalvo, era ? 300 : 0); } }
async function salvar(store, r) {
  if (!r.id) r.id = uid();
  r.alterado = new Date().toISOString(); if (!r.criado) r.criado = r.alterado;
  if (!IX[store][r.id]) { D[store].push(r); IX[store][r.id] = r; } else if (IX[store][r.id] !== r) { Object.assign(IX[store][r.id], r); r = IX[store][r.id]; }
  marcarPendente();
  if (DB && !SE.memoria) { try { await idbPor(store, await empacotarRegistro(r)); } catch (x) { aviso('Não foi possível gravar: ' + (x && x.message || x)); } }
  return r;
}
function salvarDepois(store, r) { const k = store + ':' + r.id; clearTimeout(SE.timers[k]); SE.fila.set(k, [store, r]); SE.timers[k] = setTimeout(() => { SE.fila.delete(k); salvar(store, r); }, 450); }
async function descarregarFila() { const itens = Array.from(SE.fila.values()); SE.fila.clear(); Object.values(SE.timers).forEach(clearTimeout); for (const [s, r] of itens) await salvar(s, r); }
async function apagar(store, id) { const r = IX[store][id]; if (!r) return; D[store].splice(D[store].indexOf(r), 1); delete IX[store][id]; marcarPendente(); if (DB && !SE.memoria) await idbApagar(store, id); }
async function regravarTudo() { if (!DB || SE.memoria) return; for (const s of DADOS) { await idbLimpar(s); for (const r of D[s]) await idbPor(s, await empacotarRegistro(r)); } }

/* ---------- interface básica ---------- */
let tAviso = null;
/* aviso discreto; com rot+fn, mostra um botão (ex.: "Desfazer") por alguns segundos */
function aviso(msg, rot, fn) {
  const a = $('#aviso'); if (!a) return; a.textContent = msg; a.classList.toggle('acao', !!fn);
  if (fn) { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn peq'; b.textContent = rot || 'Desfazer'; b.onclick = async () => { a.classList.remove('on'); await fn(); }; a.append(' ', b); }
  a.classList.add('on'); clearTimeout(tAviso); tAviso = setTimeout(() => a.classList.remove('on'), fn ? 7000 : 3800);
}
/* apagar com "desfazer": o registro volta igual, com o mesmo id */
async function apagarComDesfazer(store, id, msg, depois) {
  const r = IX[store][id]; if (!r) return; const copia = clone(r); await apagar(store, id); if (depois) depois(); else render();
  aviso(msg || 'Apagado.', 'Desfazer', async () => { await salvar(store, copia); if (depois) depois(); else render(); aviso('Restaurado.'); });
}
function dlg(o) {
  return new Promise(res => {
    const f = document.createElement('div'); f.className = 'fundo';
    f.innerHTML = '<form class="modal ' + (o.largo ? 'largo' : '') + '" novalidate><h2>' + e(o.titulo) + '</h2><div class="corpo">' + (o.corpo || '') + '</div><p class="erro oculto" role="alert"></p><div class="pe">' + (o.extra || '') + (o.cancelar === false ? '' : '<button type="button" class="btn" data-x="c">' + (o.cancelar || 'Cancelar') + '</button>') + (o.ok === false ? '' : '<button class="btn pri">' + (o.ok || 'OK') + '</button>') + '</div></form>';
    $('#modais').appendChild(f); const form = f.firstChild, fechar = v => { f.remove(); res(v); };
    f.addEventListener('click', ev => { const x = ev.target.closest('[data-x]'); if (x && x.dataset.x === 'c') fechar(null); else if (x && x.dataset.x) fechar({ _botao: x.dataset.x }); });
    f.addEventListener('keydown', ev => { if (ev.key === 'Escape' && o.cancelar !== false) fechar(null); });
    form.addEventListener('submit', async ev => {
      ev.preventDefault(); const v = {}; form.querySelectorAll('[name]').forEach(el => { if (el.type === 'checkbox') { if (el.dataset.multi) { (v[el.name] = v[el.name] || []); if (el.checked) v[el.name].push(el.value); } else v[el.name] = el.checked; } else if (el.type === 'radio') { if (el.checked) v[el.name] = el.value; } else v[el.name] = el.value; });
      if (o.validar) { const er = await o.validar(v, form); if (er) { const p = $('.erro', form); p.textContent = er; p.classList.remove('oculto'); return; } }
      fechar(v);
    });
    if (o.aoAbrir) o.aoAbrir(form, fechar);
    const foco = form.querySelector('[autofocus]') || form.querySelector('input,select,textarea'); if (foco) setTimeout(() => foco.focus(), 30);
  });
}
const confirmar = (titulo, texto, ok) => dlg({ titulo, corpo: '<p>' + texto + '</p>', ok: ok || 'Confirmar' });
const informar = (titulo, html) => dlg({ titulo, corpo: html, cancelar: false, ok: 'Fechar' });
/* Seletor do arquivo .tecela em cada aparelho.
   - Android: a extensão .tecela não é registrada no sistema, que a trata como "Arquivo em BIN" (application/octet-stream).
     Filtrar só por .tecela deixava o arquivo cinza; não filtrar fazia o Chrome abrir a escolha "Câmera / Galeria", sem acesso
     aos arquivos. Com tipos de documento (BIN, JSON e texto), o navegador abre direto o seletor de arquivos do sistema e o
     .tecela fica habilitado.
   - iPhone e iPad: sem filtro, o Safari mostra "Escolher arquivo", que abre o app Arquivos.
   - Computador: filtro pela extensão.
   Em todos os casos o conteúdo é conferido ao ler (lerCopia). */
const ANDROID = /Android/i.test(navigator.userAgent);
const APPLE_TOQUE = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const ACEITA_TECELA = ANDROID ? 'application/octet-stream,application/json,text/plain,.tecela,.json,.txt' : APPLE_TOQUE ? '' : '.tecela,.json,application/json';
function escolherArquivo(accept) { return new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.accept = accept; i.style.display = 'none'; document.body.appendChild(i); i.addEventListener('change', () => { res(i.files[0] || null); i.remove(); }); i.addEventListener('cancel', () => { res(null); i.remove(); }); i.click(); }); }
function baixar(nome, conteudo, tipo) { const blob = conteudo instanceof Blob ? conteudo : new Blob([conteudo], { type: tipo || 'application/octet-stream' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nome; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 3000); }
let ultimoLocal = null;
async function salvarComo(nome, conteudo, tipo, descricao) {
  if (typeof window.showSaveFilePicker !== 'function') { baixar(nome, conteudo, tipo); return { nome, escolheu: false }; }
  const ext = nome.slice(nome.lastIndexOf('.')), janela = inicio => window.showSaveFilePicker({ suggestedName: nome, startIn: inicio, types: [{ description: descricao, accept: { [tipo]: [ext] } }] });
  let h;
  try { h = await janela(ultimoLocal || 'documents'); }
  catch (x) { if (x && x.name === 'AbortError') return null; try { h = await janela('downloads'); } catch (y) { if (y && y.name === 'AbortError') return null; baixar(nome, conteudo, tipo); return { nome, escolheu: false }; } }
  const w = await h.createWritable(); await w.write(conteudo); await w.close(); ultimoLocal = h; return { nome: h.name, escolheu: true };
}
const nomeArq = s => String(s || 'documento').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_').slice(0, 60);

/* ---------- vínculo de campos: data-rec="store:id" + data-b="caminho" ---------- */
function bloqueado(store, r) { return r && r.estado === 'finalizado' && (store === 'atas' || store === 'boletins'); }
function vincular(el, mudou) {
  const c = el.closest('[data-rec]'); if (!c) return; const k = c.dataset.rec.indexOf(':'), st = c.dataset.rec.slice(0, k), id = c.dataset.rec.slice(k + 1), r = IX[st] && IX[st][id]; if (!r || bloqueado(st, r)) return;
  let v = el.type === 'checkbox' ? el.checked : el.type === 'number' ? (el.value === '' ? null : Number(el.value)) : el.value;
  setP(r, el.dataset.b, v); salvarDepois(st, r);
  if (mudou && el.dataset.rr) render();
}
document.addEventListener('input', ev => { const el = ev.target.closest('[data-b]'); if (el && el.type !== 'checkbox' && el.tagName !== 'SELECT') vincular(el, false); });
/* campos de data: o navegador já considera válida a data enquanto o ano é digitado (ano 0002…), então a tela só é
   redesenhada quando a pessoa sai do campo; antes disso o valor é só gravado */
function aoMudar(alvo, ev) { const el = alvo.closest('[data-b]'); if (el) vincular(el, true); const c = alvo.closest('[data-c]'); if (c && C_[c.dataset.c]) C_[c.dataset.c](c, ev); }
document.addEventListener('focusin', ev => { if (ev.target.type === 'date') ev.target._foco = true; });
document.addEventListener('focusout', ev => { if (ev.target.type === 'date') ev.target._foco = false; });
document.addEventListener('change', ev => {
  const t = ev.target;
  if (t.type === 'date' && t._foco && (t.dataset.rr || t.dataset.c)) {
    const el = t.closest('[data-b]'); if (el) vincular(el, false);
    if (!t._adiado) { t._adiado = true; t.addEventListener('blur', () => { t._adiado = false; if (t.isConnected) aoMudar(t, ev); }, { once: true }); }
    return;
  }
  aoMudar(t, ev);
});
document.addEventListener('input', ev => { const c = ev.target.closest('[data-i]'); if (c && C_[c.dataset.i]) C_[c.dataset.i](c, ev); });
const A = {}, C_ = {}, T = {};
document.addEventListener('click', ev => { const el = ev.target.closest('[data-a]'); if (!el || el.disabled) return; const fn = A[el.dataset.a]; if (fn) { ev.preventDefault(); fn(el.dataset, el, ev); } });
const campo = (rotulo, html, dica) => '<label class="cp"><span class="r">' + rotulo + '</span>' + html + (dica ? '<span class="dica">' + dica + '</span>' : '') + '</label>';
const inp = (b, v, tipo, extra) => '<input type="' + (tipo || 'text') + '" data-b="' + b + '" value="' + e(v) + '" ' + (extra || '') + '>';
const area = (b, v, extra) => '<textarea data-b="' + b + '" ' + (extra || '') + '>' + e(v) + '</textarea>';
const sel = (b, v, ops, extra) => '<select data-b="' + b + '" ' + (extra || '') + '>' + ops.map(o => { const [val, rot] = Array.isArray(o) ? o : [o, o]; return '<option value="' + e(val) + '"' + (String(v) === String(val) ? ' selected' : '') + '>' + e(rot) + '</option>'; }).join('') + '</select>';
const ck = (b, v, rot, extra) => '<label class="ck"><input type="checkbox" data-b="' + b + '"' + (v ? ' checked' : '') + ' ' + (extra || '') + '> <span>' + rot + '</span></label>';

/* ---------- senha ---------- */
async function definirSenha(titulo, texto) {
  return dlg({
    titulo, ok: 'Definir senha',
    corpo: '<p>' + texto + '</p>' + campo('Senha (mínimo de 6 caracteres)', '<input type="password" name="s1" autofocus autocomplete="new-password">') + campo('Repita a senha', '<input type="password" name="s2" autocomplete="new-password">') + campo('Dica da senha (opcional)', '<input name="dica" autocomplete="off">', 'A dica fica visível na tela de entrada. Não escreva a senha nela.'),
    validar: v => v.s1.length < 6 ? 'Use pelo menos 6 caracteres.' : v.s1 !== v.s2 ? 'As duas senhas não são iguais.' : v.dica && v.dica.includes(v.s1) ? 'A dica não pode conter a senha.' : null
  });
}
async function mostrarChave(chave) {
  await dlg({
    titulo: 'Chave de recuperação', cancelar: false, ok: 'Continuar',
    corpo: '<p>Se você esquecer a senha, esta chave é a única forma de abrir seus dados. Ela aparece só agora.</p><div class="chave">' + chave + '</div><p>Imprima ou anote e guarde longe do aparelho. Quem tiver a chave consegue abrir os dados.</p><label class="ck"><input type="checkbox" name="ok"> Já imprimi ou anotei a chave</label>',
    extra: '<button type="button" class="btn" id="impCh">Imprimir a chave</button>',
    aoAbrir: f => $('#impCh', f).addEventListener('click', () => imprimirHtml('<div class="doc"><h2>Tecelã: chave de recuperação</h2><p>Guarde esta folha em local seguro.</p><p style="font-size:20pt;font-family:monospace;text-align:center">' + chave + '</p><p>Gerada em ' + dataBR(hojeISO()) + '. Use na tela de senha, em “Esqueci a senha”.</p></div>', 'A4')),
    validar: v => v.ok ? null : 'Marque a caixa depois de imprimir ou anotar a chave.'
  });
}
async function ligarSenha() {
  if (!temCripto()) return informar('Senha indisponível', '<p>Este navegador não oferece a criptografia necessária. Use uma versão recente do Chrome, Edge, Firefox ou Safari.</p>');
  const v = await definirSenha('Ligar a senha', 'Com a senha ligada, todos os dados deste aparelho e o arquivo .tecela passam a ser criptografados.'); if (!v) return false;
  await descarregarFila();
  const dk = crypto.getRandomValues(new Uint8Array(32)), chave = novaChave(), a = await embrulhar(dk, v.s1), b = await embrulhar(dk, normChave(chave));
  CFG.cripto = { s1: a.s, w1: a.w, s2: b.s, w2: b.w, dica: v.dica.trim() }; SE.dk = dk;
  await gravarConfig('cripto'); await regravarTudo(); await mostrarChave(chave); tocar(true); aviso('Senha ligada. Os dados estão criptografados.'); return true;
}
async function desligarSenha() {
  let ok = false;
  const v = await dlg({ titulo: 'Desligar a senha', ok: 'Desligar', corpo: '<p class="alerta verm">Sem senha, qualquer pessoa que use este aparelho pode ler os dados das crianças. A LGPD recomenda manter a proteção.</p>' + campo('Confirme a senha atual', '<input type="password" name="s" autofocus>'), validar: async v => { try { await desembrulhar(CFG.cripto.s1, CFG.cripto.w1, v.s); ok = true; } catch (x) { return 'Senha incorreta.'; } } });
  if (!v || !ok) return; await descarregarFila(); SE.dk = null; CFG.cripto = null; if (DB) await idbApagar('config', 'cripto'); await regravarTudo(); render(); aviso('Senha desligada.');
}
async function trocarSenha() {
  let ok = false;
  const v = await dlg({ titulo: 'Alterar a senha', ok: 'Continuar', corpo: campo('Senha atual', '<input type="password" name="s" autofocus>'), validar: async v => { try { await desembrulhar(CFG.cripto.s1, CFG.cripto.w1, v.s); ok = true; } catch (x) { return 'Senha incorreta.'; } } });
  if (!v || !ok) return; const n = await definirSenha('Nova senha', 'A chave de recuperação continua a mesma.'); if (!n) return;
  const a = await embrulhar(SE.dk, n.s1); CFG.cripto.s1 = a.s; CFG.cripto.w1 = a.w; CFG.cripto.dica = n.dica.trim(); await gravarConfig('cripto'); aviso('Senha alterada.');
}
async function abrirComSenha(c, senha, chave) { return chave ? desembrulhar(c.s2, c.w2, normChave(chave)) : desembrulhar(c.s1, c.w1, senha); }

/* travamento por inatividade */
let tInativ = null, ultToque = 0;
function tocar(forcar) { const n = Date.now(); if (!forcar && n - ultToque < 4000) return; ultToque = n; clearTimeout(tInativ); if (SE.dk && CFG.prefs.inativ > 0 && !SE.travado) tInativ = setTimeout(travar, CFG.prefs.inativ * 60000); }
['mousemove', 'keydown', 'click', 'touchstart'].forEach(t => document.addEventListener(t, () => tocar(false), { passive: true }));
async function travar() { if (!SE.dk) return; await descarregarFila(); zerarMemoria(); SE.dk = null; CHAVE_CACHE = null; SE.travado = true; $('#modais').innerHTML = ''; telaSenha('A Tecelã foi travada por inatividade.'); }

/* ---------- cópia de segurança ---------- */
async function pacoteCopia() {
  await descarregarFila();
  const dados = { config: { escola: CFG.escola, prefs: { periodos: CFG.prefs.periodos, biblio: CFG.prefs.biblio, prazoEgressos: CFG.prefs.prazoEgressos, ataFormato: CFG.prefs.ataFormato, periodoObs: CFG.prefs.periodoObs, mig12: CFG.prefs.mig12, mig13: CFG.prefs.mig13, bnccComputacao: CFG.prefs.bnccComputacao, fonteTexto: CFG.prefs.fonteTexto, fonteTitulo: CFG.prefs.fonteTitulo, fontePoema: CFG.prefs.fontePoema, reforcoSaida: CFG.prefs.reforcoSaida, bilheteReforco: CFG.prefs.bilheteReforco, mig15: CFG.prefs.mig15, mostrar9: CFG.prefs.mostrar9, mig16: CFG.prefs.mig16, minDias: CFG.prefs.minDias, minHoras: CFG.prefs.minHoras, horasDia: CFG.prefs.horasDia, festas: CFG.prefs.festas } } };
  DADOS.forEach(s => dados[s] = D[s]);
  const base = { app: 'Tecela', formato: 1, versao: VERSAO, guardado: new Date().toISOString() };
  if (!SE.dk) return JSON.stringify(Object.assign(base, { dados }));
  const c = await cifrar(SE.dk, JSON.stringify(dados));
  return JSON.stringify(Object.assign(base, { cripto: Object.assign({ kdf: 'PBKDF2-SHA256-250000', cifra: 'AES-256-GCM', iv: c.iv }, CFG.cripto), dados: c.d }));
}
/* ---------- arquivo de trabalho (como no PazNoBolso): "Salvar" grava no mesmo arquivo ---------- */
/* o nome do arquivo leva a data e a hora em que foi guardado: Tecela_Escola_2026-11-05_14h32.tecela */
const carimbo = (d => { d = d || new Date(); return hojeISO(d) + '_' + String(d.getHours()).padStart(2, '0') + 'h' + String(d.getMinutes()).padStart(2, '0'); });
const semCarimbo = n => String(n || '').replace(/\.(tecela|json)$/i, '').replace(/_\d{4}-\d{2}-\d{2}_\d{2}h\d{2}$/, '');
const nomeComData = base => (semCarimbo(base) || 'Tecela_' + nomeArq(CFG.escola.nome || 'turma')) + '_' + carimbo() + '.tecela';
const nomeArquivoPadrao = () => nomeComData('Tecela_' + nomeArq(CFG.escola.nome || 'turma'));
async function lerHandle() { if (!DB || SE.memoria) return null; try { const r = (await idbTudo('config')).find(x => x.id === 'arqHandle'); return r ? r.v : null; } catch (x) { return null; } }
async function guardarHandle(h) { SE.arq = h; if (DB && !SE.memoria && !SE.demo) { try { await idbPor('config', { id: 'arqHandle', v: h }); } catch (x) { } } }
async function permissao(h) { try { if (!h.queryPermission) return true; if (await h.queryPermission({ mode: 'readwrite' }) === 'granted') return true; return await h.requestPermission({ mode: 'readwrite' }) === 'granted'; } catch (x) { return false; } }
async function guardar(comoNovo) {
  if (SE.demo) { aviso('O modelo de demonstração não é salvo em arquivo.'); return false; }
  const txt = await pacoteCopia(); let nome = null, escolheu = true;
  let h = comoNovo || CFG.prefs.copiaNova ? null : (SE.arq || await lerHandle());
  if (h && h.createWritable && await permissao(h)) {
    try { const w = await h.createWritable(); await w.write(txt); await w.close(); nome = h.name;
      /* o mesmo arquivo, renomeado com a nova data e hora, quando o navegador permite */
      if (typeof h.move === 'function') { const novo = nomeComData(h.name); try { await h.move(novo); nome = h.name || novo; } catch (x) { } }
    } catch (x) { h = null; nome = null; } } else h = null;
  if (!nome) { const r = await salvarComo(nomeComData(CFG.prefs.arquivoNome || nomeArquivoPadrao()), txt, 'application/json', 'Arquivo da Tecelã'); if (!r) { aviso('Nada foi salvo: a janela de salvar foi cancelada.'); return false; } nome = r.nome; escolheu = r.escolheu; if (r.escolheu && ultimoLocal) await guardarHandle(ultimoLocal); }
  await prefs({ pendente: false, ultimaCopia: new Date().toISOString(), arquivoNome: nome });
  aviso(escolheu ? 'Salvo em ' + nome : 'Salvo na pasta de downloads: ' + nome); if (!SE.saiu && SE.app) render(); return true;
}
const fazerCopia = () => guardar(false);
function normalizarDados(d) {
  if (!d || typeof d !== 'object') throw new Error('Arquivo de dados inválido.');
  DADOS.forEach(s => { if (!Array.isArray(d[s])) d[s] = []; }); d.config = d.config || {}; return d;
}
async function lerCopia(txt) {
  let o; try { o = JSON.parse(txt); } catch (x) { throw new Error('Este não é um arquivo da Tecelã.'); }
  if (o && o.app === 'Tecela' && o.tipo === 'partilha') throw new Error('Este arquivo é uma partilha pedagógica, não um arquivo de trabalho. Para trazer o material dele, use “Receber partilha”, em Ajustes e arquivo → Partilha pedagógica. A partilha só acrescenta itens; nunca substitui os seus dados.');
  if (!o || o.app !== 'Tecela' || o.dados == null) throw new Error('Este não é um arquivo da Tecelã.');
  if (!o.cripto) return { dados: normalizarDados(o.dados), cr: null, dk: null, quando: o.guardado };
  if (!temCripto()) throw new Error('Este arquivo tem senha, mas este navegador não oferece a criptografia necessária.');
  const c = o.cripto; let dk = null;
  const r = await dlg({
    titulo: 'Arquivo protegido por senha', ok: 'Abrir', corpo: (c.dica ? '<p class="alerta">Dica: ' + e(c.dica) + '</p>' : '') + campo('Senha do arquivo', '<input type="password" name="senha" autofocus>') + '<label class="ck"><input type="checkbox" name="rec" id="ckRec"> Esqueci a senha, vou usar a chave de recuperação</label><label class="cp oculto" id="cpRec"><span class="r">Chave de recuperação</span><input name="chave"></label>',
    aoAbrir: f => $('#ckRec', f).addEventListener('change', ev => $('#cpRec', f).classList.toggle('oculto', !ev.target.checked)),
    validar: async v => { try { dk = await abrirComSenha(c, v.senha, v.rec ? v.chave : null); } catch (x) { return v.rec ? 'Chave incorreta.' : 'Senha incorreta.'; } }
  });
  if (!r) return null;
  const dados = normalizarDados(JSON.parse(await decifrar(dk, c.iv, o.dados)));
  return { dados, cr: { s1: c.s1, w1: c.w1, s2: c.s2, w2: c.w2, dica: c.dica || '' }, dk, quando: o.guardado };
}
async function aplicarCopia(r) {
  zerarMemoria(); DADOS.forEach(s => { D[s] = r.dados[s]; indexar(s); });
  if (r.dados.config.escola) CFG.escola = r.dados.config.escola;
  if (r.dados.config.prefs) Object.assign(CFG.prefs, r.dados.config.prefs);
  if (r.cr) { CFG.cripto = r.cr; SE.dk = r.dk; } else { CFG.cripto = null; SE.dk = null; if (DB && !SE.memoria) await idbApagar('config', 'cripto'); } // o arquivo define a senha
  if (DB && !SE.memoria) { if (CFG.cripto) await gravarConfig('cripto'); await gravarConfig('escola'); CFG.prefs.lgpdOk = true; CFG.prefs.pendente = false; await gravarConfig('prefs'); await regravarTudo(); }
  if (!IX.turmas[CFG.prefs.turmaId]) CFG.prefs.turmaId = (D.turmas.slice().sort((a, b) => b.ano - a.ano)[0] || {}).id || null;
}
async function escolherArquivoDados() {
  if (typeof window.showOpenFilePicker === 'function') { try { const [h] = await window.showOpenFilePicker({ types: [{ description: 'Arquivo da Tecelã', accept: { 'application/json': ['.tecela', '.json'] } }] }); return { arquivo: await h.getFile(), handle: h }; } catch (x) { if (x && x.name === 'AbortError') return null; } }
  const f = await escolherArquivo(ACEITA_TECELA); return f ? { arquivo: f, handle: null } : null;
}
async function restaurarCopia(substituir) {
  const esc = await escolherArquivoDados(); if (!esc) return false; const f = esc.arquivo;
  let r; try { r = await lerCopia(await f.text()); } catch (x) { await informar('Não foi possível abrir', '<p>' + e(x.message) + '</p>'); return false; }
  if (!r) return false;
  if (substituir) { const ok = await confirmar('Substituir os dados?', 'O arquivo foi salvo em <b>' + (r.quando ? new Date(r.quando).toLocaleString('pt-BR') : 'data desconhecida') + '</b>. Os dados atuais deste aparelho serão substituídos pelos dele.', 'Substituir'); if (!ok) return false; }
  await aplicarCopia(r); await prefs({ arquivoNome: f.name, pendente: false }); await guardarHandle(esc.handle || null); /* sem o caminho do arquivo, “Salvar” pergunta onde salvar: nunca grava no arquivo anterior */ aviso('Arquivo aberto: ' + f.name); return true;
}

/* ---------- ZIP simples (sem compressão), para entregar vários arquivos de uma vez ---------- */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u) { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC_T[(c ^ u[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
async function zipBlob(arquivos) {
  const enc = new TextEncoder(), partes = [], central = []; let pos = 0; const d = new Date(), hora = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), dia = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  for (const { nome, blob } of arquivos) {
    const dados = new Uint8Array(await blob.arrayBuffer()), n = enc.encode(nome), crc = crc32(dados), loc = new DataView(new ArrayBuffer(30));
    [[0, 0x04034b50, 4], [4, 20, 2], [6, 0x0800, 2], [8, 0, 2], [10, hora, 2], [12, dia, 2], [14, crc, 4], [18, dados.length, 4], [22, dados.length, 4], [26, n.length, 2], [28, 0, 2]].forEach(([o, v, t]) => t === 4 ? loc.setUint32(o, v, true) : loc.setUint16(o, v, true));
    const cen = new DataView(new ArrayBuffer(46));
    [[0, 0x02014b50, 4], [4, 20, 2], [6, 20, 2], [8, 0x0800, 2], [10, 0, 2], [12, hora, 2], [14, dia, 2], [16, crc, 4], [20, dados.length, 4], [24, dados.length, 4], [28, n.length, 2], [30, 0, 2], [32, 0, 2], [34, 0, 2], [36, 0, 2], [38, 0, 4], [42, pos, 4]].forEach(([o, v, t]) => t === 4 ? cen.setUint32(o, v, true) : cen.setUint16(o, v, true));
    partes.push(loc.buffer, n, dados); central.push(cen.buffer, n); pos += 30 + n.length + dados.length;
  }
  const tamC = central.reduce((s, x) => s + (x.byteLength || x.length), 0), fim = new DataView(new ArrayBuffer(22));
  [[0, 0x06054b50, 4], [8, arquivos.length, 2], [10, arquivos.length, 2], [12, tamC, 4], [16, pos, 4]].forEach(([o, v, t]) => t === 4 ? fim.setUint32(o, v, true) : fim.setUint16(o, v, true));
  return new Blob(partes.concat(central, [fim.buffer]), { type: 'application/zip' });
}

/* ---------- impressão ---------- */
/* o navegador usa o título da página como nome do PDF: durante a impressão o título vira o nome do documento */
function imprimirHtml(html, papel, margens, nome) {
  const m = margens || { s: 20, i: 20, e: 25, d: 20 }, tam = papel === 'oficio' ? '216mm 330mm' : papel === 'paisagem' ? 'A4 landscape' : 'A4';
  $('#pg').textContent = '@page{size:' + tam + ';margin:' + m.s + 'mm ' + m.d + 'mm ' + m.i + 'mm ' + m.e + 'mm}';
  $('#print').innerHTML = html;
  const tit = imprimirHtml.titulo || (imprimirHtml.titulo = document.title); if (nome) document.title = nome;
  const volta = () => { document.title = tit; window.removeEventListener('afterprint', volta); };
  window.addEventListener('afterprint', volta); setTimeout(() => window.print(), 60);
}

/* ---------- conexão e e-mail ---------- */
async function temInternet() {
  if (!navigator.onLine) return false;
  try { const c = new AbortController(), t = setTimeout(() => c.abort(), 4000); await fetch('https://www.gstatic.com/generate_204?t=' + Date.now(), { mode: 'no-cors', cache: 'no-store', signal: c.signal }); clearTimeout(t); return true; } catch (x) { return false; }
}
async function exigirInternet() {
  for (;;) {
    if (await temInternet()) return true;
    const r = await dlg({ titulo: 'Sem conexão com a internet', corpo: '<p>Para enviar por e-mail, conecte este aparelho à internet (Wi-Fi ou dados móveis) e toque em “Tentar de novo”.</p>', ok: 'Tentar de novo', cancelar: 'Cancelar' });
    if (!r) return false;
  }
}
/* envia um arquivo: compartilhamento do sistema (celular/tablet) ou salvar + e-mail pronto (computador) */
async function enviarPorEmail({ blob, nome, assunto, corpo, para }) {
  if (SE.demo) { aviso('No modelo de demonstração o envio por e-mail fica desligado.'); return; }
  if (!(await exigirInternet())) return;
  const arq = new File([blob], nome, { type: blob.type });
  if (navigator.canShare && navigator.canShare({ files: [arq] })) {
    try { await navigator.share({ files: [arq], title: assunto, text: corpo }); return; } catch (x) { if (x && x.name === 'AbortError') return; }
  }
  baixar(nome, blob);
  await informar('Anexe o arquivo ao e-mail', '<p>O arquivo <b>' + e(nome) + '</b> foi salvo na pasta de downloads. Agora vamos abrir o seu programa de e-mail com destinatário, assunto e texto prontos.</p><p>Arraste o arquivo para a mensagem (ou use o clipe de anexo) e envie.</p>');
  location.href = 'mailto:' + encodeURIComponent((para || []).join(',')).replace(/%40/g, '@').replace(/%2C/g, ',') + '?subject=' + encodeURIComponent(assunto) + '&body=' + encodeURIComponent(corpo + '\n\n(Anexo: ' + nome + ')');
}

/* ---------- aplicação de tema ---------- */
function aplicarTema() { document.documentElement.dataset.tema = CFG.prefs.tema === 'escuro' ? 'escuro' : 'claro'; document.documentElement.style.setProperty('--fs', (CFG.prefs.fs || 16) + 'px'); }

/* ---------- saída e aviso ao fechar ---------- */
window.addEventListener('beforeunload', ev => { if (!SE.saiu && !SE.demo && CFG.prefs.pendente && (D.turmas.length || D.alunos.length)) { descarregarFila(); ev.preventDefault(); ev.returnValue = ''; } });
