// Testes da versão 1.11: cópia de segurança com senha (senha das cópias sem a senha da Tecelã, chave de
// recuperação, lembrete a cada 5 dias no Painel, no alto e no Sair, explicação no primeiro Salvar, abrir a cópia
// com ou sem senha), desfazer nos textos (↶, Ctrl+Z fora do campo, trecho apagado, histórico) e digitalizados
// (foto reduzida, PDF até 3 MB, álbuns, ligações, visualizador, medidor, partilha nunca).
// Só dados fictícios. Uso: LOG=log.txt node testes/teste-v111.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
const TMP = path.resolve(__dirname, 'saida', 'v111'); fs.mkdirSync(TMP, { recursive: true });
const SENHA_C = 'copias-fict-2026';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const ctx = await b.newContext({ viewport: { width: 1280, height: 820 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo', acceptDownloads: true });
  await ctx.addInitScript(() => { window.showSaveFilePicker = undefined; window.showOpenFilePicker = undefined; window.print = () => { }; });
  const p = await ctx.newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const texto = () => p.textContent('#app');
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal', { timeout: 30000 }); return p.locator('#modais .modal').last(); };
  const baixado = async acao => { const [d] = await Promise.all([p.waitForEvent('download', { timeout: 30000 }), acao()]); const f = path.join(TMP, d.suggestedFilename()); await d.saveAs(f); return f; };

  // ---------- 1. primeiro uso sem a senha da Tecelã ----------
  await p.goto(APP); await p.waitForTimeout(400);
  await p.check('#ckLgpd'); await p.click('[data-a=novo]:not([data-bol])');
  let m = await modal(); await m.locator('[data-x=c]').click(); // Agora não
  m = await modal(); await m.locator('button.pri').click(); // biblioteca
  m = await modal(); await m.locator('[name=escola]').fill('Escola Teste (fictício)'); await m.locator('[name=ano]').fill('2026'); await m.locator('[name=prof]').fill('Rui Teste'); await m.locator('[name=gen]').selectOption('o'); await m.locator('button.pri').click();
  await p.waitForTimeout(800);
  await p.evaluate(() => ir('painel')); await p.waitForTimeout(200);
  certo(await p.locator('#corpo .alerta [data-a=copiaSeg]').count() === 1 && /ainda não fez uma cópia de segurança/.test(await texto()), 'Painel: aviso amarelo de cópia de segurança ainda não feita');
  certo(await p.locator('.estado-salvo.pend[data-a=copiaSeg]').count() === 1 && await p.locator('.btn.alerta-copia[data-a=copiaSeg]').count() === 1, 'no alto: botão 🛟 destacado e lembrete ao lado do estado do salvamento');

  // ---------- 2. primeira cópia: cria a senha das cópias e a chave ----------
  await p.click('.btn[data-a=copiaSeg]'); m = await modal();
  certo(/protegido por senha/.test(await m.textContent()) && /fora deste computador/.test(await m.textContent()), 'explicação da cópia de segurança antes de fazer');
  await m.locator('button.pri').click();
  m = await modal(); certo(/Senha das cópias de segurança/.test(await m.textContent()), 'sem a senha da Tecelã, pede a criação da senha das cópias');
  await m.locator('[name=s1]').fill(SENHA_C); await m.locator('[name=s2]').fill(SENHA_C); await m.locator('button.pri').click();
  await p.waitForSelector('#modais .chave', { timeout: 30000 }); const chave = (await p.textContent('#modais .chave')).trim();
  certo(/^[0-9A-Z]{4}(-[0-9A-Z]{4}){7}$/.test(chave), 'chave de recuperação das cópias mostrada');
  m = await modal(); await m.locator('[name=ok]').check();
  const fSeg = await baixado(() => m.locator('button.pri').click());
  m = await modal(); certo(/Cópia de segurança feita/.test(await m.textContent()) && /pendrive/.test(await m.textContent()), 'confirmação com a orientação de levar a cópia para fora do computador'); await m.locator('button.pri').click();
  const seg = JSON.parse(fs.readFileSync(fSeg, 'utf8'));
  certo(/^Tecela_COPIA_.*\.tecela$/.test(path.basename(fSeg)) && seg.copiaSeg === true && seg.cripto && typeof seg.dados === 'string', 'arquivo Tecela_COPIA_…tecela marcado como cópia de segurança e cifrado');
  certo(!JSON.stringify(seg).includes('copiaSegDk'), 'a chave das cópias não vai dentro da cópia');
  const est = await p.evaluate(() => ({ ult: !!CFG.prefs.ultimaCopiaSeg, cr: !!CFG.prefs.copiaSegCripto, dk: !!CFG.prefs.copiaSegDk, ap: CFG.cripto }));
  certo(est.ult && est.cr && est.dk && !est.ap, 'senha das cópias guardada só no aparelho; a Tecelã continua sem senha');
  await p.evaluate(() => ir('painel')); await p.waitForTimeout(200);
  certo(await p.locator('#corpo .alerta [data-a=copiaSeg]').count() === 0 && await p.locator('.estado-salvo.pend[data-a=copiaSeg]').count() === 0, 'feita a cópia, o lembrete some');

  // segunda cópia: usa a senha das cópias sem perguntar
  await p.click('.btn[data-a=copiaSeg]'); m = await modal(); certo(/senha das cópias de segurança, que você já criou/.test(await m.textContent()), 'nas próximas, usa a senha das cópias já criada');
  const fSeg2 = await baixado(() => m.locator('button.pri').click()); m = await modal(); await m.locator('button.pri').click();
  certo(JSON.parse(fs.readFileSync(fSeg2, 'utf8')).cripto.s1 === seg.cripto.s1, 'mesma senha (mesmos embrulhos) na segunda cópia');

  // ---------- 3. Salvar normal: sem a senha das cópias; explicação uma vez ----------
  const fArq = await baixado(() => p.click('[data-a=copia]'));
  m = await modal(); certo(/O seu arquivo foi salvo/.test(await m.textContent()) && /Google Drive ou do OneDrive/.test(await m.textContent()), 'no primeiro Salvar, explicação única sugerindo a pasta do Drive ou do OneDrive'); await m.locator('button.pri').click();
  const arq = JSON.parse(fs.readFileSync(fArq, 'utf8'));
  certo(!arq.copiaSeg && !arq.cripto && !JSON.stringify(arq.dados.config).includes('copiaSeg'), 'o arquivo do Salvar não leva a senha nem a chave das cópias');
  await p.evaluate(() => { const r = D.turmas[0]; r.obs = 'x'; salvar('turmas', r); }); await p.waitForTimeout(200);
  await baixado(() => p.click('[data-a=copia]')); await p.waitForTimeout(500);
  certo(await p.locator('#modais .modal').count() === 0, 'no segundo Salvar, a explicação não volta');

  // ---------- 4. lembrete: 5 dias, ajustável, no Sair ----------
  await p.evaluate(() => { CFG.prefs.ultimaCopiaSeg = new Date(Date.now() - 4 * 864e5).toISOString(); ir('painel'); });
  certo(await p.locator('#corpo .alerta [data-a=copiaSeg]').count() === 0, '4 dias depois: ainda sem lembrete');
  await p.evaluate(() => { CFG.prefs.ultimaCopiaSeg = new Date(Date.now() - 5 * 864e5).toISOString(); ir('painel'); });
  certo(await p.locator('#corpo .alerta [data-a=copiaSeg]').count() === 1 && /Faz 5 dias/.test(await texto()), '5 dias depois: lembrete no Painel');
  await p.evaluate(() => ir('ajustes')); await p.waitForTimeout(200);
  certo(await p.locator('#m-copiaseg-aj [data-c=lembreteCopia]').count() === 1 && await p.locator('[data-a=trocarSenhaCopias]').count() === 1, 'Ajustes: cartão da cópia de segurança com o intervalo e a troca da senha das cópias');
  await p.fill('[data-c=lembreteCopia]', '10'); await p.dispatchEvent('[data-c=lembreteCopia]', 'change'); await p.waitForTimeout(300);
  await p.evaluate(() => ir('painel')); certo(await p.locator('#corpo .alerta [data-a=copiaSeg]').count() === 0, 'intervalo mudado para 10 dias: sem lembrete aos 5');
  await p.evaluate(() => { CFG.prefs.lembreteCopia = 5; render(); });
  await p.click('[data-a=sair]'); m = await modal();
  certo(/não faz uma cópia de segurança/.test(await m.textContent()) && await m.locator('[data-x=seg]').count() === 1, 'Sair lembra da cópia vencida, com o botão para fazer');
  await m.locator('[data-x=c]').click(); await p.waitForTimeout(200);

  // ---------- 5. abrir a cópia: continuar sem senha ----------
  const abrir = async (f, senha, modo) => {
    await p.evaluate(() => ir('ajustes')); await p.waitForTimeout(200);
    const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('[data-a=restaurarAjustes]')]); await fc.setFiles(f);
    let mm = await modal(); await mm.locator('[name=senha]').fill(senha); await mm.locator('button.pri').click();
    mm = await modal(); await mm.locator('button.pri').click(); // substituir
    mm = await modal(); const t = await mm.textContent(); await mm.locator('[name=modo][value=' + modo + ']').check(); await mm.locator('button.pri').click();
    await p.waitForTimeout(1200); return t;
  };
  const t1 = await abrir(fSeg, SENHA_C, 'sem');
  certo(/Continuar com senha/.test(t1) && /Usar sem senha/.test(t1), 'ao abrir a cópia: escolher continuar com senha ou sem');
  const e1 = await p.evaluate(() => ({ ap: CFG.cripto, dk: SE.dk, cr: !!CFG.prefs.copiaSegCripto, nome: CFG.prefs.arquivoNome, pend: CFG.prefs.pendente, al: D.turmas.length }));
  certo(!e1.ap && !e1.dk && e1.cr && e1.al === 1, 'sem senha: a Tecelã segue sem senha e a senha da cópia vira a senha das cópias');
  certo(!e1.nome && e1.pend, 'a cópia de segurança não vira o arquivo de trabalho: o próximo Salvar pergunta onde salvar');
  // ---------- 6. abrir a cópia com a chave de recuperação, continuando com senha ----------
  await p.evaluate(() => ir('ajustes')); await p.waitForTimeout(200);
  const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('[data-a=restaurarAjustes]')]); await fc.setFiles(fSeg2);
  m = await modal(); await m.locator('#ckRec').check(); await m.locator('[name=chave]').fill(chave); await m.locator('button.pri').click();
  m = await modal(); await m.locator('button.pri').click();
  m = await modal(); await m.locator('button.pri').click(); // "com" é o padrão
  await p.waitForTimeout(1200);
  const e2 = await p.evaluate(() => ({ ap: !!CFG.cripto, dk: !!SE.dk }));
  certo(e2.ap && e2.dk, 'com a chave de recuperação: aberta e a Tecelã passa a usar a senha neste aparelho');
  await p.evaluate(() => ir('ajustes')); await p.click('#m-copiaseg-aj [data-a=copiaSeg]'); m = await modal();
  certo(/mesma senha da Tecelã/.test(await m.textContent()), 'com a senha da Tecelã ligada, a cópia usa a mesma senha');
  const fSeg3 = await baixado(() => m.locator('button.pri').click()); m = await modal(); await m.locator('button.pri').click();
  certo(await p.evaluate(s1 => CFG.cripto.s1 === s1, JSON.parse(fs.readFileSync(fSeg3, 'utf8')).cripto.s1), 'cópia cifrada com a chave da Tecelã');
  await p.evaluate(() => ir('painel')); await p.waitForTimeout(200);
  certo(await p.locator('#corpo .alerta.verm').count() === 0, 'com senha, sem o aviso vermelho de senha desligada');

  // ---------- 7. desfazer nos textos (modelo de demonstração) ----------
  const p2 = await ctx.newPage(); p2.on('pageerror', x => erros.push('pageerror2: ' + x.message)); p2.on('console', x => { if (x.type() === 'error') erros.push('console2: ' + x.text()); });
  await p2.goto(APP); await p2.click('[data-a=entrarDemo]'); await p2.waitForTimeout(2600);
  const ataId = await p2.evaluate(() => { CFG.prefs.turmaId = 't26'; const a = D.atas.find(x => x.estado !== 'finalizado'); a.texto = 'Texto original da ata, escrito com calma, com mais de quarenta letras.'; A.abrirAta({ id: a.id }); return a.id; });
  await p2.waitForTimeout(300); const ta = p2.locator('[data-rec="atas:' + ataId + '"] textarea[data-b=texto]');
  certo(await p2.locator('[data-a=desfazerTexto]').count() === 1, 'botão ↶ no alto');
  await ta.click(); await ta.fill('Texto mudado.'); await p2.click('h2'); await p2.waitForTimeout(600);
  certo(await p2.evaluate(id => IX.atas[id].texto, ataId) === 'Texto mudado.', 'texto alterado gravado');
  await p2.click('[data-a=desfazerTexto]'); await p2.waitForTimeout(400);
  certo(await p2.evaluate(id => IX.atas[id].texto, ataId) === 'Texto original da ata, escrito com calma, com mais de quarenta letras.' && /Desfeito/.test(await p2.textContent('#aviso')), '↶ desfaz a alteração depois de sair do campo');
  // desfazer depois de mudar de tela
  await p2.locator('[data-rec="atas:' + ataId + '"] textarea[data-b=texto]').fill('Outra versão.'); await p2.click('h2'); await p2.waitForTimeout(300);
  await p2.evaluate(() => ir('painel')); await p2.waitForTimeout(200);
  await p2.keyboard.press('Control+z'); await p2.waitForTimeout(400);
  certo(await p2.evaluate(id => IX.atas[id].texto, ataId) === 'Texto original da ata, escrito com calma, com mais de quarenta letras.', 'Ctrl+Z fora do campo, em outra tela, desfaz');
  // trecho grande apagado
  await p2.evaluate(id => A.abrirAta({ id }), ataId); await p2.waitForTimeout(300);
  await p2.locator('[data-rec="atas:' + ataId + '"] textarea[data-b=texto]').fill(''); await p2.waitForTimeout(200);
  certo(/Trecho apagado/.test(await p2.textContent('#aviso')), 'apagar um trecho grande mostra “Trecho apagado · Desfazer”');
  await p2.click('#aviso button'); await p2.waitForTimeout(600);
  certo(await p2.evaluate(id => IX.atas[id].texto, ataId) === 'Texto original da ata, escrito com calma, com mais de quarenta letras.' && (await p2.locator('[data-rec="atas:' + ataId + '"] textarea[data-b=texto]').inputValue()).startsWith('Texto original'), 'o trecho volta no campo e no registro');
  // histórico
  await p2.locator('[data-rec="atas:' + ataId + '"] textarea[data-b=texto]').fill('Versão A, nova.'); await p2.click('h2'); await p2.waitForTimeout(300);
  await p2.evaluate(() => { A.historicoTextos(); }); m = await p2.waitForSelector('#modais .modal');
  const nLin = await p2.locator('#modais [data-x^=v]').count();
  certo(nLin >= 2, 'histórico dos textos da sessão lista as alterações (' + nLin + ')');
  await p2.locator('#modais [data-x^=v]').first().click(); await p2.waitForTimeout(400);
  certo((await p2.evaluate(id => IX.atas[id].texto, ataId)).startsWith('Texto original'), 'voltar a uma versão anterior pelo histórico');
  // ata finalizada não muda
  const fin = await p2.evaluate(async () => { const a = D.atas.find(x => x.estado === 'finalizado'); if (!a) return 'sem'; const t0 = a.texto; HIST.push({ store: 'atas', id: a.id, path: 'texto', antes: 'outro', depois: t0, rot: 't', quando: new Date() }); await A.desfazerTexto(); return IX.atas[a.id].texto === t0; });
  certo(fin === true || fin === 'sem', 'ata finalizada não é alterada pelo desfazer');

  // ---------- 8. digitalizados ----------
  // imagem fictícia grande (3000×2000) gerada no próprio navegador
  const png = await p2.evaluate(() => { const c = document.createElement('canvas'); c.width = 3000; c.height = 2000; const g = c.getContext('2d'); for (let i = 0; i < 60; i++) { g.fillStyle = 'hsl(' + i * 6 + ',60%,60%)'; g.fillRect(i * 50, 0, 50, 2000); } g.fillStyle = '#000'; g.font = '120px serif'; g.fillText('Folha fictícia', 200, 600); return c.toDataURL('image/png').split(',')[1]; });
  const fImg = path.join(TMP, 'folha-ficticia.png'); fs.writeFileSync(fImg, Buffer.from(png, 'base64'));
  const fPdf = path.join(TMP, 'pequeno.pdf'); fs.writeFileSync(fPdf, '%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n');
  const fPdfG = path.join(TMP, 'grande.pdf'); fs.writeFileSync(fPdfG, Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(3.2 * 1024 * 1024, 32)]));
  await p2.evaluate(() => { UI.sub = null; ir('digitais'); }); await p2.waitForTimeout(200);
  certo(await p2.locator('nav [data-t=digitais], [data-a=ir][data-t=digitais]').count() >= 1 && /Digitalizados/.test(await p2.textContent('#corpo')) && /nunca/.test(await p2.textContent('#corpo')), 'tela Digitalizados no menu (A turma), avisando que não vai na partilha');
  certo(await p2.locator('.medidor').count() === 1, 'medidor do espaço usado');
  let [ch] = await Promise.all([p2.waitForEvent('filechooser'), p2.click('#corpo [data-a=digIncluir]:not([data-camera])')]); await ch.setFiles([fImg]);
  m = await p2.waitForSelector('#modais .modal'); await p2.waitForTimeout(200);
  certo(/1600×1067 px/.test(await p2.textContent('#modais .modal')), 'foto reduzida para o lado maior de 1600 px');
  await p2.fill('#modais [name=titulo]', 'Folha da caderneta (fictícia)'); await p2.selectOption('#modais [name=album]', 'caderneta'); await p2.selectOption('#modais [name=alunoId]', 'ana');
  await p2.click('#modais button.pri'); await p2.waitForTimeout(500);
  const dg = await p2.evaluate(() => { const x = D.digitais.find(y => y.titulo === 'Folha da caderneta (fictícia)'); return x && { t: x.tamanho, mime: x.mime, mini: !!x.mini, al: x.alunoId, alb: x.album, w: x.largura }; });
  certo(dg && dg.mime === 'image/jpeg' && dg.mini && dg.w === 1600 && dg.t < 700 * 1024, 'gravada em JPEG reduzido (' + (dg && Math.round(dg.t / 1024)) + ' KB), com miniatura');
  certo(dg && dg.al === 'ana' && dg.alb === 'caderneta', 'álbum e ligação com a criança');
  certo(await p2.locator('#corpo .dig-mini').count() === 1 && /Caderneta/.test(await p2.textContent('#corpo')), 'miniatura agrupada no álbum');
  // PDF grande recusado, pequeno aceito e ligado à ata
  [ch] = await Promise.all([p2.waitForEvent('filechooser'), p2.click('#corpo [data-a=digIncluir]:not([data-camera])')]); await ch.setFiles([fPdfG]);
  m = await p2.waitForSelector('#modais .modal'); certo(/limite para PDF é 3 MB/.test(await p2.textContent('#modais .modal')), 'PDF acima de 3 MB é recusado com a explicação'); await p2.click('#modais button.pri'); await p2.waitForTimeout(200);
  await p2.evaluate(id => A.abrirAta({ id }), ataId); await p2.waitForTimeout(300);
  certo(/Digitalizados desta ata/.test(await p2.textContent('#corpo')), 'ata com o bloco de digitalizados');
  [ch] = await Promise.all([p2.waitForEvent('filechooser'), p2.click('#corpo [data-a=digIncluir][data-ata]:not([data-camera])')]); await ch.setFiles([fPdf]);
  m = await p2.waitForSelector('#modais .modal'); await p2.waitForTimeout(150);
  certo(await p2.inputValue('#modais [name=ataId]') === ataId && await p2.inputValue('#modais [name=album]') === 'atas', '“Incluir aqui” na ata já vem ligado à ata, no álbum Atas');
  await p2.click('#modais button.pri'); await p2.waitForTimeout(500);
  certo(await p2.locator('#corpo .dig-mini .dig-pdf').count() === 1, 'PDF aparece na ata');
  // visualizador
  await p2.evaluate(() => { const x = D.digitais.find(y => y.tipo === 'img'); A.digVer({ id: x.id }); }); await p2.waitForSelector('#digImg');
  await p2.click('#zMais'); const wz = await p2.evaluate(() => $('#digImg').style.width);
  certo(wz === '140%', 'visualizador com zoom');
  const fDown = await (async () => { const [d] = await Promise.all([p2.waitForEvent('download'), p2.click('#modais [data-x=baixar]')]); return d.suggestedFilename(); })();
  certo(/\.jpg$/.test(fDown), 'baixar a foto (' + fDown + ')');
  // ligações também na criança e na busca
  await p2.evaluate(() => { ir('turma', 'ana', 'alunos'); }); await p2.waitForTimeout(300);
  certo(/Digitalizados da criança/.test(await p2.textContent('#corpo')) && await p2.locator('#corpo .dig-mini').count() >= 1, 'na ficha da criança, os digitalizados ligados a ela');
  certo(await p2.evaluate(() => { UI.filtro.busca = 'caderneta (fict'; ir('busca'); return /Digitalizado/.test($('#corpo').textContent); }), 'a busca encontra digitalizados');
  // partilha e armazenamento
  certo(await p2.evaluate(() => PARTILHA.nunca.includes('digitais') && !Object.keys(PARTILHA.pode).includes('digitais') && STORES.includes('digitais') && STORES_TURMA.some(s => s[0] === 'digitais')), 'digitais: na lista “nunca” da partilha, nos stores e na exclusão da turma');
  certo(await p2.evaluate(() => { const x = D.digitais[0], t = x.tamanho; x.tamanho = 101 * 1048576; ir('digitais'); const r = /acima de 100 MB/.test($('#corpo').textContent) && !!$('.medidor.cheio'); x.tamanho = t; return r; }), 'acima de 100 MB, o medidor avisa');
  certo(await p2.evaluate(() => itensLista('albuns').length >= 6), 'álbuns editáveis em Cadastros');
  // reunião com a família: 📎
  certo(await p2.evaluate(() => typeof A.reuDigitais === 'function'), 'reuniões com as famílias têm o 📎 dos digitalizados');
  // versão
  // 1.11.1: aviso de que os digitalizados são o que mais ocupa espaço
  certo(/de longe, o que mais ocupa espaço/.test(await p2.evaluate(() => { ir('digitais'); return $('#corpo').textContent; })), 'Digitalizados: aviso fixo junto ao medidor');
  certo(await p2.evaluate(() => { const x = D.digitais[0], t = x.tamanho; x.tamanho = 60 * 1048576; ir('digitais'); const r = !!$('.medidor.meio') && /acima de 50 MB/.test($('#corpo').textContent); x.tamanho = t; render(); return r; }), 'medidor amarelo entre 50 e 100 MB');
  [ch] = await Promise.all([p2.waitForEvent('filechooser'), p2.click('#corpo [data-a=digIncluir]:not([data-camera])')]); await ch.setFiles([fImg]);
  await p2.waitForSelector('#modais .aviso-peso'); certo(/acrescenta cerca de .*KB.* ao seu arquivo e a cada cópia de segurança/.test(await p2.textContent('#modais .aviso-peso')), 'ao incluir: quanto o arquivo vai crescer');
  await p2.click('#modais [data-x=c]'); await p2.waitForTimeout(200);
  await p2.evaluate(() => ir('ajustes')); await p2.waitForSelector('#armazPeso', { timeout: 5000 });
  certo(/Digitalizados .*%.*Todo o resto/.test(await p2.textContent('#armazPeso')) && await p2.locator('#armazPeso').count() === 1, 'Ajustes → Armazenamento: peso dos digitalizados × todo o resto');
  certo(await p2.evaluate(() => /^1\.11(\.\d+)?$/.test(VERSAO)), 'versão 1.11.x');

  await b.close();
  const real = erros.filter(x => !/favicon|net::ERR/.test(x));
  fs.appendFileSync(LOG, (real.length ? 'FALHOU: ' + real.join(' | ') : 'TUDO CERTO') + '\n');
  console.log(real.length ? 'FALHOU\n' + real.join('\n') : 'TUDO CERTO'); process.exit(real.length ? 1 : 0);
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU: ' + x.message + '\n'); console.log('FALHOU', x); process.exit(1); });
