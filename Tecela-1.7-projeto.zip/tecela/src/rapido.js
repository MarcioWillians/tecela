/* ==========================================================================
   Tecelã — atalhos para trabalhar menos: anotar de qualquer tela (com seção
   e critério sugeridos pelo texto e frases prontas), grade de faltas,
   busca em tudo e pendências do Painel.
   ========================================================================== */
'use strict';
/* palavras do texto → seção do boletim e critério do perfil (só sugestão: a professora confirma) */
const PISTAS = [
  [/\bflauta/i, 'flauta', 'sentir'], [/aquarela|pintou|pintura/i, 'aquarela', 'sentir'], [/desenho de forma|desenhos de forma/i, 'formas', 'querer'],
  [/desenh/i, 'desenho', 'sentir'], [/caderno|[ée]poca/i, 'conteudo', 'aprendizagem'], [/li[çc][ãa]o de casa|dever de casa|tarefa de casa/i, 'licao', 'querer'],
  [/tabuada|c[aá]lculo|\bconta|n[úu]mero|soma|subtra|multiplic|divis|problema/i, 'matematica', 'pensar'],
  [/leitura|\bl[eê]u\b|\bler\b|escrev|escrit|\bletra|palavra|ditado|c[óo]pia|caligraf|soletr/i, 'portugues', 'aprendizagem'],
  [/\broda\b|ritm|verso|recita/i, 'ritmica', 'querer'], [/poema da manh/i, 'poemaManha', 'sentir'], [/retrospectiv|recont|lembrou da hist/i, 'retrospectiva', 'pensar'],
  [/\bjogo|brincadeira|\bbola\b|pega-pega|corrida/i, 'jogos', 'social'], [/lanche|comeu|comida|aliment/i, 'lanche', 'constituicao'],
  [/recreio|\bpausa|brincar livre|\bparque/i, 'pausa', 'social'], [/euritmia/i, 'euritmia', 'querer'], [/tric[ôo]|croch[êe]|trabalhos? manua|costur|tecel/i, 'trabalhos', 'querer'],
  [/chegou|chegada|atrasad|acolhid|despedi/i, 'chegada', 'sentir'], [/religios|gratid[ãa]o|reverên/i, 'religiosidade', 'sentir'],
  [/brig|colega|amig|conflit|empurr|bateu|ajudou|grupo|lider/i, 'atitudes', 'social'], [/falt(ou|a)|assiduidade|pontual/i, 'atitudes', 'querer'],
  [/chor|triste|alegr|medo|emocion|ansios|irrit|sens[ií]vel/i, '', 'sentir'], [/persist|desist|termin|iniciativa|pregui|agitad|inquiet|empenh|capricho/i, '', 'querer'],
  [/aten[çc][ãa]o|atent|distra|concentr|mem[óo]ria|lembr|entendeu|compreend|racioc/i, '', 'pensar'], [/\bdor\b|febre|sono|dormiu|machuc|coorden|equil[ií]brio|trope[çc]|cansad/i, '', 'constituicao']];
function sugerirClassificacao(txt, t) {
  const ativas = new Set(modeloDaSerie(t.serie).secoes.filter(s => s.ativa).map(s => s.key)), crits = new Set(itensLista('criterios').map(i => i.chave)); let secao = '', criterio = '';
  for (const [re, s, c] of PISTAS) if (re.test(txt || '')) { if (!secao && s && ativas.has(s)) secao = s; if (!criterio && c && crits.has(c)) criterio = c; if (secao && criterio) break; }
  return { secao, criterio };
}
/* liga a sugestão a um formulário com campos texto, secao e criterio (só mexe no que a pessoa não escolheu) */
function ligarSugestao(f, t) {
  const tx = f.querySelector('[name=texto]'), ss = f.querySelector('[name=secao]'), cs = f.querySelector('[name=criterio]'); if (!tx || !ss || !cs) return;
  [ss, cs].forEach(s => s.addEventListener('change', () => { s.dataset.manual = '1'; s.classList.remove('sugerido'); }));
  tx.addEventListener('input', () => { const g = sugerirClassificacao(tx.value, t); [[ss, g.secao], [cs, g.criterio]].forEach(([s, v]) => { if (s.dataset.manual || !v || s.value === v) return; s.value = v; s.classList.add('sugerido'); }); });
  const fr = f.querySelector('[name=frase]'); if (fr) fr.addEventListener('change', () => { if (!fr.value) return; tx.value = (tx.value.trim() ? tx.value.trim() + ' ' : '') + fr.value; fr.value = ''; tx.dispatchEvent(new Event('input')); tx.focus(); });
  const sg = f.querySelector('[name=sigilo]'), es = f.querySelector('[name=estrela]'); if (sg && es) sg.addEventListener('change', () => { if (sg.checked) es.checked = false; es.disabled = sg.checked; });
}
const opcoesFrases = () => campo('Frases prontas (opcional)', '<select name="frase"><option value="">Escolha uma frase para acrescentar ao texto…</option>' + itensLista('frases').map(i => '<option value="' + e(i.nome) + '">' + e(i.nome) + '</option>').join('') + '</select>', 'A frase escolhida entra no fim do texto acima, e você completa ou ajusta. {nome} vira o nome da criança e {o/a} se ajusta ao gênero. Para criar, mudar ou apagar frases: <a href="#" data-a="editarFrases">Cadastros → Frases prontas</a>.');
A.editarFrases = () => { $('#modais').innerHTML = ''; UI.aba.cadastros = 'frases'; ir('cadastros'); };
const opcoesHtml = (ops, v) => ops.map(([k, r]) => '<option value="' + e(k) + '"' + (k === v ? ' selected' : '') + '>' + e(r) + '</option>').join('');

/* ---------- ✎ Anotar: de qualquer tela ---------- */
A.anotar = async d => {
  const t = turmaAtual(); if (!t) return; const al = alunosDaTurma(t.id); if (!al.length) return aviso('Cadastre os alunos da turma.');
  const pre = (d && d.al) || (UI.tela === 'obs' ? UI.filtro.obsAluno : UI.tela === 'perfis' ? UI.filtro.perfilAluno : '') || '';
  const v = await dlg({ titulo: 'Anotar', largo: true, ok: 'Lançar', corpo:
    '<div class="chips" style="margin-bottom:.7rem"><label><input type="checkbox" id="qTodos"> Toda a turma</label>' + al.map(a => '<label><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '"' + (a.id === pre ? ' checked' : '') + '> ' + e(primeiroNome(a)) + '</label>').join('') + '</div>' +
    campo('O que você observou?', '<textarea name="texto" autofocus style="min-height:6rem"></textarea>', 'A seção e o critério são sugeridos pelo texto (contorno amarelo). Confira e mude se quiser.') + opcoesFrases() +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));margin-top:.6rem">' + campo('Data', '<input type="date" name="data" value="' + hojeISO() + '">') + campo('Seção do boletim', '<select name="secao">' + opcoesHtml(opcoesSecao(t), '') + '</select>') + campo('Critério do perfil', '<select name="criterio">' + opcoesHtml(criterios(), '') + '</select>') + '</div>' +
    '<div class="linha"><label class="ck"><input type="checkbox" name="estrela" checked> <span class="estrela">★</span> Usar no boletim</label><label class="ck"><input type="checkbox" name="conselho"> ⚖ Levar ao conselho</label><label class="ck"><input type="checkbox" name="sigilo"> Sigilosa</label></div>',
    aoAbrir: f => { ligarSugestao(f, t); const q = $('#qTodos', f); q.addEventListener('change', () => $$('input[name=alunos]', f).forEach(c => c.checked = q.checked)); },
    validar: x => !(x.alunos || []).length ? 'Marque pelo menos uma criança.' : !x.texto.trim() ? 'Escreva a anotação.' : null });
  if (!v) return;
  const n = await salvar('anotacoes', { turmaId: t.id, data: v.data || hojeISO(), alunos: v.alunos, secao: v.secao, criterio: v.criterio, texto: v.texto.trim(), estrela: !!v.estrela && !v.sigilo, sigilo: !!v.sigilo, conselho: !!v.conselho });
  if (UI.tela === 'anot' || UI.tela === 'painel') render();
  aviso('Anotação lançada' + (v.alunos.length > 1 ? ' para ' + v.alunos.length + ' crianças.' : '.'), 'Desfazer', async () => { await apagar('anotacoes', n.id); render(); });
};

/* ---------- FALTAS: todas as crianças e períodos numa grade ---------- */
T.faltas = () => {
  const t = turmaAtual(); if (!t) return '<h1>Faltas</h1>' + vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id), per = CFG.prefs.periodos || [], dl = t.diasLetivos || []; if (!al.length) return '<h1>Faltas</h1>' + vazio('Cadastre os alunos da turma.');
  let h = '<h1>Faltas</h1><p class="dica">' + e(rotuloTurma(t)) + ' · digite o total de faltas de cada período. Use Tab ou Enter para ir à próxima célula. Os períodos se ajustam em <a href="#" data-a="ir" data-t="ajustes">Ajustes</a>.</p>';
  h += '<div class="cartao rolagem"><table class="tabela" id="gradeFaltas"><tr><th>Criança</th>' + per.map(p => '<th>' + e(p) + '</th>').join('') + '<th>Total</th><th>%</th></tr>';
  h += '<tr data-rec="turmas:' + t.id + '"><td class="dica">Dias letivos</td>' + per.map((_, i) => '<td>' + inp('diasLetivos.' + i, dl[i], 'number', 'min="0" style="width:5rem" data-i="faltaTot"') + '</td>').join('') + '<td></td><td></td></tr>';
  h += al.map(a => { const m = matricula(t.id, a.id); if (!m) return ''; const f = m.faltas || []; return '<tr data-rec="matriculas:' + m.id + '"><td>' + e(a.nome) + '</td>' + per.map((_, i) => '<td>' + inp('faltas.' + i, f[i], 'number', 'min="0" style="width:5rem" data-i="faltaTot" data-al="' + a.id + '"') + '</td>').join('') + '<td class="ft" data-al="' + a.id + '">' + somaFaltas(f) + '</td><td class="fp" data-al="' + a.id + '">' + pctFaltas(t, f) + '</td></tr>'; }).join('');
  return h + '</table></div><p class="dica">A LDB exige frequência mínima de 75%: acima de 25% de faltas, a célula fica vermelha; acima de 15%, amarela. O relatório completo está em Relatórios → Frequência.</p>';
};
const somaFaltas = f => (f || []).reduce((s, x) => s + (Number(x) || 0), 0);
function pctFaltas(t, f, cru) {
  const dl = t.diasLetivos || [], ult = (f || []).reduce((u, v, i) => v !== null && v !== undefined && v !== '' ? i : u, -1), tot = dl.slice(0, ult + 1).reduce((s, x) => s + (Number(x) || 0), 0);
  const p = tot ? 100 * somaFaltas(f) / tot : null; if (cru) return p; return p == null ? '—' : '<span class="flag ' + (p > 25 ? '' : p > 15 ? 'am' : 'az') + '">' + p.toFixed(1).replace('.', ',') + '%</span>';
}
C_.faltaTot = () => setTimeout(() => { const t = turmaAtual(); $$('#gradeFaltas td.ft').forEach(td => { const m = matricula(t.id, td.dataset.al); td.textContent = somaFaltas(m.faltas); $('#gradeFaltas td.fp[data-al="' + td.dataset.al + '"]').innerHTML = pctFaltas(t, m.faltas); }); }, 20);
T.faltas_pos = () => { const g = $('#gradeFaltas'); if (!g) return; g.addEventListener('keydown', ev => { if (ev.key !== 'Enter') return; ev.preventDefault(); const xs = $$('input', g), i = xs.indexOf(ev.target); if (xs[i + 1]) { xs[i + 1].focus(); xs[i + 1].select(); } }); };

/* ---------- BUSCA em tudo ---------- */
const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
T.busca = () => {
  const q = norm(UI.filtro.busca), tem = s => norm(s).includes(q), r = [];
  if (q.length < 2) return '<h1>Buscar</h1>' + vazio('Digite pelo menos duas letras no campo “Buscar…”.');
  const trecho = s => { const n = norm(s), i = n.indexOf(q); if (i < 0) return e(String(s || '').slice(0, 140)); const a = Math.max(0, i - 60), x = String(s); return (a ? '…' : '') + e(x.slice(a, i)) + '<mark>' + e(x.slice(i, i + q.length)) + '</mark>' + e(x.slice(i + q.length, i + q.length + 80)) + '…'; };
  D.alunos.filter(a => tem(a.nome) || tem(a.chamada)).forEach(a => r.push(['Criança', a.nome, '', 'ir', { t: 'turma', aba: 'alunos', sub: a.id }]));
  D.anotacoes.filter(n => tem(n.texto)).forEach(n => r.push(['Anotação', dataBR(n.data) + ' · ' + nomesDe(n.alunos), trecho(n.texto) + (n.sigilo ? ' <span class="etq sig">sigilosa</span>' : ''), 'editarAnot', { id: n.id }]));
  D.atas.filter(a => ['assunto', 'pauta', 'texto', 'deliberacoes', 'conclusao', 'cabecalho'].some(k => tem(a[k]))).forEach(a => r.push(['Ata', nomeReuniao(a) + ' · ' + dataBR(a.data), trecho(['assunto', 'pauta', 'texto', 'deliberacoes', 'conclusao'].map(k => a[k] || '').join(' ')), 'abrirAta', { id: a.id }]));
  D.boletins.filter(b => tem(b.poemaTexto) || tem(b.poemaTitulo) || Object.values(b.secoes || {}).some(s => tem(s.texto))).forEach(b => { const a = IX.alunos[b.alunoId], tu = IX.turmas[b.turmaId]; if (a && tu) r.push(['Boletim', a.nome + ' · ' + tu.ano, trecho([b.poemaTitulo, b.poemaTexto].concat(Object.values(b.secoes || {}).map(s => s.texto)).join(' ')), 'abrirBolId2', { id: b.id, tu: tu.id }]); });
  D.vivencias.filter(v => tem(v.titulo) || tem(v.descricao) || tem(v.local)).forEach(v => r.push(['Vivência', dataBR(v.data) + ' · ' + v.titulo, trecho(v.descricao || v.local), 'abrirViv', { id: v.id }]));
  D.eventos.filter(v => tem(v.titulo) || tem(v.obs)).forEach(v => r.push(['Evento', dataBR(v.data) + ' · ' + v.titulo, trecho(v.obs), 'editarEvento', { id: v.id }]));
  D.tarefas.filter(x => tem(x.titulo) || tem(x.obs)).forEach(x => r.push(['Tarefa', x.titulo, trecho(x.obs), 'editarTarefa', { id: x.id }]));
  D.biblioteca.filter(x => tem(x.titulo) || tem(x.texto)).forEach(x => r.push(['Biblioteca', x.titulo, trecho(x.texto), 'ir', { t: 'biblio', sub: x.id }]));
  BNCC.filter(h => tem(h[0]) || tem(h[3])).slice(0, 60).forEach(h => r.push(['BNCC', h[0] + ' · ' + BNCC_COMP[h[1]] + ' · ' + rotAnos(h[2]), trecho(h[3]), 'ir', { t: 'biblio', sub: 'bncc:' + h[1] + ':' + h[2][0] }]));
  D.conselhos.filter(c => tem(c.decisoes) || Object.values(c.alunos || {}).some(x => tem(x.proposta) || tem(x.fala))).forEach(c => r.push(['Conselho', rotPeriodo(c.periodo), trecho([c.decisoes].concat(Object.values(c.alunos || {}).map(x => (x.fala || '') + ' ' + (x.proposta || ''))).join(' ')), 'ir', { t: 'conselho' }]));
  const txtDoc = d => [d.titulo].concat((d.secoes || []).map(x => [x.tit, x.txt || ''].concat((x.linhas || []).map(l => l.join(' '))).concat((x.dias || []).map(y => (x.campos || []).map(([k]) => y[k] || '').join(' '))).join(' '))).join(' ');
  const ROT_DOC = { combinados: 'Combinados', pei: 'PEI', anual: 'Planejamento', epoca: 'Plano de época', refAnual: 'Referência', refEpoca: 'Referência' };
  D.documentos.filter(d => ROT_DOC[d.tipo] && tem(txtDoc(d))).forEach(d => { const a = d.alunoId && IX.alunos[d.alunoId], tu = d.turmaId && IX.turmas[d.turmaId]; r.push([ROT_DOC[d.tipo], d.titulo + (a ? ' · ' + a.nome : '') + (tu ? ' · ' + tu.ano : ''), trecho(txtDoc(d)), 'abrirDocBusca', { id: d.id }]); });
  D.reforcos.filter(x => tem(x.topico) || tem(x.obs) || tem(nomeItem('componentes', x.componente))).forEach(x => r.push(['Reforço', nomesDe(x.alunos) + ' · ' + (x.datas || []).map(d => dataBR(d).slice(0, 5)).join(', '), trecho([rotRef(x), x.obs].join(' ')), 'abrirReforcoBusca', { id: x.id, tu: x.turmaId }]));
  D.contatos.filter(x => tem(x.assunto) || tem(x.texto) || tem(x.combinados)).forEach(x => r.push(['Contato com a família', nomesDe([x.alunoId]) + ' · ' + dataBR(x.data), trecho([x.assunto, x.texto, x.combinados].join(' ')), 'abrirContatoBusca', { id: x.id, tu: x.turmaId }]));
  D.repertorio.filter(x => tem(x.titulo) || tem(x.texto) || tem(x.autor)).forEach(x => r.push(['Repertório', nomeTipoRep(x.tipo), trecho([x.titulo, x.autor, x.texto].join(' ')), 'abrirRepBusca', { id: x.id, tu: x.turmaId }]));
  D.curriculo.filter(c => tem(c.titulo) || tem(c.conteudos) || tem(c.objetivos)).forEach(c => r.push(['Currículo', c.serie + 'º ano · ' + c.titulo, trecho([c.conteudos, c.objetivos].join(' ')), 'ir', { t: 'curric', sub: c.id }]));
  const attrs = o => Object.entries(o).map(([k, v]) => 'data-' + k + '="' + e(v) + '"').join(' ');
  return '<h1>Buscar: “' + e(UI.filtro.busca) + '”</h1><p class="dica">' + r.length + ' resultado(s) em todas as turmas.' + (UI.voltarBusca ? ' <a href="#" data-a="ir" data-t="' + UI.voltarBusca + '">← Voltar</a>' : '') + '</p>' + (r.length ? '<div class="cartao rolagem"><table class="tabela">' + r.slice(0, 300).map(([tipo, tit, tx, a, o]) => '<tr class="clic" data-a="' + a + '" ' + attrs(o) + '><td><span class="etq">' + tipo + '</span></td><td><b>' + e(tit) + '</b><div class="dica">' + tx + '</div></td></tr>').join('') + '</table></div>' : vazio('Nada encontrado.'));
};
const nomesDe = ids => (ids || []).map(id => primeiroNome(IX.alunos[id])).join(', ');
A.abrirDocBusca = async d => { const x = IX.documentos[d.id]; if (!x) return; if (x.turmaId && CFG.prefs.turmaId !== x.turmaId) await prefs({ turmaId: x.turmaId }); const tela = { combinados: 'combinados', pei: 'pei' }[x.tipo] || 'planej'; UI.tela = tela; UI.sub = x.tipo === 'combinados' ? null : x.id; render(); window.scrollTo(0, 0); };
A.abrirContatoBusca = async d => { if (CFG.prefs.turmaId !== d.tu) await prefs({ turmaId: d.tu }); UI.filtro.ctAl = ''; ir('acomp', null, 'contatos'); setTimeout(() => A.editarContato(d), 50); };
A.abrirRepBusca = async d => { const r = IX.repertorio[d.id]; if (CFG.prefs.turmaId !== d.tu && IX.turmas[d.tu] && !cadeiaTurmas(turmaAtual() || {}).some(x => x.id === d.tu)) await prefs({ turmaId: d.tu }); UI.filtro.repTipo = ''; UI.filtro.repEp = ''; UI.filtro.repBusca = r ? r.titulo : ''; ir('repert'); };
A.abrirReforcoBusca = async d => { if (CFG.prefs.turmaId !== d.tu) await prefs({ turmaId: d.tu }); A.abrirReforco(d); };
A.abrirBolId2 = async d => { if (CFG.prefs.turmaId !== d.tu) await prefs({ turmaId: d.tu }); ir('bol', d.id); };

/* ---------- pendências do Painel: o que pede atenção agora ---------- */
function pendenciasExtras(t) {
  const al = alunosDaTurma(t.id), hoje = hojeISO(), r = [], desde = somaDias(hoje, -30);
  const poucas = al.filter(a => D.anotacoes.filter(n => (n.alunos || []).includes(a.id) && (n.data || '') >= desde).length < 2);
  if (poucas.length && D.anotacoes.some(n => n.turmaId === t.id)) r.push('<a href="#" data-a="ir" data-t="relat" data-sub="olhar">' + poucas.length + ' criança(s) com menos de 2 anotações nos últimos 30 dias</a>: ' + e(poucas.map(primeiroNome).join(', ')));
  const per = periodoAtual(t), meio = somaDias(per.ini, Math.round(difDias(per.fim, per.ini) / 2));
  if (t.ano === new Date().getFullYear() && hoje >= meio) { const sem = al.filter(a => !temMarcas(obsRec(t.id, a.id, per.id))); if (sem.length) r.push('<a href="#" data-a="ir" data-t="obs">Observação do ' + e(per.curto) + ': ' + sem.length + ' criança(s) sem marcas</a>'); }
  const ps = CFG.prefs.periodos || [], mats = matsDaTurma(t.id), lancados = ps.filter((_, i) => mats.some(m => { const v = (m.faltas || [])[i]; return v !== null && v !== undefined && v !== ''; })).length;
  const mesesPassados = t.ano < new Date().getFullYear() ? 12 : new Date().getMonth(); const esperados = Math.min(ps.length, Math.floor(mesesPassados / (12 / Math.max(1, ps.length))));
  if (mats.length && lancados < esperados) r.push('<a href="#" data-a="ir" data-t="faltas">Faltas: ' + (esperados - lancados) + ' período(s) já encerrado(s) sem lançamento</a>');
  const cons = D.anotacoes.filter(n => n.turmaId === t.id && n.conselho && !n.conselhoVisto).length; if (cons) r.push('<a href="#" data-a="ir" data-t="conselho">' + cons + ' anotação(ões) marcadas para levar ao conselho</a>');
  const fora = al.filter(a => pctFaltas(t, (matricula(t.id, a.id) || {}).faltas, true) > 20); if (fora.length) r.push('<a href="#" data-a="ir" data-t="faltas">' + fora.length + ' criança(s) com mais de 20% de faltas</a>: ' + e(fora.map(primeiroNome).join(', ')));
  return r;
}
