/* ==========================================================================
   Tecelã — Currículo da escola (épocas por série), BNCC embutida e
   comparação entre os dois. A comparação respeita a pedagogia Waldorf:
   conteúdo trabalhado em outro ano aparece como "em outro ano", não como falta.
   ========================================================================== */
'use strict';
const IXBNCC = {}; BNCC.forEach(h => IXBNCC[h[0]] = h);
const PARADAS = new Set('para pela pelo pelas pelos como com sem sobre entre suas seus sua seu uma umas uns que dos das nos nas aos ser sao seja estar tem mais menos muito cada outros outras outro outra este esta esse essa isso aquele qual quais quando onde ate tambem entre forma formas modo modos diferentes diversos diversas partir meio meios relacao relacoes texto textos utilizando considerando identificar reconhecer compreender'.split(' '));
const fichas = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().match(/[a-z]{4,}/g) || [];
const raiz = w => w.replace(/(oes|aes|ais|eis|ores|mente|cao|coes|idade|s)$/, '').slice(0, 7);
function sugerirBncc(ep, n) {
  const area = (itemLista('componentes', ep.componente) || {}).bncc, alvo = new Set(fichas([ep.titulo, ep.conteudos, ep.objetivos].join(' ')).filter(w => !PARADAS.has(w)).map(raiz));
  if (!alvo.size) return [];
  return BNCC.filter(h => !ehEtapa(h) && (!area || h[1] === area) && !(ep.bncc || []).includes(h[0])).map(h => { const ws = new Set(fichas(h[3]).filter(w => !PARADAS.has(w)).map(raiz)); let s = 0; ws.forEach(w => { if (alvo.has(w)) s++; }); if (h[2].includes(Number(ep.serie))) s *= 2.5; return [h, s]; }).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, n || 12).map(x => x[0]);
}
const rotAnos = anos => anos.length === 1 ? anos[0] + 'º ano' : anos[0] + 'º ao ' + anos[anos.length - 1] + 'º ano';

T.curric = () => {
  const aba = UI.aba.curric || 'escola';
  if (UI.sub && IX.curriculo[UI.sub]) return editorEpoca(IX.curriculo[UI.sub]);
  return '<h1>Currículo e BNCC</h1>' + abas([['escola', 'Currículo da escola'], ['prog', 'Conteúdo programático'], ['bncc', 'BNCC (consulta)'], ['comp', 'Comparação com a BNCC']], aba) + ({ escola: abaCurriculo, prog: abaPrograma, bncc: abaBncc, comp: abaComparacao }[aba] || abaCurriculo)();
};
const serieCurr = () => Number(UI.filtro.curSerie || (turmaAtual() || {}).serie || 1);
const selSerie = (c, v) => '<select data-c="' + c + '">' + seriesVisiveis().map(n => '<option value="' + n + '"' + (n === v ? ' selected' : '') + '>' + n + 'º ano</option>').join('') + '</select>';
C_.curSerie = el => { UI.filtro.curSerie = el.value; render(); };
function abaCurriculo() {
  const s = serieCurr(), xs = D.curriculo.filter(c => c.serie === s).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)), t = turmaAtual();
  let h = '<p>O currículo da escola, organizado em <b>épocas</b> por série. Cada época pode ser ligada às habilidades da BNCC, ao calendário e às vivências.</p><div class="linha">' + selSerie('curSerie', s) + '<button class="btn pri" data-a="novaEpoca">+ Época</button><button class="btn" data-a="colarEpocas">Colar uma lista de épocas</button>' + (xs.length ? '<button class="btn" data-a="exportarCurric">Exportar</button>' : '') + '</div>';
  if (!xs.length) return h + vazio('Nenhuma época cadastrada para o ' + s + 'º ano.', (EPOCAS_REF[s] ? '<button class="btn pri" data-a="epocasRef" data-s="' + s + '">Carregar as épocas de referência do ' + s + 'º ano</button>' : ''));
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>#</th><th>Época</th><th>Componente</th><th>Período</th><th>Semanas</th><th>BNCC</th>' + (t && t.serie === s ? '<th>Realizada em ' + t.ano + '</th>' : '') + '</tr>' + xs.map((c, i) => '<tr class="clic" data-a="abrirEpoca" data-id="' + c.id + '"><td>' + (i + 1) + '</td><td><b>' + e(c.titulo) + '</b></td><td>' + e(nomeItem('componentes', c.componente)) + '</td><td>' + e(c.periodo || '') + '</td><td>' + e(c.semanas || '') + '</td><td>' + (c.bncc || []).length + '</td>' + (t && t.serie === s ? '<td>' + ((c.realizadas || []).includes(t.id) ? '✔' : '') + '</td>' : '') + '</tr>').join('') + '</table></div>';
}
A.abrirEpoca = d => { UI.sub = d.id; render(); window.scrollTo(0, 0); };
A.novaEpoca = async () => { const s = serieCurr(), c = await salvar('curriculo', { serie: s, componente: (itensLista('componentes')[0] || {}).chave || '', titulo: 'Nova época', periodo: '', semanas: '', conteudos: '', objetivos: '', bncc: [], realizadas: [], ordem: D.curriculo.filter(x => x.serie === s).length }); UI.sub = c.id; render(); };
A.colarEpocas = async () => {
  const s = serieCurr(), v = await dlg({ titulo: 'Colar épocas do ' + s + 'º ano', largo: true, ok: 'Incluir', corpo: '<p class="dica">Uma época por linha, no formato: <code>Componente; Título; Período; Semanas</code>. Exemplo: <code>Matemática; Medidas e dinheiro; maio; 3</code>. O componente é procurado na lista de Cadastros.</p>' + campo('Épocas', '<textarea name="t" class="alto" autofocus></textarea>') });
  if (!v) return; let n = 0, ordem = D.curriculo.filter(x => x.serie === s).length;
  for (const l of v.t.split('\n').map(x => x.trim()).filter(Boolean)) { const [comp, tit, per, sem] = l.split(/\s*[;\t]\s*/); const it = itensLista('componentes').find(i => norm1(i.nome) === norm1(comp) || norm1(i.chave) === norm1(comp)); await salvar('curriculo', { serie: s, componente: it ? it.chave : '', titulo: (tit || comp || '').trim(), periodo: per || '', semanas: sem || '', conteudos: '', objetivos: '', bncc: [], realizadas: [], ordem: ordem++ }); n++; }
  render(); aviso(n + ' época(s) incluída(s).');
};
const norm1 = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
function editorEpoca(c) {
  const t = turmaAtual();
  let h = '<div class="linha"><button class="btn" data-a="voltarSub">← Currículo</button><h2 style="margin:0">' + e(c.titulo) + '</h2><span class="espaco"></span><button class="btn perigo" data-a="apagarEpoca" data-id="' + c.id + '">Excluir</button></div>';
  h += '<div class="cartao" data-rec="curriculo:' + c.id + '"><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Série', sel('serie', c.serie, seriesVisiveis().map(n => [n, n + 'º ano']), 'data-rr="1"')) + campo('Componente', sel('componente', c.componente, opcoesLista('componentes', '— escolha —', c.componente), 'data-rr="1"')) + campo('Período', inp('periodo', c.periodo, 'text', 'placeholder="ex.: março e abril"')) + campo('Semanas', inp('semanas', c.semanas, 'text')) + '</div>' +
    campo('Época', inp('titulo', c.titulo)) + campo('Conteúdos', area('conteudos', c.conteudos, 'class="alto"')) + campo('Objetivos', area('objetivos', c.objetivos)) + (t && t.serie === c.serie ? '<label class="ck"><input type="checkbox" data-c="epocaRealizada" data-id="' + c.id + '"' + ((c.realizadas || []).includes(t.id) ? ' checked' : '') + '> Realizada com a turma ' + e(rotuloTurma(t)) + '</label>' : '') + '</div>';
  h += '<div class="cartao"><h3>Habilidades da BNCC ligadas a esta época</h3><div class="linha"><button class="btn" data-a="sugerirBncc" data-id="' + c.id + '">Sugerir habilidades</button><button class="btn" data-a="buscarBncc" data-id="' + c.id + '">Procurar na BNCC</button></div>' +
    ((c.bncc || []).length ? '<table class="tabela" style="margin-top:.6rem">' + c.bncc.map(cod => { const x = IXBNCC[cod]; return '<tr><td style="white-space:nowrap"><b>' + cod + '</b><br><span class="dica">' + (x ? rotAnos(x[2]) : '') + '</span></td><td>' + e(x ? x[3] : '') + '</td><td><button class="icone-btn" data-a="remBncc" data-id="' + c.id + '" data-cod="' + cod + '">✕</button></td></tr>'; }).join('') + '</table>' : '<p class="dica">Nenhuma habilidade ligada ainda. Preencha os conteúdos e use “Sugerir habilidades”.</p>') + '</div>';
  return h;
}
C_.epocaRealizada = async el => { const c = IX.curriculo[el.dataset.id], t = turmaAtual(), s = new Set(c.realizadas || []); if (el.checked) s.add(t.id); else s.delete(t.id); c.realizadas = [...s]; await salvar('curriculo', c); };
A.apagarEpoca = async d => { if (!(await confirmar('Excluir a época?', 'Ela sai do currículo e da comparação com a BNCC.', 'Excluir'))) return; await apagar('curriculo', d.id); UI.sub = null; render(); };
A.remBncc = async d => { const c = IX.curriculo[d.id]; c.bncc = c.bncc.filter(x => x !== d.cod); await salvar('curriculo', c); render(); };
async function escolherHabilidades(c, lista, titulo, busca) {
  const r = await dlg({ titulo, largo: true, ok: 'Ligar as marcadas', corpo: (busca ? '<div class="linha"><input type="search" id="bq" placeholder="Palavra ou código (ex.: medidas, EF03MA)" value="' + e(busca.q || '') + '" style="flex:1"><select id="bc"><option value="">Todos os componentes</option>' + Object.entries(BNCC_COMP).map(([k, n]) => '<option value="' + k + '"' + (busca.c === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select><select id="ba"><option value="">Todos os anos</option>' + seriesVisiveis().map(n => '<option value="' + n + '"' + (Number(busca.a) === n ? ' selected' : '') + '>' + n + 'º ano</option>').join('') + '</select><button type="button" class="btn" id="bb">Buscar</button></div>' : '') + '<div class="rolagem" style="max-height:58vh" id="blista">' + listaHab(lista, c) + '</div>',
    aoAbrir: busca ? (f => { const go = () => { $('#blista', f).innerHTML = listaHab(buscarBncc($('#bq', f).value, $('#bc', f).value, $('#ba', f).value), c); }; $('#bb', f).onclick = go; $('#bq', f).addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); go(); } }); }) : null });
  if (!r || !r.h || !r.h.length) return; c.bncc = [...new Set((c.bncc || []).concat(r.h))]; await salvar('curriculo', c); render(); aviso(r.h.length + ' habilidade(s) ligada(s).');
}
const listaHab = (xs, c) => xs.length ? '<table class="tabela">' + xs.slice(0, 200).map(x => '<tr><td><input type="checkbox" name="h" data-multi="1" value="' + x[0] + '"' + ((c.bncc || []).includes(x[0]) ? ' checked disabled' : '') + '></td><td style="white-space:nowrap"><b>' + x[0] + '</b><br><span class="dica">' + rotAnos(x[2]) + '</span></td><td style="font-size:.9rem">' + e(x[3]) + '</td></tr>').join('') + '</table>' + (xs.length > 200 ? '<p class="dica">Mostrando 200 de ' + xs.length + '. Refine a busca.</p>' : '') : '<p class="dica">Nada encontrado.</p>';
function buscarBncc(q, c, a) { const ws = fichas(q), cod = /^EF\d/i.test(q.trim()) ? q.trim().toUpperCase() : ''; return BNCC.filter(h => (!c || h[1] === c) && (!a || h[2].includes(Number(a))) && (cod ? h[0].startsWith(cod) : ws.every(w => fichas(h[3]).some(x => x.startsWith(w.slice(0, 6)))))); }
A.sugerirBncc = d => { const c = IX.curriculo[d.id], xs = sugerirBncc(c, 15); if (!xs.length) return informar('Sem sugestões', '<p>Escreva os conteúdos e os objetivos da época e escolha o componente. As sugestões vêm das palavras desses campos.</p>'); escolherHabilidades(c, xs, 'Sugestões para “' + c.titulo + '”'); };
A.buscarBncc = d => { const c = IX.curriculo[d.id], area = (itemLista('componentes', c.componente) || {}).bncc || ''; escolherHabilidades(c, buscarBncc('', area, c.serie), 'Procurar na BNCC', { q: '', c: area, a: c.serie }); };
A.exportarCurric = () => { const s = serieCurr(), xs = D.curriculo.filter(c => c.serie === s).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)), b = [{ t: 'tit', txt: 'Currículo — ' + s + 'º ano' }]; xs.forEach(c => { b.push({ t: 'h', txt: c.titulo + ' · ' + nomeItem('componentes', c.componente) + (c.periodo ? ' · ' + c.periodo : '') }); nl2p(c.conteudos).forEach(p => b.push({ t: 'p', txt: p })); if (c.objetivos) b.push({ t: 'p', txt: 'Objetivos: ' + c.objetivos.replace(/\n+/g, ' ') }); if ((c.bncc || []).length) b.push({ t: 'nota', txt: 'BNCC: ' + c.bncc.join(', ') }); }); const cab = ['Época', 'Componente', 'Período', 'Semanas', 'BNCC'], ls = xs.map(c => [c.titulo, nomeItem('componentes', c.componente), c.periodo || '', c.semanas || '', (c.bncc || []).join(' ')]); saidaDocumento({ nome: 'Curriculo_' + s + 'ano', titulo: 'Currículo — ' + s + 'º ano', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b }, { csv: { cab, linhas: ls }, assunto: 'Currículo' }); };

/* ---------- BNCC: consulta ---------- */
function abaBncc() {
  const f = UI.filtro, xs = buscarBncc(f.bq || '', f.bc || '', f.ba || ''), usos = {};
  D.curriculo.forEach(c => (c.bncc || []).forEach(cod => (usos[cod] = usos[cod] || []).push(c)));
  let h = '<p>Habilidades do Ensino Fundamental da Base Nacional Comum Curricular (versão homologada, MEC)' + (BNCC_COMP.CO ? ' e do complemento de Computação (2022, com explicação e exemplos de cada habilidade; ligue ou desligue em Ajustes)' : '') + '. Busque por palavra ou código e veja em quais épocas da escola cada habilidade está ligada.</p><div class="linha"><input type="search" data-c="bq" placeholder="Palavra ou código (ex.: frações, EF04MA)" value="' + e(f.bq || '') + '" style="flex:1;min-width:200px"><select data-c="bc"><option value="">Todos os componentes</option>' + Object.entries(BNCC_COMP).map(([k, n]) => '<option value="' + k + '"' + (f.bc === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select><select data-c="ba"><option value="">Todos os anos</option>' + seriesVisiveis().map(n => '<option value="' + n + '"' + (Number(f.ba) === n ? ' selected' : '') + '>' + n + 'º ano</option>').join('') + '</select><button class="btn" data-a="exportarBncc">Exportar</button></div><p class="dica">' + xs.length + ' habilidade(s).</p>';
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Código</th><th>Componente · anos</th><th>Habilidade</th><th>Na escola</th></tr>' + xs.slice(0, 300).map(x => '<tr><td><b>' + x[0] + '</b></td><td style="font-size:.85rem">' + BNCC_COMP[x[1]] + '<br>' + rotAnos(x[2]) + '</td><td style="font-size:.9rem">' + e(x[3]) + (x[4] ? '<div class="dica">' + e([x[4].e, x[4].o].filter(Boolean).join(' · ')) + (x[4].etapa ? ' · habilidade por etapa' + (x[4].eq ? ' (= ' + x[4].eq + ')' : '') : '') + '</div>' + (x[4].x ? '<details><summary class="dica" style="cursor:pointer">Explicação e exemplos</summary><p style="margin:.3rem 0">' + e(x[4].x) + '</p>' + (x[4].ex ? '<p style="margin:.3rem 0"><i>Exemplos:</i> ' + e(x[4].ex) + '</p>' : '') + '</details>' : '') : '') + '</td><td style="font-size:.85rem">' + (usos[x[0]] || []).map(c => '<a href="#" data-a="abrirEpocaDe" data-id="' + c.id + '">' + c.serie + 'º: ' + e(c.titulo) + '</a>').join('<br>') + '</td></tr>').join('') + '</table>' + (xs.length > 300 ? '<p class="dica">Mostrando 300 de ' + xs.length + '. Refine a busca.</p>' : '') + '</div>';
}
A.abrirEpocaDe = d => { UI.aba.curric = 'escola'; ir('curric', d.id); };
['bq', 'bc', 'ba'].forEach(k => C_[k] = el => { UI.filtro[k] = el.value; if (k === 'bq') { clearTimeout(C_.bq.t); C_.bq.t = setTimeout(() => { render(); const i = $('[data-c=bq]'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 400); } else render(); });
A.exportarBncc = () => { const f = UI.filtro, xs = buscarBncc(f.bq || '', f.bc || '', f.ba || ''), cab = ['Código', 'Componente', 'Anos', 'Habilidade'], ls = xs.map(x => [x[0], BNCC_COMP[x[1]], rotAnos(x[2]), x[3]]); saidaDocumento({ nome: 'BNCC_habilidades', titulo: 'BNCC — habilidades selecionadas', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'BNCC — habilidades selecionadas' }, { t: 'tabela', cab, linhas: ls }] }, { csv: { cab, linhas: ls }, assunto: 'BNCC' }); };

/* ---------- comparação ---------- */
function compararBncc(serie, area) {
  const lig = {}; D.curriculo.forEach(c => (c.bncc || []).forEach(cod => (lig[cod] = lig[cod] || []).push(c)));
  return BNCC.filter(h => !ehEtapa(h) && h[2].includes(serie) && (!area || h[1] === area)).map(h => { const cs = lig[h[0]] || [], mesmo = cs.filter(c => c.serie === serie), outro = cs.filter(c => c.serie !== serie); return { h, st: mesmo.length ? 'mesmo' : outro.length ? 'outro' : 'nao', mesmo, outro }; });
}
function docComparacao(serie) {
  const b = [{ t: 'tit', txt: 'Currículo da escola e BNCC — ' + serie + 'º ano' }, { t: 'p', txt: 'Na pedagogia Waldorf, vários conteúdos são trabalhados em idades diferentes das previstas na BNCC, de propósito, em sintonia com o desenvolvimento da criança. Por isso este relatório distingue as habilidades contempladas no mesmo ano, as contempladas em outro ano e as não contempladas. Habilidades da BNCC que abrangem vários anos (como EF15LP01) aparecem em todos esses anos.' }];
  const linhas = [], resumo = [];
  Object.entries(BNCC_COMP).forEach(([k, n]) => { const xs = compararBncc(serie, k); if (!xs.length) return; const m = xs.filter(x => x.st === 'mesmo').length, o = xs.filter(x => x.st === 'outro').length, nn = xs.length - m - o; resumo.push({ rot: n, v: { mesmo: m, outro: o, nao: nn } }); linhas.push([n, String(xs.length), String(m), String(o), String(nn)]); });
  b.push({ t: 'svg', svg: svgEmpilhado(resumo, ['mesmo', 'outro', 'nao'], { mesmo: '#2F6AA8', outro: '#E9B93A', nao: '#EA6A55' }, { mesmo: 'No mesmo ano', outro: 'Em outro ano', nao: 'Não contemplada' }, 'Habilidades da BNCC do ' + serie + 'º ano por componente') });
  b.push({ t: 'tabela', cab: ['Componente', 'Habilidades', 'No mesmo ano', 'Em outro ano', 'Não contempladas'], linhas });
  Object.entries(BNCC_COMP).forEach(([k, n]) => { const xs = compararBncc(serie, k).filter(x => x.st !== 'mesmo'); if (!xs.length) return; b.push({ t: 'h', txt: n + ': em outro ano ou não contempladas' }); b.push({ t: 'tabela', cab: ['Código', 'Situação', 'Habilidade'], linhas: xs.map(x => [x.h[0], x.st === 'outro' ? 'Em outro ano: ' + [...new Set(x.outro.map(c => c.serie + 'º (' + c.titulo + ')'))].join(', ') : 'Não contemplada', x.h[3]]) }); });
  return { nome: 'Curriculo_BNCC_' + serie + 'ano', titulo: 'Currículo e BNCC — ' + serie + 'º ano', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
function abaComparacao() {
  const s = serieCurr(); if (!D.curriculo.some(c => (c.bncc || []).length)) return '<div class="linha">' + selSerie('curSerie', s) + '</div>' + vazio('Para comparar, cadastre as épocas no currículo da escola e ligue cada uma às habilidades da BNCC.');
  const doc = docComparacao(s);
  return '<div class="linha">' + selSerie('curSerie', s) + '<button class="btn pri" data-a="exportarComparacao">Imprimir, exportar ou enviar</button></div><div class="cartao rolagem">' + doc.blocos.slice(1).map(htmlBloco).join('') + '</div>';
}
A.exportarComparacao = () => saidaDocumento(docComparacao(serieCurr()), { assunto: 'Currículo e BNCC' });
