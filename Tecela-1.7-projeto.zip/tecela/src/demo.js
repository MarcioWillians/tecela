/* ==========================================================================
   Tecelã — modelo de demonstração. Escola, alunos e textos inventados:
   nenhum nome ou dado é de pessoa real. Fica num banco separado
   (tecela-demo) e nunca se mistura com os dados reais.
   ========================================================================== */
'use strict';
function svgParaDataUrl(svg, w, h) {
  return new Promise(res => { const img = new Image(), url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' })); img.onload = () => { const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, 0, 0, w, h); URL.revokeObjectURL(url); res(c.toDataURL('image/png')); }; img.onerror = () => res(null); img.src = url; });
}
const LOGO_DEMO = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="240" height="240"><circle cx="60" cy="60" r="56" fill="#FCEFB4"/><path d="M60 98 C58 80 60 62 62 44" stroke="#5B7B3A" stroke-width="5" fill="none" stroke-linecap="round"/>' + [[60, 34, 0], [44, 42, -50], [76, 42, 50], [50, 26, -25], [70, 26, 25], [60, 20, 0]].map(([x, y, r]) => '<ellipse cx="' + x + '" cy="' + y + '" rx="11" ry="6.5" fill="#E9B93A" transform="rotate(' + r + ' ' + x + ' ' + y + ')"/>').join('') + '<ellipse cx="60" cy="98" rx="26" ry="5" fill="#C8B98A" opacity=".6"/></svg>';

/* muda a cada versão do modelo: um modelo antigo guardado no navegador é refeito sozinho */
const DEMO_VERSAO = '1.6';
async function construirDemo() {
  zerarMemoria();
  const add = (s, r) => { r.id = r.id || uid(); r.criado = r.criado || '2026-11-01T10:00:00.000Z'; r.alterado = r.criado; D[s].push(r); IX[s][r.id] = r; return r; };
  CFG.escola = { nome: 'Escola Waldorf Tecelã' };
  CFG.prefs = Object.assign({}, PREFS_PADRAO, { lgpdOk: true, biblio: 'pronta', turmaId: 't26', ultimaCopia: null, pendente: false, demoVersao: DEMO_VERSAO });
  const logo = await svgParaDataUrl(LOGO_DEMO, 240, 240);
  add('timbrado', { id: 'atas', logo, logoPos: 'esquerda', logoAlt: 16, papel: 'A4', margens: { s: 18, i: 18, e: 25, d: 20 }, cab: 'Escola Waldorf Tecelã\nRua das Hortênsias, 120 · Vale das Flores\ncontato@tecela.exemplo', rod: 'Modelo de demonstração da Tecelã · dados fictícios' });
  add('timbrado', { id: 'boletins', igual: true });
  carregarBiblioteca('pronta'); garantirCadastros();

  /* ---------- alunos ---------- */
  const R = (nome, par, email) => ({ nome, parentesco: par, email, tel: '(00) 90000-0000' });
  const AL = [
    ['ana', 'Ana Clara Moreira (fictício)', 'Ana Clara', '2017-03-14', 'f', [R('Juliana Moreira', 'mãe', 'juliana.moreira@exemplo.com')]],
    ['bento', 'Bento Albuquerque Lima (fictício)', 'Bento', '2017-06-02', 'm', [R('Rodrigo Lima', 'pai', 'rodrigo.lima@exemplo.com'), R('Sofia Albuquerque', 'mãe', 'sofia.alb@exemplo.com')]],
    ['cecilia', 'Cecília Duarte Prado (fictício)', 'Cecília', '2017-09-21', 'f', [R('Marta Duarte', 'mãe', 'marta.duarte@exemplo.com')]],
    ['davi', 'Davi Nogueira Costa (fictício)', 'Davi', '2017-01-30', 'm', [R('Paulo Costa', 'pai', 'paulo.costa@exemplo.com')]],
    ['helena', 'Helena Sampaio Rocha (fictício)', 'Helena', '2017-11-08', 'f', [R('Laura Sampaio', 'mãe', 'laura.sampaio@exemplo.com')]],
    ['joaquim', 'Joaquim Tavares Reis (fictício)', 'Joaquim', '2017-04-17', 'm', [R('Clara Tavares', 'mãe', 'clara.tavares@exemplo.com')]],
    ['livia', 'Lívia Barros Fontes (fictício)', 'Lívia', '2017-08-05', 'f', [R('André Fontes', 'pai', 'andre.fontes@exemplo.com')]],
    ['tomas', 'Tomás Vieira Ramos (fictício)', 'Tomás', '2016-12-19', 'm', [R('Beatriz Vieira', 'mãe', 'beatriz.vieira@exemplo.com')]],
    ['rafael', 'Rafael Campos Leite (fictício)', 'Rafael', '2017-05-26', 'm', [R('Teresa Campos', 'avó', 'teresa.campos@exemplo.com')]]];
  AL.forEach(([id, nome, chamada, nasc, genero, resp]) => add('alunos', { id, nome, chamada, nasc, genero, responsaveis: resp, situacao: 'ativo', entrada: id === 'rafael' ? '2026-02-02' : '2024-02-05', nee: id === 'tomas', acomp: id === 'tomas' || id === 'joaquim' }));
  const liv = IX.alunos.livia; liv.situacao = 'transferido'; liv.saida = '2025-12-12';

  /* ---------- turmas ---------- */
  const t25 = add('turmas', { id: 't25', serie: 2, letra: 'A', ano: 2025, professora: 'Marina Alves Correia (fictício)', genProf: 'a', diasLetivos: [50, 49, 51, 50], boletim: {
    citacao: 'Eu quero aprender, eu quero trabalhar.\nEu quero trabalhar aprendendo,\neu quero aprender trabalhando.', citacaoAutor: 'Rudolf Steiner', assinaturas: { prof: true, coord: false },
    textos: {
      intro: 'As crianças do segundo ano A chegaram a 2025 curiosas pelas letras minúsculas, pelas tabuadas e pelas histórias de animais. Foi um ano de polaridades, sentidas dentro de cada um e na própria turma, e as fábulas e as lendas ajudaram o grupo a dar forma ao que sentia.',
      chegada: 'A turma aprendeu a esperar o fechar da porta para começar o dia junto.',
      ritmica: 'Na roda, os circuitos de equilíbrio, as cantigas e a tabuada caminhada fortaleceram a lateralidade e a atenção.',
      portugues: 'Nas épocas de Língua Portuguesa vieram as letras minúsculas, a leitura de pequenos textos e as primeiras produções escritas.',
      matematica: 'Na Matemática, a memorização rítmica das tabuadas, o valor posicional e os desafios contados como histórias.',
      aquarela: 'Na aquarela, as cores se encontraram: o amarelo-limão recebeu o azul-da-prússia, e o verde nasceu.',
      pausa: 'Na pausa, o brincar livre no parque mostrou novas amizades e alguns desafios de convivência.',
      conclusao: 'Assim entrego a {nome} o poema do seu novo ano escolar:' } } });
  const t26 = add('turmas', { id: 't26', serie: 3, letra: 'A', ano: 2026, professora: 'Marina Alves Correia (fictício)', genProf: 'a', diasLetivos: [48, 50, 49, 50], origemId: 't25', boletim: {
    citacao: 'Que a criança aprenda a amar o mundo\npara que, mais tarde, saiba transformá-lo.', citacaoAutor: 'Inspirado na pedagogia de Rudolf Steiner', assinaturas: { prof: true, coord: true, coordNome: 'Coordenação pedagógica' },
    textos: {
      intro: 'O terceiro ano A viveu 2026 como um ano de chão firme. As narrativas da criação e os ofícios acompanharam crianças que começavam a se perceber separadas do mundo: construímos a nossa casinha no pátio, plantamos o trigo, moemos o grão e assamos o pão da festa da colheita.',
      chegada: 'A chegada ganhou um novo cuidado: cada criança cumprimentava a professora olhando nos olhos e encontrava o seu lugar já preparado.',
      poemaManha: 'O poema da manhã foi dito em coro todos os dias, e cada criança teve também o seu dia de recitar sozinha o poema individual.',
      ritmica: 'Na parte rítmica, a roda trouxe as medidas do corpo (palmo, pé, passo), as tabuadas cantadas e os circuitos de corda e perna de pau.',
      flauta: 'Na flauta, a turma passou à flauta diatônica e tocou a duas vozes pela primeira vez.',
      formas: 'O desenho de forma trouxe formas espelhadas e entrelaçadas, que pediram atenção e paciência.',
      conteudo: 'Nas épocas de ofícios, cada criança registrou no caderno o caminho do grão ao pão e da pedra à casa.',
      aquarela: 'Na aquarela, as cores se tornaram paisagens: o céu, a terra arada e o campo de trigo.',
      desenho: 'No desenho com blocos de giz, a figuração ganhou chão, horizonte e detalhes.',
      portugues: 'Em Língua Portuguesa, chegaram a letra cursiva e as primeiras noções de gramática, vividas como ação (verbo), coisa (substantivo) e qualidade (adjetivo).',
      matematica: 'Na Matemática, as medidas, o dinheiro, o relógio e os problemas da vida prática deram sentido às quatro operações.',
      jogos: 'Nos jogos, as brincadeiras de pegar com regras mais elaboradas pediram decisão rápida e respeito às combinações.',
      pausa: 'No brincar livre, a construção de cabanas reuniu meninos e meninas em projetos comuns.',
      atitudes: 'Ao longo do ano, cuidamos dos hábitos de organização do material, de terminar o que se começa e de ouvir o colega.',
      euritmia: 'Na euritmia, a turma movimentou as vogais e as formas geométricas no espaço, com crescente harmonia.',
      trabalhos: 'Nos trabalhos manuais, cada criança fez de crochê a sua bolsinha para a flauta.',
      conclusao: 'Foi uma alegria acompanhar {nome} neste ano. Assim entrego o poema do seu novo ano escolar:' } } });
  const m3 = { id: 'mod3', serie: 3, secoes: SECOES_PADRAO.map(([key, titulo, a]) => ({ key, titulo, ativa: !!a })) };
  m3.secoes.forEach(s => { if (['retrospectiva', 'lanche'].includes(s.key)) s.ativa = false; if (['euritmia', 'trabalhos'].includes(s.key)) s.ativa = true; });
  const ic = m3.secoes.findIndex(s => s.key === 'conclusao'), ex = m3.secoes.filter(s => ['euritmia', 'trabalhos'].includes(s.key)); m3.secoes = m3.secoes.filter(s => !['euritmia', 'trabalhos'].includes(s.key)); m3.secoes.splice(m3.secoes.findIndex(s => s.key === 'conclusao'), 0, ...ex);
  add('modelosBoletim', m3); add('modelosBoletim', { id: 'mod2', serie: 2, secoes: SECOES_PADRAO.map(([key, titulo, a]) => ({ key, titulo, ativa: !!a })) });

  /* ---------- matrículas e faltas ---------- */
  const F25 = { ana: [1, 0, 2, 1], bento: [0, 1, 0, 0], cecilia: [3, 2, 1, 2], davi: [1, 1, 0, 1], helena: [0, 2, 1, 0], joaquim: [2, 3, 2, 4], livia: [1, 0, 1, 2], tomas: [4, 2, 3, 3] };
  const F26 = { ana: [0, 1, 1, null], bento: [1, 0, 0, null], cecilia: [2, 1, 2, null], davi: [0, 0, 1, null], helena: [1, 1, 0, null], joaquim: [3, 2, 2, null], tomas: [2, 3, 1, null], rafael: [1, 0, 1, null] };
  Object.entries(F25).forEach(([a, f]) => add('matriculas', { alunoId: a, turmaId: 't25', faltas: f, resultado: a === 'livia' ? 'transferido' : 'segue' }));
  Object.entries(F26).forEach(([a, f]) => add('matriculas', { alunoId: a, turmaId: 't26', faltas: f }));

  /* ---------- anotações ---------- */
  const N = (data, alunos, secao, criterio, texto, estrela, sigilo, turmaId) => add('anotacoes', { data, alunos, secao, criterio, texto, estrela: estrela !== false, sigilo: !!sigilo, turmaId: turmaId || 't26', criado: data + 'T15:00:00.000Z' });
  N('2025-04-10', ['bento'], 'ritmica', 'sentidos', 'Bento atravessou a prancha de equilíbrio pela primeira vez sem ajuda, com um sorriso largo.', true, false, 't25');
  N('2025-06-05', ['cecilia'], 'aquarela', 'sentir', 'Cecília pintou em silêncio por longo tempo; seu verde ficou delicado e luminoso.', true, false, 't25');
  N('2025-08-21', ['tomas'], 'pausa', 'social', 'Tomás passou a pausa sozinho perto da mangueira. Convidei-o para ajudar a regar a horta.', false, false, 't25');
  N('2025-10-02', ['joaquim', 'bento'], 'jogos', 'querer', 'Joaquim e Bento lideraram o pega-pega, mas tiveram dificuldade em aceitar ser pegos.', true, false, 't25');
  N('2026-02-12', ['ana', 'bento', 'cecilia', 'davi', 'helena', 'joaquim', 'tomas', 'rafael'], 'chegada', '', '{nome} recebeu Rafael, o colega novo, com curiosidade e gentileza na primeira semana.', false);
  N('2026-02-19', ['rafael'], 'chegada', 'biografia', 'Rafael chegou de outra cidade e mora com a avó. Ainda observa muito antes de participar.', false, true);
  N('2026-03-05', ['ana'], 'poemaManha', 'sentir', 'Ana Clara disse o poema individual com voz clara e um gesto bonito ao final, olhando para os colegas.');
  N('2026-03-17', ['bento'], 'ritmica', 'querer', 'Bento conduziu a roda das medidas com entusiasmo; precisou de lembretes para dar a vez aos outros.');
  N('2026-03-24', ['davi'], 'conteudo', 'pensar', 'Davi demorou a começar o desenho da casa no caderno, mas, uma vez iniciado, trabalhou até o fim com grande capricho.');
  N('2026-04-02', ['cecilia'], 'flauta', 'sentir', 'Cecília tocou a segunda voz com afinação e cuidado; ficou emocionada quando a música se encontrou.');
  N('2026-04-15', ['joaquim'], 'atitudes', 'querer', 'Joaquim esqueceu o material três vezes nesta semana. Combinamos uma lista na mochila.');
  N('2026-04-28', ['tomas'], 'portugues', 'aprendizagem', 'Tomás confunde b e d na escrita cursiva e se cansa rapidamente nas cópias longas.');
  N('2026-05-07', ['helena'], 'aquarela', 'sentir', 'Helena pintou o campo de trigo com amarelos quentes e conversou com as cores enquanto pintava.');
  N('2026-05-21', ['ana', 'helena'], 'pausa', 'social', 'Ana Clara e Helena organizaram uma casinha de galhos e convidaram quem estava sozinho.');
  N('2026-06-04', ['rafael'], 'matematica', 'pensar', 'Rafael resolveu de cabeça o problema do troco da feira, antes de todos, e explicou o caminho.');
  N('2026-06-11', ['bento'], 'matematica', 'pensar', 'Bento domina as tabuadas até o 6 e criou sozinho um problema com o relógio para a turma.');
  N('2026-06-25', ['davi'], 'trabalhos', 'querer', 'Davi terminou a bolsinha de crochê com pontos firmes e regulares. Mostrou com orgulho à família.');
  N('2026-08-13', ['joaquim'], 'jogos', 'social', 'Joaquim discutiu com colegas sobre as regras do jogo; depois da conversa, propôs ele mesmo uma regra nova e justa.');
  N('2026-08-27', ['tomas'], 'ritmica', 'sentidos', 'Tomás evita a perna de pau e a corda. Na euritmia, prefere ficar na ponta da fila.');
  N('2026-09-10', ['ana'], 'portugues', 'aprendizagem', 'Ana Clara escreveu sozinha um pequeno texto sobre o pão, com frases completas e letra cursiva caprichada.');
  N('2026-09-17', ['cecilia'], 'atitudes', 'sentir', 'Cecília chorou ao perder no jogo e precisou de tempo para voltar ao grupo.', false);
  N('2026-09-24', ['helena'], 'formas', 'pensar', 'Helena percebeu sozinha o erro no espelhamento da forma e o corrigiu com calma.');
  N('2026-10-08', ['ana', 'bento', 'cecilia', 'davi', 'helena', 'joaquim', 'tomas', 'rafael'], 'conteudo', '', 'Na festa da colheita, {nome} ajudou a moer o trigo e a sovar o pão da turma.');
  N('2026-10-15', ['bento'], 'aquarela', 'sentir', 'Bento pintou com pinceladas largas e decididas; neste ano, aprendeu a esperar a cor secar antes de sobrepor.');
  N('2026-10-22', ['tomas'], 'conteudo', 'pensar', 'Tomás contou com detalhes a construção da casa dos castores, que lembrava da narrativa de semanas atrás.');

  /* ---------- atas ---------- */
  const MK = (ataId, trecho, alunos, secao, data) => { const n = add('anotacoes', { turmaId: 't26', data, alunos, secao, criterio: '', texto: trecho, estrela: true, sigilo: false, origem: { tipo: 'ata', id: ataId }, criado: data + 'T22:00:00.000Z' }); add('marcacoes', { ataId, trecho, alunos, secao, data, anotacaoId: n.id }); };
  const P = (nome, categoria, presente, email, justificada) => ({ nome, categoria, presente: presente !== false, email: email || '', justificada: !!justificada });
  const fam26 = add('atas', { id: 'ata1', turmaId: 't26', tipo: 'familias', subtipo: '', numero: '01', livro: '3', carater: 'ordinária', data: '2026-03-12', inicio: '19:00', fim: '20:45', local: 'sala do 3º ano A', assunto: 'apresentação do plano do terceiro ano e acolhida das famílias', pauta: 'O terceiro ano e o Rubicão\nÉpocas de ofícios e a construção da casinha\nCombinados da turma\nFesta da colheita',
    participantes: [P('Marina Alves Correia (fictício)', 'Professora'), P('Juliana Moreira', 'Familiar', true, 'juliana.moreira@exemplo.com'), P('Rodrigo Lima', 'Familiar', true, 'rodrigo.lima@exemplo.com'), P('Marta Duarte', 'Familiar', true, 'marta.duarte@exemplo.com'), P('Paulo Costa', 'Familiar', true, 'paulo.costa@exemplo.com'), P('Laura Sampaio', 'Familiar', true, 'laura.sampaio@exemplo.com'), P('Clara Tavares', 'Familiar', false, 'clara.tavares@exemplo.com', true), P('Beatriz Vieira', 'Familiar', true, 'beatriz.vieira@exemplo.com'), P('Teresa Campos', 'Familiar', true, 'teresa.campos@exemplo.com'), P('Irene Matos', 'Convidado')],
    secretario: 'Marina Alves Correia (fictício)', cabecalho: '',
    texto: 'A professora deu as boas-vindas às famílias e apresentou Teresa Campos, avó de Rafael, aluno novo da turma. Em seguida, falou sobre o momento de desenvolvimento das crianças por volta dos nove anos, quando começam a se perceber separadas do mundo, e sobre como o currículo do terceiro ano acolhe essa passagem com as narrativas da criação e com os ofícios.\nApresentou as épocas do ano: construção, agricultura, medidas e dinheiro. Contou que a turma vai construir uma pequena casa no pátio e que as famílias serão convidadas a ajudar num sábado de mutirão. Relatou que, nas primeiras semanas, Bento tem conduzido a roda das medidas com muito entusiasmo e que Cecília se emocionou com as cores da primeira aquarela do ano. Comentou também que Joaquim tem vivido conflitos na pausa, e que a professora acompanhará de perto, junto com a família.\nA convidada Irene Matos, euritmista da escola, falou sobre as aulas de euritmia do terceiro ano.',
    deliberacoes: 'Ficou decidido que o mutirão da casinha será no dia 9 de maio, das 9h às 13h. As famílias aprovaram a compra coletiva de lã para os trabalhos manuais.',
    conclusao: 'A professora agradeceu a presença de todos e reforçou a importância do sono e do ritmo em casa neste momento do ano.',
    encaminhamentos: [{ acao: 'Organizar a lista de materiais do mutirão', resp: 'Rodrigo Lima', prazo: '2026-04-30' }, { acao: 'Enviar às famílias o calendário das épocas', resp: 'Marina Alves Correia (fictício)', prazo: '2026-03-20' }],
    formato: 'moderno', papel: 'A4', assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'finalizado', finalizadoEm: '2026-03-13T11:00:00.000Z', criado: '2026-03-12T22:00:00.000Z',
    emTempo: [{ data: '2026-03-16', texto: 'Onde se lê “das 9h às 13h”, leia-se “das 8h30 às 12h30”, conforme confirmado com a coordenação.' }] });
  MK('ata1', 'Bento tem conduzido a roda das medidas com muito entusiasmo', ['bento'], 'ritmica', '2026-03-12');
  MK('ata1', 'Cecília se emocionou com as cores da primeira aquarela do ano', ['cecilia'], 'aquarela', '2026-03-12');
  MK('ata1', 'Joaquim tem vivido conflitos na pausa, e que a professora acompanhará de perto, junto com a família', ['joaquim'], 'pausa', '2026-03-12');
  add('atas', { id: 'ata2', turmaId: 't26', tipo: 'colegiado', subtipo: 'Estudo de criança', numero: '02', livro: '3', carater: 'agendada', data: '2026-06-18', inicio: '16:30', fim: '18:00', local: 'sala dos professores', assunto: 'estudo de criança sobre o aluno Tomás, do 3º ano A',
    participantes: [P('Marina Alves Correia (fictício)', 'Professor(a) do mesmo grau'), P('Irene Matos', 'Professor(a) de outro grau'), P('Lúcia Brandão', 'Professor(a) de outro grau'), P('Henrique Sales', 'Coordenação'), P('Dra. Vera Lins (médica escolar)', 'Convidado')],
    secretario: 'Henrique Sales', cabecalho: '',
    texto: 'A professora de classe descreveu Tomás sem julgamentos: um menino alto e magro, de passos cuidadosos, que observa muito antes de agir. Tem ótima memória para as narrativas e se cansa nas tarefas longas de escrita. Evita os exercícios de equilíbrio e prefere brincar sozinho.\nA euritmista contou que, nas aulas, Tomás fica na ponta da fila, mas acompanha as formas com precisão quando se sente seguro. A professora de trabalhos manuais relatou que ele é caprichoso e paciente no crochê.\nA médica escolar sugeriu observar o sentido do equilíbrio e do movimento e conversar com a família sobre o sono.',
    deliberacoes: 'O colegiado decidiu oferecer a Tomás uma tarefa de responsabilidade diária na turma e incluir exercícios de equilíbrio em dupla na parte rítmica. Cada professor levará a imagem de Tomás para a sua meditação até o próximo encontro.',
    conclusao: 'O estudo será retomado em setembro.', encaminhamentos: [{ acao: 'Conversar com a família sobre o sono e o uso de telas', resp: 'Marina Alves Correia (fictício)', prazo: '2026-07-03' }],
    formato: 'moderno', papel: 'A4', assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'finalizado', finalizadoEm: '2026-06-19T10:00:00.000Z', criado: '2026-06-18T21:00:00.000Z' });
  MK('ata2', 'é caprichoso e paciente no crochê', ['tomas'], 'trabalhos', '2026-06-18');
  add('atas', { id: 'ata3', turmaId: 't26', tipo: 'geral', subtipo: '', numero: '03', livro: '3', carater: 'extraordinária', data: '2026-10-22', inicio: '19:30', fim: '', local: 'salão da escola', assunto: 'organização do Bazar da Primavera',
    participantes: [P('Marina Alves Correia (fictício)', 'Professor(a)'), P('Henrique Sales', 'Coordenação'), P('Sofia Albuquerque', 'Familiar', true, 'sofia.alb@exemplo.com'), P('Laura Sampaio', 'Familiar', true, 'laura.sampaio@exemplo.com'), P('Associação de Amigos da Escola', 'Entidade')],
    secretario: 'Marina Alves Correia (fictício)', cabecalho: '', texto: 'Foram apresentadas as barracas do bazar e a escala das famílias. A turma do terceiro ano ficará responsável pela venda dos pães.', deliberacoes: '', conclusao: '', encaminhamentos: [], formato: 'tradicional', papel: 'A4', assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'rascunho', criado: '2026-10-22T23:00:00.000Z' });
  add('atas', { id: 'ata0', turmaId: 't25', tipo: 'familias', subtipo: '', numero: '04', livro: '2', carater: 'ordinária', data: '2025-11-27', inicio: '19:00', fim: '20:30', local: 'sala do 2º ano A', assunto: 'encerramento do segundo ano',
    participantes: [P('Marina Alves Correia (fictício)', 'Professora'), P('Juliana Moreira', 'Familiar'), P('Sofia Albuquerque', 'Familiar'), P('André Fontes', 'Familiar'), P('Beatriz Vieira', 'Familiar')], secretario: 'Marina Alves Correia (fictício)', cabecalho: '',
    texto: 'A professora fez um balanço do ano, falou das fábulas, das lendas e do crescimento da turma na leitura. O pai de Lívia comunicou que a família vai se mudar e que a menina será transferida ao final do ano.', deliberacoes: '', conclusao: 'Foi lembrada a data de entrega dos boletins.', encaminhamentos: [], formato: 'moderno', papel: 'A4', assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'finalizado', finalizadoEm: '2025-11-28T10:00:00.000Z', criado: '2025-11-27T23:00:00.000Z' });

  /* ---------- perfis ---------- */
  const PF = (alunoId, data, turmaId, c) => add('perfisAluno', { alunoId, data, turmaId, campos: c, criado: data + 'T12:00:00.000Z' });
  PF('bento', '2025-09-15', 't25', { tempPred: 'colerico', tempSec: 'sanguineo', pensarNivel: 'equilibrado', sentirNivel: 'equilibrado', quererNivel: 'fortalecido', papel: 'lider', polCosmica: 'Mais terrena', aspecto: 'Corpo compacto, passo firme, gestos decididos.', querer: 'Muita iniciativa; ainda impõe a sua vontade nos jogos.' });
  PF('cecilia', '2025-09-15', 't25', { tempPred: 'melancolico', tempSec: 'fleumatico', pensarNivel: 'equilibrado', sentirNivel: 'cuidado', quererNivel: 'equilibrado', papel: 'observador', polFantasia: 'Rica em fantasia', sentir: 'Sente tudo com intensidade; precisa de tempo para se recompor depois de frustrações.' });
  PF('tomas', '2025-09-15', 't25', { tempPred: 'melancolico', tempSec: 'colerico', pensarNivel: 'fortalecido', sentirNivel: 'cuidado', quererNivel: 'cuidado', papel: 'isolado', polCosmica: 'Mais cósmica', sentidos: 'Insegurança no equilíbrio; evita brincadeiras de movimento amplo.' });
  PF('ana', '2026-08-20', 't26', { tempPred: 'sanguineo', tempSec: 'colerico', pensarNivel: 'fortalecido', sentirNivel: 'equilibrado', quererNivel: 'equilibrado', papel: 'mediador', polCosmica: 'Equilibrada', polFantasia: 'Rica em fantasia', polMemoria: 'Boa memória', sono: 'Equilibrado', lateralidade: 'Destro(a)', aspecto: 'Leve, de gestos rápidos e expressivos; postura ereta.', tempManif: 'Interessa-se por tudo e anima o grupo; às vezes deixa tarefas pela metade.', pensar: 'Compreende rápido e faz boas conexões entre as épocas.', sentir: 'Alegre e empática; percebe quando um colega está triste.', querer: 'Persistência crescente, sobretudo quando a tarefa a encanta.', relacao: 'Querida pela turma; ajuda a resolver conflitos.', moral: 'Responsável com o material coletivo.', instrumentos: { 'observacao-continua': true, 'diario-do-professor': true, 'entrevista-com-os-pais': true } });
  PF('bento', '2026-08-20', 't26', { tempPred: 'colerico', tempSec: 'sanguineo', pensarNivel: 'fortalecido', sentirNivel: 'equilibrado', quererNivel: 'fortalecido', papel: 'lider', polCosmica: 'Mais terrena', lateralidade: 'Destro(a)', aspecto: 'Corpo compacto e forte, passo firme.', tempManif: 'Gosta de desafios difíceis e de liderar; está aprendendo a esperar a vez.', querer: 'Grande força de vontade e iniciativa.', relacao: 'Admirado pelos colegas; às vezes impõe a sua vontade.', instrumentos: { 'observacao-continua': true } });
  PF('cecilia', '2026-08-20', 't26', { tempPred: 'melancolico', tempSec: 'fleumatico', pensarNivel: 'equilibrado', sentirNivel: 'cuidado', quererNivel: 'equilibrado', papel: 'observador', polFantasia: 'Rica em fantasia', sentir: 'Ainda se frustra com intensidade, mas volta ao grupo com mais rapidez que no ano passado.', tempManif: 'Trabalha devagar e com muito capricho; observa antes de participar.' });
  PF('davi', '2026-08-20', 't26', { tempPred: 'fleumatico', tempSec: 'melancolico', pensarNivel: 'equilibrado', sentirNivel: 'equilibrado', quererNivel: 'cuidado', papel: 'colaborador', sono: 'Pesado', tempManif: 'Demora a começar, mas é constante e termina com capricho.', querer: 'Precisa de estímulo para iniciar as tarefas.' });
  PF('helena', '2026-08-20', 't26', { tempPred: 'sanguineo', tempSec: 'melancolico', pensarNivel: 'equilibrado', sentirNivel: 'fortalecido', quererNivel: 'equilibrado', papel: 'mediador', polFantasia: 'Rica em fantasia', sentir: 'Muito sensível às cores e à música.', passagens: 'Faz 9 anos em novembro; já aparecem perguntas sobre a morte e sobre os avós.' });
  PF('joaquim', '2026-08-20', 't26', { tempPred: 'sanguineo', tempSec: 'colerico', pensarNivel: 'equilibrado', sentirNivel: 'equilibrado', quererNivel: 'cuidado', papel: 'provocador', tempManif: 'Agitado, muda de interesse a todo momento; nos jogos, discute as regras.', querer: 'Esquece o material e tem dificuldade em concluir tarefas.', relacao: 'Conflitos frequentes na pausa, que vêm diminuindo.' });
  PF('tomas', '2026-08-20', 't26', { tempPred: 'melancolico', tempSec: 'colerico', pensarNivel: 'fortalecido', sentirNivel: 'cuidado', quererNivel: 'equilibrado', papel: 'observador', polCosmica: 'Mais cósmica', polMemoria: 'Boa memória', sentidos: 'O equilíbrio melhorou com os exercícios em dupla, mas ainda evita a perna de pau.', dificuldades: 'Troca b e d na escrita; cansa-se nas cópias longas. Família orientada a buscar avaliação.', instrumentos: { 'estudo-de-crianca': true, 'entrevista-com-os-pais': true } });
  PF('rafael', '2026-08-20', 't26', { tempPred: 'fleumatico', tempSec: 'sanguineo', pensarNivel: 'fortalecido', sentirNivel: 'equilibrado', quererNivel: 'equilibrado', papel: 'colaborador', familia: 'Mora com a avó desde o início do ano.', pensar: 'Raciocínio matemático rápido e claro.' });
  add('perfisTurma', { id: 'ptt25', turmaId: 't25', ano: 2025, analise: 'Um grupo vivo, com forte presença sanguínea e alguns coléricos que puxam a turma. As polaridades do segundo ano apareceram com força, inclusive entre meninos e meninas. O ritmo da roda e as fábulas ajudaram a dar forma ao que o grupo sentia.' });
  add('perfisTurma', { id: 'ptt26', turmaId: 't26', ano: 2026, analise: 'A turma atravessa o Rubicão: sete das oito crianças já fizeram nove anos. Os ofícios e a construção da casinha deram chão ao grupo. O querer pede cuidado em três crianças, o que confirma a importância das tarefas práticas e das pequenas responsabilidades diárias.' });

  /* ---------- boletins ---------- */
  const POEMAS = [['A semente', 'Pequenina na terra escura\na semente sabe esperar:\nguarda o sol dentro da casca\ne um dia vai brotar.\n\nAssim também eu me preparo,\ncom calma, chuva e calor,\npara abrir no tempo certo\nas pétalas da minha flor.'],
    ['O construtor', 'Pedra sobre pedra,\nfirme e devagar,\no construtor levanta a casa\nonde o sonho vai morar.\n\nMedindo com o seu palmo,\npesando com a sua mão,\nele sabe que o telhado\ncomeça lá no chão.'],
    ['O rio', 'O rio não tem pressa\nmas sempre chega ao mar;\ncontorna cada pedra\nsem nunca se cansar.\n\nQuem segue o seu caminho\ncom coragem e atenção\nleva a água limpa e clara\npara regar o chão.'],
    ['A estrela-guia', 'Lá no alto, à noite,\nbrilha uma estrela só;\nela não faz barulho,\nmas guia o caminhante.\n\nQue a minha luz também\nmesmo pequena e quieta\nmostre ao amigo perdido\no caminho da porta aberta.']];
  const IND25 = {
    ana: ['Ana Clara chegava saltitante, cheia de novidades para contar.', 'Leu com fluência crescente e escreveu pequenos textos com alegria.', 'Ana Clara viveu um ano de muita descoberta.'],
    bento: ['Bento chegava apressado, querendo logo começar.', 'Aprendeu as letras minúsculas com rapidez e firmeza no traço.', 'Bento mostrou grande força de vontade.'],
    cecilia: ['Cecília chegava em silêncio e ia direto ao seu lugar.', 'Leu com atenção e escreveu com capricho, sem pressa.', 'Cecília cresceu em coragem ao longo do ano.'],
    davi: ['Davi chegava tranquilo, sempre no mesmo ritmo.', 'Demorou a começar a ler, mas terminou o ano lendo pequenos textos.', 'Davi mostrou constância e paciência.'],
    helena: ['Helena chegava sorrindo e cumprimentava a todos.', 'Escreveu com letra bonita e gostou de ilustrar os textos.', 'Helena trouxe alegria e cuidado à turma.'],
    joaquim: ['Joaquim chegava agitado e precisava de tempo para se acalmar.', 'Lê bem, mas ainda tem pressa na escrita.', 'Joaquim viveu um ano de muitas emoções.'],
    livia: ['Lívia chegava de mãos dadas com a mãe e logo se soltava.', 'Lê com fluência e gosta de escrever bilhetes para os colegas.', 'Lívia deixa saudades na turma.'],
    tomas: ['Tomás chegava devagar e observava tudo antes de entrar.', 'Tem ótima memória para as histórias; a escrita ainda pede esforço.', 'Tomás mostrou profundidade e atenção.']};
  let pi = 0;
  for (const [a, [ch, pt, co]] of Object.entries(IND25)) {
    const [pt_, pp] = POEMAS[pi++ % POEMAS.length];
    add('boletins', { turmaId: 't25', alunoId: a, ano: 2025, secoes: { chegada: { texto: ch }, portugues: { texto: pt }, conclusao: { texto: co } }, importadas: [], poemaTitulo: pt_, poemaTexto: pp, assinaturas: { prof: true }, estado: 'finalizado', finalizadoEm: '2025-12-05T12:00:00.000Z', criado: '2025-11-20T12:00:00.000Z' });
  }
  const bAna = add('boletins', { id: 'bAna', turmaId: 't26', alunoId: 'ana', ano: 2026, importadas: [], poemaTitulo: POEMAS[3][0], poemaTexto: POEMAS[3][1], estado: 'rascunho', criado: '2026-10-25T12:00:00.000Z', secoes: {
    chegada: { texto: 'Ana Clara chegava animada e, neste ano, aprendeu a guardar as novidades para o momento certo de contá-las.' },
    poemaManha: { texto: 'Disse o poema individual com voz clara e um gesto bonito ao final, olhando para os colegas.' },
    ritmica: { texto: 'Na roda, acompanhou os movimentos com leveza e ajudou os colegas que se perdiam no ritmo.' },
    flauta: { texto: 'Tocou com dedos ágeis; às vezes se distraía com conversas, mas voltava rápido.' },
    formas: { texto: 'Seu traço ficou mais firme, e as formas espelhadas saíram com equilíbrio.' },
    conteudo: { texto: 'Na festa da colheita, Ana Clara ajudou a moer o trigo e a sovar o pão da turma. O caderno de época mostra capricho e cores vivas.' },
    aquarela: { texto: 'Pintou com alegria, deixando as cores conversarem no papel.' },
    desenho: { texto: 'Seus desenhos ganharam chão e horizonte, com muitos detalhes.' },
    portugues: { texto: 'Escreveu sozinha um pequeno texto sobre o pão, com frases completas e letra cursiva caprichada. Lê com fluência e expressão.' },
    matematica: { texto: 'Compreendeu bem as medidas e o dinheiro; ainda precisa de atenção nas contas de subtração com reserva.' },
    licao: { texto: 'Trouxe a lição de casa com regularidade e cuidado.' },
    jogos: { texto: 'Nos jogos, participou com entusiasmo e respeitou as regras combinadas.' },
    religiosidade: { texto: 'Ouviu as narrativas da criação com atenção e fez perguntas profundas.' },
    pausa: { texto: 'Organizou com Helena uma casinha de galhos e convidou quem estava sozinho.' },
    atitudes: { texto: 'Foi responsável com o material coletivo e teve ótima assiduidade.' },
    euritmia: { texto: 'Movimentou-se com graça e atenção às formas.' },
    trabalhos: { texto: 'Terminou a bolsinha de crochê com pontos regulares.' },
    conclusao: { texto: 'Ana Clara viveu um ano de muito crescimento e alegria.' } } });
  const bBento = add('boletins', { id: 'bBento', turmaId: 't26', alunoId: 'bento', ano: 2026, importadas: [], poemaTitulo: POEMAS[1][0], poemaTexto: POEMAS[1][1], estado: 'rascunho', criado: '2026-10-25T12:00:00.000Z', secoes: {
    chegada: { texto: 'Bento chegava decidido e, aos poucos, aprendeu a esperar o momento de começar.' },
    ritmica: { texto: 'Bento conduziu a roda das medidas com entusiasmo; ao longo do ano, aprendeu a dar a vez aos colegas.' },
    conteudo: { texto: 'Na festa da colheita, Bento ajudou a moer o trigo e a sovar o pão da turma. Seu caderno mostra traço firme e organização.' },
    aquarela: { texto: 'Pintou com pinceladas largas e decididas; neste ano, aprendeu a esperar a cor secar antes de sobrepor.' },
    portugues: { texto: 'Escreve com rapidez e firmeza; a letra cursiva ainda pede mais cuidado.' },
    matematica: { texto: 'Domina as tabuadas e criou sozinho um problema com o relógio para a turma.' },
    licao: { texto: 'Lembrou-se da lição de casa na maior parte das vezes.' },
    religiosidade: { texto: 'Gostou especialmente das histórias de construção e de trabalho.' },
    atitudes: { texto: 'Mostrou grande força de vontade e liderança, que vem aprendendo a usar a favor do grupo.' },
    conclusao: { texto: 'Bento termina o ano mais paciente e atento aos outros.' } } });
  [bAna, bBento].forEach(b => { b.importadas = D.anotacoes.filter(n => n.estrela && (n.alunos || []).includes(b.alunoId)).map(n => n.id).concat(D.marcacoes.filter(m => (m.alunos || []).includes(b.alunoId)).map(m => m.id)); });
  ['cecilia', 'davi', 'helena', 'joaquim', 'tomas', 'rafael'].forEach(a => { const b = add('boletins', { turmaId: 't26', alunoId: a, ano: 2026, secoes: {}, importadas: [], poemaTitulo: '', poemaTexto: '', estado: 'rascunho', criado: '2026-10-25T12:00:00.000Z' }); trazerAnotacoes(b); });

  /* pontos de atenção */
  IX.alunos.tomas.atencao = [{ id: uid(), tipo: 'visao-audicao', descricao: 'Usa óculos para longe; sentar perto da lousa.', desde: '2025-08-10', situacao: 'ativo', sigiloso: true }, { id: uid(), tipo: 'aprendizagem', descricao: 'Família orientada a buscar avaliação para a escrita (troca de b e d).', desde: '2026-07-03', situacao: 'ativo', sigiloso: true }];
  IX.alunos.joaquim.atencao = [{ id: uid(), tipo: 'emocional', descricao: 'Mudança na família em 2025; acompanhamento com psicóloga.', desde: '2025-09-01', situacao: 'ativo', sigiloso: true }];
  IX.alunos.ana.atencao = [{ id: uid(), tipo: 'alergia', descricao: 'Alergia a amendoim. Avisar em festas e oficinas de culinária.', desde: '2024-02-05', situacao: 'ativo', sigiloso: false }];
  IX.alunos.davi.atencao = [{ id: uid(), tipo: 'sono', descricao: 'Dormia muito tarde; família ajustou a rotina.', desde: '2025-04-01', situacao: 'resolvido', sigiloso: true }];
  /* currículo da escola (as habilidades da BNCC são sugeridas pela própria Tecelã) */
  const EP = (serie, componente, titulo, periodo, semanas, conteudos, objetivos, feita) => { const c = add('curriculo', { serie, componente, titulo, periodo, semanas, conteudos, objetivos, bncc: [], realizadas: feita ? [serie === 3 ? 't26' : 't25'] : [], ordem: D.curriculo.filter(x => x.serie === serie).length }); c.bncc = sugerirBncc(c, 4).map(h => h[0]); return c; };
  EP(3, 'ER', 'Narrativas da criação', 'fevereiro', '3', 'Narrativas da criação do mundo e dos primeiros seres humanos. Recontos orais, desenhos e escrita de frases no caderno de época.', 'Acolher a passagem do Rubicão com imagens de origem e de cuidado com a Terra.', true);
  const epCasa = EP(3, 'HI', 'Ofícios: a construção da casa', 'abril e maio', '4', 'Os ofícios de quem constrói: oleiro, carpinteiro, pedreiro. Os tipos de moradia e os materiais de cada lugar. Construção da casinha no pátio.', 'Reconhecer o trabalho humano que transforma a natureza em moradia.', true);
  const epPao = EP(3, 'CI', 'Agricultura: do grão ao pão', 'junho', '3', 'Preparo do solo, plantio do trigo, cuidado com as plantas, colheita, moagem e o pão. A água, o sol e os animais na vida da planta.', 'Viver o ciclo da planta e o trabalho do agricultor.', true);
  EP(3, 'MA', 'Medidas e dinheiro', 'agosto e setembro', '4', 'Medidas de comprimento com o corpo (palmo, pé, passo) e com a régua; massa e capacidade na cozinha; dinheiro, troco e a feira da turma.', 'Usar as medidas e o dinheiro em situações da vida prática.', true);
  EP(3, 'MA', 'O tempo: relógio e calendário', 'novembro', '3', 'Horas, minutos e o relógio de ponteiros; dias da semana, meses e o calendário do ano; duração de eventos.', 'Ler as horas e organizar o tempo vivido.', false);
  EP(3, 'LP', 'Letra cursiva e gramática da ação', 'março e outubro', '6', 'Letra cursiva; verbos como ação, substantivos como coisas e adjetivos como qualidades; frases e pequenos textos sobre os ofícios; leitura em voz alta.', 'Escrever com letra cursiva e reconhecer as classes de palavras de forma viva.', true);
  EP(3, 'musica', 'Flauta diatônica', 'ano todo', '', 'Passagem para a flauta diatônica; canções a duas vozes.', '', true);
  EP(3, 'trabalhos', 'Crochê: a bolsinha da flauta', 'segundo semestre', '', 'Correntinha, ponto baixo e a bolsinha da flauta.', '', true);
  EP(2, 'LP', 'Fábulas e lendas', 'ano todo', '', 'Fábulas de animais e lendas de pessoas virtuosas; letras minúsculas; leitura de pequenos textos.', '', true);
  EP(2, 'MA', 'Tabuadas e valor posicional', 'abril e setembro', '6', 'Tabuadas cantadas, unidades, dezenas e centenas, as quatro operações e o calendário.', '', true);
  EP(2, 'CI', 'O ciclo da água', 'maio', '3', 'A gota de água: chuva, rio, mar, nuvem. Os estados da água e seu caminho na natureza.', '', true);
  /* vivências */
  const v1 = add('vivencias', { id: 'viv1', turmaId: 't26', data: '2026-09-15', hora: '08:30', duracao: '3h', tipo: 'oficio', titulo: 'Visita à oficina do ferreiro', local: 'Ferraria Martelo Antigo (fictícia)', responsavel: 'Seu Antônio, ferreiro', epocaId: epCasa.id, descricao: 'A turma viu o fogo da forja, o ferro ficar vermelho e o ferreiro dar forma a uma ferradura. Cada criança pôde bater uma vez com o martelo, com a ajuda do ferreiro.', todos: true, participantes: [] });
  const v2 = add('vivencias', { id: 'viv2', turmaId: 't26', data: '2026-06-20', hora: '09:00', duracao: '4h', tipo: 'festa', titulo: 'Festa da colheita e oficina de pão', local: 'Pátio da escola', responsavel: 'Famílias da turma', epocaId: epPao.id, descricao: 'Colhemos o trigo plantado em março, debulhamos, moemos no moinho de pedra e assamos o pão no forno de barro.', todos: true, participantes: [] });
  add('vivencias', { id: 'viv3', turmaId: 't26', data: '2026-05-09', hora: '08:30', duracao: '4h', tipo: 'mutirao', titulo: 'Mutirão da casinha', local: 'Pátio da escola', responsavel: 'Famílias e professora', epocaId: epCasa.id, descricao: 'Famílias e crianças levantaram as paredes de pau a pique da casinha da turma.', todos: false, participantes: ['ana', 'bento', 'davi', 'helena', 'tomas'] });
  const VO = (viv, alunos, secao, criterio, texto) => add('anotacoes', { turmaId: 't26', data: viv.data, alunos, secao, criterio, texto, estrela: true, sigilo: false, origem: { tipo: 'vivencia', id: viv.id }, criado: viv.data + 'T18:00:00.000Z' });
  VO(v1, ['bento'], 'conteudo', 'querer', 'Na visita ao ferreiro, {nome} quis ser o primeiro a segurar o martelo e esperou a vez com paciência.');
  VO(v1, ['tomas'], 'conteudo', 'pensar', 'Na visita ao ferreiro, {nome} fez perguntas precisas sobre o calor do fogo e lembrou depois de cada etapa.');
  VO(v2, ['davi', 'rafael'], 'conteudo', 'querer', 'Na festa da colheita, {nome} moeu o trigo no moinho de pedra até o fim, sem desistir.');
  /* calendário */
  const EV = (turmaId, data, titulo, tipo, extra) => add('eventos', Object.assign({ turmaId, data, titulo, tipo, hora: '', duracao: '', obs: '' }, extra || {}));
  EV(null, '2026-11-02', 'Finados', 'feriado'); EV(null, '2026-11-15', 'Proclamação da República', 'feriado'); EV(null, '2026-11-20', 'Dia da Consciência Negra', 'feriado');
  EV(null, '2026-11-21', 'Bazar da Primavera', 'festa', { hora: '10:00', duracao: '6h' }); EV(null, '2026-12-05', 'Espiral do Advento EF', 'festa', { hora: '17:00', duracao: '1h30' }); EV(null, '2026-12-11', 'Encerramento do ano letivo', 'escola');
  EV('t26', '2026-11-04', 'Início da época “O tempo: relógio e calendário”', 'epoca'); EV('t26', '2026-11-11', 'Ensaio da peça de Natal', 'outro', { hora: '10:00', duracao: '1h', obs: 'Trazer as coroas de papel.' });
  EV('t26', '2026-11-18', 'Mostra das bolsinhas de crochê', 'outro', { hora: '12:00', duracao: '30min' }); EV('t26', '2026-12-03', 'Reunião de entrega dos boletins', 'reuniao', { hora: '19:00', duracao: '1h30', avisar: 2 });
  /* tarefas */
  add('tarefas', { titulo: 'Escrever os textos da turma no boletim', data: '2026-11-20', hora: '', avisar: 2, feita: false, obs: 'Faltam lição de casa e religiosidade.' });
  add('tarefas', { titulo: 'Ligar para a avó do Rafael', data: '2026-11-05', hora: '18:00', avisar: 1, feita: false, obs: 'Combinar a entrevista de meio de ano.' });
  add('tarefas', { titulo: 'Revisar os perfis da turma', data: '', repetir: 30, avisar: 0, feita: false, obs: 'Lembrete mensal.', criado: '2026-10-15T12:00:00.000Z' });
  add('tarefas', { titulo: 'Organizar a lista de materiais do mutirão', data: '2026-04-30', avisar: 1, feita: true, feitaEm: '2026-04-28', obs: 'Responsável: Rodrigo Lima · Encaminhamento da ata nº 01 de 12/03/2026', origem: { ata: 'ata1', i: 0 } });
  /* v1.2: observação do período (1º e 2º semestres), conselho de classe, evento que se repete */
  const ALS26 = ['ana', 'bento', 'cecilia', 'davi', 'helena', 'joaquim', 'tomas', 'rafael'];
  const FRACO = { ana: ['jogos'], bento: ['social', 'habitos'], cecilia: ['sentir', 'artes'], davi: ['querer', 'trabalho'], helena: ['mat'], joaquim: ['querer', 'social', 'postura'], tomas: ['sentir', 'social'], rafael: ['port'] };
  const FORTE = { ana: ['pensar', 'port'], bento: ['querer', 'jogos'], cecilia: ['artes', 'trabalho'], davi: ['habitos'], helena: ['sentir', 'artes'], joaquim: ['jogos'], tomas: ['pensar', 'mat'], rafael: ['mat', 'trabalho'] };
  const itensO = itensLista('itensObs');
  ['2026-S1', '2026-S2'].forEach((per, pi) => ALS26.forEach((a, ai) => {
    const marcas = {}, notas = {};
    itensO.forEach((it, ii) => {
      if (it.bloco === 'conclusao' || it.bloco === 'epocas' && pi === 0) return;
      const h = (ai * 31 + ii * 17 + pi * 7) % 10; if (h < 3) return; /* ~30% fica em branco: não observado */
      marcas[it.chave] = (FRACO[a] || []).includes(it.bloco) ? (h < 7 ? 'a' : 'd') : (FORTE[a] || []).includes(it.bloco) ? (h < 8 ? 'c' : 'd') : (h < 6 ? 'd' : 'c');
      if (pi === 1 && (FRACO[a] || []).includes(it.bloco) && marcas[it.chave] === 'a' && h === 3) marcas[it.chave] = 'd'; /* pequenas melhoras no 2º semestre */
    });
    if (a === 'tomas') notas['sentir-14'] = 'Ainda se fecha quando erra; aceita ajuda quando chamado em particular.';
    if (a === 'davi') notas['querer-1'] = 'Começa devagar, mas termina quando tem tempo.';
    add('observacoes', { id: 'obs:t26:' + a + ':' + per, turmaId: 't26', alunoId: a, periodo: per, marcas, notas });
  }));
  N('2026-10-28', ['tomas'], 'pausa', 'social', 'Tomás voltou a ficar sozinho na pausa nesta semana; levar ao conselho a ideia de um colega-padrinho.', false, false, 't26').conselho = true;
  N('2026-10-30', ['davi'], 'licao', 'querer', 'Davi deixou de entregar a lição três vezes no mês. Conversar com a família antes do conselho.', false, false, 't26').conselho = true;
  N('2026-10-30', ['helena'], 'matematica', 'pensar', 'Helena trava nos problemas com duas operações; com material concreto, resolve.', true, false, 't26').conselho = true;
  add('conselhos', { id: 'cons:t26:2026-S1', turmaId: 't26', periodo: '2026-S1', data: '2026-07-02', participantes: 'Paulo Henrique (euritmia), Sandra Ribeiro (trabalhos manuais), coordenação pedagógica', decisoes: 'Manter a roda de verso no início do dia e aumentar o tempo de desenho de forma no 2º semestre. Organizar com as famílias a lista de materiais da horta.', ataId: 'ataCons1', alunos: {
    tomas: { situacao: 'acao', fala: 'Muito capaz no pensar; no grupo, se recolhe. As especialistas notam o mesmo na euritmia.', proposta: 'Encontro com a família e a terapeuta até agosto', resp: 'Marina e coordenação', prazo: '2026-08-15' },
    davi: { situacao: 'acomp', fala: 'Ritmo lento e sono pesado; termina quando tem tempo.', proposta: 'Combinar com a família a rotina de sono', resp: 'Marina', prazo: '2026-08-30' },
    joaquim: { situacao: 'acomp', fala: 'Energia boa nos jogos, mas atrapalha a concentração dos colegas.', proposta: 'Dar a ele uma tarefa de ajudante nas transições', resp: 'Marina', prazo: '' },
    ana: { situacao: 'ok', fala: 'Caminha bem; mediadora no grupo.', proposta: '', resp: '', prazo: '' },
    cecilia: { situacao: 'acomp', fala: 'Sensível e delicada; precisa de tempo para se expor.', proposta: 'Oferecer pequenas falas na peça', resp: 'Marina', prazo: '2026-11-30' } } });
  add('atas', { id: 'ataCons1', turmaId: 't26', tipo: 'conselho', subtipo: 'Conselho de classe', numero: '02-A', livro: '3', carater: 'ordinária', data: '2026-07-02', inicio: '14:00', fim: '16:00', local: 'sala dos professores', assunto: 'Conselho de classe do 1º semestre de 2026', pauta: 'Situação de cada criança; propostas e encaminhamentos; decisões sobre a turma.', participantes: [{ nome: 'Marina Alves Correia (fictício)', categoria: 'Professor(a) de classe', presente: true }, { nome: 'Paulo Henrique (fictício)', categoria: 'Professor(a) especialista', presente: true }, { nome: 'Sandra Ribeiro (fictício)', categoria: 'Professor(a) especialista', presente: true }], secretario: 'Marina Alves Correia (fictício)', cabecalho: '', texto: 'Tomás (pede ação): muito capaz no pensar; no grupo, se recolhe. Proposta: encontro com a família e a terapeuta até agosto.\n\nDavi (acompanhar): ritmo lento e sono pesado. Proposta: combinar com a família a rotina de sono.', deliberacoes: 'Manter a roda de verso no início do dia e aumentar o tempo de desenho de forma no 2º semestre.', conclusao: '', encaminhamentos: [{ acao: 'Encontro com a família de Tomás e a terapeuta', resp: 'Marina e coordenação', prazo: '2026-08-15' }], formato: 'moderno', papel: 'A4', assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'rascunho' });
  add('tarefas', { titulo: 'Tomás: Encontro com a família e a terapeuta até agosto (Marina e coordenação)', data: '2026-08-15', feita: true, feitaEm: '2026-08-12', avisar: 2, origem: { conselho: 'cons:t26:2026-S1', aluno: 'tomas' } });
  EV('t26', '2026-08-06', 'Euritmia com o Paulo', 'outro', { hora: '10:20', duracao: '50min', repete: '7', repeteAte: '2026-12-10', obs: 'Toda quinta-feira.' });
  EV(null, '2026-12-09', 'Conselho de classe do 2º semestre', 'reuniao', { hora: '14:00', duracao: '2h', avisar: 7 });
  /* 1.5: início do ano, recessos e sábados letivos (para o planejamento), horário semanal, reforço */
  EV(null, '2026-02-02', 'Início das aulas', 'escola'); EV(null, '2026-02-16', 'Recesso de Carnaval', 'feriado', { dataFim: '2026-02-18' }); EV(null, '2026-04-03', 'Sexta-feira Santa', 'feriado'); EV(null, '2026-04-21', 'Tiradentes', 'feriado');
  EV(null, '2026-06-04', 'Corpus Christi', 'feriado'); EV(null, '2026-07-06', 'Recesso de julho', 'feriado', { dataFim: '2026-07-31' }); EV(null, '2026-09-07', 'Independência do Brasil', 'feriado'); EV(null, '2026-10-12', 'Recesso da primavera', 'feriado', { dataFim: '2026-10-16' });
  EV(null, '2026-03-14', 'Sábado letivo: festa da colheita na escola', 'escola'); EV(null, '2026-08-29', 'Sábado letivo: mutirão da escola', 'escola');
  t26.materias = [['Religiosidade', 'PM', 'Ana'], ['Inglês', 'PM', 'Carla'], ['Euritmia', 'PM', 'Paulo'], ['Educação Física', 'PM', 'Rui'], ['Música', 'PM', 'Lia'], ['Trabalhos Manuais', 'PM', 'Tereza'], ['Jardinagem', 'PM', 'João'], ['Alemão', 'PM', 'Greta'], ['Aquarela', 'PC', ''], ['Caderno de profissões', 'PC', '']].map(([nome, quem, prof]) => ({ nome, quem, prof }));
  const HOR = [['07:30', '09:30'], ['10:10', '10:55'], ['11:00', '11:45'], ['11:50', '12:35']], dia = (...ms) => ({ itens: ['Aula principal'].concat(ms).map((m, i) => ({ m, ini: HOR[i][0], fim: HOR[i][1] })) });
  t26.grade = { 1: dia('Religiosidade', 'Inglês', 'Euritmia'), 2: dia('Educação Física', 'Música', 'Trabalhos Manuais'), 3: dia('Inglês', 'Aquarela'), 4: dia('Jardinagem', 'Música', 'Caderno de profissões'), 5: dia('Alemão', 'Caderno de profissões', 'Trabalhos Manuais') };
  t26.gradeObs = 'Às quintas, Alemão em horário especial, das 8h45 às 9h30, dentro da aula principal.';
  /* 1.6: saúde e segurança, repertório e contatos com as famílias */
  Object.assign(IX.alunos.ana, { seg: { alergias: 'Amendoim (alergia grave: avisar em festas e passeios)', medicamentos: 'Antialérgico na mochila, com a receita', buscam: 'Mãe, pai ou a avó Lúcia' } });
  Object.assign(IX.alunos.tomas, { seg: { buscam: 'Mãe ou a tia Raquel' } });
  [['verso', 'Verso da manhã (classes 1 a 4)', 'Rudolf Steiner', true, null], ['cancao', 'Canção do bom dia', '', true, null], ['historia', 'A criação do mundo', 'Antigo Testamento', false, 'Narrativas da criação'], ['historia', 'Noé e a arca', 'Antigo Testamento', false, 'Narrativas da criação'], ['cancao', 'Canção do lavrador', 'tradicional', false, 'Agricultura'], ['roda', 'Roda do pão', 'tradicional', false, 'Agricultura'], ['poema', 'O ferreiro', 'poema da classe', false, 'Ofícios']].forEach(([tipo, titulo, autor, rotina, ep], i) => { const c = ep && D.curriculo.find(x => x.serie === 3 && x.titulo.startsWith(ep)); add('repertorio', { turmaId: 't26', tipo, titulo, autor, rotina, epocaId: c ? c.id : null, texto: '', usos: rotina ? ['2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29', '2026-10-30'] : i < 4 ? ['2026-02-' + String(10 + i * 3)] : [] }); });
  add('contatos', { turmaId: 't26', alunoId: 'davi', data: '2026-10-20', meio: 'conversa', quem: 'o pai', assunto: 'Divisão e lição de casa', texto: 'O pai contou que Davi desanima com as contas longas em casa.', combinados: 'Vamos começar o reforço em novembro; em casa, desafios curtos.', sigilo: false });
  add('contatos', { turmaId: 't26', alunoId: 'tomas', data: '2026-09-02', meio: 'telefone', quem: 'a mãe', assunto: 'Sono', texto: 'Tomás tem dormido tarde por causa da mudança de casa.', combinados: 'A família vai antecipar o ritual da noite.', sigilo: false });
  add('reforcos', { turmaId: 't26', alunos: ['davi'], componente: 'MA', topico: 'divisão com dois números na chave', obs: 'Usar material concreto; Davi responde bem a desafios curtos.', textoBilhete: 'Vamos retomar a divisão com material concreto e desafios curtos.', mostrarTopico: true, datas: ['2026-11-09', '2026-11-16', '2026-11-23'], hora: '13:30', saida: '15:00', situacao: 'previsto' });
  /* impressões digitais dos documentos finalizados */
  for (const s of ['atas', 'boletins']) for (const r of D[s]) if (r.estado === 'finalizado') r.hash = await sha256(conteudoParaHash(s, r));
  /* grava no banco do modelo */
  if (DB) { for (const s of DADOS) { await idbLimpar(s); for (const r of D[s]) await idbPor(s, r); } await gravarConfig('escola'); await gravarConfig('prefs'); }
}
