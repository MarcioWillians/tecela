/* ==========================================================================
   Tecelã — textos de ajuda: manual do usuário, créditos e licenças,
   privacidade e LGPD, sobre.
   ========================================================================== */
'use strict';
const MANUAL_HTML = `
<p>Este manual funciona sem internet. O botão <b>?</b> no alto de cada tela abre a parte correspondente. Use “Imprimir esta página” para ter uma cópia em papel ou em PDF.</p>
<h3>Sumário</h3>
<ol><li><a href="#m-inicio">Primeiros passos</a></li><li><a href="#m-menu">O menu, os atalhos e o Painel</a></li><li><a href="#m-turma">Escola, turma e crianças</a></li><li><a href="#m-anot">Anotações</a></li><li><a href="#m-frases">Frases prontas</a></li><li><a href="#m-obs">Observação do período</a></li><li><a href="#m-faltas">Faltas</a></li><li><a href="#m-atas">Atas</a></li><li><a href="#m-bol">Boletim Descritivo</a></li><li><a href="#m-poema">Poema do ano</a></li><li><a href="#m-conselho">Conselho de classe</a></li><li><a href="#m-perfis">Perfil do aluno</a></li><li><a href="#m-relat">Relatórios</a></li><li><a href="#m-viv">Vivências</a></li><li><a href="#m-agenda">Calendário</a></li><li><a href="#m-tarefas">Tarefas e lembretes</a></li><li><a href="#m-curric">Currículo e BNCC</a></li><li><a href="#m-biblio">Biblioteca Waldorf</a></li><li><a href="#m-planej">Planejamento</a></li><li><a href="#m-pei">PEI — Plano Educacional Individualizado</a></li><li><a href="#m-reforco">Reforço escolar</a></li><li><a href="#m-combinados">Combinados da turma</a></li><li><a href="#m-acomp">Acompanhamento: contatos, entrevista e estudo de criança</a></li><li><a href="#m-comunic">Comunicados às famílias</a></li><li><a href="#m-repert">Repertório da turma</a></li><li><a href="#m-ano">Ano letivo: dias, festas e materiais</a></li><li><a href="#m-cadastros">Cadastros</a></li><li><a href="#m-atencao">Pontos de atenção</a></li><li><a href="#m-importar">Importar boletins anteriores</a></li><li><a href="#m-timbrado">Papel timbrado, exportar e enviar</a></li><li><a href="#m-copia">Salvar o arquivo</a></li><li><a href="#m-partilha">Partilha pedagógica</a></li><li><a href="#m-virada">Virada do ano letivo</a></li><li><a href="#m-seguranca">Segurança e LGPD</a></li><li><a href="#m-faq">Perguntas frequentes</a></li></ol>

<h2 id="m-inicio">1. Primeiros passos</h2>
<p>Abra o arquivo <i>Tecela.html</i> com dois cliques. Ele funciona em qualquer navegador atual (Chrome, Edge, Firefox, Safari), sem internet. Mantenha o <i>Tecela.html</i> sempre no mesmo lugar: o navegador associa os dados ao local de onde ele é aberto.</p>
<p>A tela inicial oferece seis caminhos:</p>
<ul><li><b>Continuar:</b> volta ao trabalho que está neste aparelho. Mostra o nome do seu arquivo e quando ele foi salvo pela última vez.</li>
<li><b>Abrir um arquivo da Tecelã:</b> abre um arquivo <i>.tecela</i> (de um pendrive, de outro computador, de uma pasta na nuvem). A partir daí, “💾 Salvar” grava nesse mesmo arquivo.</li>
<li><b>Novo:</b> começa do zero. A Tecelã sugere ligar a senha, pergunta como você quer a Biblioteca (pronta ou em branco) e pede a escola e a turma.</li>
<li><b>Novo a partir de boletins anteriores (.docx):</b> começa lendo os boletins dos anos anteriores. Veja <a href="#m-importar">Importar boletins anteriores</a>.</li>
<li><b>Modelo de demonstração:</b> a Tecelã já preenchida, com a “Escola Waldorf Tecelã”, uma professora e crianças fictícias. Fica num espaço separado: nada do que você fizer nele mexe nos seus dados. A faixa amarela no alto permite restaurar, apagar ou sair do modelo.</li>
<li><b>Computador de terceiros:</b> abre um arquivo .tecela sem gravar nada no aparelho (por exemplo, no computador da escola). Ao terminar, use “💾 Salvar” para levar as alterações no arquivo.</li></ul>
<p>Na tela inicial aparecem também a versão da Tecelã e o aviso de autoria (veja <a href="#m-seguranca">Segurança e LGPD</a> e os Créditos).</p>
<p><b>Senha:</b> ligue-a (é o recomendado para dados de crianças) e anote ou imprima a <b>chave de recuperação</b>. Ela é a única forma de abrir os dados se você esquecer a senha.</p>
<p><b>Um bom começo:</b> 1) abra o modelo de demonstração e passeie pelas telas; 2) saia do modelo e crie o seu arquivo (Novo); 3) cadastre as crianças; 4) use o botão <b>✎ Anotar</b> no dia a dia; 5) no fim de cada período, preencha a <b>Observação do período</b>; 6) no fim do ano, monte os boletins.</p>

<h2 id="m-menu">2. O menu, os atalhos e o Painel</h2>
<p>O menu tem cinco grupos:</p>
<ul><li><b>Dia a dia:</b> Painel, Anotações, Observação do período e Faltas.</li>
<li><b>Documentos:</b> Boletins, Atas, Conselho de classe, Perfil do aluno, PEI, Acompanhamento e Relatórios.</li>
<li><b>Planejar:</b> Planejamento, Repertório, Currículo e BNCC, Calendário e Tarefas.</li>
<li><b>A turma:</b> Turma e alunos (com o horário semanal), Vivências, Reforço, Comunicados e Combinados.</li>
<li><b>Ajustar:</b> Biblioteca, Cadastros, Papel timbrado, Ajustes e arquivo, Ajuda.</li></ul>
<p>Toque no nome de um grupo para recolhê-lo ou abri-lo. No fim do menu, <b>Recentes</b> mostra as últimas telas usadas. O menu fica na mesma posição quando você troca de tela.</p>
<p>No celular, as telas mais usadas ficam numa barra embaixo (Painel, Anotações, Observação, Boletins); o botão <b>Mais</b> mostra todas as outras.</p>
<p>No alto de todas as telas ficam o seletor da turma, o campo <b>Buscar…</b>, o <b>?</b> (ajuda daquela tela), <b>💾 Salvar</b> e <b>Sair</b>. Logo abaixo, uma linha discreta mostra se está tudo salvo neste aparelho e quando o arquivo foi salvo pela última vez; toque nela para entender a diferença (veja <a href="#m-copia">Salvar o arquivo</a>).</p>
<h3>Atalhos que poupam trabalho</h3>
<ul><li><b>✎ Anotar</b>, o botão vermelho no canto da tela: registra uma anotação sem sair de onde você está. Veja <a href="#m-anot">Anotações</a>.</li>
<li><b>Buscar…:</b> digite uma palavra e tecle Enter. A Tecelã procura em crianças, anotações, atas, boletins, vivências, eventos, tarefas, conselhos, reforços, épocas do currículo, planejamentos, planos de época, combinados, PEIs e na Biblioteca, em todas as turmas, e também em contatos com as famílias e no repertório. Toque num resultado para abri-lo.</li>
<li><b>Teclado:</b> <b>Ctrl+S</b> (ou ⌘S) salva o arquivo; <b>Ctrl+K</b> vai para a busca; <b>Alt+N</b> abre a anotação rápida.</li>
<li><b>Desfazer:</b> depois de lançar ou apagar uma anotação, ou de apagar um evento ou uma tarefa, aparece embaixo, por alguns segundos, o botão “Desfazer”.</li>
<li><b>Sugestões:</b> a Tecelã sugere a seção e o critério das anotações, rascunhos para o boletim, níveis do perfil e a ata do conselho. Tudo pode ser mudado: a decisão é sempre sua.</li></ul>
<h3 id="m-painel">O Painel</h3>
<p>Mostra a turma, o seu arquivo (e se há alterações não salvas no arquivo), os botões de lançamento rápido (Anotar, Observar, Faltas e <b>Roteiro para substituto</b>), a <b>chamada de hoje</b> (nos dias letivos: toque no nome de quem faltou e a falta entra sozinha no total do período, em Faltas e no boletim; toque de novo para desfazer), os <b>próximos dias</b> (eventos, reuniões, vivências, tarefas e aniversários das próximas duas semanas) e as <b>pendências</b>: crianças com poucas anotações no último mês, observação do período sem marcas, faltas de períodos já encerrados sem lançamento, crianças com mais de 20% de faltas, anotações marcadas para o conselho, atas em rascunho, boletins incompletos e perfis sem revisão há mais de um semestre. Cada pendência é um link para a tela onde resolvê-la. O Painel também avisa quem está chegando aos 9 anos (o Rubicão) ou aos 12.</p>

<h2 id="m-turma">3. Escola, turma e crianças</h2>
<p>Em <b>Turma e alunos</b> há cinco abas: Alunos, Escola e turmas, Horário semanal, Virada do ano e Arquivo.</p>
<ul><li><b>Alunos:</b> “+ Novo aluno” abre o cadastro. O <b>nome de chamada</b> e o <b>gênero</b> são usados nos textos do boletim ({nome}, {o/a}…). A idade e o setênio são calculados sozinhos. No cadastro ficam os responsáveis, <b>Saúde e segurança</b> (alergias e restrições, medicamentos e cuidados, plano de saúde, contato de emergência e quem pode buscar a criança; ao contrário dos pontos de atenção, estas informações saem impressas na ficha de emergência dos passeios e no roteiro do substituto), as necessidades educacionais especiais, o acompanhamento externo, os <a href="#m-atencao">pontos de atenção</a>, as faltas do ano e os <b>poemas do ano</b> de todos os anos.</li>
<li>Na mesma aba ficam os botões para cadastrar várias crianças de uma vez: “Baixar modelo de planilha” (preencha no Excel, LibreOffice ou Google Planilhas, salve como CSV) e “Importar planilha (CSV)”, com prévia antes de gravar; e “Importar boletins anteriores (.docx)” (veja <a href="#m-importar">Importar boletins anteriores</a>).</li>
<li><b>Imprimir ou exportar a lista:</b> o nome completo entra sempre; escolha as outras colunas: nome de chamada, data de nascimento, idade, gênero, responsável, telefone e e-mail do responsável, necessidades educacionais especiais, acompanhamento externo, pontos de atenção e faltas. Com muitas colunas, a folha sai deitada. Os dados sigilosos só entram se você marcar. A Tecelã lembra as colunas da última vez.</li>
<li><b>Escola e turmas:</b> nome da escola, série, letra, ano e nome de quem dá aula, com a escolha entre <b>professora</b> e <b>professor</b>, usada nos documentos (“Professora:” ou “Professor:”; o marcador {a professora} vira “a professora” ou “o professor”). O seletor no alto da tela troca a turma em uso. Na lista de turmas, <b>Arquivar</b> tira a turma do seletor sem apagar nada (Desarquivar a traz de volta) e <b>✕</b> exclui a turma: antes, a Tecelã mostra tudo o que vai junto (matrículas, boletins, atas, conselhos, observações, planos, reforços, vivências) e oferece salvar o arquivo, porque não há como desfazer. Crianças que estão em outras turmas continuam cadastradas.</li>
<li><b>Horário semanal:</b> veja <a href="#m-grade">Horário semanal</a>.</li>
<li><b>Virada do ano:</b> veja <a href="#m-virada">Virada do ano letivo</a>.</li>
<li><b>Arquivo:</b> egressos e transferidos. Os registros de quem saiu ficam guardados pelo prazo definido em Ajustes (5 anos, se você não mudar); depois disso a Tecelã lembra você de avaliar a exclusão, mas nunca apaga sozinha.</li></ul>

<h2 id="m-anot">4. Anotações</h2>
<p>A anotação é o registro rápido do que você observou num dia. É o “fio” principal da Tecelã: dela saem o boletim, o perfil, o conselho e os relatórios.</p>
<h3>Como lançar</h3>
<ol><li>Toque em <b>✎ Anotar</b> (de qualquer tela) ou abra a tela <b>Anotações</b>.</li>
<li>Marque uma ou várias crianças, ou “Toda a turma”.</li>
<li>Escreva o que você viu. Se quiser, escolha uma <a href="#m-frases">frase pronta</a> para começar.</li>
<li>Confira a <b>seção do boletim</b> e o <b>critério do perfil</b>. Enquanto você escreve, a Tecelã os sugere pelas palavras do texto e mostra a sugestão com um contorno amarelo (por exemplo, “tabuada” sugere Matemática; “brigou com um colega no recreio” sugere Pausa e o critério Social). Se você escolher outra opção, a sugestão para de mexer naquele campo.</li>
<li>Marque, se for o caso:
<ul><li><span class="estrela">★</span> <b>Usar no boletim:</b> a anotação vai para o texto individual da seção escolhida quando o boletim for montado.</li>
<li><b>⚖ Levar ao conselho:</b> a anotação entra no relatório preparatório do <a href="#m-conselho">conselho de classe</a>.</li>
<li><b>Sigilosa:</b> nunca é impressa nem levada ao boletim. Ao marcar “Sigilosa”, “Usar no boletim” é desligado.</li></ul></li>
<li>Toque em <b>Lançar</b>. Se errou, use “Desfazer” no aviso que aparece embaixo.</li></ol>
<p>Você pode usar marcadores no texto: <code>{nome}</code> vira o nome de chamada; <code>{ele/ela}</code>, <code>{o/a}</code>, <code>{dele/dela}</code> se ajustam ao gênero. Assim uma anotação feita para várias crianças fica certa no boletim de cada uma.</p>
<h3>A lista de lançamentos</h3>
<p>Na tela Anotações, filtre por criança, seção, critério, palavra ou “só as do conselho”. O lápis edita; a lixeira apaga (com “Desfazer”). “Exportar” gera a lista em PDF, Word ou planilha (as sigilosas só entram se você marcar). As anotações com critério aparecem também ao lado do bloco correspondente no perfil da criança.</p>

<h2 id="m-frases">5. Frases prontas</h2>
<p>São frases que você escreve muitas vezes, guardadas para não precisar digitá-las de novo. Exemplos que já vêm cadastrados: “{nome} participou com alegria e atenção.”, “{nome} terminou o trabalho com capricho.”, “{nome} precisou de ajuda para começar a tarefa.”</p>
<h3>Como usar</h3>
<ol><li>Abra o <b>✎ Anotar</b> (ou a tela Anotações) e marque as crianças.</li>
<li>No campo <b>Frases prontas</b>, logo abaixo do texto, escolha uma frase.</li>
<li>A frase é acrescentada ao fim do texto da anotação. Complete ou ajuste o que quiser (por exemplo: “{nome} terminou o trabalho com capricho <i>e ajudou a arrumar a sala</i>.”).</li>
<li>Escolha outra frase, se quiser juntar mais de uma, e toque em <b>Lançar</b>.</li></ol>
<p>No boletim e nos relatórios, <code>{nome}</code> vira o nome de chamada de cada criança e <code>{o/a}</code> se ajusta ao gênero (“cansado” ou “cansada”).</p>
<h3>Como criar, mudar ou apagar frases</h3>
<p>Em <b>Cadastros → Frases prontas (anotações)</b> (há também um link no próprio campo de frases): “+ Novo item” cria uma frase; o texto pode ser mudado direto na tabela; as setas mudam a ordem em que aparecem; a lixeira apaga.</p>

<h2 id="m-obs">6. Observação do período</h2>
<p>É um roteiro de observação sistemática de cada criança, feito a partir do roteiro da escola, em 13 blocos: capacidades do pensar, movimentos do sentir, atitudes do querer, trabalho e estudo, postura individual, hábitos gerais, atitudes sociais, matemática, português, artes (música e trabalhos manuais), jogos, rendimento das épocas e conclusão do ano. Preencha uma vez por período (semestre, trimestre ou bimestre, conforme Ajustes).</p>
<h3>Os níveis</h3>
<p>Para cada item, um toque marca: <span class="dot c"></span> <b>consolidado</b>, <span class="dot d"></span> <b>em desenvolvimento</b> ou <span class="dot a"></span> <b>pede atenção</b>. Tocar de novo no mesmo nível desmarca, e o item volta a ser <b>não observado</b>. Marque só o que se destaca: o que fica em branco não entra em nenhum relatório e não aparece como problema.</p>
<h3>Duas formas de preencher</h3>
<ul><li><b>Uma criança:</b> escolha a criança (ou passe de uma para outra com ‹ e ›) e marque os itens, bloco por bloco. O lápis ✎ abre uma nota curta para o item. “Copiar do período anterior” traz as marcas do período passado, para você só mudar o que mudou. “Limpar” apaga as marcas (com “Desfazer”).</li>
<li><b>A turma toda:</b> uma grade com os itens nas linhas e as crianças nas colunas. Cada toque numa célula passa ao nível seguinte (em branco → consolidado → em desenvolvimento → pede atenção → em branco). Tocar no nome do item aplica o mesmo nível a todas as crianças (ou só às que ainda não têm marca).</li></ul>
<h3>Para onde vão as marcas</h3>
<ul><li><b>Boletim:</b> cada item está ligado a uma seção do boletim (pelo bloco ou pelo próprio item). Nas seções ligadas, o editor do boletim mostra o botão <b>◎ Rascunho da observação</b>. Veja <a href="#m-bol">Boletim</a>.</li>
<li><b>Perfil do aluno:</b> os blocos do pensar, do sentir e do querer geram uma sugestão de nível (fortalecido, equilibrado, pede cuidado).</li>
<li><b>Conselho de classe e relatórios:</b> mostram o que pede atenção em cada criança e na turma.</li></ul>
<p>Os blocos e itens podem ser mudados em <b>Cadastros → Observação: blocos</b> e <b>Observação: itens</b>: o nome, o critério do perfil, a seção do boletim, a ordem, e novos itens.</p>

<h2 id="m-faltas">7. Faltas</h2>
<p>Uma grade com todas as crianças nas linhas e os períodos nas colunas. Digite o total de faltas de cada período; Enter leva à próxima célula. Na primeira linha, digite os <b>dias letivos</b> de cada período: com eles a Tecelã calcula o percentual de faltas. Acima de 15% o percentual fica amarelo; acima de 25% (o limite da LDB), vermelho. Os nomes dos períodos das faltas se ajustam em Ajustes. O relatório completo está em Relatórios → Frequência.</p>

<h2 id="m-atas">8. Atas</h2>
<ol><li>Toque em <b>+ Nova ata</b> e escolha o tipo: reunião com as famílias, do colegiado, geral ou conselho de classe (e o subtipo, quando houver). Com “Aproveitar a última ata do mesmo tipo” marcado, os participantes, o local, o horário e a pauta vêm da última reunião desse tipo.</li>
<li>Preencha a identificação: número, livro, caráter (ordinária, extraordinária…), data, horários, local, assunto e pauta.</li>
<li>Inclua os participantes. “+ Familiares da turma” traz os responsáveis cadastrados. Marque presentes e ausências justificadas.</li>
<li>Escreva o texto. A abertura pode ficar em branco: a Tecelã escreve sozinha (“Aos doze dias do mês de março…”). Os nomes dos campos não aparecem no documento, e campos vazios são ignorados.</li>
<li>Registre os encaminhamentos (ação, responsável e prazo). “Encaminhamentos → Tarefas” cria as tarefas correspondentes.</li>
<li>Escolha o formato (moderno, em parágrafos, ou tradicional, em texto corrido) e as linhas de assinatura.</li></ol>
<p><b>Trechos para as crianças:</b> selecione uma frase ou um parágrafo do texto e toque em “Marcar trecho”. Escolha as crianças, a seção do boletim e o critério do perfil. O trecho vira uma anotação da criança, ligada à ata, e vai para o boletim se a estrela estiver marcada. Na prévia ele aparece destacado; no documento impresso, não há marca.</p>
<p><b>Nova ata a partir desta:</b> cria uma ata com o mesmo tipo, participantes, local e pauta, com o texto em branco.</p>
<p><b>Salvar, finalizar e corrigir:</b> “Salvar” guarda e oferece o envio por e-mail. “Finalizar” trava a ata e grava uma impressão digital que comprova que o original não mudou. Para corrigir uma ata finalizada, use <b>Em tempo</b> (uma nota acrescentada ao final) ou <b>Nova versão</b> (uma cópia editável ligada à original). A original fica sempre intacta.</p>

<h2 id="m-bol">9. Boletim Descritivo</h2>
<p>Em <b>Boletins</b> há quatro abas: Alunos e conferência, Textos da turma, Poema do ano e Seções do ano.</p>
<ol><li><b>Seções do ano:</b> ligue, desligue, renomeie e reordene as seções da série. Cada série tem as suas.</li>
<li><b>Textos da turma:</b> a citação, as assinaturas e, para cada seção, o texto que vale para toda a turma (ele entra no boletim de todas as crianças, antes do texto individual). O botão <b>✦ Rascunho da introdução</b> monta um começo com o número de crianças, as épocas e as vivências do ano; os trechos entre colchetes são para você completar.</li>
<li><b>Boletim de cada criança:</b> na aba “Alunos e conferência”, toque no nome. Cada seção mostra, em cinza, o texto da turma e, abaixo, o campo do texto individual.</li></ol>
<h3>De onde vem o texto individual</h3>
<p>São duas fontes diferentes, com botões diferentes:</p>
<ul><li><b>Trazer novas anotações:</b> copia para cada seção as <b>anotações com estrela</b> (e os trechos marcados nas atas) daquela seção. Elas já vêm na primeira vez que o boletim é aberto; o botão traz as que foram lançadas depois. O lápis ✎ ao lado do título da seção mostra todas as anotações daquela seção.</li>
<li><b>◎ Rascunho da observação:</b> acrescenta ao fim do texto um parágrafo montado com as marcas da <a href="#m-obs">Observação do período</a> nos itens ligados àquela seção (por exemplo: “Ana Clara lê bem oralmente e reconta histórias com propriedade. Está em desenvolvimento: escreve com capricho e em letra legível.”). O botão só aparece nas seções que têm itens do roteiro ligados a elas; se a criança ainda não tiver marcas nesses itens, a Tecelã explica o que falta. “◎ Rascunho nas seções vazias” faz isso de uma vez, só onde ainda não há texto; na aba “Alunos e conferência”, o mesmo botão vale para a turma toda.</li></ul>
<p>Os dois são pontos de partida: reescreva com o seu olhar.</p>
<p><b>Conferência:</b> a grade mostra, para cada criança e cada seção, se há texto individual (●), só o texto da turma (○) ou nada (·), e se falta o poema.</p>
<p><b>Conferir os textos</b> aponta frases iguais em três ou mais boletins, seções muito curtas ou muito longas em comparação com as da turma e palavras que podem estar no gênero errado (por exemplo, “ele” no boletim de uma menina). É só um apoio: o olhar final é seu.</p>
<p><b>Finalizar</b> trava o boletim, como nas atas. <b>✓ Finalizar os boletins prontos</b> finaliza de uma vez todos os boletins completos: antes, a Tecelã mostra quais serão finalizados e quais ficam de fora por estarem incompletos (seção vazia ou sem poema). “Exportar todos num só documento” gera um único PDF ou Word da turma; “Um arquivo por criança (.zip)” gera um boletim por criança, em Word ou em página para imprimir, prontos para cada família. Pontos de atenção e anotações sigilosas nunca entram no boletim.</p>

<h2 id="m-poema">10. Poema do ano</h2>
<p>Cada criança recebe um poema por ano escolar, que fecha o boletim. Escreva-o no próprio boletim da criança ou, para a turma toda de uma vez, na aba <b>Boletins → Poema do ano</b>: ali cada criança tem o título e o poema, e aparece quem ainda está sem poema. Separe as estrofes com uma linha em branco. Os poemas de todos os anos ficam no cadastro da criança (Turma e alunos → Alunos).</p>

<h2 id="m-conselho">11. Conselho de classe</h2>
<p>Escolha o período no alto (os mesmos da observação) e siga as três abas:</p>
<ol><li><b>Pré-conselho:</b> o relatório preparatório. Para cada criança, a Tecelã mostra os <b>sinais</b> já registrados: faltas, itens que pedem atenção na observação, perfil que pede cuidado, pontos de atenção, necessidades especiais e acompanhamento, poucas anotações, anotações marcadas com ⚖ e propostas do conselho anterior. As crianças com mais sinais aparecem primeiro, para que o tempo do conselho vá para quem mais precisa. “Ver” mostra tudo sobre a criança. Ao exportar, pontos de atenção e anotações sigilosas só entram se você marcar (o conselho é reservado: não envie esse relatório por e-mail).</li>
<li><b>Conselho:</b> durante a reunião, para cada criança, a situação (caminha bem, acompanhar, pede ação), o que o conselho viu e a proposta, com responsável e prazo; no fim, as decisões sobre a turma. Tudo é salvo enquanto você escreve.</li>
<li><b>Pós-conselho:</b> “Propostas → Tarefas” cria as tarefas com prazo e aviso; “Criar a ata do conselho” monta a ata (tipo Conselho de classe) com o registro, para você revisar e finalizar; “Marcar como tratadas” encerra as anotações levadas ao conselho. Aqui aparecem também os encaminhamentos de todas as atas e a situação de cada um.</li></ol>

<h2 id="m-perfis">12. Perfil do aluno</h2>
<p>O perfil segue sete blocos: constituição e corpo, temperamento, trimembração anímica (pensar, sentir e querer), momento biográfico, aprendizagem e expressão, dimensão social e moral, instrumentos e registros. Ao lado de cada bloco aparecem as anotações daquele critério. O ícone 📖 abre o verbete da Biblioteca sobre o assunto.</p>
<p>No bloco da trimembração, quando há observação do período, aparece uma <b>sugestão</b> de nível para o pensar, o sentir e o querer. “Usar nos campos vazios” só preenche o que está em branco.</p>
<p>Use <b>Nova revisão</b> para registrar um novo momento: a revisão anterior fica no histórico, com data, e não pode mais ser editada. O perfil da turma e a evolução da turma ficam em <a href="#m-relat">Relatórios</a>.</p>

<h2 id="m-relat">13. Relatórios</h2>
<p>A Tecelã compara cada criança só com ela mesma, e a turma só com ela mesma. Toque num relatório para vê-lo; “Exportar ou enviar” gera PDF, Word ou e-mail (e, em alguns, planilha CSV).</p>
<ul><li><b>Ficha da criança:</b> escolha a criança e a finalidade: <i>reunião com a família</i> (o que foi registrado desde a última reunião), <i>estudo de criança</i> (cadastro, perfil, pontos de atenção e anotações, para o colegiado), <i>conselho de classe</i> (sinais, observação por bloco e registro do conselho) ou <i>evolução ao longo dos anos</i>.</li>
<li><b>Observação do período:</b> escolha o período. O resumo mostra a turma por bloco, os itens que pedem atenção em várias crianças, uma tabela com quantos itens cada criança tem em cada nível e o que pede atenção em cada uma. Em “Detalhar”, escolha uma criança para ver tudo o que foi marcado para ela, bloco por bloco.</li>
<li><b>Conselho de classe:</b> abre a tela do conselho.</li>
<li><b>Perfil da turma:</b> o retrato do grupo no ano (temperamentos, pensar, sentir e querer, papéis, faltas, registros), com um campo para a sua análise.</li>
<li><b>Evolução da turma:</b> a turma comparada com ela mesma, ano a ano (aparece depois da primeira virada do ano ou da importação de boletins anteriores).</li>
<li><b>Equilíbrio do olhar</b> (quem recebeu menos anotações), <b>disposição dos lugares por temperamento</b>, <b>frequência</b>, <b>o ano da turma</b> e <b>currículo e BNCC</b>.</li>
<li><b>Aniversariantes do ano:</b> por mês, com o dia, o dia da semana daquele ano, o nome e a idade que a criança completa. Quando o aniversário cai no fim de semana ou num dia sem aula, aparece uma sugestão de data para comemorar. Escolha entre o nome de chamada e o nome completo.</li>
<li><b>Poemas:</b> um poema de uma criança num ano, todos os poemas de uma criança (de todos os anos) ou os poemas de um ano de toda a turma, sempre um por folha, com ou sem papel timbrado. Os poemas vêm dos boletins.</li>
<li><b>Pauta da reunião:</b> escolha a ata (em rascunho) e imprima ou envie a pauta antes da reunião: data, horário, local, assunto, itens numerados, convidados e espaço para anotações. O mesmo botão, “Pauta para imprimir”, fica na própria ata.</li>
<li><b>Reforço escolar</b>, <b>Planejamento anual</b>, <b>Planos de época</b>, <b>Combinados</b> e <b>PEI</b>: veja as partes de cada um neste manual.</li></ul>

<h2 id="m-viv">14. Vivências</h2>
<p>Registre as vivências da turma: visitas a ofícios (ferreiro, vidreiro, padeiro…), oficinas, saídas, festas do ano, teatro e mutirões. Informe data, horário, duração, tipo, local, quem conduziu, a época relacionada e o que a turma viveu; marque se toda a turma participou ou só algumas crianças. “+ Observação para aluno(s)” cria anotações ligadas à vivência, que entram no perfil e, com a estrela, no boletim. As vivências aparecem no calendário, no relatório “O ano da turma” e no rascunho da introdução do boletim.</p>
<p>A vivência tem duas partes. <b>Antes da vivência: informações para as famílias</b> vai para as famílias com antecedência, para se prepararem e tomarem as providências. <b>Depois da vivência: registro</b> guarda o que a turma viveu e quem participou; o <b>Relatório da vivência</b> sai só com esse registro, sem os itens da preparação.</p>
<p><b>Informações para as famílias:</b> abra a parte “Antes da vivência” e preencha o que fizer sentido: o que vamos viver (apresentação), programação (horário e atividade), endereço, contato no local, concentração, saída e chegada, turmas e datas, adultos que acompanham, orçamento, forma de pagamento, tempo de percurso, documentação do local (AVCB, vistoria), informações adicionais (estrada de terra, sinal de celular, retirada das peças), vestimenta, alimentação, cardápio, compras opcionais e o prazo para avisar sobre restrição alimentar. Os campos mais usados ficam à vista; os outros, em “Mais campos”. O botão <b>Informações para as famílias (antes)</b>, no alto, gera o documento para imprimir ou enviar.</p>
<p><b>Autorização:</b> uma folha por criança (duas por página), com o resumo da vivência para a família e, abaixo da linha de corte, a autorização com o nome da criança, a data e o local, para assinar e devolver.</p>
<p><b>Ficha de emergência:</b> uma tabela com cada criança participante, os responsáveis e telefones, o contato de emergência, alergias e restrições, medicamentos e cuidados, plano de saúde e quem pode buscar, tirados de “Saúde e segurança” no cadastro de cada criança. Leve na vivência e devolva à professora depois.</p>
<p><b>Restrições alimentares das crianças:</b> o botão com esse nome lista as crianças participantes que têm “Alergia ou restrição alimentar” nos pontos de atenção, para avisar o local com antecedência. São dados de saúde: envie só a quem precisa.</p>

<h2 id="m-agenda">15. Calendário</h2>
<ul><li><b>Eventos da turma e da escola:</b> data (o dia da semana aparece sozinho), período de vários dias, horário, duração, nome, tipo (com cor), aviso e observação.</li>
<li><b>Repetir:</b> um evento pode se repetir toda semana, a cada 15 dias ou todo mês, até uma data (por exemplo, a aula de euritmia de toda quinta-feira). No calendário ele aparece com ↻. Ao abrir uma das datas, “Salvar” muda todas; <b>Apagar só esta data</b> tira apenas aquele dia (um feriado, por exemplo); <b>Mudar só esta data</b> cria um evento avulso naquele dia, para trocar o horário ou o local, sem mexer nos outros. As datas apagadas aparecem no diálogo e podem voltar com “Trazer de volta”. A exportação .ics leva as datas apagadas.</li>
<li><b>Vários de uma vez:</b> escreva um evento por linha, como “12/03 - Festa da Páscoa”, “21/04 a 25/04 - Recesso” ou “05/06 14h - Reunião com as famílias”. A Tecelã mostra a lista para você conferir antes de incluir.</li>
<li><b>Entram sozinhos:</b> reuniões (atas), vivências, tarefas com data, encaminhamentos com prazo, aniversários das crianças e os encontros de reforço ainda não marcados. As <b>festas do ano</b>, com as tarefas de preparação, entram pelo Planejamento → Ano letivo (veja <a href="#m-ano">Ano letivo</a>).</li>
<li><b>Ver:</b> o mês em grade, a lista do mês ou o ano inteiro em lista. Um toque no número do dia cria um evento naquele dia.</li>
<li><b>Imprimir ou exportar:</b> a <b>grade do mês</b>, como na tela (folha deitada, semanas em linhas, dias em colunas, eventos em cada dia), ou a lista do mês ou do ano, em PDF, Word ou planilha.</li>
<li><b>Exportar (.ics):</b> gera um arquivo que abre no Google Agenda, no Outlook e no calendário do celular, com os avisos. Assim os lembretes chegam mesmo com a Tecelã fechada.</li></ul>

<h2 id="m-tarefas">16. Tarefas e lembretes</h2>
<p>Cada tarefa pode ter data e horário, repetir (todo dia, toda semana, a cada 15 dias, todo mês ou a cada tantos dias) e pedir aviso no dia ou alguns dias antes. Ao marcar uma tarefa que se repete, a Tecelã agenda a próxima vez. Os avisos aparecem dentro da Tecelã ao abrir e a cada 5 minutos, e no painel “Próximos dias”; “Permitir avisos do sistema” pede ao navegador para mostrar também os avisos do sistema. Tarefas também nascem dos encaminhamentos das atas e das propostas do conselho de classe. “Imprimir ou exportar a lista” gera as pendentes (ou todas) em PDF, Word ou planilha.</p>

<h2 id="m-curric">17. Currículo e BNCC</h2>
<ul><li><b>Currículo da escola:</b> cadastre as épocas de cada série (componente, título, período, semanas, conteúdos e objetivos) ou cole uma lista pronta. Marque as épocas já realizadas com a turma.</li>
<li><b>Épocas de referência:</b> se um ano ainda não tem épocas, “Carregar as épocas de referência” traz uma proposta de épocas para aquele ano (do 1º ao 9º), com componente, semanas, período, conteúdos e objetivos. Ajuste à sua escola.</li>
<li><b>Conteúdo programático:</b> por ano e componente, com o número de aulas no ano, inclusive das aulas de especialistas. A Tecelã traz como referência o conteúdo programático de uma escola Waldorf brasileira. “Usar e editar este conteúdo” copia a referência para você ajustar; “Voltar à referência” desfaz. Ele entra no Planejamento anual.</li>
<li><b>Ligar à BNCC:</b> em cada época, “Sugerir habilidades” procura, pelas palavras dos conteúdos, as habilidades mais próximas; “Procurar na BNCC” busca por palavra ou código.</li>
<li><b>BNCC (consulta):</b> as 1.304 habilidades do Ensino Fundamental, com busca por palavra, código, componente e ano.</li>
<li><b>Computação (complemento de 2022):</b> as 83 habilidades de Computação do 1º ao 9º ano, com o texto oficial, o eixo (pensamento computacional, mundo digital, cultura digital), o objeto de conhecimento e, em “Explicação e exemplos”, como trabalhar cada uma. Há também 21 habilidades “por etapa” (EF15, do 1º ao 5º ano, e EF69, do 6º ao 9º), uma forma alternativa de organizar as mesmas aprendizagens: elas aparecem na consulta e na Biblioteca, mas não entram nas sugestões nem na comparação, para não contar duas vezes. O componente “Computação” já vem nos Cadastros. Se a escola não trabalha com a Computação, desligue em Ajustes: as ligações já feitas continuam guardadas. O texto de referência recomenda começar de forma desplugada, sem computador, o que combina com a pedagogia Waldorf.</li>
<li><b>Comparação:</b> para cada série e componente, as habilidades contempladas no mesmo ano, em outro ano ou não contempladas. Na pedagogia Waldorf, conteúdo trabalhado em outra idade é escolha pedagógica, não falta.</li></ul>

<h2 id="m-biblio">18. Biblioteca Waldorf</h2>
<p>Reúne verbetes sobre fundamentos, desenvolvimento, temperamentos, trimembração, sentidos, currículo do 1º ao 9º ano, prática escolar, princípios da Federação e <b>Para a estruturação do ensino</b>, sempre com a fonte, e a <b>BNCC para consulta</b>.</p>
<p><b>Para a estruturação do ensino:</b> resumos, em paráfrase, do manual “Para a estruturação do ensino do 1º ao 8º ano nas Escolas Waldorf” (Seção Pedagógica do Goetheanum, edição brasileira da Federação das Escolas Waldorf no Brasil): o plano de ensino, o professor de classe, a aula principal e as épocas, o 1º ao 3º ano, o 4º e o 5º, o 6º ao 8º e as matérias complementares. O texto da obra não é reproduzido; para estudar, consulte o livro.</p>
<h3>Ler e editar</h3>
<ul><li>Toque no título para abrir o verbete. Mude o que quiser e toque em <b>Salvar alterações</b>; “Cancelar” ou “← Biblioteca” saem sem gravar (a Tecelã avisa se há alterações não salvas).</li>
<li>Um verbete que veio com a Tecelã e foi mudado aparece como “editado”; “Restaurar o texto original” desfaz as mudanças.</li>
<li>Quando a Tecelã é atualizada, os verbetes que você <b>não editou</b> recebem o texto novo sozinhos; os editados ficam como estão. Os verbetes do currículo de cada ano foram conferidos com o currículo tradicional e com o de uma escola Waldorf brasileira, com temas do Brasil.</li></ul>
<h3>Novo verbete</h3>
<ol><li>Toque em <b>+ Novo verbete</b>.</li>
<li>Escreva o título, escolha a <b>categoria</b> (uma que já existe, “Meus verbetes” ou “Nova categoria…”) e escreva o texto e, se quiser, a fonte.</li>
<li>Toque em <b>Inserir na Biblioteca</b>. Só então o verbete passa a existir; “Cancelar” não cria nada.</li></ol>
<h3>Excluir ou ocultar</h3>
<ul><li><b>Verbetes seus:</b> “Excluir verbete”, com confirmação e “Desfazer” no aviso. Nos seus verbetes também dá para mudar a categoria.</li>
<li><b>Verbetes que vêm com a Tecelã:</b> não são excluídos, porque o perfil do aluno e os relatórios usam alguns deles. Use <b>Ocultar verbete</b>: ele sai da lista, da exportação e dos relatórios e fica em “Verbetes ocultos”, no fim da Biblioteca, de onde volta com “Reexibir”.</li></ul>
<h3>BNCC — Ensino Fundamental</h3>
<p>Uma categoria só de leitura, com o texto oficial: um verbete por componente e ano (por exemplo, “Matemática — 3º ano”), mais “Como ler a BNCC na Tecelã” e, quando a Computação está ligada em Ajustes, “Computação: competências e eixos”. O seletor da categoria mostra, de início, o ano da turma atual. Em cada habilidade aparecem as épocas da escola ligadas a ela. Na Computação aparecem também o eixo, o objeto de conhecimento, a explicação e exemplos. Os verbetes da BNCC podem ser exportados, mas não editados nem excluídos. Para ligar habilidades às épocas, use Currículo e BNCC.</p>
<h2 id="m-planej">19. Planejamento</h2>
<p>Em <b>Planejar → Planejamento</b> ficam o Planejamento anual da turma, os Planos de época, o Ano letivo (veja <a href="#m-ano">Ano letivo</a>) e as referências de cada ano.</p>
<h3>Rascunhos de todos os anos</h3>
<p>A aba <b>Rascunhos de todos os anos</b> mostra os anos do 1º ao 8º (e o 9º, se ele estiver ligado em Ajustes) numa tabela: quantas épocas cada ano tem no currículo, o planejamento anual de referência e quantos planos de época já existem. <b>Montar os rascunhos de todos os anos</b> carrega as épocas de referência nos anos que ainda não têm épocas e monta, de uma vez, o planejamento anual e os planos de época que faltam; o que já existe não é mexido. Toque em “Ver” para abrir um ano. Para cada ano há um <b>Planejamento anual de referência</b> e um <b>Plano de época de referência</b> para cada época do currículo. As referências são iguais para qualquer turma daquele ano: ajuste ali o que vale para todas as turmas. Elas são montadas pela Tecelã com o que já está no app: a justificativa antropológica e os objetivos do ano, as épocas do currículo, as habilidades da BNCC ligadas a cada época (ou sugeridas, marcadas como “sugestão”), o conteúdo programático, a avaliação e as referências bibliográficas. Se o ano ainda não tem épocas, a Tecelã oferece carregar as épocas de referência.</p>
<h3>Planejamento anual da turma</h3>
<p>“Criar o Planejamento anual” copia a referência do ano da turma e monta a tabela <b>Épocas do ano</b> com as datas: cada época começa no mês indicado no seu período, dura as semanas previstas e conta os <b>dias letivos</b> pelo calendário. Feriados e recessos (eventos do tipo “Feriado ou recesso”, de um dia ou de vários) ficam de fora; sábados com um evento que tenha “letivo” no nome contam. A coluna de observações mostra os dias sem aula e os sábados letivos. Mudou o calendário ou o início do ano letivo? Toque em <b>Distribuir as datas pelo calendário</b>.</p>
<h3>Plano de época</h3>
<p>Na aba <b>Planos de época</b> há links para o <b>horário semanal</b> e para o <b>Currículo e BNCC</b>, onde ficam as épocas e onde dá para <b>colar uma lista de épocas</b> de uma vez. “Criar” monta o plano de uma época a partir da sua referência: epígrafe, objetivos específicos (pedagogia Waldorf), objetivos gerais (habilidades da BNCC), objetivos da língua materna, conteúdos, recontar, estrutura da aula, ritmo (versos, poemas e canções com gestos), desenho de formas, avaliação, materiais, bibliografia, o <b>Diário da época</b>, o <b>Repertório da época</b> (versos, canções e histórias ligados a ela na tela <a href="#m-repert">Repertório</a>, mais os da rotina diária) e a <b>Avaliação da época</b>.</p>
<p><b>Avaliação da época:</b> ao terminar a época, responda com calma: o que funcionou, o que mudar da próxima vez, quais crianças surpreenderam, o que lembrar no ano que vem. Ela fica “só para mim” (fora do impresso). Quando outra turma, ou a colega que vai dar aquele ano, criar o plano da mesma época, essas notas aparecem na seção <b>Notas de quem já deu esta época</b>.</p>
<p>As datas vêm de um evento “Época” no calendário (com o nome da época) ou do Planejamento anual. O diário tem um dia por dia letivo, com o dia da semana, as aulas daquele dia, com os horários, vindas do <b>horário semanal</b> (Turma e alunos → Horário semanal), os aniversários e os campos Conteúdo, Registro, História, PC (professor de classe) e Lição de casa. Mudou as datas? “Montar o diário pelo calendário” refaz os dias e mantém o que já foi escrito em cada um. O botão <b>Ir para o diário</b>, no alto do plano, leva direto a ele, e a lista de épocas mostra quantos dias do diário já foram preenchidos. Quando alguma criança tem PEI, as adaptações aparecem no alto do plano, como lembrete só para você.</p>
<h3>Editar, versões e relatório</h3>
<ul><li>Cada seção tem título e texto editáveis (toque no título para mudá-lo; as caixas de texto crescem com o texto), ↑ e ↓ para mudar a ordem, ↻ para trazer de novo do sistema (substitui o que foi escrito naquela seção) e ✕ para tirar (com “Desfazer”). “+ Seção de texto” e “+ Tabela” acrescentam partes suas. No texto, linhas que começam com “- ” viram lista e “## ” vira subtítulo.</li>
<li>“Só para mim” deixa a seção fora do documento impresso.</li>
<li><b>Registrar versão</b> guarda o documento como está, com data, hora, o que mudou e impressão digital. Você continua editando para a próxima versão. Em “Versões”, exporte, confira ou volte a uma versão.</li>
<li><b>Imprimir ou exportar</b> gera PDF, Word ou e-mail, do texto atual ou de uma versão, com o histórico de versões no fim, se quiser.</li>
<li>“↻ Refazer o rascunho” monta de novo todas as seções que vêm do sistema e mantém as seções que você criou.</li></ul>
<h3 id="m-grade">Horário semanal</h3>
<p>Em <b>Turma e alunos → Horário semanal</b>:</p>
<ul><li><b>O horário:</b> cada dia da semana tem as suas aulas, uma por linha, com <b>início</b>, <b>fim</b>, <b>matéria</b> e a sigla de quem dá a aula: <b>PC</b> (Professor de Classe) ou <b>PM</b> (Professor de Matéria). “+ aula” acrescenta uma linha, que já começa onde a anterior terminou; ↑ e ↓ mudam a ordem; ✕ tira. A <b>Aula principal</b> está sempre na lista e é do Professor de Classe. “+ Sábado letivo” acrescenta o sábado.</li>
<li><b>Observações do horário:</b> o que vale para a semana (saídas mais cedo, aulas em semanas alternadas…). Vai impressa logo abaixo do horário.</li>
<li><b>Matérias do ano:</b> cadastre uma vez cada matéria da turma naquele ano, diga se é PC ou PM e, se quiser, o nome do professor ou da professora. “Trazer do conteúdo programático” preenche a lista a partir dos componentes do ano (confira quem dá cada aula).</li>
<li>No diário da época, as aulas do Professor de Matéria aparecem na linha de aulas do dia, e as do Professor de Classe entram no campo “PC”, sempre com o horário.</li>
<li><b>Imprimir ou exportar o horário:</b> o horário sai numa tabela, com os dias nas colunas e as aulas nas linhas (horário, matéria e sigla), a legenda das siglas e as observações. A lista das matérias, com quem dá cada uma e o nome do professor, sai em <b>folha separada</b>, mesmo quando se imprime tudo junto. Também sai em planilha.</li>
<li>As horas de cada dia do horário semanal são usadas na contagem da carga horária (veja <a href="#m-ano">Ano letivo</a>).</li></ul>

<h2 id="m-pei">20. PEI — Plano Educacional Individualizado</h2>
<p>Para a criança que precisa de adaptações. Na lista, “Criar” monta o rascunho com o que já está registrado: quem é a criança (idade, setênio e o último perfil), necessidades e acompanhamentos (pontos de atenção, NEE, acompanhamento externo), o que a observação do período mostra, o <b>conteúdo curricular planejado</b> (uma tabela com cada componente, o que está planejado para a classe e o que está planejado para a criança, que começa como “Acompanha o conteúdo da classe”), recursos didáticos e adaptações, objetivos, reforço escolar e acompanhamento e revisão. No cabeçalho: tutores, componentes, professores e vigência.</p>
<p>O PEI é <b>sigiloso</b>: fica só no aparelho e no arquivo e só sai quando você exporta. Depois de criado, as adaptações aparecem como lembrete no boletim e no plano de época, e o PEI aparece como sinal no pré-conselho (o texto, só se você incluir os sigilosos). Como nos outros documentos, há ↻ por seção, versões e exportação.</p>

<h2 id="m-reforco">21. Reforço escolar</h2>
<ol><li>Em <b>A turma → Reforço</b>, toque em <b>+ Reforço</b>.</li>
<li>Marque a criança (ou as crianças), a matéria e o tópico. A observação é só para você; o texto livre vai para o bilhete.</li>
<li>Escolha a primeira data, quantos encontros e a repetição (toda semana no mesmo dia, dias letivos seguidos ou a cada 15 dias), ou escreva as datas. Dias sem aula ficam de fora. Informe o horário de início e o horário de saída.</li></ol>
<ul><li>As datas entram sozinhas no <b>calendário</b>; o reforço aparece como sinal no <b>pré-conselho</b> e no <b>PEI</b>.</li>
<li><b>Cada encontro:</b> toque numa data da lista para marcar se o encontro foi realizado, se a criança faltou ou se foi cancelado. Encontros marcados saem do calendário e do Painel e continuam no histórico do reforço, na ficha da criança, no PEI e no pré-conselho (por exemplo, “2 realizados, 1 falta”). Quando todos os encontros estão marcados, o reforço passa sozinho a realizado (ou a cancelado). A situação do reforço inteiro também pode ser mudada direto na lista; um reforço realizado ou cancelado sai do calendário.</li>
<li><b>Bilhetes:</b> um por criança, um por folha, para todos os reforços previstos ou para um só. O texto se ajusta à criança (o aluno ou a aluna, chamado ou chamada) e às datas, como “durante três segundas-feiras seguidas, nos dias 9, 16 e 23 de novembro de 2026”. Desmarque “Mostrar a matéria e o tópico no bilhete” quando preferir. “Modelo do bilhete” muda o texto e o horário de saída mais usado.</li>
<li><b>Listas:</b> em Relatórios → Reforço escolar, a lista geral da turma ou a de uma criança, por situação.</li></ul>

<h2 id="m-combinados">22. Combinados da turma</h2>
<p>O guia da turma com as famílias, em tom amigável e, quando der, bem-humorado: representantes de sala, comunicação com a professora, encontros da turma, telas e eletrônicos, ano escolar e férias, a caixinha da turma, outros combinados (fotos, aniversários, lanche coletivo, turma paralela) e a revisão dos combinados. Ele completa as regras da escola, sem passar por cima delas.</p>
<ul><li>“Começar com o modelo da Tecelã” traz o texto pronto, com lacunas para completar. No ano seguinte, <b>Repetir os combinados</b> do ano anterior copia tudo para a turma nova.</li>
<li>Ao longo do ano, cada ajuste vira uma nova versão (“Registrar versão”), com data, hora e o que mudou. O documento impresso mostra o número da versão e, se quiser, o histórico.</li></ul>

<h2 id="m-acomp">23. Acompanhamento: contatos, entrevista e estudo de criança</h2>
<p>Em <b>Documentos → Acompanhamento</b> há três abas. Tudo aqui é <b>sigiloso</b>: fica só no aparelho e no arquivo e só sai quando você exporta.</p>
<ul><li><b>Contatos com as famílias:</b> “+ Contato” registra uma conversa, um telefonema, uma mensagem, um e-mail, um bilhete ou uma reunião: a criança, a data, com quem, o assunto, o que foi conversado e o que foi combinado. Os contatos não sigilosos aparecem no <b>pré-conselho</b>, na preparação para a <b>reunião com a família</b> (Relatórios → Ficha da criança) e no <b>estudo de criança</b>.</li>
<li><b>Entrevista com a família:</b> um roteiro de conversa para a entrada da criança (gestação e nascimento, primeiros anos, saúde, sono, alimentação, brincar, família e rotina, escola anterior, o jeito da criança, expectativas). As perguntas entre parênteses são só um guia: escreva o que a família contar.</li>
<li><b>Estudo de criança:</b> para o colegiado. O rascunho já traz a apresentação da criança (com o que a família contou na entrevista), a imagem do perfil, a observação do período, as anotações recentes, o PEI, o reforço e os contatos com a família, e deixa espaço para as perguntas ao colegiado, o que o colegiado percebeu, as propostas e o acompanhamento. Como nos planos, há ↻ por seção, versões e exportação.</li></ul>

<h2 id="m-comunic">24. Comunicados às famílias</h2>
<p>Em <b>A turma → Comunicados</b> ficam modelos prontos: material, festa, reunião de pais, lembrete e passeio. “Usar” pede o texto livre, a data, o horário e o local e gera <b>um bilhete por criança</b> (o texto se ajusta a cada uma, com {nome} e pares como {o aluno/a aluna}) ou <b>um comunicado geral</b>, em PDF, Word ou e-mail (com os e-mails dos responsáveis já sugeridos). “Editar o modelo” muda o texto; “+ Modelo” cria um seu. Marcadores: {nome}, {texto}, {data}, {hora}, {local}, {turma}, {professora}, {Professora}, {hoje}.</p>

<h2 id="m-repert">25. Repertório da turma</h2>
<p>Em <b>Planejar → Repertório</b> registre os versos, canções, poemas, histórias contadas, brincadeiras de roda e jogos rítmicos da turma: título, tipo, autor ou fonte, a época a que se ligam e o texto (para obras protegidas, prefira o título, a fonte e um resumo). Marque “rotina diária” no que se faz todos os dias, como o verso da manhã.</p>
<ul><li><b>Usei hoje</b> registra a data. A lista mostra quantas vezes cada item foi usado e quando, para não repetir sem querer.</li>
<li>O repertório acompanha a turma de ano em ano: no 4º ano você ainda vê o que a turma viveu no 1º, 2º e 3º.</li>
<li>Os itens ligados a uma época entram no <b>Repertório da época</b> do plano de época; os da rotina diária entram também no <b>roteiro do substituto</b>.</li></ul>

<h2 id="m-ano">26. Ano letivo: dias, festas e materiais</h2>
<p>Em <b>Planejamento → Ano letivo</b>:</p>
<ul><li><b>Dias letivos e carga horária:</b> a Tecelã conta, pelo calendário, os dias letivos de cada período (sem domingos, feriados e recessos, com os sábados letivos), a partir do início do ano letivo e até o último dia de aula (um evento com “fim das aulas” ou “término do ano letivo” no nome). As horas de cada dia vêm do horário semanal; onde não há horário, vale o número de horas que você informar. O total é comparado com os mínimos definidos pela legislação (hoje, 200 dias e 800 horas, pela LDB); se a legislação mudar, ou se a sua rede exigir outros números, mude em <b>Ajustes → Ano letivo</b>. <b>Usar estes dias nas faltas e no boletim</b> leva os números para a tela Faltas e para o cálculo da frequência. Confira sempre com a secretaria.</li>
<li><b>Festas do ano:</b> Festa da Colheita, Páscoa, Festa das Lanternas, São João, Micael, Festa da Primavera, Espiral do Advento e Auto de Natal, com datas sugeridas para o hemisfério sul (a da Páscoa é calculada). A lista é sua: <b>Editar</b> muda o nome, a data (fixa, ou ligada à Páscoa ou ao 1º domingo do Advento, com dias antes ou depois) e os passos da preparação (um por linha, com os dias antes da festa: “21: Ensaiar as canções”); <b>+ Festa</b> inclui uma festa da sua escola; <b>✕</b> exclui da lista (o que já está no calendário continua lá); “Voltar à lista original” desfaz as mudanças. <b>Colocar no calendário</b>: marque as festas e confira as datas; cada festa entra no calendário e cada passo da preparação (ensaiar as canções, comunicado às famílias, preparar os enfeites…) vira uma tarefa com prazo.</li>
<li><b>Lista de materiais do ano:</b> uma sugestão montada pelo ano (flauta, tricô, crochê, bordado, compasso…) e pelas épocas do currículo, com um texto de apresentação para as famílias. Revise e envie; as partes com ↻ podem ser montadas de novo.</li></ul>

<h2 id="m-cadastros">27. Cadastros</h2>
<p>Em <b>Cadastros</b> você personaliza as listas usadas pela Tecelã. Escolha a lista nos botões do alto:</p>
<ul><li>tipos de reunião (com as categorias de participantes e os subtipos; o tipo “Conselho de classe” já vem cadastrado), caráter da reunião, critérios do perfil, papéis no grupo, tipos de ponto de atenção, tipos de vivência, tipos de evento (com cor) e componentes do currículo (ligados ou não a uma área da BNCC, inclusive a Computação);</li>
<li><b>Observação: blocos</b> (cada bloco com seu critério do perfil e sua seção do boletim) e <b>Observação: itens</b> (escolha o bloco no alto; cada item pode ter uma seção do boletim própria);</li>
<li><b>Frases prontas</b> das anotações (veja <a href="#m-frases">Frases prontas</a>).</li></ul>
<p>“+ Novo item” inclui; o nome pode ser editado direto na tabela; as setas mudam a ordem.</p>
<h3>Excluir e arquivar</h3>
<p>O botão de cada item já diz o que vai acontecer:</p>
<ul><li><b>Excluir</b> aparece quando o item não é usado em nenhum registro: ele é apagado (com “Desfazer” no aviso).</li>
<li><b>Arquivar</b> aparece quando o item já é usado. Para não perder as relações e o histórico, ele não é apagado: sai das listas de escolha e continua nos registros antigos. “Reativar” traz o item de volta; se um item arquivado deixar de ser usado, ele também pode ser excluído.</li>
<li>A coluna <b>Uso</b> mostra em quantos registros o item aparece. Toque no número para ver quais (por exemplo, “Reunião com as famílias nº 01 de 12/03/2026”).</li>
<li>As <b>frases prontas</b> sempre podem ser excluídas: a frase é copiada para o texto da anotação, então as anotações que já a usaram continuam como estão.</li></ul>
<p>As seções do boletim ficam em Boletins → Seções do ano, e os períodos das faltas e da observação em Ajustes.</p>
<h2 id="m-atencao">28. Pontos de atenção</h2>
<p>No cadastro da criança, “+ Ponto de atenção” registra saúde, alergias, visão e audição, sono, aspectos emocionais, aprendizagem, acompanhamento terapêutico, família e guarda, entre outros, com descrição, data de início e situação (ativo ou resolvido).</p>
<p>São dados sensíveis pela LGPD (art. 11), por isso são <b>sigilosos por padrão</b>: aparecem para você no editor do boletim, no perfil e no pré-conselho, mas nunca são impressos no boletim, e só entram em relatórios exportados se você marcar. Desmarque “sigiloso” só quando a informação puder constar de documentos (uma alergia, por exemplo). Quando um ponto deixar de ser necessário, prefira marcar “Resolvido”, para manter o histórico.</p>

<h2 id="m-importar">29. Importar boletins anteriores</h2>
<p>A Tecelã lê os boletins dos anos anteriores, em .docx, dentro do próprio app e sem internet: nada sai do aparelho.</p>
<ol><li>Na tela inicial, use “Novo a partir de boletins anteriores”; ou, já dentro do app, Turma e alunos → “Importar boletins anteriores (.docx)”.</li>
<li>Escolha os arquivos (pode escolher vários de uma vez).</li>
<li>Confira o que foi lido em cada boletim: nome, gênero, série, letra, ano, professora e a seção de cada parágrafo. Corrija o que for preciso. Parágrafos que se repetem em vários boletins da mesma turma são reconhecidos como texto da turma.</li>
<li>Confirme. As turmas, as crianças e os boletins (como rascunhos editáveis, com o poema) entram nos seus dados. Crianças já cadastradas com o mesmo nome não são duplicadas.</li></ol>

<h2 id="m-timbrado">30. Papel timbrado, exportar e enviar</h2>
<p><b>Papel timbrado:</b> escolha o logotipo, a posição, o cabeçalho, o rodapé, o tamanho do papel (A4 ou Ofício) e as margens. Os boletins podem usar o mesmo timbrado das atas ou um próprio.</p>
<p><b>Fontes dos documentos impressos</b> (em Ajustes): escolha a fonte do texto, a dos títulos e a dos poemas. A lista mostra as fontes encontradas no aparelho; no Chrome do computador, “Ver todas as fontes deste computador” traz a lista completa, e “Usar outra fonte instalada” aceita o nome de qualquer fonte que esteja no aparelho. Valem para o PDF e o Word; as telas do app não mudam. No Word, o arquivo leva só o nome da fonte: quem abrir num computador sem ela verá outra.</p>
<ul><li><b>PDF:</b> a Tecelã abre a janela de impressão. Escolha “Salvar como PDF” ou uma impressora.</li>
<li><b>Word (DOCX):</b> salva um arquivo editável, com o papel timbrado.</li>
<li><b>Planilha (CSV):</b> em listas e relatórios com tabelas; abre no Excel, LibreOffice ou Google Planilhas.</li>
<li><b>E-mail:</b> a Tecelã verifica a conexão. No celular e no tablet, abre o compartilhamento do sistema com o arquivo anexado. No computador, salva o arquivo e abre o seu e-mail com destinatário, assunto e texto prontos: arraste o arquivo para a mensagem e envie.</li></ul>

<h2 id="m-copia">31. Salvar o arquivo</h2>
<p id="m-ajustes">A Tecelã guarda o seu trabalho em dois lugares, e vale entender a diferença:</p>
<ul><li><b>Neste aparelho, sozinha:</b> tudo o que você digita é gravado na hora, sem botão, no armazenamento do navegador (o IndexedDB). Por isso, ao sair sem salvar no arquivo, nada se perde de imediato: ao abrir a Tecelã de novo, neste mesmo navegador e a partir do mesmo <i>Tecela.html</i>, tudo estará lá. A linha discreta no alto da tela mostra quando isso aconteceu (“✓ Salvo neste aparelho às 10:32”).</li>
<li><b>Mas essa cópia do navegador pode se perder</b> se os dados de navegação forem limpos (“limpar histórico”, “limpar dados dos sites”), se você usar janela anônima, trocar de navegador ou de computador, se o aparelho ficar sem espaço ou, no iPhone e no iPad, se a Tecelã ficar vários dias sem ser aberta (o Safari apaga os dados de sites pouco usados).</li>
<li><b>No arquivo .tecela, quando você salva:</b> é a cópia que vale. Ele guarda tudo (turmas, crianças, anotações, observações, atas, boletins, perfis, conselhos, planos, calendário, tarefas, repertório e biblioteca), pode ficar num pendrive ou numa pasta na nuvem, abre em outro aparelho e é o que permite recuperar tudo. Com a senha ligada, vai criptografado.</li></ul>
<ul><li><b>💾 Salvar</b> (no alto da tela, no Painel ou em Ajustes → Arquivo; ou <b>Ctrl+S</b>) grava no seu arquivo. O nome do arquivo leva a <b>data e a hora</b>, como <i>Tecela_Escola_2026-11-06_14h32.tecela</i>. Nos navegadores que permitem (Chrome e Edge no computador), a gravação vai direto ao mesmo arquivo, e a data e a hora do nome são atualizadas quando o navegador deixa renomear; nos outros, uma cópia nova vai para a pasta de downloads. O botão fica destacado quando há alterações que ainda não estão no arquivo.</li>
<li><b>Salvar sempre como um arquivo novo:</b> em Ajustes → Arquivo, marque esta opção para que cada “Salvar” crie um arquivo novo, com data e hora, mantendo o histórico de cópias.</li>
<li><b>Salvar como novo arquivo</b> e <b>Abrir outro arquivo</b> ficam em Ajustes → Arquivo.</li>
<li><b>Ao sair:</b> o botão “Sair” oferece “Salvar e sair”. “Sair sem salvar no arquivo” mantém as alterações só neste navegador (veja acima). Se você fechar a aba direto, o navegador mostra o aviso “Sair do site?”. Na próxima abertura, se ficaram alterações fora do arquivo, a Tecelã pergunta se quer salvar.</li>
<li>Com a senha ligada, o arquivo é criptografado e só abre com a mesma senha ou com a chave de recuperação. Arquivos de cópia antigos (.json) também abrem.</li>
<li><b>No celular e no tablet:</b> o sistema não conhece a extensão .tecela (no Android ela aparece como “Arquivo em BIN”). Há uma limitação do Android: quando o <i>Tecela.html</i> é aberto pelo gerenciador de arquivos, o navegador abre a página como “content://” e não entrega à página o arquivo escolhido. Por isso, no Android, abrir um arquivo .tecela pode não funcionar; use a Tecelã no computador para abrir e salvar o arquivo. No iPhone e no iPad, o arquivo precisa estar no app Arquivos. Se escolher outro tipo de arquivo, a Tecelã avisa e nada é alterado.</li></ul>
<p>Em <b>Ajustes</b> ficam também a senha e o tempo para travar, as <b>fontes dos documentos impressos</b>, os períodos das faltas, os <b>períodos da observação e do conselho</b> (anual, semestral, trimestral ou bimestral), a <b>Computação</b> na BNCC (ligada ou não), o <b>ano letivo</b> (mínimo de dias letivos e mínimo de horas, definidos pela legislação), os <b>anos mostrados</b> (o 9º ano fica oculto por padrão: na tradição Waldorf ele já é o início do ensino médio; pela legislação brasileira, faz parte do Ensino Fundamental), o formato das atas, o prazo de guarda dos egressos, o tema (claro ou escuro) e o tamanho da letra.</p>

<h2 id="m-partilha">32. Partilha pedagógica</h2>
<p>A partilha leva para outra professora ou outro professor o seu <b>material pedagógico</b>, sem nenhum dado de pessoas ou da escola. O arquivo tem extensão própria, <i>.tecela-partilha</i>, e não é uma cópia de segurança: ele só acrescenta itens em quem recebe e nunca substitui nada. Fica em <b>Ajustes e arquivo → Partilha pedagógica</b>.</p>
<h3>Para quem envia</h3>
<ul><li><b>O que vai:</b> planejamentos anuais e planos de época, épocas do currículo, conteúdo programático que você adaptou, repertório, verbetes próprios ou editados da Biblioteca, modelos de boletim (as seções), modelos de comunicado, os textos das vivências (roteiro, vestimenta, alimentação, cardápio e outras orientações) e as festas do ano que você personalizou.</li>
<li><b>O que nunca vai:</b> crianças, matrículas, famílias e contatos, saúde e segurança, boletins, anotações, observações, atas, conselhos, PEI, estudos de caso, entrevistas, reforço, chamada, perfis, calendário e tarefas, professoras, cadastros, papel timbrado e dados da escola. Das vivências ficam de fora data, local, responsável, participantes, endereço, contatos, orçamento, autorizações e fichas de emergência. Dos planos de época ficam de fora o diário, a avaliação da época e as avaliações anteriores; do planejamento anual, as datas das épocas.</li>
<li><b>Nomes trocados por marcadores:</b> os nomes que a Tecelã conhece (crianças, pelo nome completo e pelo primeiro nome, familiares, professoras, pessoas das atas e das vivências, nome e endereço da escola), além de e-mails e telefones, viram <i>[aluno]</i>, <i>[responsável]</i>, <i>[professora]</i>, <i>[pessoa]</i>, <i>[escola]</i> e <i>[contato]</i>.</li>
<li><b>Conferir antes de gerar:</b> ao tocar em “Compartilhar planejamentos”, um aviso curto resume tudo isso. Depois, a tela <b>Conferir a partilha</b> mostra cada item com o texto como vai sair: as trocas em lilás e, em <b>amarelo</b>, palavras com cara de nome próprio que a Tecelã não reconheceu. Abra os itens, desmarque o que não quiser enviar e use “Editar o texto para a partilha” para corrigir: a edição vale só para o arquivo, o seu material continua como está.</li>
<li><b>Direitos autorais:</b> compartilhar poemas, histórias ou trechos de livros protegidos é responsabilidade de quem envia. Na dúvida, desmarque o item ou deixe só o título e a fonte.</li>
<li><b>Assinar é opcional:</b> no campo “Assinar como”, escreva como quer aparecer para quem recebe. Vazio, o arquivo não leva nome algum.</li>
<li><b>Senha opcional:</b> marque “Proteger o arquivo com senha” e combine a senha com quem vai receber por outro meio (não no mesmo e-mail ou mensagem).</li>
<li>“Gerar o arquivo” salva o <i>.tecela-partilha</i> na pasta de downloads. Quem receber poderá editar ou apagar o material livremente.</li></ul>
<h3>Para quem recebe</h3>
<ul><li>Toque em <b>Receber partilha</b>. O aviso lembra que nada do seu será alterado e oferece <b>Salvar cópia antes</b>: é o recomendado, assim você tem como voltar atrás de qualquer jeito.</li>
<li>Escolha o arquivo e, se ele tiver senha, digite a senha combinada. Aparece a lista do que veio: desmarque o que não quiser e escolha a <b>turma</b> que recebe os planejamentos, o repertório e as vivências. Sem turma cadastrada, esses itens ficam desabilitados; os demais podem vir.</li>
<li><b>Nada do que você já tem é alterado ou substituído.</b> Tudo entra como item novo, marcado “recebido de …” (ou “recebido de partilha”, sem assinatura).</li>
<li><b>Itens iguais</b> aos seus são pulados. <b>Com o mesmo nome e conteúdo diferente</b> (um modelo de comunicado, uma festa, um verbete), o seu é mantido e o recebido entra com “(recebido)” no nome.</li>
<li><b>Planejamentos:</b> se a turma ainda não tem planejamento anual ou plano daquela época, o recebido passa a ser o dela. Se já tem, o seu continua valendo e o recebido fica <b>guardado à parte</b>: abra-o em Partilha pedagógica → Material recebido para copiar o que quiser. A época que faltar no currículo do ano da turma é criada. O mesmo vale para o modelo de boletim: se o ano já tem o seu, o recebido fica como referência.</li>
<li>As vivências entram sem data, para você marcar quando forem acontecer. Os marcadores como <i>[aluno]</i> ficam como texto: troque-os à mão, se fizer sentido.</li>
<li>Ao final, um resumo mostra quantos itens entraram de cada tipo, quantos repetidos foram pulados, quantos ganharam “(recebido)” e onde encontrá-los.</li>
<li><b>Desfazer:</b> em Material recebido, cada partilha tem o botão <b>Remover o que veio desta partilha</b>, que apaga de uma vez só os itens dela (inclusive o que você editou neles), sem tocar no seu material.</li>
<li>Uma partilha não abre por “Abrir outro arquivo”, e uma cópia de segurança não abre por “Receber partilha”: a Tecelã avisa e explica qual caminho usar.</li></ul>
<h2 id="m-virada">33. Virada do ano letivo</h2>
<ol><li>Salve o arquivo.</li><li>Em Turma e alunos → Virada do ano, confira quem dará aula no novo ano.</li><li>Para cada criança, escolha: segue com a turma, retido (sai desta turma) ou transferido (vai para o arquivo). No 9º ano, a turma conclui e as crianças vão para os egressos.</li><li>Veja as <b>pendências</b> do ano que termina: boletins e atas não finalizados, PEIs a revisar e encontros de reforço sem marcação. Deixe marcado “Criar uma tarefa para cada pendência” e escolha o prazo: elas entram na agenda do novo ano.</li><li>Confirme. A nova turma (por exemplo, “4º ano A de 2027”) é criada com a citação e as assinaturas do boletim do ano anterior e com a lista de matérias do horário semanal (quem dá cada aula), para você ajustar ao novo ano; os dias do horário semanal começam vazios.</li><li>Inclua as crianças novas.</li></ol>
<p><b>O ano anterior continua aberto.</b> Depois da virada, tudo o que não foi finalizado (boletins, atas, planos, PEI, reforços) pode ser editado e finalizado normalmente: basta escolher a turma do ano anterior no seletor, no alto da tela. Só o que já estava finalizado fica travado, como sempre. O ano anterior também continua disponível para consulta, para a ficha da criança e para a evolução da turma.</p>

<h2 id="m-seguranca">34. Segurança e LGPD</h2>
<ul><li><b>Senha:</b> com ela ligada, tudo é criptografado (AES-256-GCM) neste aparelho e no arquivo .tecela.</li>
<li><b>Esqueci a senha:</b> na tela de senha, marque “Esqueci a senha” e digite a chave de recuperação. Depois, defina uma senha nova.</li>
<li><b>Travamento:</b> a Tecelã trava sozinha depois de alguns minutos sem uso (ajustável).</li>
<li><b>Computador de terceiros:</b> abra o arquivo sem gravar nada no aparelho e, ao terminar, use “💾 Salvar”.</li>
<li><b>Sigilo:</b> anotações sigilosas e pontos de atenção nunca entram no boletim, e só saem do app em relatórios se você marcar. Nada é enviado a servidores: tudo fica no aparelho e no seu arquivo.</li>
<li><b>Documentos sigilosos:</b> PEI, entrevista com a família, estudo de criança e contatos marcados como sigilosos só saem do app quando você exporta. A ficha de emergência e o roteiro do substituto levam só o que está em “Saúde e segurança” e os pontos de atenção não sigilosos: entregue-os só a quem cuida das crianças e peça de volta.</li>
<li><b>Partilha pedagógica:</b> o arquivo de partilha leva só material pedagógico, por uma lista fechada do que pode sair; nomes conhecidos, e-mails e telefones são trocados por marcadores, e você confere tudo antes de gerar (veja <a href="#m-partilha">Partilha pedagógica</a>).</li>
<li><b>Licença e autoria:</b> a Tecelã é software livre (GNU GPL versão 3, com termos adicionais). Toda cópia deve manter visível o aviso “Tecelã — criada por Márcio Willians Barreto de Andrade”, e versões modificadas devem se identificar como diferentes da original e informar que o autor original não tem responsabilidade sobre as alterações. O texto completo está nos Créditos.</li></ul>

<h2 id="m-faq">35. Perguntas frequentes</h2>
<p><b>Quero apagar um verbete que veio com a Tecelã.</b> Abra o verbete e use “Ocultar verbete”. Ele sai da lista e dos relatórios e pode voltar em “Verbetes ocultos”.</p>
<p><b>Por que um item de Cadastros foi arquivado, e não excluído?</b> Porque ele já é usado em algum registro. Toque no número da coluna “Uso” para ver onde.</p>
<p><b>Como uso as frases prontas?</b> Veja <a href="#m-frases">Frases prontas</a>: no ✎ Anotar, escolha a frase no campo “Frases prontas”, logo abaixo do texto; ela entra no texto e você completa.</p>
<p><b>Toquei em “◎ Rascunho da observação” e não veio texto.</b> O rascunho usa só as marcas da Observação do período, não as anotações. Ou a criança ainda não tem marcas nos itens ligados àquela seção, ou nenhum item está ligado a ela (ligue em Cadastros → Observação: itens). Para trazer anotações, use “Trazer novas anotações”.</p>
<p><b>O relatório “Observação do período” está vazio.</b> Confira o período escolhido no alto do relatório: só aparecem as marcas daquele período.</p>
<p><b>Limpei o navegador e os dados sumiram.</b> Na tela inicial, use “Abrir um arquivo da Tecelã” e escolha o seu arquivo .tecela. Por isso é importante salvar o arquivo com frequência (veja <a href="#m-copia">Salvar o arquivo</a>).</p>
<p><b>Saí sem salvar no arquivo. Perdi o que fiz?</b> Não, se você abrir a Tecelã de novo no mesmo navegador: o que você digitou fica gravado nele. Mas essa cópia pode se perder se o navegador for limpo; salve no arquivo assim que puder.</p>
<p><b>Fiz a virada do ano e ficou um boletim sem finalizar.</b> Escolha a turma do ano anterior no seletor, no alto da tela: tudo o que não foi finalizado continua editável.</p>
<p><b>A data de nascimento ficava com o ano errado.</b> Isso acontecia em versões anteriores, ao digitar o ano. Desde a 1.6, digite a data inteira; a idade aparece quando você sai do campo.</p>
<p><b>No celular Android, o arquivo .tecela não abre.</b> Quando o <i>Tecela.html</i> é aberto pelo gerenciador de arquivos, o endereço da página começa com “content://”, e nesse modo o Chrome (e os navegadores feitos com ele, como Edge e Brave) não entrega à página o arquivo escolhido. Não é problema do arquivo nem da pasta. Por enquanto, abra e salve o arquivo no computador.</p>
<p><b>Troquei de computador.</b> Salve o arquivo, leve o <i>Tecela.html</i> e o arquivo .tecela para o novo computador, abra o app e use “Abrir um arquivo da Tecelã”.</p>
<p><b>No celular não apareceu o aviso ao fechar.</b> Os celulares quase nunca mostram esse aviso. Por isso a Tecelã pergunta na abertura seguinte. Prefira sempre o botão “Sair”.</p>
<p><b>O arquivo não abre.</b> Confira se é um arquivo .tecela (ou uma cópia antiga .json). Se ele tem senha, use a senha da época em que foi salvo, ou a chave de recuperação.</p>
<p><b>Mudei a observação de semestral para bimestral.</b> Nada se perde: as observações feitas continuam guardadas no período em que foram feitas.</p>
<p><b>O modelo de demonstração está diferente do que eu vi antes.</b> Quando a Tecelã é atualizada, o modelo é refeito sozinho com os dados da nova versão. As mudanças que você fez nele se perdem; seus dados reais não são afetados.</p>
<p><b>O PDF saiu com cabeçalhos do navegador.</b> Na janela de impressão, desmarque “Cabeçalhos e rodapés” em “Mais configurações”.</p>
<p><b>Os dados sumiram ao abrir o app de outro lugar.</b> O navegador associa os dados ao local do arquivo <i>Tecela.html</i>. Abra-o do mesmo lugar de sempre, ou abra o seu arquivo .tecela.</p>
`;

const LICENCA = '__LICENCA__';
const TEXTO_LICENCA = '<p>' + e(AUTORIA) + '</p><p>A Tecelã é software livre, sob a <b>GNU GPL versão 3</b> com termos adicionais: toda cópia deve manter este aviso de autoria visível na tela inicial e nos Créditos, e versões modificadas devem se identificar como diferentes da original e informar que o autor original não tem responsabilidade sobre as alterações.</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere;font-size:.78rem;max-height:50vh;overflow:auto">' + e(LICENCA) + '</pre>';
const CREDITOS_HTML = `
<p class="dica">Atualizado em ${DATA_VERSAO} (versão ${VERSAO})</p>
<p>A Tecelã existe graças a projetos de código aberto e a fontes livres. Esta página lista cada um, com sua licença. Os avisos de direitos autorais originais permanecem nos próprios componentes.</p>
<p><b>Nesta página:</b> 1. Tecelã · 2. Bibliotecas · 3. Fontes · 4. Conteúdo pedagógico · 5. Identidade visual · 6. Encontrou algo faltando?</p>
<h2>1. Tecelã</h2>
<ul><li><b>Autor e idealizador:</b> ${AUTOR}.</li>
<li><b>Licença do programa:</b> GNU GPL versão 3, com termos adicionais (texto completo abaixo). Em resumo: a Tecelã é software livre; você pode usar, estudar, modificar e compartilhar, desde que mantenha a mesma licença e o aviso de autoria visível. Versões modificadas devem se identificar como diferentes da original e informar que o autor original não responde pelas alterações.</li>
<li><b>Aviso de autoria (obrigatório em toda cópia):</b> ${AUTORIA}</li>
<li>Parte do conteúdo (a Biblioteca Waldorf, este manual e os textos do modelo de demonstração) foi feita com ajuda de inteligência artificial, sob direção humana.</li>
<li>O logotipo e o ícone da Tecelã pertencem ao autor.</li></ul>
<h2>2. Bibliotecas</h2>
<table class="tabela"><tr><th>Componente</th><th>Uso</th><th>Licença</th></tr>
<tr><td>docx 9.7.1 (Dolan Miu)</td><td>Exportar atas, boletins e relatórios em Word</td><td>MIT</td></tr>
<tr><td>JSZip (incluído na docx)</td><td>Montar o arquivo .docx</td><td>MIT ou GPLv3, à escolha</td></tr></table>
<h2>3. Fontes</h2>
<table class="tabela"><tr><th>Fonte</th><th>Uso</th><th>Licença</th></tr>
<tr><td>Antropos Freefont, de Lutz Baar (1998)</td><td>Nome no logotipo, convertido em desenho; o arquivo da fonte não é distribuído</td><td>Gratuita para fins culturais, sem uso comercial</td></tr>
<tr><td>Poppins, de Indian Type Foundry</td><td>Slogan do logotipo, convertido em desenho</td><td>SIL Open Font License 1.1</td></tr>
<tr><td>Marcellus</td><td>Títulos (quando instalada no aparelho)</td><td>SIL Open Font License 1.1</td></tr>
<tr><td>Nunito</td><td>Textos (quando instalada no aparelho)</td><td>SIL Open Font License 1.1</td></tr>
<tr><td>Caveat</td><td>Detalhes manuscritos (quando instalada no aparelho)</td><td>SIL Open Font License 1.1</td></tr></table>
<p class="dica">Sem essas fontes instaladas, a Tecelã usa fontes parecidas do próprio sistema.</p>
<h2>4. Conteúdo pedagógico</h2>
<p>Obras de Rudolf Steiner (<i>Estudo Geral do Homem</i>, GA 293; <i>A Arte da Educação II e III</i>, GA 294 e 295; <i>A Educação da Criança segundo a Ciência Espiritual</i>; conferências de Torquay, GA 311; <i>O mistério dos temperamentos</i>) e a <i>Base Nacional Comum Curricular</i> (MEC, versão homologada para a Educação Infantil e o Ensino Fundamental), de onde vêm as 1.304 habilidades consultadas no app; e documentos da Federação das Escolas Waldorf no Brasil: <i>Características Essenciais da Pedagogia Waldorf/Rudolf Steiner</i> (2018) e o documento sobre Pedagogia Waldorf e BNCC (2021); o complemento de Computação à BNCC (Parecer CNE/CEB nº 2/2022 e Resolução CNE/CEB nº 1/2022), de onde vêm as habilidades de Computação, com explicações e exemplos do documento “BNCC Computação — completo diagramado”; e o currículo do Ensino Fundamental publicado pela Escola Waldorf de Ribeirão Preto, usado na conferência dos verbetes de cada ano; o manual <i>Para a estruturação do ensino do 1º ao 8º ano nas Escolas Waldorf</i> (Seção Pedagógica do Goetheanum e Centro de Pesquisas Pedagógicas da Federação das Escolas Waldorf Livres; tradução de Rudolf Lanz; edição brasileira da Federação das Escolas Waldorf no Brasil), resumido em paráfrase na Biblioteca e usado nos textos de base do planejamento; e o conteúdo programático de uma escola Waldorf brasileira (2026), usado, sem identificar a escola, como conteúdo programático de referência. Os textos da Biblioteca e dos rascunhos de planejamento são paráfrases, com a fonte indicada em cada verbete.</p>
<h2>5. Identidade visual</h2>
<p>Baseada nos modelos “Álbum de Fotos Waldorf” e “Aquarela” fornecidos pelo autor: aquarela úmida em vermelho, amarelo e azul sobre papel creme.</p>
<h2>6. Encontrou algo faltando?</h2>
<p>Se você é autor de algum componente e quer corrigir um crédito, escreva para <a href="mailto:${CONTATO}">${CONTATO}</a>.</p>
<h2>Licença</h2>
<pre style="white-space:pre-wrap;overflow-wrap:anywhere;font-size:.8rem">${e(LICENCA)}</pre>
<hr><p class="dica">Tecelã — ${SLOGAN} · versão ${VERSAO} · Autor e idealizador: ${AUTOR} · ${CONTATO}</p>
`;

const PRIVACIDADE_HTML = `
<div class="aviso-lgpd">${AVISO_LGPD}</div>
<h2>O que a Tecelã faz para proteger os dados</h2>
<ul><li>Não tem servidor, contas nem estatísticas de uso. Nada sai do aparelho sem uma ação sua: um arquivo que você salva ou um e-mail que você envia.</li>
<li>Com a senha ligada, todos os registros deste aparelho e o arquivo .tecela são criptografados com AES-256-GCM. A chave deriva da senha (PBKDF2, 250.000 iterações).</li>
<li>Trava sozinha depois de alguns minutos sem uso.</li>
<li>O modo “computador de terceiros” abre os dados sem gravar nada no aparelho.</li>
<li>Anotações sigilosas nunca são impressas, exportadas nem levadas ao boletim.</li>
<li>Excluir um aluno apaga o cadastro, o perfil e as anotações dele. Atas e boletins finalizados são registros escolares e ficam guardados.</li>
<li>Egressos e transferidos ficam guardados por um prazo (5 anos, ajustável). Depois disso, a Tecelã lembra você de avaliar a exclusão.</li></ul>
<h2>Sua responsabilidade</h2>
<p>A professora é quem trata os dados das crianças (art. 14 da LGPD exige cuidado especial com dados de crianças e adolescentes). Use a Tecelã de acordo com as orientações da sua escola, guarde o arquivo .tecela e a chave de recuperação em local seguro e não compartilhe documentos com quem não deve recebê-los.</p>
`;

const SOBRE_HTML = `
<div style="max-width:320px">${'__LOGO_V__'}</div>
<p><b>Tecelã</b> — <i>${SLOGAN}</i>. Versão ${VERSAO}.</p><p>Boletins descritivos, atas, anotações, perfis, vivências, calendário e currículo para a professora e o professor de classe Waldorf.</p>
<p>As anotações, atas e marcações são fios tecidos no boletim de cada criança.</p>
<p><b>Princípio orientador:</b> o perfil não é um rótulo nem um diagnóstico fechado. É um retrato vivo, revisto periodicamente, que serve para o professor compreender a criança e o grupo e, a partir disso, ajustar a sua atuação pedagógica.</p>
<p>Autor e idealizador: ${AUTOR} · <a href="mailto:${CONTATO}">${CONTATO}</a></p>
<p class="dica">Funciona sem internet, num único arquivo HTML. Software livre: GNU GPL versão 3, com termos adicionais (veja os Créditos).</p>
<p class="dica">${AUTORIA}</p>
`;
