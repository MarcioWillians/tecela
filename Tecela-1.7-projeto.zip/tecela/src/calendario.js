/* ==========================================================================
   Tecelã — Calendário (da escola e da turma, com repetição), Vivências, Tarefas,
   "Próximos dias", avisos e exportação .ics para outros calendários.
   ========================================================================== */
'use strict';
const DIAS_SEM = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
const DIAS_CURTO = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
const diaSemana = iso => iso ? DIAS_SEM[new Date(iso + 'T12:00').getDay()] : '';
const somaDias = (iso, n) => { const d = new Date(iso + 'T12:00'); d.setDate(d.getDate() + n); return hojeISO(d); };
const difDias = (a, b) => Math.round((new Date(a + 'T12:00') - new Date(b + 'T12:00')) / 864e5);
const corTipo = k => (itemLista('tiposEvento', k) || {}).cor || '#999999';

/* ---------- repetição de eventos: semanal, quinzenal ou mensal, até uma data ---------- */
const REPETE_EV = [['', 'Não repete'], ['7', 'Toda semana'], ['14', 'A cada 15 dias'], ['m', 'Todo mês (mesmo dia)']];
function ocorrencias(v, de, ate) {
  const dur = v.dataFim ? difDias(v.dataFim, v.data) : 0, r = [], add = d => { const f = dur ? somaDias(d, dur) : ''; if ((f || d) >= de && d <= ate) r.push([d, f]); };
  if (!v.repete) { add(v.data); return r; }
  const fimRep = v.repeteAte && v.repeteAte < ate ? v.repeteAte : ate; let d = v.data, n = 0;
  while (d <= fimRep && n++ < 400) { if (!(v.excecoes || []).includes(d)) add(d); if (v.repete === 'm') { const x = new Date(v.data + 'T12:00'); x.setMonth(x.getMonth() + n); d = hojeISO(x); } else d = somaDias(d, Number(v.repete)); }
  return r;
}

/* ---------- todos os itens com data (guardados e automáticos) ---------- */
function itensAgenda(de, ate, opc) {
  opc = opc || {}; const t = turmaAtual(), tid = t && t.id, r = [];
  const dentro = (d, f) => d && (f || d) >= de && d <= ate;
  D.eventos.filter(v => !v.turmaId || v.turmaId === tid).forEach(v => ocorrencias(v, de, ate).forEach(([d0, f0]) => r.push({ data: d0, fim: f0, hora: v.hora, dur: v.duracao, titulo: v.titulo, obs: v.obs, tipo: v.tipo || (v.turmaId ? 'outro' : 'escola'), origem: v.turmaId ? 'turma' : 'escola', id: v.id, acao: 'editarEvento', repete: !!v.repete })));
  if (opc.auto !== false) {
    D.reforcos.filter(x => x.turmaId === tid).forEach(x => datasPendentesRef(x).filter(d => dentro(d)).forEach(d => r.push({ data: d, hora: x.hora, titulo: '✚ Reforço: ' + (x.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ') + (x.topico || x.componente ? ' (' + (x.topico || nomeItem('componentes', x.componente)) + ')' : ''), tipo: 'outro', origem: 'reforço', id: x.id, acao: 'abrirReforco' })));
    D.atas.filter(a => a.turmaId === tid && dentro(a.data) && !D.atas.some(x => x.origemId === a.id)).forEach(a => r.push({ data: a.data, hora: a.inicio, titulo: nomeReuniao(a) + (a.assunto ? ': ' + a.assunto : ''), tipo: 'reuniao', origem: 'ata', id: a.id, acao: 'abrirAta' }));
    D.vivencias.filter(v => v.turmaId === tid && dentro(v.data)).forEach(v => r.push({ data: v.data, hora: v.hora, dur: v.duracao, titulo: v.titulo, obs: v.local, tipo: 'vivencia', origem: 'vivência', id: v.id, acao: 'abrirViv' }));
    D.tarefas.filter(x => !x.feita && proximaData(x) && dentro(proximaData(x))).forEach(x => r.push({ data: proximaData(x), hora: x.hora, titulo: '☐ ' + x.titulo, obs: x.obs, tipo: 'outro', origem: 'tarefa', id: x.id, acao: 'editarTarefa' }));
    if (t) alunosDaTurma(tid).forEach(a => { if (!a.nasc) return; for (const ano of [Number(de.slice(0, 4)), Number(ate.slice(0, 4))]) { const d = ano + a.nasc.slice(4); if (dentro(d) && !r.some(x => x.origem === 'aniversário' && x.id === a.id && x.data === d)) r.push({ data: d, titulo: 'Aniversário de ' + primeiroNome(a) + ' (' + (ano - Number(a.nasc.slice(0, 4))) + ' anos)', tipo: 'festa', origem: 'aniversário', id: a.id }); } });
    D.atas.filter(a => a.turmaId === tid && !D.atas.some(x => x.origemId === a.id)).forEach(a => (a.encaminhamentos || []).forEach((x, i) => { if (x.acao && x.prazo && dentro(x.prazo) && !D.tarefas.some(tf => tf.origem && tf.origem.ata === a.id && tf.origem.i === i)) r.push({ data: x.prazo, titulo: 'Encaminhamento: ' + x.acao, obs: x.resp, tipo: 'reuniao', origem: 'encaminhamento', id: a.id, acao: 'abrirAta' }); }));
  }
  return r.sort((a, b) => (a.data + (a.hora || '')).localeCompare(b.data + (b.hora || '')));
}

/* ---------- CALENDÁRIO ---------- */
T.agenda = () => {
  const t = turmaAtual(); UI.mes = UI.mes || hojeISO().slice(0, 7);
  const [ano, mes] = UI.mes.split('-').map(Number), ini = UI.mes + '-01', fim = hojeISO(new Date(ano, mes, 0)), vis = UI.aba.agenda || 'mes';
  const itens = itensAgenda(ini, fim).filter(filtroOrig);
  let h = '<h1>Calendário</h1><div class="linha"><button class="btn" data-a="mesAnt">‹</button><h2 style="margin:0;min-width:12rem;text-align:center">' + MESES[mes - 1][0].toUpperCase() + MESES[mes - 1].slice(1) + ' de ' + ano + '</h2><button class="btn" data-a="mesProx">›</button><button class="btn peq" data-a="mesHoje">Hoje</button><span class="espaco"></span>' +
    '<select data-c="agOrig"><option value="">Escola e turma</option><option value="escola"' + (UI.filtro.agOrig === 'escola' ? ' selected' : '') + '>Só a escola</option><option value="turma"' + (UI.filtro.agOrig === 'turma' ? ' selected' : '') + '>Só a turma</option></select>' +
    '<button class="btn' + (vis === 'mes' ? ' pri' : '') + ' peq" data-a="aba" data-v="mes">Mês</button><button class="btn' + (vis === 'lista' ? ' pri' : '') + ' peq" data-a="aba" data-v="lista">Lista do mês</button><button class="btn' + (vis === 'ano' ? ' pri' : '') + ' peq" data-a="aba" data-v="ano">O ano em lista</button></div>' +
    '<div class="linha" style="margin:.7rem 0"><button class="btn pri" data-a="novoEvento">+ Evento da turma</button><button class="btn" data-a="novoEvento" data-escola="1">+ Evento da escola</button><button class="btn" data-a="variosEventos">+ Vários de uma vez</button><button class="btn" data-a="imprimirMes">' + (vis === 'ano' ? 'Imprimir ou exportar o ano' : 'Imprimir ou exportar o mês') + '</button><button class="btn" data-a="exportarIcs">Exportar para outro calendário (.ics)</button></div>';
  h += '<p class="dica">' + itensLista('tiposEvento').map(i => '<span class="etq" style="border-color:' + i.cor + ';border-left:6px solid ' + i.cor + '">' + e(i.nome) + '</span>').join(' ') + '</p>';
  if (vis === 'lista') return h + listaAgenda(itens);
  if (vis === 'ano') { const ia = itensAgenda(ano + '-01-01', ano + '-12-31').filter(filtroOrig); return h + (ia.length ? MESES.map((nm, i) => { const xs = ia.filter(x => Number(x.data.slice(5, 7)) === i + 1); return xs.length ? '<h3 style="margin-top:1.2rem">' + nm[0].toUpperCase() + nm.slice(1) + ' de ' + ano + '</h3>' + listaAgenda(xs) : ''; }).join('') : vazio('Nada em ' + ano + '.')); }
  const pri = new Date(ano, mes - 1, 1).getDay(), nd = new Date(ano, mes, 0).getDate(), hoje = hojeISO();
  h += '<div class="cartao rolagem" style="padding:.6rem"><table class="tabela" style="table-layout:fixed;min-width:640px"><tr>' + DIAS_CURTO.map(d => '<th style="text-align:center">' + d + '</th>').join('') + '</tr><tr>';
  for (let i = 0; i < pri; i++) h += '<td></td>';
  for (let d = 1; d <= nd; d++) {
    const iso = UI.mes + '-' + String(d).padStart(2, '0'), xs = itens.filter(x => x.data <= iso && (x.fim || x.data) >= iso);
    h += '<td style="height:6.5rem;vertical-align:top;padding:.25rem;' + (iso === hoje ? 'background:var(--amarC);' : '') + '"><div style="font-weight:700;font-size:.85rem;cursor:pointer" data-a="novoEvento" data-data="' + iso + '" title="Novo evento neste dia">' + d + '</div>' + xs.map(x => '<div style="font-size:.72rem;line-height:1.2;margin:2px 0;padding:2px 4px;border-radius:5px;background:' + corTipo(x.tipo) + '22;border-left:3px solid ' + corTipo(x.tipo) + ';cursor:pointer;overflow:hidden" ' + (x.acao ? 'data-a="' + x.acao + '" data-id="' + x.id + '" data-dia="' + x.data + '"' : '') + ' title="' + e(x.titulo + (x.obs ? ' — ' + x.obs : '')) + '">' + (x.hora ? e(x.hora) + ' ' : '') + (x.repete ? '↻ ' : '') + e(x.titulo) + '</div>').join('') + '</td>';
    if ((pri + d) % 7 === 0 && d < nd) h += '</tr><tr>';
  }
  return h + '</tr></table></div>';
};
function listaAgenda(itens) {
  if (!itens.length) return vazio('Nada neste mês.');
  return '<div class="cartao rolagem"><table class="tabela"><tr><th>Data</th><th>Dia</th><th>Horário</th><th>Duração</th><th>Evento</th><th>Observação</th><th>Origem</th></tr>' + itens.map(x => '<tr class="clic" ' + (x.acao ? 'data-a="' + x.acao + '" data-id="' + x.id + '" data-dia="' + x.data + '"' : '') + '><td style="white-space:nowrap"><span style="display:inline-block;width:.7rem;height:.7rem;border-radius:50%;background:' + corTipo(x.tipo) + '"></span> ' + dataBR(x.data) + (x.fim && x.fim !== x.data ? ' a ' + dataBR(x.fim) : '') + '</td><td>' + diaSemana(x.data) + '</td><td>' + e(x.hora || '') + '</td><td>' + e(x.dur || '') + '</td><td>' + (x.repete ? '↻ ' : '') + e(x.titulo) + '</td><td>' + e(x.obs || '') + '</td><td><span class="etq">' + e(x.origem) + '</span></td></tr>').join('') + '</table></div>';
}
const filtroOrig = x => !UI.filtro.agOrig || (UI.filtro.agOrig === 'escola' ? x.origem === 'escola' : x.origem !== 'escola');
C_.agOrig = el => { UI.filtro.agOrig = el.value; render(); };
const mudaMes = n => { const [a, m] = UI.mes.split('-').map(Number), d = new Date(a, m - 1 + n, 1); UI.mes = hojeISO(d).slice(0, 7); render(); };
A.mesAnt = () => mudaMes(-1); A.mesProx = () => mudaMes(1); A.mesHoje = () => { UI.mes = hojeISO().slice(0, 7); render(); };
A.abrirViv = d => { $('#modais').innerHTML = ''; ir('viv', d.id); };
async function dialogoEvento(v, dia) {
  const serie = v.id && v.repete, exc = (v.excecoes || []).slice().sort(), umDia = serie && dia ? dia : '';
  const r = await dlg({ titulo: v.id ? 'Editar evento' : (v.turmaId ? 'Novo evento da turma' : 'Novo evento da escola'), ok: serie ? 'Salvar (todas as datas)' : 'Salvar', largo: !!serie,
    extra: v.id ? (umDia ? '<button type="button" class="btn" data-x="separa" title="Muda só esta data; as outras continuam iguais">Mudar só ' + dataBR(umDia) + '</button><button type="button" class="btn perigo" data-x="apagaDia">Apagar só ' + dataBR(umDia) + '</button>' : '') + '<button type="button" class="btn perigo" data-x="apagar">' + (serie ? 'Apagar todas as datas' : 'Apagar') + '</button>' : '', corpo:
    (serie ? '<p class="alerta">Este evento se repete' + (umDia ? '. Você abriu a data de <b>' + dataBR(umDia) + '</b>' : '') + '. “Salvar” muda todas as datas; para mexer só numa, use os botões embaixo.' + (exc.length ? '<br>Datas apagadas: ' + exc.map(dataBR).join(', ') + ' <button type="button" class="btn peq" data-x="restaura">Trazer de volta</button>' : '') + '</p>' : '') +
    '<div class="duas">' + campo('Data', '<input type="date" name="data" value="' + e(v.data || hojeISO()) + '" required>', '<span id="dSem">' + diaSemana(v.data || hojeISO()) + '</span>') + campo('Até (opcional)', '<input type="date" name="dataFim" value="' + e(v.dataFim || '') + '">', 'Para eventos de vários dias') + '</div>' +
    '<div class="duas">' + campo('Horário', '<input type="time" name="hora" value="' + e(v.hora || '') + '">') + campo('Duração', '<input name="duracao" value="' + e(v.duracao || '') + '" placeholder="ex.: 1h30">') + '</div>' +
    campo('Evento', '<input name="titulo" value="' + e(v.titulo || '') + '" autofocus>') + '<div class="duas">' + campo('Tipo', '<select name="tipo">' + opcoesLista('tiposEvento', '', v.tipo).map(([k, n]) => '<option value="' + k + '"' + (k === v.tipo ? ' selected' : '') + '>' + e(n) + '</option>').join('') + '</select>') + campo('Avisar', '<select name="avisar">' + [['', 'Não avisar'], ['0', 'No dia'], ['1', '1 dia antes'], ['2', '2 dias antes'], ['7', '1 semana antes']].map(([k, n]) => '<option value="' + k + '"' + (String(v.avisar == null ? '' : v.avisar) === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + '</div>' +
    '<div class="duas">' + campo('Repetir', '<select name="repete">' + REPETE_EV.map(([k, n]) => '<option value="' + k + '"' + (String(v.repete || '') === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>', v.repete && v.id ? 'Mudanças valem para todas as datas.' : '') + campo('Repetir até', '<input type="date" name="repeteAte" value="' + e(v.repeteAte || '') + '">', 'Em branco: até o fim do ano') + '</div>' +
    campo('Observação', '<textarea name="obs" style="min-height:4rem">' + e(v.obs || '') + '</textarea>'),
    aoAbrir: f => f.querySelector('[name=data]').addEventListener('input', ev => $('#dSem', f).textContent = diaSemana(ev.target.value)), validar: x => x._botao ? null : !x.titulo.trim() ? 'Escreva o nome do evento.' : !x.data ? 'Informe a data.' : null });
  if (!r) return;
  if (r._botao === 'apagar') { await apagarComDesfazer('eventos', v.id, 'Evento apagado' + (v.repete ? ' (todas as datas).' : '.')); return; }
  if (r._botao === 'apagaDia') { v.excecoes = [...new Set((v.excecoes || []).concat([umDia]))]; await salvar('eventos', v); render(); aviso('Só a data de ' + dataBR(umDia) + ' foi apagada.', 'Desfazer', async () => { v.excecoes = v.excecoes.filter(x => x !== umDia); await salvar('eventos', v); render(); }); return; }
  if (r._botao === 'restaura') { v.excecoes = []; await salvar('eventos', v); render(); aviso('As datas apagadas voltaram.'); return; }
  if (r._botao === 'separa') { v.excecoes = [...new Set((v.excecoes || []).concat([umDia]))]; await salvar('eventos', v); const dur = v.dataFim ? difDias(v.dataFim, v.data) : 0, n = await salvar('eventos', { turmaId: v.turmaId, data: umDia, dataFim: dur ? somaDias(umDia, dur) : '', hora: v.hora, duracao: v.duracao, titulo: v.titulo, tipo: v.tipo, obs: v.obs, avisar: v.avisar, origemSerie: v.id }); render(); return dialogoEvento(n); }
  Object.assign(v, { data: r.data, dataFim: r.dataFim && r.dataFim > r.data ? r.dataFim : '', hora: r.hora, duracao: r.duracao, titulo: r.titulo.trim(), tipo: r.tipo, obs: r.obs, avisar: r.avisar === '' ? null : Number(r.avisar), repete: r.repete || null, repeteAte: r.repete ? (r.repeteAte || r.data.slice(0, 4) + '-12-31') : '' }); await salvar('eventos', v); render();
}
A.novoEvento = d => dialogoEvento({ turmaId: d.escola ? null : (turmaAtual() || {}).id || null, data: d.data || hojeISO(), tipo: d.escola ? 'escola' : 'outro' });
A.editarEvento = d => dialogoEvento(IX.eventos[d.id], d.dia);
A.imprimirMes = async () => {
  const [a, m] = UI.mes.split('-').map(Number), vis = UI.aba.agenda || 'mes', t = turmaAtual(), cab = ['Data', 'Dia', 'Horário', 'Duração', 'Evento', 'Observação', 'Origem'];
  const linha = x => [dataBR(x.data) + (x.fim && x.fim !== x.data ? ' a ' + dataBR(x.fim) : ''), diaSemana(x.data), x.hora || '', x.dur || '', x.titulo, x.obs || '', x.origem];
  if (vis === 'ano') { const xs = itensAgenda(a + '-01-01', a + '-12-31').filter(filtroOrig), tit = 'Calendário de ' + a + ' — ' + rotuloTurma(t), b = [{ t: 'tit', txt: tit }]; MESES.forEach((nm, i) => { const ys = xs.filter(x => Number(x.data.slice(5, 7)) === i + 1); if (ys.length) b.push({ t: 'h', txt: nm[0].toUpperCase() + nm.slice(1) }, { t: 'tabela', cab, linhas: ys.map(linha) }); }); return saidaDocumento({ nome: 'Calendario_' + a, titulo: tit, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b }, { csv: { cab, linhas: xs.map(linha) }, assunto: tit }); }
  const ini = UI.mes + '-01', fim = hojeISO(new Date(a, m, 0)), xs = itensAgenda(ini, fim).filter(filtroOrig), tit = MESES[m - 1][0].toUpperCase() + MESES[m - 1].slice(1) + ' de ' + a + ' — ' + rotuloTurma(t);
  const v = await dlg({ titulo: 'Imprimir ou exportar o mês', ok: 'Continuar', corpo: '<label class="ck"><input type="radio" name="f" value="grade" checked> <span><b>Grade do mês</b>, como na tela: linhas das semanas, colunas dos dias e os eventos em cada dia (folha deitada)</span></label><label class="ck"><input type="radio" name="f" value="lista"> <span><b>Lista</b> de eventos, com horário e observação</span></label>' }); if (!v) return;
  if (v.f === 'lista') return saidaDocumento({ nome: 'Calendario_' + UI.mes, titulo: tit, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: tit }, { t: 'tabela', cab, linhas: xs.map(linha) }] }, { csv: { cab, linhas: xs.map(linha) }, assunto: tit });
  const pri = new Date(a, m - 1, 1).getDay(), nd = new Date(a, m, 0).getDate(), sem = []; let w = Array(pri).fill(null);
  for (let d = 1; d <= nd; d++) { const iso = UI.mes + '-' + String(d).padStart(2, '0'); w.push({ dia: d, itens: xs.filter(x => x.data <= iso && (x.fim || x.data) >= iso).map(x => ({ txt: (x.hora ? x.hora + ' ' : '') + x.titulo, cor: corTipo(x.tipo) })) }); if (w.length === 7) { sem.push(w); w = []; } }
  if (w.length) { while (w.length < 7) w.push(null); sem.push(w); }
  const leg = itensLista('tiposEvento').filter(i => xs.some(x => x.tipo === i.chave)).map(i => i.nome).join(' · ');
  saidaDocumento({ nome: 'Calendario_grade_' + UI.mes, titulo: tit, paisagem: true, papel: 'A4', timbrado: {}, blocos: [{ t: 'tit', txt: tit }, { t: 'cal', cab: DIAS_SEM.map(d => d.replace('-feira', '')), semanas: sem, alt: sem.length > 5 ? 22 : 27 }].concat(leg ? [{ t: 'nota', txt: 'Tipos: ' + leg }] : []) }, { assunto: tit });
};
/* vários eventos de uma vez: uma linha por evento */
A.variosEventos = async () => {
  const t = turmaAtual(), ano = Number((UI.mes || hojeISO()).slice(0, 4));
  const v = await dlg({ titulo: 'Vários eventos de uma vez', largo: true, ok: 'Conferir', corpo: '<p class="dica">Escreva um evento por linha: a data (dia/mês), um traço e o nome. Para vários dias, use “a”. Exemplos:</p><pre style="background:var(--papel);padding:.5rem;border-radius:8px">12/03 - Festa da Páscoa\n21/04 a 25/04 - Recesso\n05/06 14h - Reunião com as famílias</pre><textarea name="txt" style="min-height:10rem" autofocus></textarea><div class="duas">' + campo('Ano', '<input type="number" name="ano" value="' + ano + '">') + campo('Tipo', '<select name="tipo">' + opcoesLista('tiposEvento', '', 'outro').map(([k, n]) => '<option value="' + k + '"' + (k === 'outro' ? ' selected' : '') + '>' + e(n) + '</option>').join('') + '</select>') + '</div><label class="ck"><input type="radio" name="de" value="turma" checked> Eventos da turma</label><label class="ck"><input type="radio" name="de" value="escola"> Eventos da escola</label>', validar: x => x.txt.trim() ? null : 'Escreva pelo menos um evento.' });
  if (!v) return; const xs = [], ruins = [], p2 = n => String(n).padStart(2, '0');
  v.txt.split('\n').map(l => l.trim()).filter(Boolean).forEach(l => { const m = l.match(/^(\d{1,2})\/(\d{1,2})(?:\s*(?:a|até|-)\s*(\d{1,2})\/(\d{1,2}))?\s*(?:(\d{1,2})[h:](\d{2})?)?\s*[-–:]\s*(.+)$/i); if (!m) return ruins.push(l); const d = v.ano + '-' + p2(m[2]) + '-' + p2(m[1]), f = m[3] ? v.ano + '-' + p2(m[4]) + '-' + p2(m[3]) : ''; if (isNaN(new Date(d + 'T12:00'))) return ruins.push(l); xs.push({ data: d, dataFim: f > d ? f : '', hora: m[5] ? p2(m[5]) + ':' + (m[6] || '00') : '', titulo: m[7].trim() }); });
  if (!xs.length) return informar('Nada reconhecido', '<p>Nenhuma linha está no formato “dia/mês - nome”.</p>');
  const ok = await dlg({ titulo: xs.length + ' evento(s)', ok: 'Incluir', largo: true, corpo: '<table class="tabela">' + xs.map(x => '<tr><td>' + dataBR(x.data) + (x.dataFim ? ' a ' + dataBR(x.dataFim) : '') + '</td><td>' + e(x.hora) + '</td><td>' + (x.repete ? '↻ ' : '') + e(x.titulo) + '</td></tr>').join('') + '</table>' + (ruins.length ? '<p class="alerta">Linhas não reconhecidas (ficam de fora): ' + ruins.map(e).join(' · ') + '</p>' : '') });
  if (!ok) return; for (const x of xs) await salvar('eventos', Object.assign({ turmaId: v.de === 'escola' ? null : t && t.id, tipo: v.tipo, obs: '', avisar: null }, x));
  render(); aviso(xs.length + ' evento(s) incluído(s).');
};

/* ---------- exportação .ics (Google Agenda, Outlook, celular) ---------- */
function icsData(iso, hora) { return iso.replace(/-/g, '') + (hora ? 'T' + hora.replace(':', '') + '00' : ''); }
function icsTexto(s) { return String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n'); }
function duracaoMin(s) { const m = String(s || '').match(/(\d+)\s*h(?:\s*(\d+))?|(\d+)\s*min/i); if (!m) return 60; return m[3] ? Number(m[3]) : Number(m[1]) * 60 + (Number(m[2]) || 0); }
A.exportarIcs = async () => {
  const r = await dlg({ titulo: 'Exportar para outro calendário', ok: 'Gerar arquivo .ics', corpo: '<p>O arquivo .ics abre no Google Agenda, no Outlook e no calendário do celular. Assim os avisos chegam mesmo com a Tecelã fechada.</p>' + ['eventos da turma', 'eventos da escola', 'reuniões (atas)', 'vivências', 'tarefas e lembretes', 'aniversários dos alunos'].map((x, i) => '<label class="ck"><input type="checkbox" name="o' + i + '"' + (i < 5 ? ' checked' : '') + '> ' + x + '</label>').join('') + '<p class="dica">Os aniversários levam o primeiro nome das crianças para fora da Tecelã. Inclua só se o calendário de destino for pessoal e protegido.</p>' });
  if (!r) return; const t = turmaAtual(), L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Tecela//PT-BR', 'CALSCALE:GREGORIAN'], agora = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z';
  const ev = (id, data, fim, hora, dur, titulo, obs, avisar, rrule, excecoes) => { L.push('BEGIN:VEVENT', 'UID:' + id + '@tecela', 'DTSTAMP:' + agora); if (hora) { L.push('DTSTART:' + icsData(data, hora), 'DURATION:PT' + duracaoMin(dur) + 'M'); } else { L.push('DTSTART;VALUE=DATE:' + icsData(data), 'DTEND;VALUE=DATE:' + icsData(somaDias(fim || data, 1))); } L.push('SUMMARY:' + icsTexto(titulo)); if (obs) L.push('DESCRIPTION:' + icsTexto(obs)); if (rrule) L.push('RRULE:' + rrule); if (rrule && (excecoes || []).length) L.push(hora ? 'EXDATE:' + excecoes.map(x => icsData(x, hora)).join(',') : 'EXDATE;VALUE=DATE:' + excecoes.map(x => icsData(x)).join(',')); if (avisar != null && avisar !== '') L.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + icsTexto(titulo), 'TRIGGER:-P' + Number(avisar) + 'D', 'END:VALARM'); L.push('END:VEVENT'); };
  D.eventos.filter(v => v.turmaId ? r.o0 && (!t || v.turmaId === t.id) : r.o1).forEach(v => ev(v.id, v.data, v.dataFim, v.hora, v.duracao, v.titulo, v.obs, v.avisar, v.repete ? (v.repete === 'm' ? 'FREQ=MONTHLY' : 'FREQ=WEEKLY;INTERVAL=' + (Number(v.repete) / 7)) + (v.repeteAte ? ';UNTIL=' + v.repeteAte.replace(/-/g, '') + 'T235959Z' : '') : null, v.excecoes));
  if (r.o2) D.atas.filter(a => t && a.turmaId === t.id && a.data).forEach(a => ev(a.id, a.data, null, a.inicio, a.fim && a.inicio ? (difHoras(a.inicio, a.fim)) : '', nomeReuniao(a), a.assunto, null));
  if (r.o3) D.vivencias.filter(v => t && v.turmaId === t.id && v.data).forEach(v => ev(v.id, v.data, null, v.hora, v.duracao, 'Vivência: ' + v.titulo, v.local, 1));
  if (r.o4) D.tarefas.filter(x => !x.feita && proximaData(x)).forEach(x => ev(x.id, proximaData(x), null, x.hora, '', x.titulo, x.obs, x.avisar == null ? 0 : x.avisar, x.repetir ? 'FREQ=DAILY;INTERVAL=' + x.repetir : null));
  if (r.o5 && t) alunosDaTurma(t.id).filter(a => a.nasc).forEach(a => ev('aniv-' + a.id, t.ano + a.nasc.slice(4), null, '', '', 'Aniversário de ' + primeiroNome(a), '', 1, 'FREQ=YEARLY'));
  L.push('END:VCALENDAR');
  const res = await salvarComo('Tecela_calendario_' + hojeISO() + '.ics', L.join('\r\n'), 'text/calendar', 'Calendário (.ics)'); if (res) aviso('Arquivo salvo: ' + res.nome + '. Abra-o no seu calendário.');
};
const difHoras = (a, b) => { const [h1, m1] = a.split(':').map(Number), [h2, m2] = b.split(':').map(Number), n = (h2 * 60 + m2) - (h1 * 60 + m1); return n > 0 ? Math.floor(n / 60) + 'h' + (n % 60 ? String(n % 60).padStart(2, '0') : '') : ''; };

/* ---------- VIVÊNCIAS ---------- */
T.viv = () => {
  const t = turmaAtual(); if (!t) return '<h1>Vivências</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && IX.vivencias[UI.sub]) return editorVivencia(IX.vivencias[UI.sub]);
  const xs = D.vivencias.filter(v => v.turmaId === t.id).sort((a, b) => (b.data || '').localeCompare(a.data || ''));
  let h = '<h1>Vivências</h1><p>Visitas a ofícios (ferreiro, vidreiro, padeiro…), oficinas, saídas, festas do ano, teatro e mutirões. Elas aparecem no calendário, nos relatórios da turma e podem gerar anotações para cada criança.</p><div class="linha"><button class="btn pri" data-a="novaViv">+ Nova vivência</button>' + (xs.length ? '<button class="btn" data-a="exportarViv">Exportar a lista</button>' : '') + '</div>';
  if (!xs.length) return h + vazio('Nenhuma vivência registrada em ' + e(rotuloTurma(t)) + '.');
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Data</th><th>Vivência</th><th>Tipo</th><th>Local</th><th>Participantes</th><th>Anotações</th></tr>' + xs.map(v => '<tr class="clic" data-a="abrirViv" data-id="' + v.id + '"><td>' + dataBR(v.data) + '</td><td><b>' + e(v.titulo) + '</b></td><td>' + e(nomeItem('tiposVivencia', v.tipo)) + '</td><td>' + e(v.local) + '</td><td>' + (v.todos !== false ? 'toda a turma' : (v.participantes || []).length + ' aluno(s)') + '</td><td>' + D.anotacoes.filter(n => n.origem && n.origem.id === v.id).length + '</td></tr>').join('') + '</table></div>';
};
A.novaViv = async () => { const t = turmaAtual(), v = await salvar('vivencias', { turmaId: t.id, data: hojeISO(), hora: '', duracao: '', tipo: (itensLista('tiposVivencia')[0] || {}).chave || 'outra', titulo: 'Nova vivência', local: '', responsavel: '', epocaId: '', descricao: '', todos: true, participantes: [] }); ir('viv', v.id); };
function editorVivencia(v) {
  const t = IX.turmas[v.turmaId], al = alunosDaTurma(t.id), ep = D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  let h = '<div class="linha"><button class="btn" data-a="voltarSub">← Vivências</button><h2 style="margin:0">' + e(v.titulo) + '</h2><span class="espaco"></span><button class="btn" data-a="vivInfo" data-id="' + v.id + '">Informações para as famílias (antes)</button><button class="btn" data-a="vivAutorizacao" data-id="' + v.id + '">Autorização</button><button class="btn" data-a="vivEmergencia" data-id="' + v.id + '">Ficha de emergência</button><button class="btn" data-a="exportarUmaViv" data-id="' + v.id + '">Relatório da vivência (depois)</button><button class="btn perigo" data-a="apagarViv" data-id="' + v.id + '">Excluir</button></div>';
  h += '<div class="cartao" data-rec="vivencias:' + v.id + '"><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Data', inp('data', v.data, 'date', 'data-rr="1"'), diaSemana(v.data)) + campo('Horário', inp('hora', v.hora, 'time')) + campo('Duração', inp('duracao', v.duracao, 'text', 'placeholder="ex.: 2h"')) + campo('Tipo', sel('tipo', v.tipo, opcoesLista('tiposVivencia', '', v.tipo))) + '</div>' +
    campo('Vivência', inp('titulo', v.titulo, 'text', 'placeholder="ex.: Visita à oficina do ferreiro"')) + '<div class="duas">' + campo('Local', inp('local', v.local)) + campo('Profissional ou responsável', inp('responsavel', v.responsavel)) + '</div>' +
    campo('Época relacionada', sel('epocaId', v.epocaId || '', [['', '— nenhuma —']].concat(ep.map(c => [c.id, c.titulo + ' (' + nomeItem('componentes', c.componente) + ')'])))) + '</div>';
  h += cartaoInfoViv(v);
  h += '<div class="cartao" data-rec="vivencias:' + v.id + '"><h3>Depois da vivência: registro</h3><p class="dica">O que a turma viveu, para o relatório da vivência, o calendário e o boletim. A preparação não entra aqui.</p>' + campo('O que a turma viveu', area('descricao', v.descricao, 'class="alto"')) +
    ck('todos', v.todos !== false, 'Toda a turma participou', 'data-rr="1"') + (v.todos === false ? '<div class="lista-sel">' + al.map(a => '<label class="ck"><input type="checkbox" data-c="vivPart" data-al="' + a.id + '"' + ((v.participantes || []).includes(a.id) ? ' checked' : '') + '> ' + e(a.nome) + '</label>').join('') + '</div>' : '') + '<div class="linha"><button class="btn" data-a="exportarUmaViv" data-id="' + v.id + '">Relatório da vivência</button></div></div>';
  const ns = D.anotacoes.filter(n => n.origem && n.origem.tipo === 'vivencia' && n.origem.id === v.id);
  h += '<div class="cartao"><h3>Observações sobre as crianças</h3><p class="dica">Cada observação vira uma anotação no cadastro da criança, ligada a esta vivência.</p><button class="btn" data-a="obsViv" data-id="' + v.id + '">+ Observação para aluno(s)</button>' + (ns.length ? '<table class="tabela" style="margin-top:.6rem">' + ns.map(n => '<tr><td>' + e((n.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')) + '</td><td>' + (n.estrela ? '<span class="estrela">★</span> ' : '') + e((n.alunos || []).length === 1 ? substituir(n.texto, IX.alunos[n.alunos[0]], t) : n.texto) + '</td><td><button class="icone-btn" data-a="editarAnot" data-id="' + n.id + '">✎</button></td></tr>').join('') + '</table>' : '') + '</div>';
  return h;
}
C_.vivPart = (el) => { const v = IX.vivencias[UI.sub]; const s = new Set(v.participantes || []); if (el.checked) s.add(el.dataset.al); else s.delete(el.dataset.al); v.participantes = [...s]; salvarDepois('vivencias', v); };
A.apagarViv = async d => { if (!(await confirmar('Excluir a vivência?', 'As anotações criadas a partir dela continuam no cadastro das crianças.', 'Excluir'))) return; await apagar('vivencias', d.id); UI.sub = null; render(); };
A.obsViv = async d => {
  const v = IX.vivencias[d.id], t = IX.turmas[v.turmaId], al = alunosDaTurma(t.id).filter(a => v.todos !== false || (v.participantes || []).includes(a.id));
  const r = await dlg({ titulo: 'Observação da vivência', largo: true, ok: 'Registrar', corpo: '<div class="duas"><div class="lista-sel">' + al.map(a => '<label class="ck"><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '"> ' + e(a.nome) + '</label>').join('') + '</div><div>' + campo('Seção do boletim', '<select name="secao">' + opcoesSecao(t).map(([k, n]) => '<option value="' + k + '">' + e(n) + '</option>').join('') + '</select>') + campo('Critério do perfil', '<select name="criterio">' + criterios().map(([k, n]) => '<option value="' + k + '">' + e(n) + '</option>').join('') + '</select>') + '<label class="ck"><input type="checkbox" name="estrela" checked> <span class="estrela">★</span> Usar no boletim</label></div></div>' + campo('Observação', '<textarea name="texto" placeholder="Ex.: {nome} quis segurar o martelo e ouviu com atenção as explicações do ferreiro."></textarea>'), validar: x => !x.alunos || !x.alunos.length ? 'Escolha pelo menos um aluno.' : !x.texto.trim() ? 'Escreva a observação.' : null });
  if (!r) return; await salvar('anotacoes', { turmaId: t.id, data: v.data, alunos: r.alunos, secao: r.secao, criterio: r.criterio, texto: r.texto.trim(), estrela: !!r.estrela, sigilo: false, origem: { tipo: 'vivencia', id: v.id } }); render(); aviso('Observação registrada.');
};
const blocosViv = v => [{ t: 'h', txt: dataBR(v.data) + ' — ' + v.titulo }, { t: 'p', txt: [nomeItem('tiposVivencia', v.tipo), v.local, v.responsavel, v.todos === false ? (v.participantes || []).length + ' criança(s)' : 'toda a turma'].filter(Boolean).join(' · ') }].concat(nl2p(v.descricao).map(p => ({ t: 'p', txt: p })));
A.exportarUmaViv = async d => { await descarregarFila(); const v = IX.vivencias[d.id]; saidaDocumento({ nome: 'Vivencia_' + v.titulo, titulo: 'Relatório da vivência — ' + v.titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Relatório da vivência' }].concat(blocosViv(v)) }, { assunto: 'Vivência — ' + v.titulo }); };
A.exportarViv = () => { const t = turmaAtual(), xs = D.vivencias.filter(v => v.turmaId === t.id).sort((a, b) => (a.data || '').localeCompare(b.data || '')), cab = ['Data', 'Vivência', 'Tipo', 'Local', 'Responsável', 'Descrição'], ls = xs.map(v => [dataBR(v.data), v.titulo, nomeItem('tiposVivencia', v.tipo), v.local || '', v.responsavel || '', v.descricao || '']); saidaDocumento({ nome: 'Vivencias_' + t.ano, titulo: 'Vivências — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Vivências — ' + rotuloTurma(t) }].concat(xs.flatMap(blocosViv)) }, { csv: { cab, linhas: ls }, assunto: 'Vivências' }); };

/* ---------- TAREFAS ---------- */
function proximaData(x) { if (x.data) return x.data; if (x.repetir) return somaDias((x.ultima || (x.criado || '').slice(0, 10) || hojeISO()), Number(x.repetir)); return null; }
const REPETIR = [['', 'Não repete'], ['1', 'Todo dia'], ['7', 'Toda semana'], ['14', 'A cada 15 dias'], ['30', 'Todo mês'], ['outro', 'A cada … dias']];
T.tarefas = () => {
  const ver = UI.aba.tarefas || 'pend', xs = D.tarefas.filter(x => ver === 'feitas' ? x.feita : !x.feita).sort((a, b) => (proximaData(a) || '9999').localeCompare(proximaData(b) || '9999')), hoje = hojeISO();
  let h = '<h1>Tarefas e lembretes</h1><div class="linha"><button class="btn pri" data-a="novaTarefa">+ Tarefa</button><button class="btn" data-a="exportarTarefas">Imprimir ou exportar a lista</button><button class="btn" data-a="permitirAvisos">Permitir avisos do sistema</button><span class="espaco"></span><button class="btn peq' + (ver === 'pend' ? ' pri' : '') + '" data-a="aba" data-v="pend">Pendentes</button><button class="btn peq' + (ver === 'feitas' ? ' pri' : '') + '" data-a="aba" data-v="feitas">Concluídas</button></div><p class="dica">Uma tarefa pode ter data, repetir (por exemplo, a cada 15 dias, com ou sem data inicial) e pedir aviso alguns dias antes. Os avisos aparecem enquanto a Tecelã está aberta; para recebê-los com ela fechada, exporte o calendário (.ics) para o celular.</p>';
  if (!xs.length) return h + vazio(ver === 'feitas' ? 'Nenhuma tarefa concluída.' : 'Nenhuma tarefa pendente.');
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th></th><th>Tarefa</th><th>Quando</th><th>Repete</th><th>Aviso</th><th></th></tr>' + xs.map(x => { const pd = proximaData(x), atraso = pd && pd < hoje; return '<tr><td><input type="checkbox" data-c="tarefaFeita" data-id="' + x.id + '"' + (x.feita ? ' checked' : '') + ' title="Concluída"></td><td><b>' + e(x.titulo) + '</b>' + (x.obs ? '<br><span class="dica">' + e(x.obs) + '</span>' : '') + '</td><td style="white-space:nowrap;' + (atraso && !x.feita ? 'color:var(--verm);font-weight:700' : '') + '">' + (pd ? dataBR(pd) + ' · ' + diaSemana(pd).split('-')[0] + (x.hora ? ' ' + x.hora : '') : '—') + '</td><td>' + (x.repetir ? 'a cada ' + x.repetir + ' dia(s)' : '—') + '</td><td>' + (x.avisar == null ? '—' : x.avisar === 0 ? 'no dia' : x.avisar + ' dia(s) antes') + '</td><td><button class="icone-btn" data-a="editarTarefa" data-id="' + x.id + '">✎</button></td></tr>'; }).join('') + '</table></div>';
};
async function dialogoTarefa(x) {
  const rep = x.repetir ? String(x.repetir) : '', outro = rep && !REPETIR.some(r => r[0] === rep);
  const r = await dlg({ titulo: x.id ? 'Editar tarefa' : 'Nova tarefa', ok: 'Salvar', extra: x.id ? '<button type="button" class="btn perigo" data-x="apagar">Apagar</button>' : '', corpo: campo('Tarefa', '<input name="titulo" value="' + e(x.titulo || '') + '" autofocus>') + '<div class="duas">' + campo('Data (opcional)', '<input type="date" name="data" value="' + e(x.data || '') + '">') + campo('Horário', '<input type="time" name="hora" value="' + e(x.hora || '') + '">') + '</div><div class="duas">' + campo('Repetir', '<select name="rep">' + REPETIR.map(([k, n]) => '<option value="' + k + '"' + ((outro ? 'outro' : rep) === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + campo('A cada quantos dias', '<input type="number" min="1" name="n" value="' + e(outro ? rep : '') + '">', 'Só para “A cada … dias”') + '</div>' + campo('Avisar', '<select name="avisar">' + [['', 'Não avisar'], ['0', 'No dia'], ['1', '1 dia antes'], ['2', '2 dias antes'], ['3', '3 dias antes'], ['7', '1 semana antes']].map(([k, n]) => '<option value="' + k + '"' + (String(x.avisar == null ? (x.id ? '' : '0') : x.avisar) === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + campo('Observação', '<textarea name="obs" style="min-height:4rem">' + e(x.obs || '') + '</textarea>'), validar: v => v._botao ? null : !v.titulo.trim() ? 'Escreva a tarefa.' : v.rep === 'outro' && !(Number(v.n) > 0) ? 'Informe a cada quantos dias.' : null });
  if (!r) return; if (r._botao === 'apagar') { await apagarComDesfazer('tarefas', x.id, 'Tarefa apagada.'); return; }
  Object.assign(x, { titulo: r.titulo.trim(), data: r.data, hora: r.hora, repetir: r.rep === 'outro' ? Number(r.n) : r.rep ? Number(r.rep) : null, avisar: r.avisar === '' ? null : Number(r.avisar), obs: r.obs }); await salvar('tarefas', x); render();
}
A.exportarTarefas = async () => {
  const v = await dlg({ titulo: 'Lista de tarefas', ok: 'Continuar', corpo: '<label class="ck"><input type="radio" name="q" value="pend" checked> Pendentes</label><label class="ck"><input type="radio" name="q" value="todas"> Todas (pendentes e concluídas)</label>' }); if (!v) return;
  const rp = x => x.repetir ? ((REPETIR.find(r => r[0] === String(x.repetir)) || [, 'a cada ' + x.repetir + ' dias'])[1]) : '';
  const xs = D.tarefas.filter(x => v.q === 'todas' || !x.feita).sort((a, b) => (a.feita ? 1 : 0) - (b.feita ? 1 : 0) || (proximaData(a) || '9999').localeCompare(proximaData(b) || '9999'));
  const cab = ['', 'Tarefa', 'Quando', 'Repete', 'Observação'], ls = xs.map(x => [x.feita ? '☑' : '☐', x.titulo, (proximaData(x) ? dataBR(proximaData(x)) : '') + (x.hora ? ' ' + x.hora : ''), rp(x), x.obs || '']);
  const tit = 'Tarefas e lembretes' + (v.q === 'pend' ? ' pendentes' : '') + ' — ' + dataBR(hojeISO());
  saidaDocumento({ nome: 'Tarefas_' + hojeISO(), titulo: tit, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: tit }, { t: 'tabela', cab, linhas: ls }] }, { csv: { cab: cab.slice(1).concat(['Feita']), linhas: xs.map((x, i) => ls[i].slice(1).concat([x.feita ? 'sim' : 'não'])) }, assunto: 'Tarefas' });
};
A.novaTarefa = () => dialogoTarefa({ feita: false }); A.editarTarefa = d => dialogoTarefa(IX.tarefas[d.id]);
C_.tarefaFeita = async el => {
  const x = IX.tarefas[el.dataset.id];
  if (el.checked && x.repetir) { const base = proximaData(x) || hojeISO(); x.ultima = base; if (x.data) x.data = somaDias(x.data, x.repetir); x.feita = false; aviso('Feito! A próxima vez fica para ' + dataBR(proximaData(x)) + '.'); }
  else { x.feita = el.checked; x.feitaEm = el.checked ? hojeISO() : null; }
  await salvar('tarefas', x); render();
};
A.tarefasDaAta = async d => { const a = IX.atas[d.id]; let n = 0; for (const [i, x] of (a.encaminhamentos || []).entries()) { if (!x.acao || D.tarefas.some(tf => tf.origem && tf.origem.ata === a.id && tf.origem.i === i)) continue; await salvar('tarefas', { titulo: x.acao, data: x.prazo || '', obs: (x.resp ? 'Responsável: ' + x.resp + ' · ' : '') + 'Encaminhamento da ata nº ' + (a.numero || '') + ' de ' + dataBR(a.data), avisar: 1, feita: false, origem: { ata: a.id, i } }); n++; } aviso(n ? n + ' tarefa(s) criada(s).' : 'Os encaminhamentos já estão nas tarefas.'); };

/* ---------- próximos dias e avisos ---------- */
function painelProximos(t) {
  const hoje = hojeISO(), xs = itensAgenda(somaDias(hoje, -1), somaDias(hoje, 14)), atras = D.tarefas.filter(x => !x.feita && proximaData(x) && proximaData(x) < hoje);
  if (!xs.length && !atras.length) return '<div class="cartao"><h3>Próximos dias</h3><p class="dica">Nada nos próximos 14 dias. <a href="#" data-a="ir" data-t="agenda">Abrir o calendário</a></p></div>';
  return '<div class="cartao"><h3>Próximos dias</h3>' + (atras.length ? '<p class="alerta verm">' + atras.length + ' tarefa(s) atrasada(s): ' + atras.map(x => '<a href="#" data-a="editarTarefa" data-id="' + x.id + '">' + e(x.titulo) + '</a>').join(', ') + '</p>' : '') + '<table class="tabela">' + xs.map(x => { const n = difDias(x.data, hoje); return '<tr class="clic" ' + (x.acao ? 'data-a="' + x.acao + '" data-id="' + x.id + '" data-dia="' + x.data + '"' : '') + '><td style="white-space:nowrap;width:9rem"><span style="display:inline-block;width:.7rem;height:.7rem;border-radius:50%;background:' + corTipo(x.tipo) + '"></span> ' + (n === 0 ? '<b>hoje</b>' : n === 1 ? 'amanhã' : n < 0 ? 'ontem' : dataBR(x.data).slice(0, 5) + ' · ' + diaSemana(x.data).slice(0, 3)) + '</td><td>' + (x.hora ? e(x.hora) + ' · ' : '') + e(x.titulo) + '</td><td><span class="etq">' + e(x.origem) + '</span></td></tr>'; }).join('') + '</table><p><a href="#" data-a="ir" data-t="agenda">Abrir o calendário</a> · <a href="#" data-a="ir" data-t="tarefas">Tarefas</a></p></div>';
}
A.permitirAvisos = async () => { if (!('Notification' in window)) return informar('Avisos do sistema', '<p>Este navegador não oferece avisos do sistema. Os avisos aparecem dentro da Tecelã.</p>'); try { const p = await Notification.requestPermission(); aviso(p === 'granted' ? 'Avisos do sistema permitidos.' : 'O navegador não permitiu os avisos. Eles continuam aparecendo dentro da Tecelã.'); } catch (x) { aviso('O navegador não permitiu os avisos.'); } };
function verificarAvisos() {
  if (!SE.app || SE.demo && !SE.avisosDemo) return; const hoje = hojeISO(), ja = CFG.prefs.avisados || {}, novos = [];
  D.tarefas.filter(x => !x.feita && x.avisar != null && proximaData(x)).forEach(x => { const pd = proximaData(x), n = difDias(pd, hoje); if (n <= x.avisar && n >= -3 && ja['t' + x.id] !== hoje) { novos.push((n < 0 ? 'Atrasada: ' : n === 0 ? 'Hoje: ' : 'Em ' + n + ' dia(s): ') + x.titulo); ja['t' + x.id] = hoje; } });
  D.eventos.filter(v => v.avisar != null && (!v.turmaId || v.turmaId === (turmaAtual() || {}).id)).forEach(v => { const n = difDias(v.data, hoje); if (n >= 0 && n <= v.avisar && ja['e' + v.id] !== hoje) { novos.push((n === 0 ? 'Hoje: ' : 'Em ' + n + ' dia(s): ') + v.titulo); ja['e' + v.id] = hoje; } });
  if (!novos.length) return; CFG.prefs.avisados = ja; gravarConfig('prefs');
  aviso('🔔 ' + novos.join(' · '));
  try { if ('Notification' in window && Notification.permission === 'granted') novos.forEach(m => new Notification('Tecelã', { body: m })); } catch (x) { }
}
setInterval(verificarAvisos, 5 * 60000);

/* ---------- dias letivos: segunda a sexta, menos feriados e recessos; sábados só quando marcados como letivos ---------- */
function eventosDoDia(iso) { const t = turmaAtual(), tid = t && t.id; return D.eventos.filter(v => !v.turmaId || v.turmaId === tid).filter(v => ocorrencias(v, iso, iso).length); }
const semAula = iso => (eventosDoDia(iso).find(v => v.tipo === 'feriado') || {}).titulo || '';
const sabadoLetivo = iso => eventosDoDia(iso).some(v => /letiv/i.test(v.titulo || '') && v.tipo !== 'feriado');
function ehLetivo(iso) { const w = new Date(iso + 'T12:00').getDay(); if (w === 0) return false; if (w === 6) return sabadoLetivo(iso); return !semAula(iso); }
function diasLetivos(de, ate) { const r = []; if (!de || !ate || ate < de) return r; let d = de, n = 0; while (d <= ate && n++ < 800) { if (ehLetivo(d)) r.push(d); d = somaDias(d, 1); } return r; }
function letivoAntes(iso) { let d = iso, n = 0; while (n++ < 40) { d = somaDias(d, -1); if (ehLetivo(d)) return d; } return ''; }
function letivoDepois(iso) { let d = iso, n = 0; while (n++ < 60) { if (ehLetivo(d)) return d; d = somaDias(d, 1); } return iso; }
