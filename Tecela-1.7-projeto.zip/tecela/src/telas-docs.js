/* ==========================================================================
   Tecelã — anotações, atas (com marcações para o boletim) e boletins.
   ========================================================================== */
'use strict';
const SECOES_PADRAO = [
  ['intro', 'Introdução da turma', 1], ['chegada', 'Chegada e acolhida', 1], ['poemaManha', 'Poema da manhã', 1], ['ritmica', 'Parte rítmica e roda', 1], ['flauta', 'Flauta', 1], ['formas', 'Desenho de forma', 1],
  ['retrospectiva', 'Retrospectiva', 1], ['conteudo', 'Conteúdo e caderno', 1], ['aquarela', 'Aquarela', 1], ['desenho', 'Desenho', 1], ['portugues', 'Língua Portuguesa', 1], ['matematica', 'Matemática', 1],
  ['licao', 'Lição de casa', 1], ['jogos', 'Jogos e brincadeiras', 1], ['religiosidade', 'Religiosidade', 1], ['lanche', 'Lanche', 1], ['pausa', 'Pausa e brincar livre', 1], ['atitudes', 'Atitudes, hábitos e assiduidade', 1],
  ['euritmia', 'Euritmia', 0], ['trabalhos', 'Trabalhos manuais', 0], ['linguas', 'Línguas estrangeiras', 0], ['musica', 'Música', 0], ['jardinagem', 'Jardinagem', 0], ['marcenaria', 'Marcenaria', 0], ['edfisica', 'Educação física', 0],
  ['conclusao', 'Conclusão', 1]];
const nomeCrit = k => k ? nomeItem('criterios', k) : '';
function modeloDaSerie(serie) {
  let m = D.modelosBoletim.find(x => x.serie === Number(serie) && !x.referencia);
  if (!m) { m = { id: 'mod' + serie, serie: Number(serie), secoes: SECOES_PADRAO.map(([key, titulo, a]) => ({ key, titulo, ativa: !!a })) }; D.modelosBoletim.push(m); IX.modelosBoletim[m.id] = m; salvar('modelosBoletim', m); }
  return m;
}
const nomeSecao = (k, serie) => { const m = modeloDaSerie(serie || (turmaAtual() || {}).serie || 1), s = m.secoes.find(x => x.key === k); return s ? s.titulo : k ? k : ''; };
const opcoesSecao = t => [['', '— sem seção —']].concat(modeloDaSerie(t.serie).secoes.filter(s => s.ativa).map(s => [s.key, s.titulo]));

/* ---------- ANOTAÇÕES ---------- */
T.anot = () => {
  const t = turmaAtual(); if (!t) return '<h1>Anotações</h1>' + vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id), f = UI.filtro;
  let h = '<h1>Anotações</h1><div class="cartao"><h3>Novo lançamento</h3><form id="fAnot"><div class="duas"><div>' + campo('Data', '<input type="date" name="data" value="' + hojeISO() + '">') +
    campo('Seção do boletim', '<select name="secao">' + opcoesSecao(t).map(([k, r]) => '<option value="' + k + '">' + e(r) + '</option>').join('') + '</select>') + campo('Critério do perfil', '<select name="criterio">' + criterios().map(([k, r]) => '<option value="' + k + '">' + e(r) + '</option>').join('') + '</select>') + '</div>' +
    '<div><span class="dica">Aluno(s) — marque um ou vários</span><div class="lista-sel">' + (al.length ? '<label class="ck"><input type="checkbox" id="ckTodos"> <b>Toda a turma</b></label>' + al.map(a => '<label class="ck"><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '"> ' + e(a.nome) + '</label>').join('') : '<p class="dica">Cadastre alunos primeiro.</p>') + '</div></div></div>' +
    campo('Anotação', '<textarea name="texto" placeholder="O que você observou?"></textarea>', 'Pode usar {nome} e {ele/ela} para o texto se ajustar a cada criança no boletim. A seção e o critério são sugeridos pelo texto (contorno amarelo).') + opcoesFrases() +
    '<div class="linha"><label class="ck"><input type="checkbox" name="estrela" checked> <span class="estrela">★</span> Usar no boletim</label><label class="ck"><input type="checkbox" name="conselho"> ⚖ Levar ao conselho</label><label class="ck"><input type="checkbox" name="sigilo"> Sigilosa (nunca impressa nem exportada)</label><span class="espaco"></span><button class="btn pri">Lançar</button></div></form></div>';
  const lista = D.anotacoes.filter(n => n.turmaId === t.id && (!f.aluno || (n.alunos || []).includes(f.aluno)) && (!f.secao || n.secao === f.secao) && (!f.crit || n.criterio === f.crit) && (!f.txt || (n.texto || '').toLowerCase().includes(f.txt.toLowerCase())) && (!f.cons || n.conselho)).sort((a, b) => (b.data || '').localeCompare(a.data || '') || (b.criado || '').localeCompare(a.criado || ''));
  h += '<div class="cartao"><div class="linha"><h3 style="margin:0">Lançamentos</h3><span class="espaco"></span><select data-c="fAluno"><option value="">Todos os alunos</option>' + al.map(a => '<option value="' + a.id + '"' + (f.aluno === a.id ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select><select data-c="fSecao">' + [['', 'Todas as seções']].concat(opcoesSecao(t).slice(1)).map(([k, r]) => '<option value="' + k + '"' + (f.secao === k ? ' selected' : '') + '>' + e(r) + '</option>').join('') + '</select><select data-c="fCrit">' + [['', 'Todos os critérios']].concat(criterios().slice(1)).map(([k, r]) => '<option value="' + k + '"' + (f.crit === k ? ' selected' : '') + '>' + e(r) + '</option>').join('') + '</select><input type="search" data-c="fTxt" placeholder="Buscar…" value="' + e(f.txt || '') + '" style="max-width:180px"><label class="ck"><input type="checkbox" data-c="fCons"' + (f.cons ? ' checked' : '') + '> ⚖ só as do conselho</label><button class="btn peq" data-a="exportarAnot">Exportar</button></div>';
  h += lista.length ? '<div class="rolagem"><table class="tabela"><tr><th>Data</th><th>Aluno(s)</th><th>Seção · critério</th><th>Anotação</th><th></th></tr>' + lista.map(n => '<tr><td>' + dataBR(n.data) + '</td><td>' + e((n.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')) + '</td><td>' + (n.secao ? '<span class="etq">' + e(nomeSecao(n.secao, t.serie)) + '</span> ' : '') + (n.criterio ? '<span class="etq viol">' + e(nomeCrit(n.criterio)) + '</span>' : '') + '</td><td>' + (n.estrela ? '<span class="estrela" title="Usar no boletim">★</span> ' : '') + (n.sigilo ? '<span class="etq sig">sigilosa</span> ' : '') + (n.conselho ? '<span class="etq" title="Levar ao conselho">⚖ conselho</span> ' : '') + origemAnot(n) + e((n.alunos || []).length === 1 ? substituir(n.texto, IX.alunos[n.alunos[0]], t) : n.texto) + '</td><td style="white-space:nowrap"><button class="icone-btn" data-a="editarAnot" data-id="' + n.id + '" title="Editar">✎</button><button class="icone-btn" data-a="apagarAnot" data-id="' + n.id + '" title="Apagar">🗑</button></td></tr>').join('') + '</table></div>' : '<p class="dica">Nenhuma anotação encontrada.</p>';
  return h + '</div>';
};
function anotFiltradas(t) { const f = UI.filtro; return D.anotacoes.filter(n => n.turmaId === t.id && (!f.aluno || (n.alunos || []).includes(f.aluno)) && (!f.secao || n.secao === f.secao) && (!f.crit || n.criterio === f.crit) && (!f.txt || (n.texto || '').toLowerCase().includes(f.txt.toLowerCase())) && (!f.cons || n.conselho)).sort((a, b) => (a.data || '').localeCompare(b.data || '')); }
A.exportarAnot = async () => {
  const t = turmaAtual(), xs = anotFiltradas(t), sig = xs.filter(n => n.sigilo).length;
  let incluir = false; if (sig) { const r = await dlg({ titulo: 'Anotações sigilosas', ok: 'Continuar', corpo: '<p>Há ' + sig + ' anotação(ões) sigilosa(s) nesta lista. Por padrão, elas ficam de fora da exportação.</p><label class="ck"><input type="checkbox" name="inc"> Incluir as sigilosas (só para uso próprio)</label>' }); if (!r) return; incluir = r.inc; }
  const ls = xs.filter(n => incluir || !n.sigilo).map(n => [dataBR(n.data), (n.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', '), nomeSecao(n.secao, t.serie), nomeCrit(n.criterio), substituir(n.texto, (n.alunos || []).length === 1 ? IX.alunos[n.alunos[0]] : null, t)]);
  const cab = ['Data', 'Aluno(s)', 'Seção', 'Critério', 'Anotação'];
  saidaDocumento({ nome: 'Anotacoes_' + t.serie + 'ano' + t.letra + '_' + t.ano, titulo: 'Anotações — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Anotações — ' + rotuloTurma(t) }, { t: 'tabela', cab, linhas: ls }] }, { csv: { cab, linhas: ls }, assunto: 'Anotações' });
};
T.anot_pos = () => {
  const f = $('#fAnot'); if (!f) return;
  ligarSugestao(f, turmaAtual());
  const todos = $('#ckTodos'); if (todos) todos.addEventListener('change', () => $$('input[name=alunos]', f).forEach(c => c.checked = todos.checked));
  f.addEventListener('submit', async ev => {
    ev.preventDefault(); const als = $$('input[name=alunos]:checked', f).map(c => c.value), texto = f.texto.value.trim();
    if (!als.length) return aviso('Marque pelo menos um aluno.'); if (!texto) return aviso('Escreva a anotação.');
    await salvar('anotacoes', { turmaId: turmaAtual().id, data: f.data.value, alunos: als, secao: f.secao.value, criterio: f.criterio.value, texto, estrela: f.estrela.checked && !f.sigilo.checked, sigilo: f.sigilo.checked, conselho: f.conselho.checked });
    render(); aviso('Anotação lançada' + (als.length > 1 ? ' para ' + als.length + ' alunos.' : '.'));
  });
};
C_.fCons = el => { UI.filtro.cons = el.checked; render(); };
C_.fAluno = el => { UI.filtro.aluno = el.value; render(); }; C_.fSecao = el => { UI.filtro.secao = el.value; render(); }; C_.fCrit = el => { UI.filtro.crit = el.value; render(); };
C_.fTxt = el => { UI.filtro.txt = el.value; clearTimeout(C_.fTxt.t); C_.fTxt.t = setTimeout(() => { render(); const i = $('[data-c=fTxt]'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 350); };
function origemAnot(n) { if (!n.origem) return ''; if (n.origem.tipo === 'ata' && IX.atas[n.origem.id]) return '<a href="#" class="etq" data-a="abrirAta" data-id="' + n.origem.id + '" title="Abrir a ata">ata nº ' + e(IX.atas[n.origem.id].numero || '') + '</a> '; if (n.origem.tipo === 'vivencia' && IX.vivencias[n.origem.id]) return '<span class="etq viol">vivência: ' + e(IX.vivencias[n.origem.id].titulo) + '</span> '; return ''; }
A.apagarAnot = d => apagarComDesfazer('anotacoes', d.id, 'Anotação apagada.');
A.editarAnot = async d => {
  const n = IX.anotacoes[d.id], t = turmaAtual(), al = alunosDaTurma(t.id);
  const v = await dlg({ titulo: 'Editar anotação', largo: true, ok: 'Salvar', corpo: '<div class="duas"><div>' + campo('Data', '<input type="date" name="data" value="' + e(n.data) + '">') + campo('Seção', '<select name="secao">' + opcoesSecao(t).map(([k, r]) => '<option value="' + k + '"' + (n.secao === k ? ' selected' : '') + '>' + e(r) + '</option>').join('') + '</select>') + campo('Critério', '<select name="criterio">' + criterios().map(([k, r]) => '<option value="' + k + '"' + (n.criterio === k ? ' selected' : '') + '>' + e(r) + '</option>').join('') + '</select>') + '</div><div class="lista-sel">' + al.map(a => '<label class="ck"><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '"' + ((n.alunos || []).includes(a.id) ? ' checked' : '') + '> ' + e(a.nome) + '</label>').join('') + '</div></div>' + campo('Anotação', '<textarea name="texto">' + e(n.texto) + '</textarea>') + '<label class="ck"><input type="checkbox" name="estrela"' + (n.estrela && !n.sigilo ? ' checked' : '') + (n.sigilo ? ' disabled' : '') + '> Usar no boletim</label><label class="ck"><input type="checkbox" name="sigilo"' + (n.sigilo ? ' checked' : '') + '> Sigilosa (nunca impressa nem levada ao boletim)</label><label class="ck"><input type="checkbox" name="conselho"' + (n.conselho ? ' checked' : '') + '> ⚖ Levar ao conselho</label>', aoAbrir: f => { const sg = f.querySelector('[name=sigilo]'), es = f.querySelector('[name=estrela]'); sg.addEventListener('change', () => { if (sg.checked) es.checked = false; es.disabled = sg.checked; }); }, validar: v => !v.alunos || !v.alunos.length ? 'Marque pelo menos um aluno.' : null });
  if (!v) return; Object.assign(n, { data: v.data, secao: v.secao, criterio: v.criterio, alunos: v.alunos, texto: v.texto, estrela: !!v.estrela && !v.sigilo, sigilo: v.sigilo, conselho: !!v.conselho }); await salvar('anotacoes', n); render();
};

/* ---------- ATAS ---------- */
T.atas = () => {
  if (UI.sub && IX.atas[UI.sub]) return editorAta(IX.atas[UI.sub]);
  const t = turmaAtual(), xs = D.atas.filter(a => !t || a.turmaId === t.id || a.tipo === 'geral' && !a.turmaId).sort((a, b) => (b.data || '').localeCompare(a.data || ''));
  let h = '<h1>Atas</h1><div class="linha"><button class="btn pri" data-a="novaAta">+ Nova ata</button><span class="dica">' + e(rotuloTurma(t)) + '</span></div>';
  if (!xs.length) return h + vazio('Nenhuma ata ainda.');
  const substituidas = new Set(D.atas.map(a => a.origemId).filter(Boolean));
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Nº</th><th>Data</th><th>Reunião</th><th>Assunto</th><th>Situação</th></tr>' + xs.map(a => '<tr class="clic" data-a="abrirAta" data-id="' + a.id + '"><td>' + e(a.numero) + '</td><td>' + dataBR(a.data) + '</td><td>' + e(nomeReuniao(a)) + '</td><td>' + e(a.assunto) + '</td><td>' + (a.estado === 'finalizado' ? '<span class="etq fin">finalizada</span>' : '<span class="etq rasc">rascunho</span>') + (substituidas.has(a.id) ? ' <span class="etq">substituída</span>' : '') + (a.origemId ? ' <span class="etq">nova versão</span>' : '') + ((a.emTempo || []).length ? ' <span class="etq">em tempo</span>' : '') + '</td></tr>').join('') + '</table></div>';
};
/* número da próxima ata do ano (o maior número usado no ano + 1) */
const proximoNumeroAta = ano => D.atas.filter(a => (a.data || '').startsWith(String(ano))).reduce((m, a) => Math.max(m, parseInt(a.numero) || 0), 0) + 1;
/* campos que se repetem de uma reunião para a outra do mesmo tipo */
function baseDeAta(a) { return { tipo: a.tipo, subtipo: a.subtipo, carater: a.carater, inicio: a.inicio, fim: a.fim, local: a.local, pauta: a.pauta, secretario: a.secretario, formato: a.formato, papel: a.papel, livro: a.livro, assinaturas: clone(a.assinaturas || { incluir: true, nomes: true }), participantes: (a.participantes || []).map(p => ({ nome: p.nome, categoria: p.categoria, email: p.email || '', presente: true })) }; }
const ultimaAtaDoTipo = (tipo, tid, menos) => D.atas.filter(a => a.tipo === tipo && a.id !== menos && (!tid || a.turmaId === tid)).sort((a, b) => (b.data || '').localeCompare(a.data || ''))[0] || null;
A.ataAPartir = async d => { await descarregarFila(); const o = IX.atas[d.id], t = IX.turmas[o.turmaId] || turmaAtual(), ano = new Date().getFullYear(), num = proximoNumeroAta(ano);
  const a = await salvar('atas', Object.assign({ turmaId: o.turmaId, numero: String(num).padStart(2, '0'), data: hojeISO(), assunto: '', cabecalho: '', texto: '', deliberacoes: '', conclusao: '', encaminhamentos: [], estado: 'rascunho' }, baseDeAta(o))); UI.sub = a.id; render(); window.scrollTo(0, 0); aviso('Nova ata criada a partir da nº ' + (o.numero || '') + '. Confira os presentes.'); };
A.abrirAta = d => { $('#modais').innerHTML = ''; UI.tela = 'atas'; UI.sub = d.id; render(); window.scrollTo(0, 0); };
A.novaAta = async () => {
  const t = turmaAtual();
  const v = await dlg({ titulo: 'Nova ata', ok: 'Criar', corpo: Object.entries(tiposAta()).map(([k, x], i) => '<label class="ck"><input type="radio" name="tipo" value="' + k + '"' + (i ? '' : ' checked') + '> <span><b>' + x.nome + '</b> — ' + x.cats.join(', ').toLowerCase() + '</span></label>').join('') + campo('Subtipo (quando o tipo tiver)', '<select name="subtipo">' + Object.values(tiposAta()).flatMap(x => x.subtipos).filter((s, i, xs) => xs.indexOf(s) === i).map(s => '<option>' + e(s) + '</option>').join('') + '</select>') + '<label class="ck"><input type="checkbox" name="base" checked> <span>Aproveitar a última ata do mesmo tipo (participantes, local, horário e pauta), quando houver</span></label>' });
  if (!v) return;
  const ano = (t ? t.ano : new Date().getFullYear()), num = proximoNumeroAta(ano);
  const prof = t && t.professora ? [{ nome: t.professora, categoria: tipoAta(v.tipo).cats.find(c => /^professor/i.test(c)) || tipoAta(v.tipo).cats[0], presente: true }] : [];
  const a = await salvar('atas', { turmaId: t ? t.id : null, tipo: v.tipo, subtipo: tipoAta(v.tipo).subtipos.includes(v.subtipo) ? v.subtipo : (tipoAta(v.tipo).subtipos[0] || ''), numero: String(num).padStart(2, '0'), livro: '', carater: carateres()[0] || '', data: hojeISO(), inicio: '', fim: '', local: CFG.escola.nome || '', assunto: '', pauta: '', participantes: prof, secretario: t ? t.professora : '', cabecalho: '', texto: '', deliberacoes: '', conclusao: '', encaminhamentos: [], formato: CFG.prefs.ataFormato || 'moderno', papel: TIM('atas').papel, assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'rascunho' });
  const ult = v.base && ultimaAtaDoTipo(v.tipo, t && t.id, a.id); if (ult) { const b = baseDeAta(ult); if (tipoAta(v.tipo).subtipos.includes(v.subtipo)) b.subtipo = v.subtipo; Object.assign(a, b); await salvar('atas', a); aviso('Participantes, local e pauta vieram da ata nº ' + (ult.numero || '') + '.'); }
  UI.sub = a.id; render();
};
function editorAta(a) {
  const fin = a.estado === 'finalizado', tipo = tipoAta(a.tipo), t = IX.turmas[a.turmaId], marcavel = true;
  let h = '<div class="linha"><button class="btn" data-a="voltarSub">← Atas</button><h2 style="margin:0">' + e(nomeReuniao(a)) + (a.numero ? ' nº ' + e(a.numero) : '') + '</h2>' + (fin ? '<span class="etq fin">finalizada</span>' : '<span class="etq rasc">rascunho</span>') + '</div>';
  h += '<div class="linha" style="margin:.8rem 0">' + (fin ? '<button class="btn pri" data-a="alterarAta" data-id="' + a.id + '">Em tempo ou nova versão</button><button class="btn" data-a="conferirAta" data-id="' + a.id + '">Conferir impressão digital</button>' : '<button class="btn pri" data-a="salvarAta" data-id="' + a.id + '">Salvar</button><button class="btn" data-a="finalizarAta" data-id="' + a.id + '">Finalizar</button>') + '<button class="btn" data-a="sairAta" data-id="' + a.id + '">Imprimir, exportar ou enviar</button><button class="btn" data-a="pautaAta" data-id="' + a.id + '">Pauta para imprimir</button><button class="btn" data-a="previaAta">Atualizar prévia</button><button class="btn" data-a="ataAPartir" data-id="' + a.id + '" title="Mesmo tipo, participantes, local e pauta; texto em branco">Nova ata a partir desta</button>' + ((a.encaminhamentos || []).some(x => x.acao) ? '<button class="btn" data-a="tarefasDaAta" data-id="' + a.id + '">Encaminhamentos → Tarefas</button>' : '') + (!fin ? '<span class="espaco"></span><button class="btn perigo" data-a="excluirAta" data-id="' + a.id + '">Excluir</button>' : '') + '</div>';
  if (fin) h += '<p class="dica">Finalizada em ' + new Date(a.finalizadoEm).toLocaleString('pt-BR') + ' · impressão digital ' + e((a.hash || '').slice(0, 16)) + '…</p>';
  if (a.substitui) h += '<p class="alerta">Esta é uma nova versão que substitui a ata de ' + dataBR(a.substitui) + '. A original permanece guardada.</p>';
  h += '<fieldset style="border:0;padding:0;margin:0" ' + (fin ? 'disabled' : '') + ' data-rec="atas:' + a.id + '">';
  h += '<div class="cartao"><h3>Identificação</h3><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Tipo', sel('tipo', a.tipo, opcoesLista('tiposAta', '', a.tipo), 'data-rr="1"')) + (tipo.subtipos.length ? campo('Subtipo', sel('subtipo', a.subtipo, tipo.subtipos.concat(a.subtipo && !tipo.subtipos.includes(a.subtipo) ? [a.subtipo] : []), 'data-rr="1"')) : '') + campo('Caráter', sel('carater', a.carater, opcoesLista('carateres', '', a.carater))) + campo('Número', inp('numero', a.numero)) + campo('Livro', inp('livro', a.livro)) + '</div>' +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Data', inp('data', a.data, 'date')) + campo('Início', inp('inicio', a.inicio, 'time')) + campo('Término', inp('fim', a.fim, 'time')) + campo('Local', inp('local', a.local)) + '</div>' + campo('Assunto', inp('assunto', a.assunto)) + campo('Pauta', area('pauta', a.pauta, 'style="min-height:4rem"'), 'Um item por linha.') +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">' + campo('Quem secretariou / lavrou', inp('secretario', a.secretario)) + campo('Formato do texto', sel('formato', a.formato || 'moderno', [['moderno', 'Moderno (parágrafos)'], ['tradicional', 'Tradicional (texto corrido)']])) + campo('Papel', sel('papel', a.papel || 'A4', [['A4', 'A4 (210 × 297 mm)'], ['oficio', 'Ofício (216 × 330 mm)']])) + '</div></div>';
  h += '<div class="cartao"><h3>Participantes</h3><div class="rolagem"><table class="tabela"><tr><th>Nome</th><th>Categoria</th><th>Presente</th><th>Ausência justificada</th><th>E-mail</th><th></th></tr>' + (a.participantes || []).map((p, i) => '<tr><td>' + inp('participantes.' + i + '.nome', p.nome) + '</td><td>' + sel('participantes.' + i + '.categoria', p.categoria, tipo.cats.concat(p.categoria && !tipo.cats.includes(p.categoria) ? [p.categoria] : [])) + '</td><td style="text-align:center"><input type="checkbox" data-b="participantes.' + i + '.presente"' + (p.presente !== false ? ' checked' : '') + '></td><td style="text-align:center"><input type="checkbox" data-b="participantes.' + i + '.justificada"' + (p.justificada ? ' checked' : '') + '></td><td>' + inp('participantes.' + i + '.email', p.email, 'email') + '</td><td><button type="button" class="icone-btn" data-a="remPart" data-id="' + a.id + '" data-i="' + i + '" title="Remover">✕</button></td></tr>').join('') + '</table></div><div class="linha" style="margin-top:.5rem"><button type="button" class="btn peq" data-a="addPart" data-id="' + a.id + '">+ Participante</button>' + (t && a.tipo !== 'colegiado' ? '<button type="button" class="btn peq" data-a="addFamilias" data-id="' + a.id + '">+ Familiares da turma</button>' : '') + '</div></div>';
  h += '<div class="cartao"><h3>Texto da ata</h3><p class="dica">Os nomes dos campos não aparecem no documento. Campos em branco são ignorados.</p>' + campo('Abertura (cabeçalho)', area('cabecalho', a.cabecalho, 'data-campo-ata="1" style="min-height:4.5rem" placeholder="Em branco: a Tecelã escreve a abertura com data, local, participantes e assunto."'), '<a href="#" data-a="verAbertura" data-id="' + a.id + '">Ver a abertura automática</a>') +
    campo('Texto geral', area('texto', a.texto, 'class="alto" data-campo-ata="1"')) + campo('Deliberações', area('deliberacoes', a.deliberacoes, 'data-campo-ata="1"')) + campo('Conclusão', area('conclusao', a.conclusao, 'data-campo-ata="1"')) + '</div>';
  h += '<div class="cartao"><h3>Encaminhamentos</h3>' + (a.encaminhamentos || []).map((x, i) => '<div class="grade" style="grid-template-columns:3fr 2fr 1.3fr auto;gap:.5rem;align-items:end">' + campo('Ação', inp('encaminhamentos.' + i + '.acao', x.acao)) + campo('Responsável', inp('encaminhamentos.' + i + '.resp', x.resp)) + campo('Prazo', inp('encaminhamentos.' + i + '.prazo', x.prazo, 'date')) + '<button type="button" class="icone-btn" style="margin-bottom:.8rem" data-a="remEnc" data-id="' + a.id + '" data-i="' + i + '">✕</button></div>').join('') + '<button type="button" class="btn peq" data-a="addEnc" data-id="' + a.id + '">+ Encaminhamento</button></div>';
  const as = a.assinaturas || {}, npres = (a.participantes || []).filter(p => p.presente !== false && p.nome).length;
  h += '<div class="cartao"><h3>Assinaturas</h3>' + ck('assinaturas.incluir', as.incluir !== false, 'Imprimir a lista de assinaturas', 'data-rr="1"') + (as.incluir !== false ? '<div class="duas">' + campo('Quantidade de linhas', inp('assinaturas.linhas', as.linhas || npres, 'number', 'min="1"'), 'Padrão: número de presentes (' + npres + ')') + ck('assinaturas.nomes', as.nomes !== false, 'Imprimir o nome sob cada linha') + '</div>' : '') + '</div>';
  h += '</fieldset>';
  const ms = D.marcacoes.filter(m => m.ataId === a.id);
  if (marcavel) h += '<div class="cartao"><h3>Trechos para os alunos <span class="dica">(a marcação não é impressa)</span></h3><p class="dica">Selecione uma frase ou um parágrafo em “Abertura”, “Texto geral”, “Deliberações” ou “Conclusão” e toque em “Marcar trecho”. Ele vira uma anotação no cadastro do aluno e, se você quiser, vai para o boletim.</p><button class="btn" data-a="marcarTrecho" data-id="' + a.id + '">🖍 Marcar trecho para aluno(s)</button>' + (ms.length ? '<table class="tabela" style="margin-top:.6rem"><tr><th>Trecho</th><th>Aluno(s)</th><th>Seção</th><th></th></tr>' + ms.map(m => '<tr><td><span class="marcado">' + e(m.trecho) + '</span></td><td>' + e((m.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')) + '</td><td>' + e(nomeSecao(m.secao, t && t.serie)) + '</td><td><button class="icone-btn" data-a="remMarca" data-id="' + m.id + '">✕</button></td></tr>').join('') + '</table>' : '') + '</div>';
  if ((a.emTempo || []).length) h += '<div class="cartao"><h3>Em tempo</h3>' + a.emTempo.map(x => '<p><span class="etq">' + dataBR(x.data) + '</span> <span class="mao">' + e(x.texto) + '</span></p>').join('') + '</div>';
  h += '<div class="cartao"><h3>Prévia</h3><div class="previa" id="previaAta">' + previaAta(a) + '</div></div>';
  return h;
}
function previaAta(a) {
  let html = htmlDoc(docAta(a), true);
  D.marcacoes.filter(m => m.ataId === a.id && m.trecho && m.trecho.length > 3).forEach(m => { const t = e(m.trecho); html = html.split(t).join('<span class="marcado" title="Marcado para o boletim">' + t + '</span>'); });
  return html;
}
T.atas_pos = () => { $$('[data-campo-ata]').forEach(el => el.addEventListener('focus', () => SE.ultCampoAta = el)); };
A.previaAta = () => { const a = IX.atas[UI.sub]; if (a && $('#previaAta')) { $('#previaAta').innerHTML = previaAta(a); aviso('Prévia atualizada.'); } };
A.verAbertura = d => { const a = IX.atas[d.id]; informar('Abertura automática', '<p>' + e(aberturaAta(a, IX.turmas[a.turmaId])) + '</p><p class="dica">Ela é usada quando o campo “Abertura” fica em branco.</p>'); };
A.addPart = async d => { const a = IX.atas[d.id]; a.participantes = (a.participantes || []).concat([{ nome: '', categoria: tipoAta(a.tipo).cats[0], presente: true }]); await salvar('atas', a); render(); };
A.remPart = async d => { const a = IX.atas[d.id]; a.participantes.splice(Number(d.i), 1); await salvar('atas', a); render(); };
A.addFamilias = async d => {
  const a = IX.atas[d.id], ja = new Set((a.participantes || []).map(p => p.nome));
  alunosDaTurma(a.turmaId).forEach(al => (al.responsaveis || []).forEach(r => { if (r.nome && !ja.has(r.nome)) { a.participantes.push({ nome: r.nome, categoria: tipoAta(a.tipo).cats.find(c => /famil/i.test(c)) || tipoAta(a.tipo).cats[0], presente: true, email: r.email || '' }); ja.add(r.nome); } }));
  await salvar('atas', a); render();
};
A.addEnc = async d => { const a = IX.atas[d.id]; a.encaminhamentos = (a.encaminhamentos || []).concat([{ acao: '', resp: '', prazo: '' }]); await salvar('atas', a); render(); };
A.remEnc = async d => { const a = IX.atas[d.id]; a.encaminhamentos.splice(Number(d.i), 1); await salvar('atas', a); render(); };
A.excluirAta = async d => { if (!(await confirmar('Excluir esta ata?', 'O rascunho e suas marcações serão apagados.', 'Excluir'))) return; for (const m of D.marcacoes.filter(m => m.ataId === d.id)) await apagar('marcacoes', m.id); await apagar('atas', d.id); UI.sub = null; render(); };
const emailsAta = a => (a.participantes || []).map(p => p.email).filter(Boolean);
A.salvarAta = async d => { await descarregarFila(); const a = IX.atas[d.id]; aviso('Ata salva.'); render(); await perguntarEnvio(docAta(a), { para: emailsAta(a), assunto: 'Ata — ' + nomeReuniao(a) + ' de ' + dataBR(a.data) }); };
A.finalizarAta = async d => { const a = IX.atas[d.id]; if (await finalizar('atas', a)) { render(); await perguntarEnvio(docAta(a), { para: emailsAta(a), assunto: 'Ata — ' + nomeReuniao(a) + ' de ' + dataBR(a.data) }); } };
A.alterarAta = async d => { const n = await alterarFinalizado('atas', IX.atas[d.id]); if (n) { UI.sub = n.id; render(); } };
A.conferirAta = async d => { const ok = await conferirHash('atas', IX.atas[d.id]); informar('Impressão digital', ok ? '<p>✔ O conteúdo é idêntico ao do momento da finalização.</p>' : '<p class="alerta verm">O conteúdo não confere com a impressão digital registrada.</p>'); };
A.sairAta = async d => { await descarregarFila(); const a = IX.atas[d.id]; saidaDocumento(docAta(a), { para: emailsAta(a), assunto: 'Ata — ' + nomeReuniao(a) + ' de ' + dataBR(a.data) }); };
A.marcarTrecho = async d => {
  const a = IX.atas[d.id], el = SE.ultCampoAta; let trecho = '';
  if (el && el.selectionEnd > el.selectionStart) trecho = el.value.substring(el.selectionStart, el.selectionEnd).trim();
  const t = IX.turmas[a.turmaId] || turmaAtual(), al = alunosDaTurma(t.id);
  const v = await dlg({ titulo: 'Marcar trecho para o boletim', largo: true, ok: 'Marcar', corpo: (trecho ? '' : '<p class="alerta">Nenhum trecho selecionado. Selecione o texto no campo da ata ou escreva abaixo.</p>') + campo('Trecho', '<textarea name="trecho">' + e(trecho) + '</textarea>') + '<div class="duas"><div><span class="dica">Para o boletim de:</span><div class="lista-sel">' + al.map(x => '<label class="ck"><input type="checkbox" name="alunos" data-multi="1" value="' + x.id + '"> ' + e(x.nome) + '</label>').join('') + '</div></div>' + '<div>' + campo('Seção do boletim', '<select name="secao">' + opcoesSecao(t).map(([k, r]) => '<option value="' + k + '">' + e(r) + '</option>').join('') + '</select>') + campo('Critério do perfil', '<select name="criterio">' + criterios().map(([k, r]) => '<option value="' + k + '">' + e(r) + '</option>').join('') + '</select>') + '<label class="ck"><input type="checkbox" name="estrela" checked> <span class="estrela">★</span> Usar no boletim</label><label class="ck"><input type="checkbox" name="sigilo"> Sigilosa</label></div></div><p class="dica">O trecho vira uma anotação no cadastro do aluno, ligada a esta ata. Na ata, ele não é impresso de forma diferente.</p>', aoAbrir: f => { const sg = f.querySelector('[name=sigilo]'), es = f.querySelector('[name=estrela]'); sg.addEventListener('change', () => { if (sg.checked) es.checked = false; es.disabled = sg.checked; }); }, validar: v => !v.trecho.trim() ? 'Informe o trecho.' : !v.alunos || !v.alunos.length ? 'Escolha pelo menos um aluno.' : null });
  if (!v) return;
  const n = await salvar('anotacoes', { turmaId: a.turmaId || t.id, data: a.data || hojeISO(), alunos: v.alunos, secao: v.secao, criterio: v.criterio, texto: v.trecho.trim(), estrela: !!v.estrela && !v.sigilo, sigilo: !!v.sigilo, origem: { tipo: 'ata', id: a.id } });
  await salvar('marcacoes', { ataId: a.id, trecho: v.trecho.trim(), alunos: v.alunos, secao: v.secao, data: a.data, anotacaoId: n.id }); render(); aviso('Trecho registrado como anotação' + (v.estrela && !v.sigilo ? ' e marcado para o boletim.' : '.'));
};
A.remMarca = async d => { const m = IX.marcacoes[d.id]; if (!(await confirmar('Remover a marcação?', 'A anotação criada a partir deste trecho também será apagada.', 'Remover'))) return; if (m.anotacaoId && IX.anotacoes[m.anotacaoId]) await apagar('anotacoes', m.anotacaoId); await apagar('marcacoes', d.id); render(); };

/* ---------- BOLETINS ---------- */
function boletinsAtuais(tid) {
  const r = {}; D.boletins.filter(b => b.turmaId === tid).forEach(b => { const x = r[b.alunoId]; if (!x || (b.criado || '') > (x.criado || '')) r[b.alunoId] = b; }); return r;
}
function statusBoletim(b) {
  const tu = IX.turmas[b.turmaId], tb = (tu && tu.boletim) || {}, mod = modeloDaSerie(tu ? tu.serie : 1), st = {};
  mod.secoes.filter(s => s.ativa).forEach(s => { const ind = ((b.secoes || {})[s.key] || {}).texto, tur = (tb.textos || {})[s.key]; st[s.key] = ind && ind.trim() ? 'p' : tur && tur.trim() ? 'r' : 'v'; });
  const incompleto = Object.values(st).includes('v') || !(b.poemaTexto || '').trim();
  return { st, incompleto };
}
function trazerAnotacoes(b) {
  const tu = IX.turmas[b.turmaId]; b.importadas = b.importadas || []; b.secoes = b.secoes || {}; let n = 0; const vistos = new Set();
  const add = (id, sec, txt) => { if (!sec || b.importadas.includes(id) || vistos.has(sec + '|' + txt)) return; vistos.add(sec + '|' + txt); const s = b.secoes[sec] = b.secoes[sec] || { texto: '' }; s.texto = (s.texto ? s.texto.trim() + '\n\n' : '') + txt.trim(); b.importadas.push(id); n++; };
  Object.values(b.secoes).forEach(s => (s.texto || '').split(/\n\n/).forEach(p => vistos.add('x|' + p.trim())));
  D.anotacoes.filter(x => x.estrela && !x.sigilo && x.secao && (x.alunos || []).includes(b.alunoId) && (x.turmaId === b.turmaId || (x.data || '').startsWith(String(tu.ano)))).sort((x, y) => (x.data || '').localeCompare(y.data || '')).forEach(x => add(x.id, x.secao, x.texto));
  const atasDaTurma = new Set(D.atas.filter(a => a.turmaId === b.turmaId).map(a => a.id));
  D.marcacoes.filter(m => !m.anotacaoId && atasDaTurma.has(m.ataId) && (m.alunos || []).includes(b.alunoId)).sort((x, y) => (x.data || '').localeCompare(y.data || '')).forEach(m => add(m.id, m.secao, m.trecho));
  return n;
}
async function boletimDe(t, a) {
  const atual = boletinsAtuais(t.id)[a.id]; if (atual) return atual;
  const b = { turmaId: t.id, alunoId: a.id, ano: t.ano, secoes: {}, importadas: [], poemaTitulo: '', poemaTexto: '', estado: 'rascunho' };
  trazerAnotacoes(b); return salvar('boletins', b);
}
T.bol = () => {
  const t = turmaAtual(); if (!t) return '<h1>Boletins</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && IX.boletins[UI.sub]) return editorBoletim(IX.boletins[UI.sub]);
  const aba = UI.aba.bol || 'alunos';
  return '<h1>Boletins descritivos</h1><p class="dica">' + e(rotuloTurma(t)) + ' · boletim anual</p>' + abas([['alunos', 'Alunos e conferência'], ['turma', 'Textos da turma'], ['poemas', 'Poema do ano'], ['secoes', 'Seções do ' + t.serie + 'º ano']], aba) + ({ alunos: abaBolAlunos, turma: abaBolTurma, poemas: abaBolPoemas, secoes: abaBolSecoes }[aba] || abaBolAlunos)(t);
};
function abaBolAlunos(t) {
  const al = alunosDaTurma(t.id); if (!al.length) return vazio('Cadastre os alunos da turma.');
  const bols = boletinsAtuais(t.id), mod = modeloDaSerie(t.serie), ativas = mod.secoes.filter(s => s.ativa);
  let h = '<div class="linha"><button class="btn" data-a="exportarTodos">Exportar todos num só documento</button><button class="btn" data-a="finalizarTodos" title="Finaliza de uma vez os boletins completos">✓ Finalizar os boletins prontos</button><button class="btn" data-a="conferirBol" title="Frases repetidas, seções fora do tamanho e concordância de gênero">Conferir os textos</button><button class="btn" data-a="zipBoletins">Um arquivo por criança (.zip)</button><button class="btn" data-a="trazerTodos">Trazer novas anotações para todos</button><button class="btn" data-a="rascunhoTodos" title="Usa a última observação do período">◎ Rascunho da observação nas seções vazias</button></div>';
  h += '<div class="cartao rolagem"><h3>Painel de conferência</h3><p class="dica"><span class="etq" style="background:var(--azulC)">texto individual</span> <span class="etq" style="background:var(--amarC)">só texto da turma</span> <span class="etq" style="background:var(--vermC)">vazio</span></p><table class="tabela conf"><tr><th style="text-align:left">Aluno</th>' + ativas.map(s => '<th title="' + e(s.titulo) + '" style="writing-mode:vertical-rl;transform:rotate(180deg);font-size:.72rem;text-transform:none;letter-spacing:0;height:7.5rem">' + e(s.titulo) + '</th>').join('') + '<th>Poema</th><th>Situação</th></tr>' +
    al.map(a => { const b = bols[a.id]; const st = b ? statusBoletim(b).st : {}; return '<tr class="clic" data-a="abrirBol" data-al="' + a.id + '"><td style="text-align:left;white-space:nowrap"><b>' + e(a.nome) + '</b></td>' + ativas.map(s => { const v = st[s.key] || ((t.boletim || {}).textos || {})[s.key] ? (st[s.key] || 'r') : 'v'; return '<td class="' + v + '">' + (v === 'p' ? '●' : v === 'r' ? '○' : '·') + '</td>'; }).join('') + '<td class="' + (b && b.poemaTexto ? 'p' : 'v') + '">' + (b && b.poemaTexto ? '●' : '·') + '</td><td>' + (!b ? '<span class="etq">não iniciado</span>' : b.estado === 'finalizado' ? '<span class="etq fin">finalizado</span>' : '<span class="etq rasc">rascunho</span>') + '</td></tr>'; }).join('') + '</table></div>';
  return h;
}
A.abrirBol = async d => { const t = turmaAtual(), b = await boletimDe(t, IX.alunos[d.al]); UI.sub = b.id; render(); window.scrollTo(0, 0); };
A.trazerTodos = async () => { const t = turmaAtual(); let n = 0; for (const a of alunosDaTurma(t.id)) { const b = await boletimDe(t, a); if (b.estado !== 'finalizado') { n += trazerAnotacoes(b); await salvar('boletins', b); } } render(); aviso(n ? n + ' anotação(ões) e marcação(ões) trazidas.' : 'Nada novo para trazer.'); };
A.rascunhoTodos = async () => {
  await descarregarFila(); const t = turmaAtual(); let n = 0, c = 0;
  for (const a of alunosDaTurma(t.id)) { const b = await boletimDe(t, a); if (b.estado === 'finalizado') continue; const k = preencherVazias(b); if (k) { n += k; c++; await salvar('boletins', b); } }
  render(); aviso(n ? n + ' seção(ões) preenchida(s) em ' + c + ' boletim(ns), a partir da observação do período. Revise cada texto.' : 'Nada a preencher: não há seções vazias com observação marcada.');
};
function preencherVazias(b) {
  const t = IX.turmas[b.turmaId]; b.secoes = b.secoes || {}; let n = 0;
  modeloDaSerie(t.serie).secoes.filter(s => s.ativa && s.key !== 'intro').forEach(s => { const atual = (b.secoes[s.key] || {}).texto; if (atual && atual.trim()) return; const r = rascunhoObs(b, s.key); if (r) { b.secoes[s.key] = Object.assign(b.secoes[s.key] || {}, { texto: r, rascunhoObs: true }); n++; } });
  return n;
}
A.rascunhoSec = async d => {
  await descarregarFila(); const b = IX.boletins[d.id], r = rascunhoObs(b, d.s);
  if (!r) return informar('Sem rascunho para esta seção', motivoSemRascunho(b, d.s));
  const s = b.secoes[d.s] = b.secoes[d.s] || { texto: '' }; s.texto = (s.texto && s.texto.trim() ? s.texto.trim() + '\n\n' : '') + r; await salvar('boletins', b); render(); aviso('Rascunho acrescentado ao fim do texto. Ajuste à sua maneira.');
};
A.rascunhoBol = async d => { await descarregarFila(); const b = IX.boletins[d.id], n = preencherVazias(b); await salvar('boletins', b); render(); aviso(n ? n + ' seção(ões) vazia(s) preenchida(s) com o rascunho da observação.' : 'Nenhuma seção vazia com observação marcada.'); };
A.zipBoletins = async () => {
  await descarregarFila(); const t = turmaAtual(), al = alunosDaTurma(t.id); if (!al.length) return;
  const v = await dlg({ titulo: 'Um arquivo por criança', ok: 'Gerar o .zip', corpo: '<p>Gera um arquivo .zip com o boletim de cada criança, prontos para enviar a cada família.</p><label class="ck"><input type="radio" name="f" value="docx" checked> Word (.docx)</label><label class="ck"><input type="radio" name="f" value="html"> Página para imprimir ou salvar em PDF (.html)</label>' }); if (!v) return;
  aviso('Gerando ' + al.length + ' boletins…'); const arqs = [];
  for (const a of al) { const doc = docBoletim(await boletimDe(t, a)), nome = nomeArq('Boletim_' + a.nome + '_' + t.ano); arqs.push(v.f === 'docx' ? { nome: nome + '.docx', blob: await docxBlob(doc) } : { nome: nome + '.html', blob: new Blob(['<!doctype html><meta charset="utf-8"><title>' + e(doc.titulo) + '</title><style>@page{size:A4;margin:20mm}body{font-family:Georgia,serif;max-width:170mm;margin:auto}</style>' + htmlDoc(doc)], { type: 'text/html' }) }); }
  const z = await zipBlob(arqs), r = await salvarComo(nomeArq('Boletins_' + t.serie + 'ano' + (t.letra || '') + '_' + t.ano) + '.zip', z, 'application/zip', 'Arquivo .zip'); if (r) aviso('Arquivo salvo: ' + r.nome);
};
A.exportarTodos = async () => {
  const t = turmaAtual(), docs = []; for (const a of alunosDaTurma(t.id)) docs.push(docBoletim(await boletimDe(t, a)));
  if (!docs.length) return; const blocos = []; docs.forEach((d, i) => { if (i) blocos.push({ t: 'quebra' }); blocos.push(...d.blocos); });
  const para = []; alunosDaTurma(t.id).forEach(a => (a.responsaveis || []).forEach(r => r.email && para.push(r.email)));
  saidaDocumento(Object.assign({}, docs[0], { nome: 'Boletins_' + t.serie + 'ano' + t.letra + '_' + t.ano, titulo: 'Boletins descritivos — ' + rotuloTurma(t), blocos }), { para, assunto: 'Boletins descritivos — ' + rotuloTurma(t) });
};
function abaBolTurma(t) {
  t.boletim = t.boletim || { textos: {} }; const tb = t.boletim, mod = modeloDaSerie(t.serie), as = tb.assinaturas || {};
  let h = '<div data-rec="turmas:' + t.id + '"><div class="cartao"><p>O <b>texto da turma</b> é escrito uma vez e entra no boletim de todas as crianças, logo antes do texto individual de cada seção.</p><p class="dica">Marcadores: <code>{nome}</code> vira o nome de chamada; <code>{ele/ela}</code>, <code>{o/a}</code>, <code>{dele/dela}</code>, <code>{aluno/aluna}</code> escolhem a forma pelo gênero cadastrado. Qualquer par entre chaves com barra funciona, como <code>{menino/menina}</code>.</p></div>' +
    '<div class="cartao"><h3>Citação</h3>' + campo('Texto da citação', area('boletim.citacao', tb.citacao, 'style="min-height:4.5rem"')) + campo('Autor', inp('boletim.citacaoAutor', tb.citacaoAutor)) + '</div>';
  h += mod.secoes.filter(s => s.ativa).map(s => '<div class="secao-bol"><h4>' + e(s.titulo) + (s.key === 'intro' ? ' <button type="button" class="btn peq" data-a="rascunhoIntro">✦ Rascunho da introdução</button>' : '') + '</h4>' + area('boletim.textos.' + s.key, (tb.textos || {})[s.key], 'placeholder="Texto da turma para esta seção (opcional)"') + '</div>').join('');
  h += '<div class="cartao"><h3>Assinaturas (padrão da turma)</h3>' + ck('boletim.assinaturas.prof', as.prof, 'Linha de assinatura da professora') + ck('boletim.assinaturas.coord', as.coord, 'Linha de assinatura da coordenação') + campo('Nome da coordenação (opcional)', inp('boletim.assinaturas.coordNome', as.coordNome)) + '</div></div>';
  return h;
}
/* poema do ano: cada criança recebe um poema por ano escolar; ele vive no boletim do ano */
function abaBolPoemas(t) {
  const al = alunosDaTurma(t.id); if (!al.length) return vazio('Cadastre os alunos da turma.');
  const bols = boletinsAtuais(t.id), feitos = al.filter(a => bols[a.id] && (bols[a.id].poemaTexto || '').trim()).length;
  let h = '<div class="cartao"><p>Escreva aqui o <b>poema do ano</b> de cada criança do ' + t.serie + 'º ano. Ele entra no fim do boletim. Cada criança recebe um poema por ano escolar; os dos anos anteriores ficam no cadastro dela.</p><p class="dica">' + feitos + ' de ' + al.length + ' poemas escritos.</p></div>';
  al.forEach(a => {
    const b = bols[a.id], fin = b && b.estado === 'finalizado', ant = poemasDe(a.id).filter(x => x.turma.id !== t.id);
    h += '<details class="cartao"' + (b && (b.poemaTexto || '').trim() ? '' : ' open') + '><summary style="cursor:pointer"><b>' + e(a.nome) + '</b> ' + (b && (b.poemaTexto || '').trim() ? '<span class="etq fin">' + e(b.poemaTitulo || 'escrito') + '</span>' : '<span class="etq rasc">sem poema</span>') + (fin ? ' <span class="etq">boletim finalizado</span>' : '') + '</summary>';
    if (!b) h += '<p><button class="btn peq" data-a="abrirPoema" data-al="' + a.id + '">Escrever o poema</button></p>';
    else h += '<fieldset style="border:0;padding:0;margin:.5rem 0 0" ' + (fin ? 'disabled' : '') + ' data-rec="boletins:' + b.id + '">' + campo('Título', inp('poemaTitulo', b.poemaTitulo)) + campo('Poema', area('poemaTexto', b.poemaTexto, 'style="min-height:9rem"')) + '</fieldset>';
    if (ant.length) h += '<p class="dica">Anos anteriores: ' + ant.map(x => e(x.turma.serie + 'º ano (' + x.turma.ano + ')') + ': <i>' + e(x.titulo || 'sem título') + '</i>').join(' · ') + '</p>';
    h += '</details>';
  });
  return h;
}
function poemasDe(aid) { const r = {}; D.boletins.filter(b => b.alunoId === aid && (b.poemaTexto || '').trim()).forEach(b => { const x = r[b.turmaId]; if (!x || (b.criado || '') > (x.criado || '')) r[b.turmaId] = b; }); return Object.values(r).map(b => ({ turma: IX.turmas[b.turmaId], titulo: b.poemaTitulo, texto: b.poemaTexto, bol: b })).filter(x => x.turma).sort((a, b) => a.turma.ano - b.turma.ano); }
A.abrirPoema = async d => { await boletimDe(turmaAtual(), IX.alunos[d.al]); render(); };
A.rascunhoIntro = async () => {
  const t = turmaAtual(); t.boletim = t.boletim || { textos: {} }; t.boletim.textos = t.boletim.textos || {};
  const al = alunosDaTurma(t.id), meninas = al.filter(a => a.genero === 'f').length, eps = D.curriculo.filter(c => c.serie === t.serie && (c.realizadas || []).includes(t.id)).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)), eps2 = eps.length ? eps : D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  const vs = D.vivencias.filter(v => v.turmaId === t.id).sort((a, b) => (a.data || '').localeCompare(b.data || '')), bib = (IX.biblioteca['serie-' + t.serie] || {}).oculto ? null : IX.biblioteca['serie-' + t.serie];
  const ps = ['Em ' + t.ano + ', o ' + t.serie + 'º ano ' + (t.letra || '') + ' reuniu ' + al.length + ' crianças (' + meninas + ' meninas e ' + (al.length - meninas) + ' meninos).'];
  if (bib && bib.texto) ps.push('[Escreva aqui, com suas palavras, a imagem do ' + t.serie + 'º ano. Referência na Biblioteca: “' + bib.titulo + '”.]');
  if (eps2.length) ps.push('Ao longo do ano, a turma viveu as épocas de ' + juntarLista(eps2.map(c => c.titulo)) + '.');
  if (vs.length) ps.push('Também vivemos ' + juntarLista(vs.map(v => v.titulo.charAt(0).toLowerCase() + v.titulo.slice(1))) + '.');
  ps.push('[Conte como o grupo chegou, como caminhou e como termina o ano.]');
  const atual = (t.boletim.textos.intro || '').trim();
  if (atual && !(await confirmar('Substituir a introdução?', 'Já há um texto de introdução. O rascunho será acrescentado no fim dele.', 'Acrescentar'))) return;
  t.boletim.textos.intro = (atual ? atual + '\n\n' : '') + ps.join('\n\n'); await salvar('turmas', t); render(); aviso('Rascunho criado com os dados da turma. Os trechos entre colchetes são para você completar.');
};
function abaBolSecoes(t) {
  const m = modeloDaSerie(t.serie);
  return '<div class="cartao" data-rec="modelosBoletim:' + m.id + '"><p>As seções valem para todas as turmas do <b>' + t.serie + 'º ano</b>. Ligue, desligue, renomeie e reordene. Cabeçalho, título, citação e poema do novo ano são fixos.</p><table class="tabela">' + m.secoes.map((s, i) => '<tr><td style="width:2.5rem"><input type="checkbox" data-b="secoes.' + i + '.ativa"' + (s.ativa ? ' checked' : '') + ' title="Ativa"></td><td>' + inp('secoes.' + i + '.titulo', s.titulo) + '</td><td style="white-space:nowrap"><button class="icone-btn" data-a="moverSecao" data-i="' + i + '" data-d="-1" title="Subir">↑</button><button class="icone-btn" data-a="moverSecao" data-i="' + i + '" data-d="1" title="Descer">↓</button>' + (s.propria ? '<button class="icone-btn" data-a="remSecao" data-i="' + i + '" title="Remover">✕</button>' : '') + '</td></tr>').join('') + '</table><button class="btn peq" data-a="addSecao" style="margin-top:.6rem">+ Nova seção</button></div>';
}
A.moverSecao = async d => { const m = modeloDaSerie(turmaAtual().serie), i = Number(d.i), j = i + Number(d.d); if (j < 0 || j >= m.secoes.length) return; [m.secoes[i], m.secoes[j]] = [m.secoes[j], m.secoes[i]]; await salvar('modelosBoletim', m); render(); };
A.addSecao = async () => { const v = await dlg({ titulo: 'Nova seção', ok: 'Incluir', corpo: campo('Título', '<input name="t" autofocus>'), validar: v => v.t.trim() ? null : 'Informe o título.' }); if (!v) return; const m = modeloDaSerie(turmaAtual().serie); m.secoes.splice(m.secoes.length - 1, 0, { key: 's' + uid(), titulo: v.t.trim(), ativa: true, propria: true }); await salvar('modelosBoletim', m); render(); };
A.remSecao = async d => { const m = modeloDaSerie(turmaAtual().serie); if (!(await confirmar('Remover a seção?', 'Textos já escritos nesta seção deixam de aparecer nos boletins.', 'Remover'))) return; m.secoes.splice(Number(d.i), 1); await salvar('modelosBoletim', m); render(); };
function editorBoletim(b) {
  const al = IX.alunos[b.alunoId], t = IX.turmas[b.turmaId], mod = modeloDaSerie(t.serie), tb = t.boletim || {}, fin = b.estado === 'finalizado', as = b.assinaturas || tb.assinaturas || {};
  const versoes = D.boletins.filter(x => x.alunoId === b.alunoId && x.turmaId === b.turmaId && x.id !== b.id);
  let h = '<div class="linha"><button class="btn" data-a="voltarSub">← Boletins</button><h2 style="margin:0">' + e(al.nome) + '</h2>' + (fin ? '<span class="etq fin">finalizado</span>' : '<span class="etq rasc">rascunho</span>') + '</div>';
  h += '<div class="linha" style="margin:.8rem 0">' + (fin ? '<button class="btn pri" data-a="alterarBol" data-id="' + b.id + '">Em tempo ou nova versão</button><button class="btn" data-a="conferirBol" data-id="' + b.id + '">Conferir impressão digital</button>' : '<button class="btn pri" data-a="salvarBol" data-id="' + b.id + '">Salvar</button><button class="btn" data-a="trazerBol" data-id="' + b.id + '">Trazer novas anotações</button><button class="btn" data-a="rascunhoBol" data-id="' + b.id + '" title="Usa a última observação do período">◎ Rascunho nas seções vazias</button><button class="btn" data-a="finalizarBol" data-id="' + b.id + '">Finalizar</button>') + '<button class="btn" data-a="sairBol" data-id="' + b.id + '">Imprimir, exportar ou enviar</button><button class="btn" data-a="previaBol">Atualizar prévia</button></div>';
  if (versoes.length) h += '<p class="dica">Outras versões: ' + versoes.map(v => '<a href="#" data-a="abrirBolId" data-id="' + v.id + '">' + (v.estado === 'finalizado' ? 'finalizada em ' + new Date(v.finalizadoEm).toLocaleDateString('pt-BR') : 'rascunho de ' + new Date(v.criado).toLocaleDateString('pt-BR')) + '</a>').join(' · ') + '</p>';
  const pend = D.anotacoes.filter(x => x.estrela && !x.sigilo && x.secao && (x.alunos || []).includes(b.alunoId) && x.turmaId === b.turmaId && !(b.importadas || []).includes(x.id)).length;
  if (pend && !fin) h += '<p class="alerta">Há ' + pend + ' anotação(ões) com estrela ainda não trazida(s) para este boletim.</p>';
  const pts = (al.atencao || []).filter(x => x.situacao !== 'resolvido');
  const pei = peiAtivo(t, al.id); if (pei && !fin) { const ad = adaptacoesPei(pei); h += '<div class="alerta" style="background:var(--violC)"><b>PEI de ' + e(primeiroNome(al)) + '</b> <span class="dica">(só para você)</span>' + (ad ? ': ' + e(ad) : '') + ' <a href="#" data-a="abrirPei" data-id="' + pei.id + '">abrir</a></div>'; }
  if (pts.length) h += '<div class="alerta" style="background:var(--violC)"><b>Pontos de atenção de ' + e(primeiroNome(al)) + '</b> <span class="dica">(só para você; não entram no boletim)</span><ul style="margin:.3rem 0 0">' + pts.map(x => '<li><b>' + e(nomeItem('atencao', x.tipo)) + ':</b> ' + e(x.descricao) + (x.desde ? ' <span class="dica">desde ' + dataBR(x.desde) + '</span>' : '') + '</li>').join('') + '</ul></div>';
  h += '<fieldset style="border:0;padding:0;margin:0" ' + (fin ? 'disabled' : '') + ' data-rec="boletins:' + b.id + '">';
  if (tb.citacao) h += '<div class="cartao suave" style="text-align:center;font-style:italic">' + e(tb.citacao).replace(/\n/g, '<br>') + (tb.citacaoAutor ? '<br>' + e(tb.citacaoAutor) : '') + '</div>';
  h += mod.secoes.filter(s => s.ativa).map(s => { const tur = substituir((tb.textos || {})[s.key], al, t); return '<div class="secao-bol"><h4>' + e(s.titulo) + ' <button type="button" class="icone-btn" data-a="verAnotSec" data-id="' + b.id + '" data-s="' + s.key + '" title="Ver anotações desta seção">✎</button>' + (fin || !secoesComObs().has(s.key) ? '' : ' <button type="button" class="btn peq" data-a="rascunhoSec" data-id="' + b.id + '" data-s="' + s.key + '" title="Acrescenta um texto montado com as marcas da Observação do período">◎ Rascunho da observação</button>') + '</h4>' + (tur ? '<p class="dica" style="white-space:pre-line;border-left:3px solid var(--amar);padding-left:.6rem">' + e(tur) + '</p>' : '') + area('secoes.' + s.key + '.texto', ((b.secoes || {})[s.key] || {}).texto, 'placeholder="Texto individual de ' + e(primeiroNome(al)) + '"') + '</div>'; }).join('');
  h += '<div class="cartao"><h3>Poema do ano de ' + e(primeiroNome(al)) + '</h3>' + campo('Título do poema', inp('poemaTitulo', b.poemaTitulo)) + campo('Poema', area('poemaTexto', b.poemaTexto, 'class="alto"'), 'Uma estrofe por bloco; separe as estrofes com uma linha em branco. Também dá para escrever todos de uma vez em Boletins → Poema do ano.') + '</div>';
  h += '<div class="cartao"><h3>Assinaturas</h3>' + ck('assinaturas.prof', as.prof, 'Linha de assinatura da professora') + ck('assinaturas.coord', as.coord, 'Linha de assinatura da coordenação') + campo('Nome da coordenação', inp('assinaturas.coordNome', as.coordNome)) + '</div>';
  h += '</fieldset>';
  if ((b.emTempo || []).length) h += '<div class="cartao"><h3>Em tempo</h3>' + b.emTempo.map(x => '<p><span class="etq">' + dataBR(x.data) + '</span> <span class="mao">' + e(x.texto) + '</span></p>').join('') + '</div>';
  h += '<div class="cartao"><h3>Prévia</h3><div class="previa" id="previaBol">' + htmlDoc(docBoletim(b), true) + '</div></div>';
  return h;
}
A.abrirBolId = d => { UI.sub = d.id; render(); };
A.previaBol = () => { const b = IX.boletins[UI.sub]; if (b && $('#previaBol')) { $('#previaBol').innerHTML = htmlDoc(docBoletim(b), true); aviso('Prévia atualizada.'); } };
A.trazerBol = async d => { await descarregarFila(); const b = IX.boletins[d.id], n = trazerAnotacoes(b); await salvar('boletins', b); render(); aviso(n ? n + ' anotação(ões) trazida(s).' : 'Nada novo para trazer.'); };
A.verAnotSec = d => { const b = IX.boletins[d.id], t = IX.turmas[b.turmaId]; const xs = D.anotacoes.filter(x => (x.alunos || []).includes(b.alunoId) && x.secao === d.s && x.turmaId === b.turmaId); informar('Anotações · ' + nomeSecao(d.s, t.serie), xs.length ? xs.map(x => '<p><span class="etq">' + dataBR(x.data) + '</span> ' + (x.estrela ? '<span class="estrela">★</span> ' : '') + (x.sigilo ? '<span class="etq sig">sigilosa</span> ' : '') + e(x.texto) + '</p>').join('') : '<p class="dica">Nenhuma anotação nesta seção.</p>'); };
const emailsAluno = a => (a.responsaveis || []).map(r => r.email).filter(Boolean);
A.salvarBol = async d => { await descarregarFila(); const b = IX.boletins[d.id], al = IX.alunos[b.alunoId]; aviso('Boletim salvo.'); render(); await perguntarEnvio(docBoletim(b), { para: emailsAluno(al), assunto: 'Boletim descritivo de ' + primeiroNome(al) }); };
/* finaliza de uma vez os boletins completos; os incompletos ficam de fora e são listados */
A.finalizarTodos = async () => {
  await descarregarFila(); const t = turmaAtual(), bols = boletinsAtuais(t.id), al = alunosDaTurma(t.id);
  const rasc = al.map(a => [a, bols[a.id]]).filter(([, b]) => b && b.estado !== 'finalizado'), prontos = rasc.filter(([, b]) => !statusBoletim(b).incompleto), inc = rasc.filter(([, b]) => statusBoletim(b).incompleto), sem = al.filter(a => !bols[a.id]);
  if (!prontos.length) return informar('Nenhum boletim pronto para finalizar', (inc.length ? '<p>Incompletos (seção vazia ou sem poema): ' + e(inc.map(([a]) => primeiroNome(a)).join(', ')) + '.</p>' : '') + (sem.length ? '<p>Ainda sem boletim: ' + e(sem.map(primeiroNome).join(', ')) + '.</p>' : '') + (!rasc.length && !sem.length ? '<p>Todos os boletins já estão finalizados.</p>' : ''));
  const ok = await dlg({ titulo: 'Finalizar ' + prontos.length + ' boletim' + (prontos.length > 1 ? 'ns' : '') + '?', ok: 'Finalizar', corpo: '<p>Serão finalizados: <b>' + e(prontos.map(([a]) => primeiroNome(a)).join(', ')) + '</b>.</p>' + (inc.length ? '<p>Ficam de fora, por estarem incompletos (seção vazia ou sem poema): ' + e(inc.map(([a]) => primeiroNome(a)).join(', ')) + '.</p>' : '') + (sem.length ? '<p>Ainda sem boletim: ' + e(sem.map(primeiroNome).join(', ')) + '.</p>' : '') + '<p>Depois de finalizado, o boletim não pode mais ser editado: correções só com “Em tempo” ou com uma nova versão. Cada um recebe a sua impressão digital.</p>' });
  if (!ok) return;
  for (const [, b] of prontos) { b.estado = 'finalizado'; b.finalizadoEm = new Date().toISOString(); b.hash = await sha256(conteudoParaHash('boletins', b)); await salvar('boletins', b); }
  render(); aviso(prontos.length + ' boletim' + (prontos.length > 1 ? 'ns finalizados.' : ' finalizado.'));
};
A.finalizarBol = async d => { const b = IX.boletins[d.id]; if (statusBoletim(b).incompleto && !(await confirmar('Boletim incompleto', 'Há seções vazias ou falta o poema. Finalizar mesmo assim?', 'Continuar'))) return; if (await finalizar('boletins', b)) render(); };
A.alterarBol = async d => { const n = await alterarFinalizado('boletins', IX.boletins[d.id]); if (n) { UI.sub = n.id; render(); } };
A.conferirBol = async d => { const ok = await conferirHash('boletins', IX.boletins[d.id]); informar('Impressão digital', ok ? '<p>✔ O conteúdo é idêntico ao do momento da finalização.</p>' : '<p class="alerta verm">O conteúdo não confere com a impressão digital registrada.</p>'); };
A.sairBol = async d => { await descarregarFila(); const b = IX.boletins[d.id], al = IX.alunos[b.alunoId]; saidaDocumento(docBoletim(b), { para: emailsAluno(al), assunto: 'Boletim descritivo de ' + primeiroNome(al) }); };
