/* ==========================================================================
   Tecelã — Importar boletins de anos anteriores (.docx), dentro do app.
   Lê os arquivos no próprio navegador, mostra a revisão e acrescenta turmas,
   alunos e boletins (em rascunho) aos dados abertos. Nada sai do aparelho.
   ========================================================================== */
'use strict';
const nrm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
async function inflarRaw(dados) { const ds = new DecompressionStream('deflate-raw'); return new Uint8Array(await new Response(new Blob([dados]).stream().pipeThrough(ds)).arrayBuffer()); }
async function lerDocxZip(buf) {
  const v = new DataView(buf), u8 = new Uint8Array(buf), arq = {};
  let fim = -1; for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 66000); i--) if (v.getUint32(i, true) === 0x06054b50) { fim = i; break; }
  if (fim < 0) throw new Error('não é um arquivo .docx válido');
  let p = v.getUint32(fim + 16, true); const n = v.getUint16(fim + 10, true);
  for (let k = 0; k < n; k++) {
    const met = v.getUint16(p + 10, true), tam = v.getUint32(p + 20, true), ln = v.getUint16(p + 28, true), le = v.getUint16(p + 30, true), lc = v.getUint16(p + 32, true), loc = v.getUint32(p + 42, true);
    const nome = new TextDecoder().decode(u8.subarray(p + 46, p + 46 + ln)); p += 46 + ln + le + lc;
    if (!/^word\/(document|header\d*)\.xml$/.test(nome)) continue;
    const ini = loc + 30 + v.getUint16(loc + 26, true) + v.getUint16(loc + 28, true), bruto = u8.subarray(ini, ini + tam);
    arq[nome] = new TextDecoder().decode(met === 0 ? bruto : await inflarRaw(bruto));
  }
  if (!arq['word/document.xml']) throw new Error('o arquivo não tem o texto do documento');
  return arq;
}
const WNS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
function wTexto(p) { let t = ''; p.querySelectorAll('*').forEach(n => { if (n.namespaceURI !== WNS) return; if (n.localName === 't') t += n.textContent; else if (n.localName === 'tab') t += '\t'; else if (n.localName === 'br' || n.localName === 'cr') t += '\n'; }); return t; }
function wParagrafos(xml) {
  const doc = new DOMParser().parseFromString(xml, 'application/xml'), body = doc.getElementsByTagNameNS(WNS, 'body')[0] || doc.documentElement, out = [];
  const jc = p => { const j = p.getElementsByTagNameNS(WNS, 'jc')[0]; return j ? (j.getAttributeNS(WNS, 'val') || j.getAttribute('w:val')) : ''; };
  const visita = el => Array.from(el.children).forEach(c => { if (c.namespaceURI !== WNS) return; if (c.localName === 'p') out.push({ t: wTexto(c), jc: jc(c) }); else if (c.localName === 'tbl') Array.from(c.getElementsByTagNameNS(WNS, 'tr')).forEach(tr => out.push({ t: Array.from(tr.getElementsByTagNameNS(WNS, 'tc')).map(tc => Array.from(tc.getElementsByTagNameNS(WNS, 'p')).map(wTexto).join(' ')).join('\t'), jc: '' })); else if (c.localName === 'sdt' || c.localName === 'sdtContent') visita(c); });
  visita(body); return out;
}
const PALAVRAS_SECAO = {
  chegada: ['chegava', 'chegada', 'acolh', 'cumpriment', 'adentrar', 'ao chegar'], poemaManha: ['poema da manha', 'poema individual', 'recit'], ritmica: ['momento de ritmo', 'parte ritmica', 'da roda', 'na roda', 'circuito', 'lateralidade', 'perna de pau', 'pular corda', 'equilibrio'],
  flauta: ['flauta'], formas: ['desenho de forma', 'forma da semana', 'tracado'], retrospectiva: ['retrospectiva'], conteudo: ['durante o conteudo', 'caderno', 'atividade pratica', 'epoca'], aquarela: ['aquarela', 'pincel'], desenho: ['no desenho', 'gizes', 'desenho dirigido', 'seus desenhos'],
  portugues: ['lingua portuguesa', 'letras', 'leitura', 'escrita', 'alfabetiz', 'soletr', 'textos', ' le ', 'ler '], matematica: ['matematica', 'tabuada', 'numeros', 'numeracao', 'calculo', 'operacoes', 'raciocinio logico'], licao: ['licao de casa', 'tarefa de casa'],
  jogos: ['jogos e brincadeiras', 'aulas de jogos', 'pega-pega'], religiosidade: ['religiosidade'], lanche: ['lanche', 'lancheira'], pausa: ['na pausa', 'brincadeiras livres', 'brincar livre', 'no parque'], atitudes: ['assiduidade', 'pontualidade', 'comprometid', 'zeloso', 'teve respeito', 'organizacao do material'],
  euritmia: ['euritmia'], trabalhos: ['trabalhos manuais', 'croche', 'trico', 'bordado'], musica: ['musica', 'canto', 'coral'], conclusao: ['otimo desenvolvimento', 'novo ano escolar', 'foi uma alegria', 'sendo aguardad', 'assim entrego']
};
function sugerirSecaoTexto(txt, anterior) { const t = ' ' + nrm(txt) + ' '; let melhor = null, pts = 0; Object.entries(PALAVRAS_SECAO).forEach(([k, ps]) => { const n = ps.filter(p => t.includes(p)).length; if (n > pts) { pts = n; melhor = k; } }); return melhor || anterior || ''; }
function interpretarBoletim(ps, arquivo) {
  const L = ps.map(p => ({ t: p.t.replace(/ /g, ' '), jc: p.jc })), topo = L.slice(0, 12).map(l => l.t).join('\n'), pega = re => { const m = topo.match(re); return m ? m[1].trim() : ''; };
  const r = { arquivo, nome: pega(/Alun[oa]\s*:\s*([^\t\n]+?)(?=\s*(?:\t|\n|Sala\s*:|$))/i), sala: pega(/Sala\s*:\s*([^\t\n]+?)(?=\s*(?:\t|\n|$))/i), professora: pega(/Professor[a]?\s*:\s*([^\t\n]+?)(?=\s*(?:\t|\n|Ano\s*:|$))/i), ano: pega(/Ano\s*:\s*(\d{4})/i), avisos: [] };
  r.genProf = /Professor\s*:/.test(topo) && !/Professora\s*:/.test(topo) ? 'o' : 'a';
  const ms = r.sala.match(/(\d)\s*º?\s*\.?\s*(?:ano)?\s*([A-Za-z])?/); r.serie = ms ? Number(ms[1]) : null; r.letra = ms && ms[2] ? ms[2].toUpperCase() : '';
  if (!r.nome) r.avisos.push('nome não encontrado'); if (!r.ano) r.avisos.push('ano não encontrado'); if (!r.serie) r.avisos.push('série não encontrada');
  let i = L.findIndex(l => /^\s*boletim\s+descritivo\s*$/i.test(l.t)); if (i < 0) i = L.findIndex(l => /Ano\s*:/i.test(l.t)); i++;
  const cit = []; while (i < L.length && (L[i].jc === 'center' || !L[i].t.trim()) && cit.length < 12) { if (L[i].t.trim()) cit.push(L[i].t.trim()); i++; }
  r.citacao = cit.length > 1 ? cit.slice(0, -1).join('\n') : cit.join('\n'); r.citacaoAutor = cit.length > 1 ? cit[cit.length - 1] : '';
  let fimC = L.findIndex((l, k) => k >= i && /^\s*poema\s*$/i.test(l.t)); if (fimC < 0) fimC = L.length;
  r.pars = []; let sec = null; for (let k = i; k < fimC; k++) { const t = L[k].t.trim(); if (!t) continue; sec = sugerirSecaoTexto(t, sec) || 'intro'; r.pars.push({ t, sec, turma: false }); }
  const po = L.slice(fimC + 1), pi = po.findIndex(l => l.t.trim()); r.poemaTitulo = pi >= 0 ? po[pi].t.trim() : '';
  r.poemaTexto = (pi >= 0 ? po.slice(pi + 1) : []).map(l => l.t.trim()).join('\n').replace(/^\n+|\n+$/g, '').replace(/\n{3,}/g, '\n\n');
  const f = nrm(r.pars.map(p => p.t).join(' ')), conta = re => (f.match(re) || []).length;
  r.genero = /Aluna\s*:/.test(topo) ? 'f' : (conta(/\b(ela|dela|a aluna|menina|atenta|dedicada|focada)\b/g) > conta(/\b(ele|dele|o aluno|menino|atento|dedicado|focado)\b/g) ? 'f' : 'm');
  r.chamada = (r.nome || '').split(' ')[0] || '';
  return r;
}
function marcarTextoDaTurma(lista) {
  const g = {}; lista.forEach(b => (g[b.ano + '|' + b.serie + '|' + b.letra] = g[b.ano + '|' + b.serie + '|' + b.letra] || []).push(b));
  Object.values(g).forEach(gr => { if (gr.length < 2) return; const c = {}; gr.forEach(b => new Set(b.pars.map(p => nrm(p.t))).forEach(t => c[t] = (c[t] || 0) + 1)); gr.forEach(b => { b.pars.forEach(p => { p.turma = c[nrm(p.t)] >= 2; }); for (const p of b.pars) { if (!p.turma) break; p.sec = 'intro'; } }); });
}

/* ---------- tela ---------- */
const IMP = { bols: [] };
T.importar = () => {
  let h = '<h1>Importar boletins anteriores</h1>';
  if (!IMP.bols.length) return h + '<div class="cartao"><p>Escolha os boletins em <b>.docx</b> dos anos anteriores (pode escolher vários de uma vez). A Tecelã lê os arquivos neste aparelho, sem internet, e mostra uma revisão antes de acrescentar qualquer coisa.</p><ul><li>Cria as turmas (ano e sala) e os alunos que ainda não existirem.</li><li>Parágrafos repetidos em dois ou mais boletins da mesma turma viram o <b>texto da turma</b>; os demais, o texto individual.</li><li>Os boletins entram como <b>rascunhos editáveis</b>, e o poema de cada um vai para o <b>poema do ano</b> da criança.</li></ul><button class="btn pri" data-a="impEscolher">Escolher os boletins (.docx)</button></div>';
  const ok = IMP.bols.filter(b => !b.erro), tur = new Set(ok.map(b => b.ano + b.serie + b.letra)), al = new Set(ok.map(b => nrm(b.nome))), ja = ok.filter(b => D.alunos.some(a => nrm(a.nome) === nrm(b.nome))).length;
  h += '<div class="linha"><button class="btn" data-a="impCancelar">Cancelar</button><button class="btn" data-a="impEscolher">Escolher outros arquivos</button><span class="espaco"></span><button class="btn pri" data-a="impConfirmar">Importar ' + ok.length + ' boletim(ns)</button></div>';
  h += '<p>' + ok.length + ' boletim(ns) · ' + al.size + ' aluno(s), ' + ja + ' já cadastrado(s) · ' + tur.size + ' turma(s)' + (IMP.bols.length > ok.length ? ' · <b style="color:var(--verm)">' + (IMP.bols.length - ok.length) + ' arquivo(s) com erro</b>' : '') + '.</p><p class="dica">Fundo amarelo = texto da turma. Ajuste a seção de cada parágrafo se precisar, ou escolha “— ignorar —”.</p>';
  const secoes = SECOES_PADRAO.map(([k, n]) => [k, n]);
  IMP.bols.forEach((b, ib) => {
    if (b.erro) { h += '<div class="cartao"><b>' + e(b.arquivo) + '</b>: <span style="color:var(--verm)">' + e(b.erro) + '</span></div>'; return; }
    const c = (k, r, v, t) => '<label class="cp"><span class="r">' + r + '</span><input type="' + (t || 'text') + '" data-c="impCampo" data-b="' + ib + '" data-k="' + k + '" value="' + e(v) + '"></label>', s = (k, r, v, ops) => '<label class="cp"><span class="r">' + r + '</span><select data-c="impCampo" data-b="' + ib + '" data-k="' + k + '">' + ops.map(([a, n]) => '<option value="' + a + '"' + (a === v ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></label>';
    h += '<details class="cartao"' + (b.avisos.length ? ' open' : '') + '><summary style="cursor:pointer"><b>' + e(b.nome || '(sem nome)') + '</b> · ' + e((b.serie || '?') + 'º ' + b.letra + ' · ' + (b.ano || '?')) + ' <span class="dica">(' + e(b.arquivo) + ')</span>' + (b.avisos.length ? ' <span class="etq sig">' + e(b.avisos.join('; ')) + '</span>' : '') + '</summary>' +
      '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-top:.6rem">' + c('nome', 'Nome completo', b.nome) + c('chamada', 'Nome de chamada', b.chamada) + s('genero', 'Gênero', b.genero, [['m', 'Masculino'], ['f', 'Feminino']]) + c('serie', 'Série', b.serie, 'number') + c('letra', 'Letra', b.letra) + c('ano', 'Ano', b.ano, 'number') + c('professora', 'Quem deu aula', b.professora) + s('genProf', 'Professora ou professor', b.genProf, [['a', 'Professora'], ['o', 'Professor']]) + '</div>' +
      (b.citacao ? '<p class="dica"><b>Citação:</b> ' + e(b.citacao) + (b.citacaoAutor ? ' — ' + e(b.citacaoAutor) : '') + '</p>' : '') +
      '<table class="tabela"><tr><th style="width:12rem">Seção</th><th>Turma</th><th>Parágrafo</th></tr>' + b.pars.map((p, ip) => '<tr style="' + (p.turma ? 'background:var(--amarC)' : '') + '"><td><select data-c="impPar" data-b="' + ib + '" data-p="' + ip + '" data-k="sec">' + secoes.map(([k, n]) => '<option value="' + k + '"' + (k === p.sec ? ' selected' : '') + '>' + n + '</option>').join('') + '<option value=""' + (p.sec === '' ? ' selected' : '') + '>— ignorar —</option></select></td><td style="text-align:center"><input type="checkbox" data-c="impPar" data-b="' + ib + '" data-p="' + ip + '" data-k="turma"' + (p.turma ? ' checked' : '') + '></td><td style="font-size:.9rem">' + e(p.t) + '</td></tr>').join('') + '</table>' +
      (b.poemaTexto ? '<p><b>Poema do ano:</b> ' + e(b.poemaTitulo) + '</p><pre style="white-space:pre-wrap;font-family:inherit;font-size:.9rem">' + e(b.poemaTexto) + '</pre>' : '<p class="dica">Poema não encontrado.</p>') + '</details>';
  });
  return h;
};
C_.impCampo = el => { const b = IMP.bols[el.dataset.b]; b[el.dataset.k] = el.type === 'number' ? Number(el.value) : el.value; };
C_.impPar = el => { const p = IMP.bols[el.dataset.b].pars[el.dataset.p]; p[el.dataset.k] = el.type === 'checkbox' ? el.checked : el.value; el.closest('tr').style.background = p.turma ? 'var(--amarC)' : ''; };
A.impCancelar = () => { IMP.bols = []; ir(D.turmas.length ? 'turma' : 'importar'); };
A.impEscolher = async () => {
  if (typeof DecompressionStream !== 'function') return informar('Navegador antigo', '<p>Para ler arquivos .docx, use uma versão recente do Chrome, Edge, Firefox ou Safari.</p>');
  const fs = await new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.multiple = true; i.accept = '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document'; i.style.display = 'none'; document.body.appendChild(i); i.onchange = () => { res(Array.from(i.files)); i.remove(); }; i.click(); });
  if (!fs.length) return; IMP.bols = [];
  for (const f of fs) { try { const z = await lerDocxZip(await f.arrayBuffer()); IMP.bols.push(interpretarBoletim(Object.keys(z).filter(k => /header/.test(k)).flatMap(k => wParagrafos(z[k])).concat(wParagrafos(z['word/document.xml'])), f.name)); } catch (x) { IMP.bols.push({ arquivo: f.name, erro: x.message, pars: [], avisos: [] }); } }
  marcarTextoDaTurma(IMP.bols.filter(b => !b.erro)); UI.tela = 'importar'; render();
};
A.impConfirmar = async () => {
  const ok = IMP.bols.filter(b => !b.erro && b.nome && b.ano && b.serie); if (!ok.length) return aviso('Nenhum boletim com nome, série e ano para importar.');
  let nT = 0, nA = 0, nB = 0, nP = 0;
  for (const b of ok) {
    let t = D.turmas.find(x => x.ano === Number(b.ano) && x.serie === Number(b.serie) && String(x.letra || '').toUpperCase() === String(b.letra || '').toUpperCase());
    if (!t) { t = await salvar('turmas', { ano: Number(b.ano), serie: Number(b.serie), letra: b.letra, professora: b.professora, genProf: b.genProf, boletim: { textos: {} } }); nT++; }
    let a = D.alunos.find(x => nrm(x.nome) === nrm(b.nome));
    if (!a) { a = await salvar('alunos', { nome: b.nome.trim(), chamada: b.chamada, genero: b.genero, situacao: 'ativo', responsaveis: [{ nome: '', parentesco: '', email: '', tel: '' }], obs: 'Cadastro criado a partir dos boletins anteriores. Complete a data de nascimento e os responsáveis.' }); nA++; }
    if (!matricula(t.id, a.id)) await salvar('matriculas', { alunoId: a.id, turmaId: t.id, faltas: [] });
    t.boletim = t.boletim || { textos: {} }; t.boletim.textos = t.boletim.textos || {}; if (b.citacao && !t.boletim.citacao) { t.boletim.citacao = b.citacao; t.boletim.citacaoAutor = b.citacaoAutor; }
    const secoes = {}; b.pars.filter(p => p.sec).forEach(p => { if (p.turma) { if (!t.boletim.textos[p.sec]) t.boletim.textos[p.sec] = p.t; else if (!t.boletim.textos[p.sec].includes(p.t)) t.boletim.textos[p.sec] += '\n\n' + p.t; } else secoes[p.sec] = { texto: (secoes[p.sec] ? secoes[p.sec].texto + '\n\n' : '') + p.t }; });
    await salvar('turmas', t);
    if (D.boletins.some(x => x.importadoDe === b.arquivo && x.alunoId === a.id)) continue;
    await salvar('boletins', { turmaId: t.id, alunoId: a.id, ano: Number(b.ano), secoes, importadas: [], poemaTitulo: b.poemaTitulo || '', poemaTexto: b.poemaTexto || '', estado: 'rascunho', importadoDe: b.arquivo }); nB++; if (b.poemaTexto) nP++;
  }
  for (const t of D.turmas) if (!t.origemId) { const ants = D.turmas.filter(x => x.ano === t.ano - 1 && x.serie === t.serie - 1); const ant = ants.find(x => String(x.letra) === String(t.letra)) || (ants.length === 1 ? ants[0] : null); if (ant) { t.origemId = ant.id; await salvar('turmas', t); } }
  const recente = turmasOrdenadas()[0]; if (recente) await prefs({ turmaId: recente.id });
  IMP.bols = []; UI.aba.turma = 'alunos'; await entrarNoApp('turma');
  informar('Boletins importados', '<p>' + nB + ' boletim(ns) em rascunho, ' + nP + ' poema(s) do ano, ' + nA + ' aluno(s) novo(s) e ' + nT + ' turma(s) nova(s).</p><p>Complete agora as datas de nascimento e os responsáveis em <b>Turma e alunos</b>. Se esta é a turma que você acompanha, use a <b>Virada do ano</b> para criar o ano atual.</p>');
};
