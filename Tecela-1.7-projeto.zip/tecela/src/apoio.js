/* ==========================================================================
   Tecelã — apoio ao dia a dia: aniversariantes do ano, poemas, pauta da reunião,
   reforço escolar (com bilhete às famílias) e informações completas da vivência.
   ========================================================================== */
'use strict';
const docSimples = (nome, titulo, blocos, tim) => ({ nome, titulo, papel: TIM('atas').papel, timbrado: tim === false ? {} : TIM('atas'), blocos });
const diaMes = iso => Number(iso.slice(8, 10)) + ' de ' + MESES[Number(iso.slice(5, 7)) - 1];
const maiusc1 = s => String(s || '').replace(/^./, m => m.toUpperCase());

/* ---------- ANIVERSARIANTES DO ANO ---------- */
function aniversariantes(t) {
  return alunosDaTurma(t.id).filter(a => a.nasc).map(a => {
    let d = t.ano + a.nasc.slice(4); if (a.nasc.slice(5) === '02-29' && new Date(t.ano, 1, 29).getMonth() !== 1) d = t.ano + '-02-28';
    const w = new Date(d + 'T12:00').getDay(), sa = semAula(d), obs = [];
    if (w === 0 || w === 6) { const ant = letivoAntes(d); obs.push('fim de semana' + (ant ? ': comemorar em ' + DIAS_SEM[new Date(ant + 'T12:00').getDay()].replace('-feira', '') + ', ' + dataBR(ant).slice(0, 5) : '')); }
    else if (sa) { const ant = letivoAntes(d); obs.push(sa + (ant ? ': comemorar em ' + dataBR(ant).slice(0, 5) : '')); }
    return { a, d, idade: t.ano - Number(a.nasc.slice(0, 4)), dia: diaSemana(d), obs: obs.join('') };
  }).sort((x, y) => x.d.localeCompare(y.d));
}
REL.aniver = t => {
  const xs = aniversariantes(t), completo = !!UI.filtro.aniCompleto, sem = alunosDaTurma(t.id).filter(a => !a.nasc);
  const ctr = '<div class="linha"><label class="ck"><input type="checkbox" data-c="aniCompleto"' + (completo ? ' checked' : '') + '> Nome completo</label><span class="dica">O dia da semana é o de ' + t.ano + '. Aniversários em fim de semana ou em dia sem aula trazem uma sugestão de data para comemorar.</span></div>';
  if (!xs.length) return { controles: ctr, aviso: vazio('Nenhuma criança desta turma tem data de nascimento cadastrada. Cadastre em Turma e alunos.') };
  const b = [{ t: 'p', txt: rotuloTurma(t) + (t.professora ? ' · ' + profTit(t) + ' ' + t.professora : '') }];
  MESES.forEach((m, i) => { const ms = xs.filter(x => Number(x.d.slice(5, 7)) === i + 1); if (!ms.length) return; b.push({ t: 'h', txt: maiusc1(m) }, { t: 'tabela', cab: ['Dia', 'Dia da semana', 'Nome', 'Idade', 'Observação'], linhas: ms.map(x => [x.d.slice(8, 10), maiusc1(x.dia), completo ? x.a.nome : primeiroNome(x.a), x.idade + ' anos', x.obs]) }); });
  if (sem.length) b.push({ t: 'nota', txt: 'Sem data de nascimento cadastrada: ' + sem.map(primeiroNome).join(', ') + '.' });
  return { controles: ctr, doc: docBase('Aniversariantes_' + t.ano, 'Aniversariantes do ano — ' + t.serie + 'º ano ' + (t.letra || '') + ' · ' + t.ano, b), csv: { cab: ['Data', 'Dia da semana', 'Nome', 'Idade', 'Observação'], linhas: xs.map(x => [dataBR(x.d), x.dia, x.a.nome, x.idade, x.obs]) } };
};
C_.aniCompleto = el => { UI.filtro.aniCompleto = el.checked; render(); };

/* ---------- POEMAS ---------- */
/* o poema de uma criança num ano é o do boletim mais recente daquela turma */
function poemaDe(alunoId, turmaId) {
  const bs = D.boletins.filter(b => b.alunoId === alunoId && b.turmaId === turmaId && b.poemaTexto && !D.boletins.some(x => x.origemId === b.id)).sort((a, b) => (b.alterado || '').localeCompare(a.alterado || ''));
  return bs[0] || null;
}
const turmasDoAluno = aid => D.matriculas.filter(m => m.alunoId === aid).map(m => IX.turmas[m.turmaId]).filter(Boolean).sort((a, b) => a.ano - b.ano);
function blocosPoema(b, completo) {
  const al = IX.alunos[b.alunoId], tu = IX.turmas[b.turmaId];
  return [{ t: 'centro', linhas: [completo ? al.nome : primeiroNome(al), tu.serie + 'º ano · ' + tu.ano], peq: true }, { t: 'centro', linhas: [b.poemaTitulo || 'Poema'], negrito: true, espaco: true }, { t: 'poema', grande: true, estrofes: String(b.poemaTexto).split(/\n\s*\n/).map(x => x.split('\n')) }];
}
REL.poemas = t => {
  const al = alunosDaTurma(t.id); if (!al.length) return { aviso: vazio('Cadastre os alunos da turma.') };
  const modo = UI.filtro.poeModo || 'turma', a = alunoRel(t), f = UI.filtro;
  const turmas = modo === 'turma' ? turmasOrdenadas() : turmasDoAluno(a.id), tsel = turmas.find(x => x.id === f.poeTurma) || turmas.find(x => x.id === t.id) || turmas[turmas.length - 1];
  let ctr = '<div class="linha"><select data-c="poeModo">' + [['um', 'Um poema de uma criança'], ['crianca', 'Todos os poemas de uma criança'], ['turma', 'Os poemas de um ano, de toda a turma']].map(([k, n]) => '<option value="' + k + '"' + (k === modo ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>';
  if (modo !== 'turma') ctr += selAluno(al, a.id);
  if (modo !== 'crianca') ctr += '<select data-c="poeTurma">' + turmas.map(x => '<option value="' + x.id + '"' + (tsel && x.id === tsel.id ? ' selected' : '') + '>' + e(rotuloTurma(x)) + '</option>').join('') + '</select>';
  ctr += '<label class="ck"><input type="checkbox" data-c="poeTim"' + (f.poeTim ? ' checked' : '') + '> Com papel timbrado</label><label class="ck"><input type="checkbox" data-c="poeCompleto"' + (f.poeCompleto ? ' checked' : '') + '> Nome completo</label></div><p class="dica">Um poema por folha. A fonte dos poemas pode ser escolhida em Ajustes → Fontes dos documentos.</p>';
  let ps = [];
  if (modo === 'um') ps = [poemaDe(a.id, tsel && tsel.id)];
  else if (modo === 'crianca') ps = turmasDoAluno(a.id).map(x => poemaDe(a.id, x.id));
  else ps = tsel ? alunosDaTurma(tsel.id).map(x => poemaDe(x.id, tsel.id)) : [];
  ps = ps.filter(Boolean);
  if (!ps.length) return { controles: ctr, aviso: vazio('Nenhum poema encontrado para esta escolha. Os poemas são escritos em Boletins → Poema do ano.') };
  const b = []; ps.forEach((p, i) => { if (i) b.push({ t: 'quebra' }); b.push(...blocosPoema(p, f.poeCompleto)); });
  const nome = modo === 'turma' ? 'Poemas_' + (tsel ? tsel.serie + 'ano_' + tsel.ano : '') : 'Poemas_' + a.nome;
  return { controles: ctr, doc: docSimples(nome, modo === 'turma' ? 'Poemas do ' + rotuloTurma(tsel) : 'Poemas de ' + a.nome, b, f.poeTim ? undefined : false), html: '<div class="cartao"><p class="dica">' + ps.length + ' poema(s), um por folha.</p><div class="previa">' + htmlDoc(docSimples('', '', ps.slice(0, 2).flatMap((p, i) => (i ? [{ t: 'nota', txt: '· · ·' }] : []).concat(blocosPoema(p, f.poeCompleto))), false), true) + (ps.length > 2 ? '<p class="dica">… e mais ' + (ps.length - 2) + '.</p>' : '') + '</div></div>' };
};
C_.poeModo = el => { UI.filtro.poeModo = el.value; render(); };
C_.poeTurma = el => { UI.filtro.poeTurma = el.value; render(); };
C_.poeTim = el => { UI.filtro.poeTim = el.checked; render(); };
C_.poeCompleto = el => { UI.filtro.poeCompleto = el.checked; render(); };

/* ---------- PAUTA DA REUNIÃO ---------- */
function docPauta(a) {
  const t = IX.turmas[a.turmaId], b = [{ t: 'tit', txt: 'PAUTA — ' + nomeReuniao(a).toUpperCase() }];
  b.push({ t: 'pares', linhas: [['Data: ' + (a.data ? maiusc1(diaSemana(a.data)) + ', ' + dataBR(a.data) : '____/____/______'), 'Horário: ' + (a.inicio ? horaTxt(a.inicio) + (a.fim ? ' às ' + horaTxt(a.fim) : '') : '________')], ['Local: ' + (a.local || '________________'), t && a.tipo !== 'geral' ? 'Turma: ' + t.serie + 'º ano ' + (t.letra || '') : '']] });
  if (a.assunto) b.push({ t: 'p', txt: 'Assunto: ' + a.assunto });
  const itens = String(a.pauta || '').split('\n').map(s => s.trim().replace(/^\d+[.)]\s*/, '')).filter(Boolean);
  b.push({ t: 'h', txt: 'Pauta' }); b.push(itens.length ? { t: 'lista', itens: itens.map((x, i) => (i + 1) + '. ' + x) } : { t: 'p', txt: '(a pauta ainda não foi escrita na ata)' });
  const por = {}; (a.participantes || []).filter(p => p.nome).forEach(p => (por[p.categoria || 'Participantes'] = por[p.categoria || 'Participantes'] || []).push(p.nome));
  if (Object.keys(por).length) { b.push({ t: 'h', txt: 'Participantes convidados' }); Object.entries(por).forEach(([c, ns]) => b.push({ t: 'p', txt: c + ': ' + juntarLista(ns) + '.' })); }
  b.push({ t: 'h', txt: 'Anotações' }, { t: 'p', txt: '______________________________________________________________' }, { t: 'p', txt: '______________________________________________________________' }, { t: 'p', txt: '______________________________________________________________' });
  return { nome: 'Pauta_' + nomeReuniao(a) + '_' + (a.data || ''), titulo: 'Pauta — ' + nomeReuniao(a) + (a.data ? ' de ' + dataBR(a.data) : ''), papel: a.papel || TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
A.pautaAta = async d => { await descarregarFila(); const a = IX.atas[d.id]; saidaDocumento(docPauta(a), { para: emailsAta(a), assunto: 'Pauta — ' + nomeReuniao(a) + (a.data ? ' de ' + dataBR(a.data) : '') }); };
REL.pauta = t => {
  const xs = D.atas.filter(a => a.turmaId === t.id || (!a.turmaId && a.tipo === 'geral')).sort((a, b) => (a.estado === 'rascunho' ? 0 : 1) - (b.estado === 'rascunho' ? 0 : 1) || (b.data || '').localeCompare(a.data || ''));
  if (!xs.length) return { aviso: vazio('Crie a ata da reunião (em rascunho) e escreva a pauta nela. A pauta sai daqui, antes da reunião.') };
  const a = xs.find(x => x.id === UI.filtro.pautaAta) || xs[0];
  return { controles: '<div class="linha"><select data-c="pautaAta">' + xs.map(x => '<option value="' + x.id + '"' + (x.id === a.id ? ' selected' : '') + '>' + e(nomeReuniao(x) + ' · ' + dataBR(x.data) + (x.estado === 'rascunho' ? ' (rascunho)' : '')) + '</option>').join('') + '</select><a href="#" data-a="abrirAta" data-id="' + a.id + '">Abrir a ata para editar a pauta</a></div>', doc: docPauta(a) };
};
C_.pautaAta = el => { UI.filtro.pautaAta = el.value; render(); };

/* ---------- REFORÇO ---------- */
const SIT_REF = [['previsto', 'Previsto'], ['realizado', 'Realizado'], ['cancelado', 'Cancelado']];
const BILHETE_PADRAO = 'Olá, família!\n\n{O aluno/A aluna} {nome} está sendo {chamado/chamada} para o reforço escolar.\n\n{topico}\n\n{texto}\n\nO reforço acontecerá {quando}{horario}.\n\nA saída será às {saida}.\n\nQualquer dúvida, é só perguntar.\n\nAtenciosamente,\n{Professora} {professora}.\n\n{data}';
const EST_ENC = [['', 'Previsto'], ['realizado', 'Realizado'], ['faltou', 'Faltou'], ['cancelado', 'Cancelado']];
const estadoEnc = (x, d) => (x.encontros || {})[d] || '';
/* datas que ainda devem aparecer no calendário e no Painel: só do reforço previsto e sem situação marcada no encontro */
const datasPendentesRef = x => x.situacao === 'previsto' || !x.situacao ? (x.datas || []).filter(d => !estadoEnc(x, d)) : [];
function resumoEnc(x) { const c = {}; (x.datas || []).forEach(d => { const k = estadoEnc(x, d); if (k) c[k] = (c[k] || 0) + 1; }); return [['realizado', 'realizado', 'realizados'], ['faltou', 'falta', 'faltas'], ['cancelado', 'cancelado', 'cancelados']].filter(([k]) => c[k]).map(([k, um, v]) => c[k] + ' ' + (c[k] > 1 ? v : um)).join(', '); }
const rotRef = x => [x.componente ? nomeItem('componentes', x.componente) : '', x.topico].filter(Boolean).join(' — ') || 'Reforço';
function quandoRef(datas) {
  const ds = (datas || []).slice().sort(); if (!ds.length) return 'em data a combinar';
  const ws = ds.map(d => new Date(d + 'T12:00').getDay()), semanal = ds.length > 1 && ws.every(w => w === ws[0]) && ds.every((d, i) => !i || difDias(d, ds[i - 1]) === 7);
  const porMes = []; ds.forEach(d => { const k = d.slice(0, 7), u = porMes[porMes.length - 1]; if (u && u.k === k) u.dias.push(Number(d.slice(8, 10))); else porMes.push({ k, dias: [Number(d.slice(8, 10))] }); });
  const anos = new Set(ds.map(d => d.slice(0, 4))), txt = juntarLista(porMes.map(m => juntarLista(m.dias.map(String)) + ' de ' + MESES[Number(m.k.slice(5)) - 1] + (anos.size > 1 ? ' de ' + m.k.slice(0, 4) : ''))) + (anos.size === 1 ? ' de ' + ds[0].slice(0, 4) : '');
  if (ds.length === 1) return 'no dia ' + txt + ' (' + diaSemana(ds[0]) + ')';
  const dia = DIAS_SEM[ws[0]], plural = dia.replace('-feira', 's-feiras').replace(/^sábado$/, 'sábados').replace(/^domingo$/, 'domingos');
  return semanal ? 'durante ' + extenso(ds.length).replace(/^um$/, 'uma').replace(/^dois$/, 'duas') + ' ' + plural + ' seguid' + (ws[0] === 0 || ws[0] === 6 ? 'os' : 'as') + ', nos dias ' + txt : 'nos dias ' + txt;
}
function textoBilhete(x, al, t) {
  const tm = CFG.prefs.bilheteReforco || BILHETE_PADRAO;
  const top = x.mostrarTopico !== false && (x.componente || x.topico) ? 'Matéria ou tópico a ser estudado: ' + rotRef(x) + '.' : '';
  return substituir(tm.replace(/\{topico\}/g, top).replace(/\{texto\}/g, x.textoBilhete || '').replace(/\{quando\}/g, quandoRef(x.datas)).replace(/\{horario\}/g, x.hora ? ', a partir das ' + horaTxt(x.hora) : '').replace(/\{saida\}/g, saidaTxt(x.saida || CFG.prefs.reforcoSaida || '15:00')).replace(/\{professora\}/g, (t && t.professora) || '').replace(/\{data\}/g, dataBR(hojeISO())), al, t).replace(/\n{3,}/g, '\n\n').trim();
}
const blocosBilhete = (x, al, t) => textoBilhete(x, al, t).split(/\n\s*\n/).map(p => ({ t: 'p', txt: p.replace(/\n/g, ' ') }));
const reforcosDe = (t, f) => D.reforcos.filter(x => x.turmaId === t.id && (!f || f(x))).sort((a, b) => ((a.datas || [])[0] || '').localeCompare((b.datas || [])[0] || ''));
T.reforco = () => {
  const t = turmaAtual(); if (!t) return '<h1>Reforço</h1>' + vazio('Cadastre uma turma primeiro.');
  const fs = UI.filtro.refSit || 'previsto', xs = reforcosDe(t, x => fs === 'todos' || x.situacao === fs);
  let h = '<h1>Reforço escolar</h1><p>Marque quem precisa de reforço, em que matéria ou tópico e quando. As datas entram no calendário, o reforço aparece no pré-conselho e no PEI, e o bilhete para a família sai pronto.</p><div class="linha"><button class="btn pri" data-a="novoReforco">+ Reforço</button><button class="btn" data-a="bilhetesRef">Bilhetes</button><button class="btn" data-a="abrirRel" data-k="reforco">Listas (por criança e geral)</button><button class="btn" data-a="modeloBilhete">Modelo do bilhete</button><span class="espaco"></span><select data-c="refSit">' + [['previsto', 'Previstos'], ['realizado', 'Realizados'], ['cancelado', 'Cancelados'], ['todos', 'Todos']].map(([k, n]) => '<option value="' + k + '"' + (k === fs ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></div>';
  if (!xs.length) return h + vazio(fs === 'previsto' ? 'Nenhum reforço previsto.' : 'Nada nesta lista.');
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Criança(s)</th><th>Matéria ou tópico</th><th>Datas</th><th>Horário</th><th>Situação</th><th></th></tr>' + xs.map(x => '<tr><td><b>' + e((x.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')) + '</b>' + (x.obs ? '<br><span class="dica">' + e(x.obs) + '</span>' : '') + '</td><td>' + e(rotRef(x)) + '</td><td><div class="encs">' + (x.datas || []).map(d => { const k = estadoEnc(x, d); return '<button class="enc' + (k ? ' ' + k : '') + '" data-a="refEncontro" data-id="' + x.id + '" data-d="' + d + '" title="' + e(nomeEst(k)) + ' — toque para mudar">' + dataBR(d).slice(0, 5) + (k === 'realizado' ? ' ✓' : k === 'faltou' ? ' ✗' : k === 'cancelado' ? ' —' : '') + '</button>'; }).join('') + '</div>' + (resumoEnc(x) ? '<span class="dica">' + e(resumoEnc(x)) + '</span>' : '') + '</td><td>' + e(horaTxt(x.hora)) + (x.saida ? ' · saída ' + e(saidaTxt(x.saida)) : '') + '</td><td><select data-c="refMudaSit" data-id="' + x.id + '">' + SIT_REF.map(([k, n]) => '<option value="' + k + '"' + (k === x.situacao ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></td><td style="white-space:nowrap"><button class="btn peq" data-a="editarReforco" data-id="' + x.id + '">Editar</button> <button class="btn peq" data-a="bilhetesRef" data-id="' + x.id + '">Bilhete</button> <button class="icone-btn" data-a="apagarReforco" data-id="' + x.id + '" title="Excluir">✕</button></td></tr>').join('') + '</table></div>';
};
const nomeEst = k => (EST_ENC.find(x => x[0] === k) || EST_ENC[0])[1];
A.refEncontro = async d => {
  const x = IX.reforcos[d.id]; if (!x) return; const atual = estadoEnc(x, d.d);
  const v = await dlg({ titulo: 'Encontro de ' + dataBR(d.d) + ' (' + diaSemana(d.d) + ')', ok: 'Salvar', corpo: '<p>' + e((x.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ')) + ' · ' + e(rotRef(x)) + '</p><div class="chips">' + EST_ENC.map(([k, n]) => '<label><input type="radio" name="k" value="' + k + '"' + (k === atual ? ' checked' : '') + '> ' + n + '</label>').join('') + '</div><p class="dica">Encontros realizados, com falta ou cancelados saem do calendário e do Painel e continuam no histórico do reforço, na ficha e no pré-conselho.</p>' });
  if (!v) return; x.encontros = x.encontros || {}; if (v.k) x.encontros[d.d] = v.k; else delete x.encontros[d.d];
  const ds = x.datas || [], ks = ds.map(q => estadoEnc(x, q));
  if (ds.length && ks.every(Boolean)) x.situacao = ks.every(k => k === 'cancelado') ? 'cancelado' : 'realizado'; else if (x.situacao !== 'cancelado') x.situacao = 'previsto';
  await salvar('reforcos', x); render(); aviso('Encontro de ' + dataBR(d.d).slice(0, 5) + ': ' + nomeEst(v.k).toLowerCase() + '.');
};
C_.refSit = el => { UI.filtro.refSit = el.value; render(); };
C_.refMudaSit = async el => { const x = IX.reforcos[el.dataset.id]; x.situacao = el.value; await salvar('reforcos', x); aviso('Situação: ' + el.options[el.selectedIndex].text.toLowerCase() + '.'); };
A.abrirReforco = d => { $('#modais').innerHTML = ''; UI.filtro.refSit = 'todos'; ir('reforco'); setTimeout(() => A.editarReforco(d), 50); };
A.apagarReforco = d => apagarComDesfazer('reforcos', d.id, 'Reforço excluído.');
function datasSeguidas(ini, n, passo) { const r = []; let d = ini, k = 0; while (r.length < n && k++ < 400) { if (ehLetivo(d) || passo === 'livre') r.push(d); d = somaDias(d, passo === '1' ? 1 : Number(passo) || 7); if (passo === '1') while (!ehLetivo(d) && k++ < 400) d = somaDias(d, 1); } return r; }
async function dialogoReforco(x) {
  const t = turmaAtual(), al = alunosDaTurma(t.id), eps = D.curriculo.filter(c => c.serie === t.serie).map(c => c.titulo);
  const ds = (x.datas || []).map(d => dataBR(d).slice(0, 5)).join(', ');
  const v = await dlg({ titulo: x.id ? 'Editar o reforço' : 'Novo reforço', largo: true, ok: 'Salvar', corpo:
    '<div class="chips" style="margin-bottom:.6rem">' + al.map(a => '<label><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '"' + ((x.alunos || []).includes(a.id) ? ' checked' : '') + '> ' + e(primeiroNome(a)) + '</label>').join('') + '</div>' +
    '<div class="duas">' + campo('Matéria', '<select name="componente"><option value="">—</option>' + opcoesLista('componentes', '', x.componente).map(([k, n]) => '<option value="' + k + '"' + (k === x.componente ? ' selected' : '') + '>' + e(n) + '</option>').join('') + '</select>') + campo('Tópico', '<input name="topico" list="lsTop" value="' + e(x.topico || '') + '" placeholder="ex.: divisão com dois números na chave"><datalist id="lsTop">' + eps.map(n => '<option value="' + e(n) + '">').join('') + '</datalist>') + '</div>' +
    campo('Observação (só para você)', '<textarea name="obs">' + e(x.obs || '') + '</textarea>') +
    campo('Texto livre para o bilhete (opcional)', '<textarea name="textoBilhete" placeholder="ex.: Vamos retomar a divisão com material concreto.">' + e(x.textoBilhete || '') + '</textarea>') +
    '<label class="ck"><input type="checkbox" name="mostrarTopico"' + (x.mostrarTopico !== false ? ' checked' : '') + '> Mostrar a matéria e o tópico no bilhete</label>' +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-top:.6rem">' + campo('Primeira data', '<input type="date" name="ini" value="' + ((x.datas || [])[0] || hojeISO()) + '">') + campo('Quantos encontros', '<input type="number" name="n" min="1" max="30" value="' + ((x.datas || []).length || 3) + '">') + campo('Repetição', '<select name="passo"><option value="7">Toda semana, no mesmo dia</option><option value="1">Dias letivos seguidos</option><option value="14">A cada 15 dias</option></select>') + campo('Horário de início', '<input type="time" name="hora" value="' + e(x.hora || '') + '">') + campo('Horário de saída', '<input type="time" name="saida" value="' + e(paraHora(x.saida || CFG.prefs.reforcoSaida || '15:00')) + '">') + campo('Situação', '<select name="situacao">' + SIT_REF.map(([k, n]) => '<option value="' + k + '"' + (k === (x.situacao || 'previsto') ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + '</div>' +
    campo('Ou escreva as datas (dia/mês, separadas por vírgula)', '<input name="datas" value="' + e(ds) + '" placeholder="ex.: 9/11, 16/11, 23/11">', 'Se este campo estiver preenchido, ele vale no lugar da primeira data e da repetição. Dias sem aula ficam de fora da repetição.'),
    validar: v => !(v.alunos || []).length ? 'Marque pelo menos uma criança.' : null });
  if (!v) return null;
  let datas = [];
  if (v.datas.trim() && v.datas.trim() !== ds) datas = v.datas.split(/[,;\s]+/).map(s => { const m = s.match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/); if (!m) return null; const a = m[3] ? (m[3].length === 2 ? '20' + m[3] : m[3]) : String(t.ano); return a + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0'); }).filter(Boolean).sort();
  else if (v.datas.trim() && v.datas.trim() === ds && x.datas && x.datas[0] === v.ini && x.datas.length === Number(v.n)) datas = x.datas;
  else datas = datasSeguidas(v.ini, Math.max(1, Number(v.n) || 1), v.passo);
  return Object.assign(x, { turmaId: t.id, alunos: v.alunos, componente: v.componente, topico: v.topico.trim(), obs: v.obs.trim(), textoBilhete: v.textoBilhete.trim(), mostrarTopico: !!v.mostrarTopico, datas, encontros: Object.fromEntries(Object.entries(x.encontros || {}).filter(([q]) => datas.includes(q))), hora: v.hora, saida: v.saida, situacao: v.situacao });
}
A.novoReforco = async d => { const x = await dialogoReforco({ alunos: d && d.al ? [d.al] : [] }); if (!x) return; await salvar('reforcos', x); render(); aviso('Reforço registrado. As datas estão no calendário.'); };
A.editarReforco = async d => { const x = IX.reforcos[d.id]; if (!x) return; const y = await dialogoReforco(clone(x)); if (!y) return; await salvar('reforcos', y); render(); aviso('Reforço salvo.'); };
A.modeloBilhete = async () => {
  const v = await dlg({ titulo: 'Modelo do bilhete de reforço', largo: true, ok: 'Salvar', corpo: '<p class="dica">Marcadores: {nome}, {topico} (matéria e tópico, quando marcado), {texto} (texto livre do reforço), {quando}, {horario}, {saida}, {professora}, {Professora}, {data}, e pares como {o/a} ou {chamado/chamada}, que se ajustam à criança.</p>' + campo('Texto', '<textarea name="t" style="min-height:16rem">' + e(CFG.prefs.bilheteReforco || BILHETE_PADRAO) + '</textarea>') + campo('Horário de saída mais usado', '<input type="time" name="s" value="' + e(paraHora(CFG.prefs.reforcoSaida || '15:00')) + '">'), extra: '<button type="button" class="btn" data-x="padrao">Voltar ao modelo original</button>' });
  if (!v) return; if (v._botao === 'padrao') { await prefs({ bilheteReforco: null }); return aviso('Modelo original restaurado.'); }
  await prefs({ bilheteReforco: v.t.trim(), reforcoSaida: v.s || '15:00' }); marcarPendente(); aviso('Modelo do bilhete salvo.');
};
A.bilhetesRef = async d => {
  const t = turmaAtual(), xs = d.id ? [IX.reforcos[d.id]] : reforcosDe(t, x => x.situacao === 'previsto');
  if (!xs.length) return aviso('Nenhum reforço previsto para gerar bilhetes.');
  const b = []; xs.forEach(x => (x.alunos || []).forEach(id => { const al = IX.alunos[id]; if (!al) return; if (b.length) b.push({ t: 'quebra' }); b.push(...blocosBilhete(x, al, t)); }));
  saidaDocumento(docSimples('Bilhetes_reforco_' + hojeISO(), 'Bilhetes de reforço', b), { assunto: 'Reforço escolar' });
};
REL.reforco = t => {
  const modo = UI.filtro.refModo || 'geral', al = alunosDaTurma(t.id), a = alunoRel(t), fs = UI.filtro.refRelSit || '';
  const xs = reforcosDe(t, x => (!fs || x.situacao === fs) && (modo === 'geral' || (x.alunos || []).includes(a.id)));
  const ctr = '<div class="linha"><select data-c="refModo"><option value="geral"' + (modo === 'geral' ? ' selected' : '') + '>Lista geral da turma</option><option value="crianca"' + (modo === 'crianca' ? ' selected' : '') + '>Lista de uma criança</option></select>' + (modo === 'crianca' ? selAluno(al, a.id) : '') + '<select data-c="refRelSit"><option value="">Todas as situações</option>' + SIT_REF.map(([k, n]) => '<option value="' + k + '"' + (k === fs ? ' selected' : '') + '>' + n + '</option>').join('') + '</select><a href="#" data-a="ir" data-t="reforco">Abrir o reforço</a></div>';
  if (!xs.length) return { controles: ctr, aviso: vazio('Nenhum reforço nesta lista.') };
  const linhas = [];
  if (modo === 'geral') xs.forEach(x => linhas.push([(x.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', '), rotRef(x), (x.datas || []).map(d => dataBR(d).slice(0, 5)).join(', '), horaTxt(x.hora) + (x.saida ? ' (saída ' + saidaTxt(x.saida) + ')' : ''), nomeSit(x.situacao) + (resumoEnc(x) ? ' (' + resumoEnc(x) + ')' : '')]));
  else xs.forEach(x => linhas.push([rotRef(x), (x.datas || []).map(d => dataBR(d).slice(0, 5)).join(', '), horaTxt(x.hora), nomeSit(x.situacao) + (resumoEnc(x) ? ' (' + resumoEnc(x) + ')' : ''), x.obs || '']));
  const cab = modo === 'geral' ? ['Criança(s)', 'Matéria ou tópico', 'Datas', 'Horário', 'Situação'] : ['Matéria ou tópico', 'Datas', 'Horário', 'Situação', 'Observação'];
  const b = [{ t: 'p', txt: rotuloTurma(t) + (modo === 'crianca' ? ' · ' + a.nome : '') }, { t: 'tabela', cab, linhas }];
  return { controles: ctr, doc: docBase('Reforco_' + (modo === 'crianca' ? a.nome : 'turma'), modo === 'crianca' ? 'Reforço — ' + a.nome : 'Reforço escolar — lista da turma', b), csv: { cab, linhas } };
};
const nomeSit = k => (SIT_REF.find(x => x[0] === k) || ['', ''])[1];
C_.refModo = el => { UI.filtro.refModo = el.value; render(); };
C_.refRelSit = el => { UI.filtro.refRelSit = el.value; render(); };
const reforcosDoAluno = (t, aid) => reforcosDe(t, x => (x.alunos || []).includes(aid) && x.situacao !== 'cancelado');

/* ---------- VIVÊNCIA: informações completas para as famílias ---------- */
const CAMPOS_VIV = [['endereco', 'Endereço'], ['contato', 'Responsável e contato no local'], ['concentracao', 'Concentração na escola'], ['saida', 'Saída da escola'], ['chegada', 'Chegada de volta à escola'], ['turmasDatas', 'Turmas e datas'], ['adultos', 'Adultos que acompanham'], ['orcamento', 'Orçamento'], ['pagamento', 'Forma de pagamento'], ['percurso', 'Tempo de percurso'], ['documentacao', 'Documentação do local (AVCB, vistoria)'], ['adicionais', 'Informações adicionais (estrada de terra, celular, retirada das peças…)'], ['vestimenta', 'Vestimenta'], ['alimentacao', 'Alimentação'], ['cardapio', 'Cardápio'], ['compras', 'Compras opcionais no local']];
/* os campos mais usados ficam à vista; os outros, em “Mais campos” */
const VIV_ESSENCIAIS = ['saida', 'chegada', 'adultos', 'orcamento', 'vestimenta', 'alimentacao'];
function cartaoInfoViv(v) {
  const inf = v.info || {}, prog = inf.programacao && inf.programacao.length ? inf.programacao : [{ hora: '', ativ: '' }];
  return '<details class="cartao" data-rec="vivencias:' + v.id + '"' + (Object.keys(inf).length || (v.data || '') >= hojeISO() ? ' open' : '') + '><summary><b>Antes da vivência: informações para as famílias</b> <span class="dica">para se prepararem: programação, horários, custos, roupa e alimentação</span></summary><p class="dica">Vai para as famílias antes da vivência. Preencha só o que fizer sentido; o documento sai em “Informações para as famílias (antes)”, no alto da tela.</p>' + campo('O que vamos viver (apresentação para as famílias)', area('info.apresentacao', inf.apresentacao, 'style="min-height:3.5rem"')) +
    '<h4>Programação</h4>' + prog.map((p, i) => '<div class="grade" style="grid-template-columns:7rem 1fr auto;gap:.4rem;align-items:end">' + campo('Horário', inp('info.programacao.' + i + '.hora', p.hora, 'text', 'placeholder="8h30"')) + campo('Atividade', inp('info.programacao.' + i + '.ativ', p.ativ)) + '<button type="button" class="icone-btn" style="margin-bottom:.8rem" data-a="vivRemProg" data-id="' + v.id + '" data-i="' + i + '">✕</button></div>').join('') + '<button type="button" class="btn peq" data-a="vivAddProg" data-id="' + v.id + '">+ Horário</button>' +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin-top:.8rem">' + CAMPOS_VIV.filter(([k]) => VIV_ESSENCIAIS.includes(k)).map(([k, r]) => campo(r, area('info.' + k, inf[k], 'style="min-height:2.6rem"'))).join('') + '</div>' +
    (function () { const extras = CAMPOS_VIV.filter(([k]) => !VIV_ESSENCIAIS.includes(k)), n = extras.filter(([k]) => inf[k]).length; return '<details class="mais-campos"' + (n ? ' open' : '') + '><summary>Mais campos (' + extras.length + ')' + (n ? ' · ' + n + ' preenchido' + (n > 1 ? 's' : '') : '') + '</summary><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">' + extras.map(([k, r]) => campo(r, area('info.' + k, inf[k], 'style="min-height:2.6rem"'))).join('') + '</div></details>'; })() +
    campo('Prazo para avisar sobre restrição alimentar', inp('info.prazoRestricao', inf.prazoRestricao, 'text', 'placeholder="ex.: 7 dias antes"')) +
    '<div class="linha"><button type="button" class="btn" data-a="vivRestricoes" data-id="' + v.id + '">Restrições alimentares das crianças</button><span class="dica">Lista tirada dos pontos de atenção, para avisar o local com antecedência.</span></div></details>';
}
A.vivAddProg = async d => { await descarregarFila(); const v = IX.vivencias[d.id]; v.info = v.info || {}; v.info.programacao = (v.info.programacao && v.info.programacao.length ? v.info.programacao : [{ hora: '', ativ: '' }]).concat([{ hora: '', ativ: '' }]); await salvar('vivencias', v); render(); };
A.vivRemProg = async d => { await descarregarFila(); const v = IX.vivencias[d.id]; ((v.info || {}).programacao || []).splice(Number(d.i), 1); await salvar('vivencias', v); render(); };
const restricoesTurma = (t, v) => alunosDaTurma(t.id).filter(a => !v || v.todos !== false || (v.participantes || []).includes(a.id)).map(a => [a, (a.atencao || []).filter(x => x.tipo === 'alergia' && x.situacao !== 'resolvido')]).filter(([, xs]) => xs.length);
A.vivRestricoes = async d => {
  const v = IX.vivencias[d.id], t = IX.turmas[v.turmaId], rs = restricoesTurma(t, v);
  if (!rs.length) return informar('Restrições alimentares', '<p>Nenhuma criança participante tem “Alergia ou restrição alimentar” registrada nos pontos de atenção.</p>');
  const lin = rs.map(([a, xs]) => [a.nome, xs.map(x => x.descricao).join('; ')]);
  const r = await dlg({ titulo: 'Restrições alimentares', ok: 'Exportar a lista', cancelar: 'Fechar', corpo: '<p class="alerta">São dados de saúde das crianças. Envie só ao responsável pelo local e só o necessário.</p><table class="tabela">' + lin.map(l => '<tr><td><b>' + e(l[0]) + '</b></td><td>' + e(l[1]) + '</td></tr>').join('') + '</table>' });
  if (r) saidaDocumento(docSimples('Restricoes_' + v.titulo, 'Restrições alimentares — ' + v.titulo, [{ t: 'tit', txt: 'Restrições alimentares' }, { t: 'p', txt: v.titulo + ' · ' + dataBR(v.data) + ' · ' + rotuloTurma(t) }, { t: 'tabela', cab: ['Criança', 'Restrição'], linhas: lin }]), { assunto: 'Restrições alimentares — ' + v.titulo });
};
function docInfoViv(v) {
  const t = IX.turmas[v.turmaId], inf = v.info || {}, b = [{ t: 'tit', txt: v.titulo }];
  b.push({ t: 'pares', linhas: [['Local: ' + (v.local || ''), 'Data: ' + (v.data ? maiusc1(diaSemana(v.data)) + ', ' + dataBR(v.data) : '')], [v.responsavel ? 'Com: ' + v.responsavel : '', v.duracao ? 'Duração: ' + v.duracao : '']] });
  if (inf.apresentacao) b.push(...blocosTexto(inf.apresentacao));
  const prog = (inf.programacao || []).filter(p => p.hora || p.ativ);
  if (prog.length) b.push({ t: 'h', txt: 'Programação' }, { t: 'tabela', cab: ['Horário', 'Atividade'], linhas: prog.map(p => [p.hora, p.ativ]) });
  CAMPOS_VIV.forEach(([k, r]) => { if (inf[k]) b.push({ t: 'h', txt: r.replace(/ \(.*\)$/, '') }, ...blocosTexto(inf[k])); });
  if (inf.prazoRestricao) b.push({ t: 'p', txt: 'Em caso de restrição alimentar, avise a professora com ' + inf.prazoRestricao + '.' });
  return { nome: 'Vivencia_' + v.titulo, titulo: v.titulo + ' — informações para as famílias', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
A.vivInfo = async d => { await descarregarFila(); const v = IX.vivencias[d.id], t = IX.turmas[v.turmaId]; saidaDocumento(docInfoViv(v), { assunto: v.titulo + ' — informações', para: alunosDaTurma(t.id).flatMap(emailsAluno) }); };
