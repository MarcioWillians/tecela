/* ==========================================================================
   Tecelã — Planejamento: conteúdo programático, horário semanal da turma,
   Planejamento anual e Plano de época. Para cada ano (1º ao 9º) há um rascunho
   de referência, igual para qualquer turma daquele ano e editável; o documento
   da turma nasce dele, com as datas do calendário e o diário da época.
   ========================================================================== */
'use strict';
const ord = n => n + 'ª';
const epocasDaSerie = s => D.curriculo.filter(c => c.serie === s).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
const MESES_IDX = MESES.map((m, i) => [m, i]);
const mesInicio = c => { const p = String(c.periodo || '').toLowerCase(), hit = MESES_IDX.map(([m, i]) => [p.indexOf(m), i]).filter(x => x[0] >= 0).sort((a, b) => a[0] - b[0])[0]; return hit ? hit[1] : 99; };
const epocasPrincipais = s => epocasDaSerie(s).filter(c => Number(c.semanas) > 0).sort((a, b) => mesInicio(a) - mesInicio(b) || (a.ordem || 0) - (b.ordem || 0));
const linhas = t => String(t || '').split(/\n|(?<=\.)\s+(?=[A-ZÁÉÍÓÚ])/).map(s => s.trim()).filter(Boolean);
function habilidadesEpoca(c, n) {
  const cods = (c.bncc || []).filter(k => IXBNCC[k]);
  if (cods.length) return cods.map(k => '(' + k + ') ' + IXBNCC[k][3]);
  return (typeof sugerirBncc === 'function' ? sugerirBncc(c, n || 6) : []).map(h => '(' + h[0] + ') ' + h[3] + ' [sugestão]');
}
const textoEpoca = c => '## Conteúdos\n' + listaTxt(linhas(c.conteudos)) + (c.objetivos ? '\n## Objetivos\n' + listaTxt(linhas(c.objetivos)) : '') + '\n## Habilidades da BNCC\n' + (listaTxt(habilidadesEpoca(c)) || '- (ligue habilidades à época em Currículo e BNCC)');

/* ---------- conteúdo programático ---------- */
const progSerie = s => { const xs = D.programa.filter(p => p.serie === s).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)); return xs.length ? xs : (PROG_REF[s] || []).map((p, i) => ({ serie: s, comp: p.comp, aulas: p.aulas, texto: p.texto, ordem: i, ref: true })); };
const textoPrograma = s => progSerie(s).map(p => '## ' + p.comp + (p.aulas ? ' (' + p.aulas + ' aulas)' : '') + '\n' + p.texto).join('\n');
function abaPrograma() {
  const s = serieCurr(), proprios = D.programa.filter(p => p.serie === s).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  let h = '<p>O <b>conteúdo programático</b> de cada ano, por componente, com o número de aulas no ano. Ele entra no Planejamento anual e ajuda a montar as épocas. A Tecelã traz um conteúdo de referência de uma escola Waldorf brasileira; use-o como está ou ajuste para a sua escola.</p><div class="linha">' + selSerie('curSerie', s) + (proprios.length ? '<button class="btn" data-a="progAdd">+ Componente</button><button class="btn" data-a="progExportar">Exportar</button><button class="btn perigo" data-a="progRef">Voltar à referência</button>' : '<button class="btn pri" data-a="progUsar">Usar e editar este conteúdo</button><button class="btn" data-a="progExportar">Exportar</button>') + '</div>';
  if (!proprios.length) { const xs = progSerie(s); return h + (xs.length ? '<p class="dica">Referência (só leitura até você tocar em “Usar e editar”).</p>' + xs.map(p => '<details class="cartao"><summary><b>' + e(p.comp) + '</b>' + (p.aulas ? ' <span class="dica">' + p.aulas + ' aulas</span>' : '') + '</summary>' + blocosTexto(p.texto).map(htmlBloco).join('') + '</details>').join('') : vazio('Sem conteúdo de referência para o ' + s + 'º ano.')); }
  return h + proprios.map(p => '<div class="cartao" data-rec="programa:' + p.id + '"><div class="grade" style="grid-template-columns:1fr 8rem auto;gap:.5rem;align-items:end">' + campo('Componente', inp('comp', p.comp)) + campo('Aulas no ano', inp('aulas', p.aulas, 'number')) + '<button class="icone-btn" style="margin-bottom:.8rem" data-a="progRem" data-id="' + p.id + '" title="Tirar">✕</button></div>' + campo('Conteúdo (um item por linha; “## ” para subtítulo)', area('texto', p.texto, 'class="alto"')) + '</div>').join('');
}
A.progUsar = async () => { const s = serieCurr(); for (const p of progSerie(s)) await salvar('programa', { serie: s, comp: p.comp, aulas: p.aulas, texto: p.texto, ordem: p.ordem }); render(); aviso('Conteúdo programático do ' + s + 'º ano pronto para editar.'); };
A.progAdd = async () => { const s = serieCurr(); await salvar('programa', { serie: s, comp: 'Novo componente', aulas: null, texto: '', ordem: D.programa.filter(p => p.serie === s).length }); render(); };
A.progRem = d => apagarComDesfazer('programa', d.id, 'Componente retirado.');
A.progRef = async () => { const s = serieCurr(); if (!(await confirmar('Voltar à referência?', 'O conteúdo programático do ' + s + 'º ano que você editou será apagado e a referência volta a valer.', 'Voltar'))) return; for (const p of D.programa.filter(x => x.serie === s)) await apagar('programa', p.id); render(); };
A.progExportar = () => { const s = serieCurr(); saidaDocumento(docSimples('Conteudo_programatico_' + s + 'ano', 'Conteúdo programático — ' + s + 'º ano', [{ t: 'tit', txt: 'Conteúdo programático — ' + s + 'º ano' }].concat(progSerie(s).flatMap(p => [{ t: 'h', txt: p.comp + (p.aulas ? ' (' + p.aulas + ' aulas)' : '') }].concat(blocosTexto(p.texto))))), { assunto: 'Conteúdo programático — ' + s + 'º ano' }); };
/* épocas de referência para os anos que ainda não têm épocas no currículo */
async function carregarEpocasRef(s) { let o = epocasDaSerie(s).length; for (const [comp, tit, sem, per, cont, obj] of EPOCAS_REF[s] || []) await salvar('curriculo', { serie: s, componente: comp, titulo: tit, periodo: per, semanas: sem, conteudos: cont, objetivos: obj, bncc: [], realizadas: [], ordem: o++ }); }
A.epocasRef = async d => { const s = Number(d.s || serieCurr()); if (epocasDaSerie(s).length && !(await confirmar('Acrescentar as épocas de referência?', 'O ' + s + 'º ano já tem épocas. As de referência serão acrescentadas depois delas.', 'Acrescentar'))) return; await carregarEpocasRef(s); render(); aviso('Épocas de referência do ' + s + 'º ano carregadas. Ajuste à sua escola.'); };

/* ---------- horário semanal: matérias do ano (quem dá a aula: professor de classe ou de matéria) e aulas de cada dia ---------- */
const DIAS_GRADE = [[1, 'Segunda'], [2, 'Terça'], [3, 'Quarta'], [4, 'Quinta'], [5, 'Sexta'], [6, 'Sábado letivo']];
const QUEM = [['PC', 'Professor de Classe'], ['PM', 'Professor de Matéria']];
const QUEM_PM = /euritmia|ingl|alem|m[uú]sica|educa[cç][aã]o f[ií]sica|trabalhos|jardinagem|aplicadas|marcenaria|pl[aá]sticas|cer[aâ]mica|metal|tecnologia|modelagem|religi/i;
/* A grade guarda, por dia, a lista de aulas com horário: grade[dia].itens = [{ m: matéria, ini, fim }], e uma
   observação geral em t.gradeObs. A “Aula principal” está sempre disponível e é do Professor de Classe.
   Formatos antigos: até a 1.5 { aulas: 'a, b', pc: 'c' } por dia; na 1.5.1 e 1.5.2 { lista: [nomes], obs }. */
const AULA_PRINCIPAL = 'Aula principal';
function gradeDe(t) {
  t.materias = t.materias || []; t.grade = t.grade || {};
  const tem = n => t.materias.some(m => norm1(m.nome) === norm1(n)), obsAntigas = [];
  DIAS_GRADE.forEach(([k, nd]) => {
    const g = t.grade[k] = t.grade[k] || {};
    if (!g.lista && !g.itens) { g.lista = []; String(g.aulas || '').split(',').map(x => x.trim()).filter(Boolean).forEach(n => { g.lista.push(n); if (!tem(n)) t.materias.push({ nome: n, quem: 'PM', prof: '' }); }); String(g.pc || '').split(',').map(x => x.trim()).filter(Boolean).forEach(n => { g.lista.push(n); if (!tem(n)) t.materias.push({ nome: n, quem: 'PC', prof: '' }); }); delete g.aulas; delete g.pc; }
    if (!g.itens) { g.itens = (g.lista || []).map(n => ({ m: n, ini: '', fim: '' })); delete g.lista; if (g.obs) obsAntigas.push(nd + ': ' + g.obs); delete g.obs; }
  });
  if (obsAntigas.length) t.gradeObs = [t.gradeObs, obsAntigas.join('\n')].filter(Boolean).join('\n');
  return t;
}
const materiaDe = (t, n) => norm1(n) === norm1(AULA_PRINCIPAL) ? { nome: AULA_PRINCIPAL, quem: 'PC', prof: t.professora || '' } : (t.materias || []).find(m => norm1(m.nome) === norm1(n)) || { nome: n, quem: '' };
const aulasDe = (t, k) => (gradeDe(t).grade[k] || { itens: [] }).itens;
const horarioAula = x => x.ini ? horaTxt(x.ini) + (x.fim ? '–' + horaTxt(x.fim) : '') : '';
const diasUsados = t => DIAS_GRADE.filter(([k]) => k < 6 || aulasDe(t, k).length);
function abaGrade() {
  const t = turmaAtual(); if (!t) return vazio('Cadastre uma turma primeiro.');
  gradeDe(t); const ms = t.materias, opcs = [[AULA_PRINCIPAL, AULA_PRINCIPAL + ' (PC)']].concat(ms.filter(m => m.nome).map(m => [m.nome, m.nome + ' (' + (m.quem || 'PM') + ')']));
  let h = '<div class="linha"><button class="btn pri" data-a="gradeExportar">Imprimir ou exportar o horário</button></div>';
  h += '<div class="cartao" data-rec="turmas:' + t.id + '"><h3>Horário semanal de ' + e(rotuloTurma(t)) + '</h3><p class="dica">As aulas de cada dia, na ordem, com o horário. <b>PC</b> = Professor de Classe; <b>PM</b> = Professor de Matéria. A “Aula principal” está sempre na lista. As aulas aparecem sozinhas no diário do Plano de época.</p>' +
    diasUsados(t).map(([k, n]) => { const its = aulasDe(t, k); return '<div class="dia-grade"><div class="linha" style="margin:0"><b>' + n + '</b><span class="espaco"></span><button type="button" class="btn peq" data-a="gradeAddAula" data-k="' + k + '">+ aula</button></div>' + (its.length ? '<table class="tabela grade-dia"><tr><th>Início</th><th>Fim</th><th>Matéria</th><th>Quem</th><th></th></tr>' + its.map((x, i) => { const m = materiaDe(t, x.m); return '<tr><td>' + inp('grade.' + k + '.itens.' + i + '.ini', x.ini, 'time') + '</td><td>' + inp('grade.' + k + '.itens.' + i + '.fim', x.fim, 'time') + '</td><td>' + sel('grade.' + k + '.itens.' + i + '.m', x.m, opcs.some(o => o[0] === x.m) ? opcs : opcs.concat([[x.m, x.m]]), 'data-rr="1"') + '</td><td><span class="etq' + (m.quem === 'PC' ? ' fin' : '') + '" title="' + e((QUEM.find(q => q[0] === m.quem) || ['', 'sem matéria cadastrada'])[1]) + '">' + (m.quem || '—') + '</span></td><td style="white-space:nowrap"><button type="button" class="icone-btn" data-a="gradeMover" data-k="' + k + '" data-i="' + i + '" data-d="-1" title="Subir">↑</button><button type="button" class="icone-btn" data-a="gradeMover" data-k="' + k + '" data-i="' + i + '" data-d="1" title="Descer">↓</button><button type="button" class="icone-btn" data-a="gradeRemAula" data-k="' + k + '" data-i="' + i + '" title="Tirar">✕</button></td></tr>'; }).join('') + '</table>' : '<p class="dica" style="margin:.3rem 0">Sem aulas.</p>') + '</div>'; }).join('') +
    (aulasDe(t, 6).length ? '' : '<button type="button" class="btn peq" data-a="gradeAddAula" data-k="6">+ Sábado letivo</button>') +
    campo('Observações do horário', area('gradeObs', t.gradeObs, 'placeholder="ex.: às quintas a turma sai às 12h30; Euritmia em semanas alternadas"'), 'Vai impressa logo abaixo do horário.') + '</div>';
  h += '<div class="cartao" data-rec="turmas:' + t.id + '"><h3>Matérias de ' + t.ano + ', quem dá a aula e o professor ou a professora</h3><p class="dica">Cadastre uma vez cada matéria do ano. As aulas do PC entram no campo “PC” do diário da época; as do PM aparecem na linha de aulas do dia. Na impressão, esta lista vai numa folha separada.</p>' +
    (ms.length ? '<div class="rolagem"><table class="tabela"><tr><th>Matéria</th><th>Quem dá a aula</th><th>Professor ou professora</th><th></th></tr>' + ms.map((m, i) => '<tr><td>' + inp('materias.' + i + '.nome', m.nome, 'text', 'data-rr="1"') + '</td><td>' + sel('materias.' + i + '.quem', m.quem || 'PM', QUEM, 'data-rr="1"') + '</td><td>' + inp('materias.' + i + '.prof', m.prof) + '</td><td><button type="button" class="icone-btn" data-a="gradeRemMat" data-i="' + i + '" title="Tirar">✕</button></td></tr>').join('') + '</table></div>' : '<p class="dica">Nenhuma matéria cadastrada.</p>') +
    '<div class="linha"><button type="button" class="btn peq" data-a="gradeAddMat">+ Matéria</button><button type="button" class="btn peq" data-a="gradeDoPrograma">Trazer do conteúdo programático do ' + t.serie + 'º ano</button></div></div>';
  return h;
}
async function salvarTurmaGrade(t, msg) { await descarregarFila(); await salvar('turmas', t); render(); if (msg) aviso(msg); }
A.gradeAddMat = () => { const t = gradeDe(turmaAtual()); t.materias.push({ nome: '', quem: 'PM', prof: '' }); salvarTurmaGrade(t); };
A.gradeRemMat = async d => { const t = gradeDe(turmaAtual()), m = t.materias[Number(d.i)]; const usada = DIAS_GRADE.some(([k]) => aulasDe(t, k).some(x => norm1(x.m) === norm1(m.nome))); if (usada && !(await confirmar('Tirar a matéria?', '“' + e(m.nome) + '” também sai dos dias da grade.', 'Tirar'))) return; t.materias.splice(Number(d.i), 1); DIAS_GRADE.forEach(([k]) => { t.grade[k].itens = aulasDe(t, k).filter(x => norm1(x.m) !== norm1(m.nome)); }); salvarTurmaGrade(t); };
A.gradeDoPrograma = () => { const t = gradeDe(turmaAtual()); let n = 0; progSerie(t.serie).forEach(p => { if (!p.aulas) return; String(p.comp).split(/\s+e\s+(?=[A-ZÁÉÍÓÚ])/).forEach(nm => { nm = nm.replace(/^Arte\s*[–-]\s*/, '').trim(); if (!nm || t.materias.some(m => norm1(m.nome) === norm1(nm))) return; t.materias.push({ nome: nm, quem: QUEM_PM.test(nm) ? 'PM' : 'PC', prof: '' }); n++; }); }); salvarTurmaGrade(t, n ? n + ' matéria(s) trazida(s). Confira quem dá cada aula.' : 'Nada novo para trazer.'); };
/* nova aula: começa onde a anterior terminou; a primeira do dia é a Aula principal */
A.gradeAddAula = async d => { await descarregarFila(); const t = gradeDe(turmaAtual()), its = aulasDe(t, d.k), u = its[its.length - 1]; its.push({ m: its.length ? ((t.materias.find(m => m.nome) || {}).nome || AULA_PRINCIPAL) : AULA_PRINCIPAL, ini: u ? u.fim || '' : '', fim: '' }); salvarTurmaGrade(t); };
A.gradeRemAula = d => { const t = gradeDe(turmaAtual()); aulasDe(t, d.k).splice(Number(d.i), 1); salvarTurmaGrade(t); };
A.gradeMover = d => { const t = gradeDe(turmaAtual()), its = aulasDe(t, d.k), i = Number(d.i), j = i + Number(d.d); if (j < 0 || j >= its.length) return; [its[i], its[j]] = [its[j], its[i]]; salvarTurmaGrade(t); };
/* impressão: a grade em tabela (dias nas colunas, aulas nas linhas) e, em folha separada, as matérias e quem as dá */
function docGrade(t) {
  gradeDe(t); const ds = diasUsados(t), max = Math.max(0, ...ds.map(([k]) => aulasDe(t, k).length));
  const cel = x => { if (!x) return ''; const m = materiaDe(t, x.m), h = horarioAula(x); return (h ? h + ' · ' : '') + x.m + (m.quem ? ' (' + m.quem + ')' : ''); };
  const linhas = Array.from({ length: max }, (_, i) => [(i + 1) + 'ª'].concat(ds.map(([k]) => cel(aulasDe(t, k)[i]))));
  const b = [{ t: 'tit', txt: 'Horário semanal — ' + rotuloTurma(t) }, { t: 'p', txt: (t.professora ? profTit(t) + ' de classe: ' + t.professora + '. ' : '') + 'PC = Professor de Classe; PM = Professor de Matéria.' }, { t: 'tabela', cab: ['Aula'].concat(ds.map(x => x[1])), linhas: linhas.length ? linhas : [['—'].concat(ds.map(() => ''))] }];
  if ((t.gradeObs || '').trim()) b.push({ t: 'h', txt: 'Observações' }, ...String(t.gradeObs).split(/\n+/).filter(x => x.trim()).map(x => ({ t: 'p', txt: x.trim() })));
  const ms = t.materias.filter(m => m.nome);
  if (ms.length) b.push({ t: 'quebra' }, { t: 'tit', txt: 'Matérias e professores — ' + rotuloTurma(t) }, { t: 'tabela', cab: ['Matéria', 'Quem dá a aula', 'Professor ou professora'], linhas: [[AULA_PRINCIPAL, 'PC — Professor de Classe', t.professora || '']].concat(ms.map(m => [m.nome, m.quem ? m.quem + ' — ' + (QUEM.find(q => q[0] === m.quem) || ['', ''])[1] : '', m.prof || ''])) });
  return { nome: 'Horario_semanal_' + t.serie + 'ano_' + t.ano, titulo: 'Horário semanal — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), paisagem: ds.length > 5, blocos: b };
}
A.gradeExportar = async () => { await descarregarFila(); const t = gradeDe(turmaAtual()), d = docGrade(t), linhas = []; diasUsados(t).forEach(([k, n]) => aulasDe(t, k).forEach(x => { const m = materiaDe(t, x.m); linhas.push([n, x.ini || '', x.fim || '', x.m, m.quem || '', m.prof || '']); })); saidaDocumento(d, { assunto: d.titulo, csv: { cab: ['Dia', 'Início', 'Fim', 'Matéria', 'PC ou PM', 'Professor ou professora'], linhas } }); };
function aulasDoDia(t, iso) {
  const w = new Date(iso + 'T12:00').getDay(), its = t ? aulasDe(t, w) || [] : [], xs = [];
  const rot = x => (horarioAula(x) ? horarioAula(x) + ' ' : '') + x.m;
  const pm = its.filter(x => materiaDe(t, x.m).quem !== 'PC'), pc = its.filter(x => materiaDe(t, x.m).quem === 'PC' && norm1(x.m) !== norm1(AULA_PRINCIPAL));
  if (pm.length) xs.push(pm.map(rot).join(' – '));
  const an = t ? alunosDaTurma(t.id).filter(a => a.nasc && a.nasc.slice(5) === iso.slice(5)).map(primeiroNome) : []; if (an.length) xs.push('Aniversário: ' + an.join(', '));
  return { aulas: xs.join(' · '), pc: pc.map(rot).join(', ') };
}

/* ---------- PLANEJAMENTO ANUAL ---------- */
const refAnualDe = s => docsDe('refAnual', d => d.serie === s)[0];
function secoesAnualRef(s) {
  const B = BASE_SERIE[s] || BASE_SERIE[1], eps = epocasDaSerie(s);
  return [secTexto('just', 'Justificativa antropológica', B.just), secTexto('obj', 'Objetivos gerais do ano', listaTxt(B.obj)),
    secTabela('epocas', 'Épocas do ano', ['Nº', 'Época', 'Componente', 'Semanas', 'Período'], epocasPrincipais(s).map((c, i) => [ord(i + 1), c.titulo, nomeItem('componentes', c.componente), String(c.semanas || ''), c.periodo || '']).concat(eps.filter(c => !(Number(c.semanas) > 0)).map(c => ['—', c.titulo, nomeItem('componentes', c.componente), '', c.periodo || 'ano todo'])))]
    .concat(epocasPrincipais(s).map((c, i) => secTexto('ep:' + c.id, ord(i + 1) + ' época: ' + c.titulo, textoEpoca(c))))
    .concat([secTexto('prog', 'Conteúdo programático do ano', textoPrograma(s)), secTexto('aval', 'Estratégias de avaliação', listaTxt(AVALIACAO_BASE)), secTexto('ref', 'Referências', listaTxt(REFERENCIAS_BASE))]);
}
TIPOS_DOC.refAnual = {
  nome: 'Planejamento anual de referência',
  ajuda: 'Referência do ano, igual para qualquer turma deste ano. Ela é a base do Planejamento anual de cada turma. As seções com ↻ vêm do currículo, da BNCC e do conteúdo programático.',
  gerar: d => ({ titulo: 'Planejamento anual de referência — ' + d.serie + 'º ano', cab: {}, secoes: secoesAnualRef(d.serie) }),
  cabDoc: d => ['Ano: ' + d.serie + 'º ano', 'Referência para qualquer turma']
};
function inicioDoAno(t) { const ev = D.eventos.find(v => (v.data || '').startsWith(String(t.ano)) && /in[ií]cio (das aulas|do ano letivo)|volta às aulas/i.test(v.titulo || '')); return ev ? ev.data : letivoDepois(t.ano + '-02-02'); }
/* distribui as épocas principais pelo calendário, semana a semana, pulando as semanas sem aula */
/* a partir de ini, conta N semanas que tenham aula (semanas inteiras de recesso não contam) */
function semanasLetivas(ini, n) {
  let cur = ini, precisa = n, a = '', f = '', k = 0;
  while (precisa > 0 && k++ < 60) { const w = new Date(cur + 'T12:00').getDay(), seg = somaDias(cur, w === 0 ? 1 : 1 - w), dl = diasLetivos(cur > seg ? cur : seg, somaDias(seg, 6)); if (dl.length) { if (!a) a = dl[0]; f = dl[dl.length - 1]; precisa--; } cur = somaDias(seg, 7); }
  return [a, f, cur];
}
/* cada época começa no mês indicado no período (ou logo depois da anterior) e dura as semanas previstas */
function distribuirEpocas(t, inicio) {
  let cur = inicio; const r = [];
  for (const c of epocasPrincipais(t.serie)) {
    const mi = mesInicio(c); if (mi < 12) { const m = letivoDepois(t.ano + '-' + String(mi + 1).padStart(2, '0') + '-01'); if (m > cur) cur = m; }
    const [ini, fim, prox] = semanasLetivas(cur, Number(c.semanas) || 4); cur = prox;
    const dl = diasLetivos(ini, fim), sab = dl.filter(d => new Date(d + 'T12:00').getDay() === 6).length, fer = []; for (let d = ini; d && d <= fim; d = somaDias(d, 1)) { const w = new Date(d + 'T12:00').getDay(); if (w > 0 && w < 6 && semAula(d)) fer.push(d); }
    r.push({ c, ini, fim, dias: dl.length, obs: [fer.length ? fer.length + ' dia(s) sem aula' : '', sab ? sab + ' sábado(s) letivo(s)' : ''].filter(Boolean).join('; ') });
  }
  return r;
}
const tabelaAnual = (t, inicio) => { const ds = distribuirEpocas(t, inicio), outras = epocasDaSerie(t.serie).filter(c => !(Number(c.semanas) > 0)); return ds.map((x, i) => [ord(i + 1), x.c.titulo, nomeItem('componentes', x.c.componente), dataBR(x.ini), dataBR(x.fim), String(x.dias), x.obs]).concat(outras.map(c => ['—', c.titulo, nomeItem('componentes', c.componente), '', '', '', c.periodo || 'ano todo'])); };
TIPOS_DOC.anual = {
  nome: 'Planejamento anual',
  cab: [['escola', 'Escola'], ['professora', 'Professora ou professor de classe'], ['inicioAno', 'Início do ano letivo', 'date']],
  ajuda: 'O planejamento da turma nasce da referência do ano. As datas das épocas vêm do calendário: dias sem aula ficam de fora e sábados marcados como letivos contam. Mudou o calendário ou o início do ano? Toque em “Distribuir as datas”.',
  botoes: d => '<button class="btn" data-a="anualDatas" data-id="' + d.id + '">Distribuir as datas pelo calendário</button>',
  gerar: d => {
    const t = IX.turmas[d.turmaId], ref = refAnualDe(t.serie), base = ref ? clone(ref.secoes) : secoesAnualRef(t.serie), ini = (d.cab || {}).inicioAno || inicioDoAno(t);
    const secoes = base.map(s => s.k === 'epocas' ? secTabela('epocas', 'Épocas do ano', ['Nº', 'Época', 'Componentes', 'Início', 'Fim', 'Dias letivos', 'Obs.'], tabelaAnual(t, ini)) : s);
    return { titulo: 'Planejamento anual — ' + t.ano, cab: { escola: CFG.escola.nome || '', professora: t.professora || '', inicioAno: ini }, secoes };
  },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}, c = d.cab || {}; return [c.escola || CFG.escola.nome || '', 'Turma: ' + t.serie + 'º ano ' + (t.letra || ''), profTit(t) + ' de classe: ' + (c.professora || t.professora || ''), 'Ano: ' + t.ano]; }
};
A.anualDatas = async d => { await descarregarFila(); const x = IX.documentos[d.id], t = IX.turmas[x.turmaId], i = x.secoes.findIndex(s => s.k === 'epocas'), ini = (x.cab || {}).inicioAno || inicioDoAno(t); const nova = secTabela('epocas', i >= 0 ? x.secoes[i].tit : 'Épocas do ano', ['Nº', 'Época', 'Componentes', 'Início', 'Fim', 'Dias letivos', 'Obs.'], tabelaAnual(t, ini)); const antes = i >= 0 ? clone(x.secoes[i]) : null; await mexer(x, y => { if (i >= 0) y.secoes[i] = nova; else y.secoes.splice(2, 0, nova); }); aviso('Datas distribuídas a partir de ' + dataBR(ini) + '.', 'Desfazer', () => mexer(x, y => { if (antes) y.secoes[i] = antes; else y.secoes.splice(2, 1); })); };
const proprioPrimeiro = (a, b) => (a.partilha ? 1 : 0) - (b.partilha ? 1 : 0);
const anualDe = t => docsDe('anual', d => d.turmaId === t.id).sort(proprioPrimeiro)[0];

/* ---------- PLANO DE ÉPOCA ---------- */
const CAMPOS_DIARIO = [['conteudo', 'Conteúdo'], ['registro', 'Registro'], ['historia', 'História'], ['pc', 'PC (professor de classe)'], ['licao', 'Lição de casa']];
const refEpocaDe = id => docsDe('refEpoca', d => d.epocaId === id)[0];
function secoesEpocaRef(c) {
  const B = BASE_SERIE[c.serie] || BASE_SERIE[1];
  return [secTexto('epi', 'Epígrafe', ''), secTexto('objw', 'Objetivos específicos (Pedagogia Waldorf)', listaTxt(linhas(c.objetivos).concat([B.obj[0]]))),
    secTexto('objg', 'Objetivos gerais (habilidades da BNCC)', listaTxt(habilidadesEpoca(c, 8)) || '- (ligue habilidades à época em Currículo e BNCC)'),
    secTexto('objlm', 'Objetivos da língua materna', listaTxt(B.lm)), secTexto('cont', 'Conteúdos', listaTxt(linhas(c.conteudos))),
    secTexto('recontar', 'Recontar', 'Criar este momento todos os dias: as crianças recontam a aula anterior, com perguntas dirigidas, e quem fala menos é convidado a participar.'),
    secTabela('rotina', 'Estrutura da aula', ['Horário', 'Momento'], B.rotina.map(x => x.slice())),
    secTabela('ritmo', 'Ritmo: versos, poemas e canções', ['Verso, poema ou canção', 'Gestos ou notas'], [['', ''], ['', ''], ['', '']]),
    secTabela('formas', 'Desenho de formas', ['Dia', 'Como'], [['1º dia', 'A professora mostra na lousa; as crianças fazem com o dedo na mesa ou no ar.'], ['2º dia', 'Com giz de cera em folha avulsa.'], ['3º dia', 'No caderno.']]),
    secTexto('aval', 'Avaliação', listaTxt(AVALIACAO_BASE)), secTexto('mat', 'Materiais', '- Caderno da época\n- Caderno de lição de casa\n- Folhas avulsas para desenho e pintura\n- Giz de cera, lápis de cor e aquarela'),
    secTexto('bib', 'Bibliografia', listaTxt(REFERENCIAS_BASE.slice(0, 3)))];
}
TIPOS_DOC.refEpoca = {
  nome: 'Plano de época de referência',
  ajuda: 'Referência desta época, igual para qualquer turma do ano. O plano de cada turma nasce dela, com as datas e o diário.',
  gerar: d => { const c = IX.curriculo[d.epocaId] || {}; return { titulo: 'Época “' + (c.titulo || '') + '” — ' + (c.serie || '') + 'º ano', cab: {}, secoes: secoesEpocaRef(c) }; },
  cabDoc: d => { const c = IX.curriculo[d.epocaId] || {}; return ['Ano: ' + c.serie + 'º ano', 'Componente: ' + nomeItem('componentes', c.componente), 'Semanas: ' + (c.semanas || ''), 'Período: ' + (c.periodo || '')]; }
};
/* datas da época: do Planejamento anual da turma ou de um evento “Época” do calendário */
function datasEpoca(t, c) {
  const an = anualDe(t), s = an && an.secoes.find(x => x.k === 'epocas'), l = s && s.linhas.find(r => norm1(r[1]) === norm1(c.titulo));
  const iso = v => { const m = String(v || '').match(/(\d{2})\/(\d{2})\/(\d{4})/); return m ? m[3] + '-' + m[2] + '-' + m[1] : ''; };
  const ev = D.eventos.find(v => v.tipo === 'epoca' && (v.turmaId === t.id || !v.turmaId) && (v.data || '').startsWith(String(t.ano)) && norm1(v.titulo).includes(norm1(c.titulo)));
  if (ev) return [letivoDepois(ev.data), ev.dataFim || semanasLetivas(letivoDepois(ev.data), Number(c.semanas) || 4)[1]];
  if (l && iso(l[3]) && iso(l[4])) return [iso(l[3]), iso(l[4])];
  return ['', ''];
}
function montarDiario(t, ini, fim, antes) { const velho = {}; (antes || []).forEach(x => velho[x.data] = x); return diasLetivos(ini, fim).map(d => { const a = aulasDoDia(t, d); return Object.assign({ data: d, conteudo: '', registro: '', historia: '', pc: a.pc, licao: '' }, velho[d] || {}, { aulas: a.aulas }); }); }
TIPOS_DOC.epoca = {
  nome: 'Plano de época',
  cab: [['professora', 'Professora ou professor'], ['inicio', 'Início', 'date'], ['fim', 'Fim', 'date']],
  ajuda: 'O plano nasce da referência da época. O diário tem um dia por dia letivo, com as aulas do horário semanal e os aniversários. Mudou as datas? Toque em “Montar o diário pelo calendário”: o que já foi escrito em cada dia é mantido.',
  botoes: d => '<button class="btn" data-a="irDiario">Ir para o diário</button><button class="btn" data-a="epocaDiario" data-id="' + d.id + '">Montar o diário pelo calendário</button>',
  gerar: d => {
    const t = IX.turmas[d.turmaId], c = IX.curriculo[d.epocaId] || {}, ref = refEpocaDe(c.id), base = ref ? clone(ref.secoes) : secoesEpocaRef(c);
    const [ini, fim] = d.cab && d.cab.inicio ? [d.cab.inicio, d.cab.fim] : datasEpoca(t, c), velho = (d.secoes || []).find(s => s.k === 'diario');
    const ant = avaliacoesAnteriores(c, d), sec = [secDiario('diario', 'Diário da época', CAMPOS_DIARIO, ini && fim ? montarDiario(t, ini, fim, velho && velho.dias) : []), secRepertorio(t, c),
      Object.assign(secTexto('avaliacao', 'Avaliação da época', '- O que funcionou: \n- O que mudar da próxima vez: \n- Crianças que surpreenderam: \n- Para lembrar no ano que vem: '), { naoImprimir: true, manual: true })];
    if (ant) sec.push(Object.assign(secTexto('anterior', 'Notas de quem já deu esta época', ant), { naoImprimir: true }));
    return { titulo: 'Época “' + c.titulo + '”', cab: { professora: t.professora || '', inicio: ini, fim }, secoes: base.concat(sec) };
  },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}, c = d.cab || {}, n = c.inicio && c.fim ? diasLetivos(c.inicio, c.fim).length : 0; return [profTit(t) + ': ' + (c.professora || ''), 'Turma: ' + t.serie + 'º ano ' + (t.letra || '') + ' · ' + (CFG.escola.nome || ''), c.inicio ? 'Período: ' + diaMes(c.inicio) + ' a ' + diaMes(c.fim) + ' de ' + c.fim.slice(0, 4) : 'Período: ', n ? n + ' dias letivos' : '']; }
};
/* avaliação da época: o que outras turmas (ou anos) escreveram ao terminar a mesma época volta no plano novo */
function avaliacoesAnteriores(c, d) {
  const xs = docsDe('epoca', x => x.epocaId === c.id && x.id !== d.id && x.turmaId !== d.turmaId).map(x => { const s = (x.secoes || []).find(y => y.k === 'avaliacao'), tx = s && String(s.txt || '').split('\n').filter(l => l.replace(/^-\s*[^:]*:\s*$/, '').trim()).join('\n'); const tu = IX.turmas[x.turmaId]; return tx ? (tu ? rotuloTurma(tu) : 'Outra turma') + ':\n' + tx : ''; }).filter(Boolean);
  return xs.join('\n\n');
}
A.irDiario = () => { const el = $('#sec-diario'); if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); const p = el.querySelector('details:not([open])'); if (p) p.open = true; } };
const diasPreenchidos = d => { const s = (d.secoes || []).find(x => x.k === 'diario'); return s ? [s.dias.filter(x => CAMPOS_DIARIO.some(([k]) => k !== 'pc' && x[k])).length, s.dias.length] : [0, 0]; };
A.epocaDiario = async d => { await descarregarFila(); const x = IX.documentos[d.id], t = IX.turmas[x.turmaId], c = x.cab || {}; if (!c.inicio || !c.fim) return aviso('Informe o início e o fim da época.'); const i = x.secoes.findIndex(s => s.k === 'diario'), dias = montarDiario(t, c.inicio, c.fim, i >= 0 ? x.secoes[i].dias : []); await mexer(x, y => { if (i >= 0) y.secoes[i].dias = dias; else y.secoes.push(secDiario('diario', 'Diário da época', CAMPOS_DIARIO, dias)); }); aviso('Diário com ' + dias.length + ' dias letivos.'); };
const planoEpocaDe = (t, id) => docsDe('epoca', d => d.turmaId === t.id && d.epocaId === id).sort(proprioPrimeiro)[0];
const peiLembretes = t => alunosDaTurma(t.id).map(a => [a, peiAtivo(t, a.id)]).filter(([, p]) => p).map(([a, p]) => '<li><b>' + e(primeiroNome(a)) + ':</b> ' + e(adaptacoesPei(p) || 'há um PEI; veja as adaptações.') + '</li>').join('');

/* ---------- TELA ---------- */
T.planej = () => {
  const t = turmaAtual(); if (!t) return '<h1>Planejamento</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && IX.documentos[UI.sub]) { const d = IX.documentos[UI.sub], lem = d.tipo === 'epoca' ? peiLembretes(t) : ''; return editorDoc(d, { voltar: 'Planejamento', alerta: lem ? '<div class="alerta" style="background:var(--violC)"><b>Lembretes dos PEIs</b> <span class="dica">(só para você)</span><ul style="margin:.3rem 0 0">' + lem + '</ul></div>' : '' }); }
  const aba = UI.aba.planej || 'anual';
  let h = '<h1>Planejamento</h1>' + abas([['anual', 'Planejamento anual'], ['epocas', 'Planos de época'], ['ano', 'Ano letivo: dias, festas e materiais'], ['ref', 'Rascunhos de todos os anos']], aba) + avisoRecebidos(t);
  return h + ({ anual: abaAnual, epocas: abaEpocas, ano: abaAnoLetivo, ref: abaRef }[aba] || abaAnual)(t);
};
const semEpocas = s => '<div class="cartao"><p>O ' + s + 'º ano ainda não tem épocas no currículo.</p><div class="linha"><button class="btn pri" data-a="epocasRef" data-s="' + s + '">Carregar as épocas de referência do ' + s + 'º ano</button><button class="btn" data-a="irColarEpocas" data-s="' + s + '">Colar uma lista de épocas</button><button class="btn" data-a="irCurriculo" data-s="' + s + '">Abrir Currículo e BNCC</button></div><p class="dica">As épocas ficam em Currículo e BNCC, onde você ajusta à sua escola.</p></div>';
A.irCurriculo = d => { UI.filtro.curSerie = Number((d && d.s) || (turmaAtual() || {}).serie || 1); UI.sub = null; ir('curric', null, 'escola'); };
A.irColarEpocas = d => { A.irCurriculo(d); setTimeout(() => A.colarEpocas(), 60); };
function abaAnual(t) {
  const d = anualDe(t);
  if (!epocasDaSerie(t.serie).length) return semEpocas(t.serie);
  if (d) { const ult = (d.versoes || []).slice(-1)[0]; return '<div class="cartao"><h3>' + e(d.titulo) + '</h3><p class="dica">' + (ult ? 'Versão ' + ult.n + ' de ' + dataBR(ult.data.slice(0, 10)) : 'Rascunho') + ' · ' + d.secoes.length + ' seções</p><button class="btn pri" data-a="abrirDocSub" data-id="' + d.id + '">Abrir</button></div>'; }
  return '<div class="cartao"><p>O Planejamento anual de ' + e(rotuloTurma(t)) + ' nasce da referência do ' + t.serie + 'º ano: justificativa antropológica, objetivos, épocas com datas do calendário, conteúdos, habilidades da BNCC, conteúdo programático e avaliação. Depois, tudo é editável.</p><button class="btn pri" data-a="anualNovo">Criar o Planejamento anual de ' + t.ano + '</button></div>';
}
A.anualNovo = async () => { const t = turmaAtual(), x = await criarDoc('anual', { turmaId: t.id }); UI.sub = x.id; render(); window.scrollTo(0, 0); aviso('Rascunho do Planejamento anual criado.'); };
function abaEpocas(t) {
  const eps = epocasDaSerie(t.serie); if (!eps.length) return semEpocas(t.serie);
  return '<p>Um plano para cada época do ' + t.serie + 'º ano. O rascunho vem da referência da época, e o diário é montado pelo calendário, com as aulas do <a href="#" data-a="ir" data-t="turma" data-aba="grade">horário semanal</a>. As épocas vêm do <a href="#" data-a="irCurriculo">Currículo e BNCC</a>, onde você também pode <a href="#" data-a="irColarEpocas">colar uma lista de épocas</a>.</p><div class="cartao rolagem"><table class="tabela"><tr><th>Época</th><th>Componente</th><th>Datas</th><th>Plano</th><th></th></tr>' + eps.map(c => { const d = planoEpocaDe(t, c.id), [i, f] = d ? [d.cab.inicio, d.cab.fim] : datasEpoca(t, c); return '<tr><td><b>' + e(c.titulo) + '</b></td><td>' + e(nomeItem('componentes', c.componente)) + '</td><td>' + (i ? dataBR(i).slice(0, 5) + ' a ' + dataBR(f).slice(0, 5) : '<span class="dica">' + e(c.periodo || '') + '</span>') + '</td><td>' + (d ? ((d.versoes || []).length ? 'versão ' + d.versoes.length : 'rascunho') + (diasPreenchidos(d)[1] ? '<br><span class="dica">diário: ' + diasPreenchidos(d).join(' de ') + ' dias</span>' : '') : '—') + '</td><td>' + (d ? '<button class="btn peq" data-a="abrirDocSub" data-id="' + d.id + '">Abrir</button>' : '<button class="btn peq" data-a="epocaNovo" data-id="' + c.id + '">Criar</button>') + '</td></tr>'; }).join('') + '</table></div>';
}
A.epocaNovo = async d => { const t = turmaAtual(), x = await criarDoc('epoca', { turmaId: t.id, epocaId: d.id }); UI.sub = x.id; render(); window.scrollTo(0, 0); aviso('Plano de época criado' + (x.cab.inicio ? ', com ' + diasLetivos(x.cab.inicio, x.cab.fim).length + ' dias letivos.' : '. Informe o início e o fim para montar o diário.')); };
function abaRef(t) {
  const s = Number(UI.filtro.refSerie || t.serie), eps = epocasDaSerie(s), ra = refAnualDe(s);
  let h = '<p>Os rascunhos de planejamento de todos os anos do Ensino Fundamental, iguais para qualquer turma de cada ano. Consulte e edite aqui; o planejamento de cada turma nasce deles.</p>';
  h += '<div class="cartao rolagem"><div class="linha"><h3 style="margin:0">Todos os anos</h3><span class="espaco"></span><button class="btn pri" data-a="refTodos">Montar os rascunhos de todos os anos</button></div><table class="tabela"><tr><th>Ano</th><th>Épocas no currículo</th><th>Planejamento anual</th><th>Planos de época</th><th></th></tr>' + seriesVisiveis().map(n => { const es = epocasDaSerie(n), r = refAnualDe(n), pe = es.filter(c => refEpocaDe(c.id)).length; return '<tr' + (n === s ? ' style="background:var(--azulC)"' : '') + '><td><b>' + n + 'º ano</b></td><td>' + (es.length || '<span class="dica">nenhuma</span>') + '</td><td>' + (r ? ((r.versoes || []).length ? 'versão ' + r.versoes.length : 'rascunho') : '<span class="dica">—</span>') + '</td><td>' + (es.length ? pe + ' de ' + es.length : '<span class="dica">—</span>') + '</td><td><button class="btn peq" data-a="refVer" data-s="' + n + '">Ver</button></td></tr>'; }).join('') + '</table><p class="dica">“Montar os rascunhos de todos os anos” carrega as épocas de referência nos anos que ainda não têm épocas e monta o planejamento anual e os planos de época que faltam. O que já existe não é mexido.</p></div>';
  h += '<h3>' + s + 'º ano</h3>';
  if (!eps.length) return h + semEpocas(s);
  h += '<div class="cartao"><h3>Planejamento anual de referência — ' + s + 'º ano</h3>' + (ra ? '<button class="btn pri" data-a="abrirDocSub" data-id="' + ra.id + '">Abrir</button>' : '<button class="btn pri" data-a="refAnualNovo" data-s="' + s + '">Montar o rascunho</button>') + '</div>';
  h += '<div class="cartao rolagem"><div class="linha"><h3 style="margin:0">Planos de época de referência</h3><span class="espaco"></span><a href="#" data-a="irCurriculo" data-s="' + s + '">Épocas em Currículo e BNCC</a></div><table class="tabela"><tr><th>Época</th><th>Componente</th><th>Semanas</th><th></th></tr>' + eps.map(c => { const r = refEpocaDe(c.id); return '<tr><td><b>' + e(c.titulo) + '</b></td><td>' + e(nomeItem('componentes', c.componente)) + '</td><td>' + e(c.semanas || '') + '</td><td>' + (r ? '<button class="btn peq" data-a="abrirDocSub" data-id="' + r.id + '">Abrir</button>' : '<button class="btn peq" data-a="refEpocaNovo" data-id="' + c.id + '">Montar o rascunho</button>') + '</td></tr>'; }).join('') + '</table></div>';
  return h;
}
A.refVer = d => { UI.filtro.refSerie = d.s; render(); };
A.refTodos = async () => {
  if (!(await confirmar('Montar os rascunhos de todos os anos?', 'Para cada ano do 1º ao 9º, a Tecelã carrega as épocas de referência (se o ano ainda não tem épocas) e monta o planejamento anual e os planos de época de referência que faltam. O que já existe fica como está.', 'Montar'))) return;
  aviso('Montando os rascunhos…'); let n = 0;
  for (const s of seriesVisiveis()) { if (!epocasDaSerie(s).length) await carregarEpocasRef(s); if (!refAnualDe(s)) { await criarDoc('refAnual', { serie: s }); n++; } for (const c of epocasDaSerie(s)) if (!refEpocaDe(c.id)) { await criarDoc('refEpoca', { epocaId: c.id, serie: s }); n++; } }
  render(); aviso(n ? n + ' rascunho(s) montado(s) para os anos do 1º ao 9º.' : 'Todos os rascunhos já existiam.');
};
C_.refSerie = el => { UI.filtro.refSerie = el.value; render(); };
A.refAnualNovo = async d => { const x = await criarDoc('refAnual', { serie: Number(d.s) }); UI.sub = x.id; render(); window.scrollTo(0, 0); };
A.refEpocaNovo = async d => { const c = IX.curriculo[d.id], x = await criarDoc('refEpoca', { epocaId: c.id, serie: c.serie }); UI.sub = x.id; render(); window.scrollTo(0, 0); };
