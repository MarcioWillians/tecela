/* Tecelã — Computação na BNCC (complemento de 2022): liga ou desliga as habilidades nas consultas,
   nas sugestões e na comparação do currículo, e monta o verbete de apresentação da Biblioteca.
   As habilidades "por etapa" (EF15, EF69) aparecem na consulta e na Biblioteca, mas não entram nas
   sugestões nem na comparação, para não contar duas vezes o que já está nas habilidades de cada ano. */
'use strict';
const EIXOS_CO = [
  ['Pensamento computacional', 'A capacidade de compreender, analisar, definir, modelar, resolver, comparar e automatizar problemas e suas soluções de forma metódica, criando e adaptando algoritmos.'],
  ['Mundo digital', 'Os artefatos digitais, físicos (computadores, celulares) e virtuais (internet, redes, nuvem): o que é a informação, como é representada em códigos, guardada, protegida, processada e transmitida.'],
  ['Cultura digital', 'A participação consciente e democrática por meio das tecnologias digitais: os impactos da revolução digital, a atitude crítica, ética e responsável diante das mídias e a fluência no uso das tecnologias.']];
const ehEtapa = h => !!(h[4] && h[4].etapa);
function aplicarComputacao() {
  const liga = CFG.prefs.bnccComputacao !== false, tem = BNCC.some(h => h[1] === 'CO');
  if (liga && !tem) { BNCC.push(...BNCC_CO); BNCC_COMP.CO = 'Computação (complemento de 2022)'; }
  if (!liga && tem) { for (let i = BNCC.length - 1; i >= 0; i--) if (BNCC[i][1] === 'CO') BNCC.splice(i, 1); delete BNCC_COMP.CO; }
  BNCC_CO.forEach(h => IXBNCC[h[0]] = h); /* as ligações já feitas continuam com o texto */
}
/* blocos de documento de uma habilidade de Computação, com eixo, objeto, explicação e exemplos */
function blocosHabCO(h, curto) {
  const m = h[4] || {}, b = [{ t: 'h', txt: h[0] + (m.etapa ? ' (por etapa, ' + h[2][0] + 'º ao ' + h[2][h[2].length - 1] + 'º ano' + (m.eq ? '; equivale a ' + m.eq : '') + ')' : '') }, { t: 'p', txt: h[3] }, { t: 'nota', txt: [m.e, m.o].filter(Boolean).join(' · ') }];
  if (!curto && m.x) b.push({ t: 'p', txt: 'Explicação: ' + m.x });
  if (!curto && m.ex) b.push({ t: 'p', txt: 'Exemplos: ' + m.ex });
  return b;
}
