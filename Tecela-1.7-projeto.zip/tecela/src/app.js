/* ==========================================================================
   Tecelã — inicialização e modelo de demonstração.
   ========================================================================== */
'use strict';
async function abrirBancoSeguro(nome) {
  BANCO = nome; if (DB) { try { DB.close(); } catch (x) { } DB = null; }
  try { DB = await abrirBanco(nome); SE.semBanco = false; } catch (x) { DB = null; SE.semBanco = true; }
}
async function iniciar() {
  SE.app = false; SE.demo = false; SE.memoria = false; SE.dk = null; SE.travado = false; CHAVE_CACHE = null; UI.tela = 'painel'; UI.sub = null;
  await abrirBancoSeguro('tecela');
  CFG = await lerConfig(); aplicarTema();
  const temDados = DB ? ((await idbTudo('turmas')).length > 0 || !!CFG.cripto) : false;
  zerarMemoria(); telaInicio(temDados);
}
async function depoisDeCarregar() {
  await entrarNoApp();
  if (CFG.prefs.pendente && !SE.demo) {
    const r = await dlg({ titulo: 'Salvar as alterações no arquivo?', ok: 'Salvar agora', cancelar: 'Depois', corpo: '<p>Na última vez, a Tecelã foi fechada sem salvar as alterações' + (CFG.prefs.arquivoNome ? ' em ' + e(CFG.prefs.arquivoNome) : ' em um arquivo') + '.</p><p>Elas continuam neste aparelho. Salvar agora protege seu trabalho caso o navegador seja limpo.</p>' });
    if (r) await fazerCopia();
  }
}

/* ---------- modelo de demonstração ---------- */
A.entrarDemo = async () => {
  await descarregarFila();
  const salvo = { cfg: CFG }; SE.antesDemo = salvo;
  await abrirBancoSeguro('tecela-demo'); SE.demo = true; SE.dk = null; SE.memoria = !DB;
  CFG = await lerConfig();
  const temDados = DB ? (await idbTudo('turmas')).length > 0 : false;
  if (temDados && CFG.prefs.demoVersao === DEMO_VERSAO) await carregarTudo(); else await construirDemo(); /* modelo antigo: refaz com os dados da versão atual */
  CFG.prefs.pendente = false; UI.tela = 'painel'; UI.sub = null; UI.aba = {}; UI.filtro = {};
  entrarNoApp(); aviso('Você está no modelo de demonstração. Tudo aqui é fictício.');
};
A.sairDemo = async () => { await descarregarFila(); SE.demo = false; UI.aba = {}; UI.filtro = {}; zerarMemoria(); iniciar(); };
A.apagarDemo = async () => { if (!(await confirmar('Apagar o modelo?', 'O modelo de demonstração será removido deste aparelho. Ele pode ser criado de novo pela tela inicial.', 'Apagar'))) return; if (DB) { DB.close(); DB = null; } try { indexedDB.deleteDatabase('tecela-demo'); } catch (x) { } SE.demo = false; UI.aba = {}; UI.filtro = {}; zerarMemoria(); iniciar(); };
A.restaurarDemo = async () => { if (!(await confirmar('Restaurar o modelo?', 'As mudanças feitas no modelo de demonstração serão desfeitas.', 'Restaurar'))) return; await construirDemo(); CFG.prefs.pendente = false; UI.sub = null; render(); aviso('Modelo restaurado.'); };

window.addEventListener('DOMContentLoaded', () => { iniciar().catch(x => { console.error(x); document.body.insertAdjacentHTML('afterbegin', '<p style="padding:1rem;color:#C8452F">Erro ao iniciar a Tecelã: ' + e(x.message || x) + '</p>'); }); });
