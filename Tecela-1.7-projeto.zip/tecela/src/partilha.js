/* ==========================================================================
   Tecelã — Partilha pedagógica
   Leva para outro educador só o material pedagógico (planejamentos, repertório,
   biblioteca própria, modelos, comunicados, vivências e festas), sem dados de
   pessoas nem da escola. Arquivo próprio: .tecela-partilha.

   REGRA PERMANENTE: toda coleção de STORES precisa estar em PARTILHA.pode ou em
   PARTILHA.nunca, e todo campo das coleções que podem ir precisa estar em
   "vai" ou em "fica". O teste teste-partilha.js falha se algo ficar sem
   classificação. Ao criar uma coleção ou um campo novo, classifique aqui.
   ========================================================================== */
'use strict';
const PT_META = ['id', 'criado', 'alterado', 'partilha'];
const PARTILHA = {
  pode: {
    curriculo: { rot: 'Época do currículo', vai: ['serie', 'componente', 'titulo', 'periodo', 'semanas', 'conteudos', 'objetivos', 'bncc', 'ordem'], fica: ['realizadas'] },
    programa: { rot: 'Conteúdo programático', vai: ['serie', 'comp', 'aulas', 'texto', 'ordem'], fica: [] },
    documentos: { rot: 'Planejamento', vai: ['tipo', 'titulo', 'secoes'], fica: ['turmaId', 'alunoId', 'serie', 'epocaId', 'cab', 'versoes', 'hash', 'estado', 'finalizadoEm'], tipos: ['anual', 'epoca'],
      secoes: { vai: ['k', 'tit', 'tipo', 'txt', 'cols', 'linhas', 'campos', 'auto', 'manual', 'naoImprimir'], fica: ['dias'] }, secoesFora: ['avaliacao', 'anterior'] },
    repertorio: { rot: 'Repertório', vai: ['tipo', 'titulo', 'autor', 'rotina', 'texto'], fica: ['turmaId', 'epocaId', 'usos'] },
    biblioteca: { rot: 'Biblioteca', vai: ['grupo', 'titulo', 'texto', 'fonte', 'ordem'], fica: ['origem', 'oculto', 'editado'] },
    modelosBoletim: { rot: 'Modelo de boletim', vai: ['serie', 'secoes'], fica: [] },
    comunicados: { rot: 'Modelo de comunicado', vai: ['nome', 'texto'], fica: ['chave'] },
    vivencias: { rot: 'Vivência', vai: ['tipo', 'titulo', 'duracao', 'descricao', 'info'], fica: ['turmaId', 'data', 'hora', 'local', 'responsavel', 'epocaId', 'todos', 'participantes', 'repete', 'repeteAte', 'dataFim', 'excecoes', 'avisar', 'obs'],
      info: { vai: ['programacao', 'vestimenta', 'alimentacao', 'cardapio', 'compras', 'percurso', 'adicionais'], fica: ['endereco', 'contato', 'concentracao', 'saida', 'chegada', 'turmasDatas', 'adultos', 'orcamento', 'pagamento', 'documentacao'] } }
  },
  /* coleções que nunca saem numa partilha */
  nunca: ['config', 'timbrado', 'turmas', 'alunos', 'matriculas', 'anotacoes', 'atas', 'marcacoes', 'boletins', 'perfisAluno', 'perfisTurma', 'cadastros', 'eventos', 'tarefas', 'observacoes', 'conselhos', 'reforcos', 'contatos'],
  /* dos ajustes, só as festas personalizadas */
  prefs: ['festas']
};
const PT_TURMA = ['documentos', 'repertorio', 'vivencias'];        // precisam de uma turma de destino
const PT_NOME = { curriculo: 'titulo', programa: 'comp', documentos: 'titulo', repertorio: 'titulo', biblioteca: 'titulo', comunicados: 'nome', vivencias: 'titulo', festas: 'nome' };
const PT_NAO_TEXTO = ['tipo', 'k', 'componente', 'bncc', 'serie', 'quando', 'chave', 'grupo', 'cols', 'campos', 'key', 'hora', 'ordem'];
const PT_MARCAS = /\[(aluno|responsável|professora|pessoa|escola|contato)\]/g;
const ACEITA_PARTILHA = ANDROID ? 'application/octet-stream,application/json,text/plain,.tecela-partilha,.json,.txt' : APPLE_TOQUE ? '' : '.tecela-partilha,.json,application/json';
const rotPt = s => s === 'festas' ? 'Festa do ano' : PARTILHA.pode[s].rot;

/* ---------- nomes conhecidos, trocados por marcadores ---------- */
const semFicticio = s => String(s || '').replace(/\s*\((fict[íi]ci[oa]s?)\)/gi, '').trim();
const primeiro = s => semFicticio(s).split(/\s+/)[0] || '';
function nomesConhecidos() {
  const m = new Map(), add = (s, rot) => { s = semFicticio(s); if (s.length >= 3 && !m.has(s)) m.set(s, rot); };
  D.alunos.forEach(a => { add(a.nome, '[aluno]'); add(a.chamada, '[aluno]'); add(primeiro(a.nome), '[aluno]'); (a.responsaveis || []).forEach(r => { add(r.nome, '[responsável]'); add(primeiro(r.nome), '[responsável]'); }); });
  D.turmas.forEach(t => { add(t.professora, '[professora]'); add(primeiro(t.professora), '[professora]'); (t.materias || []).forEach(x => { add(x.prof, '[professora]'); add(primeiro(x.prof), '[professora]'); }); });
  D.atas.forEach(a => (a.participantes || []).forEach(p => { add(p.nome, '[pessoa]'); add(primeiro(p.nome), '[pessoa]'); }));
  D.conselhos.forEach(c => String(c.participantes || '').split(/[,;\n]/).forEach(p => { const n = p.replace(/\(.*?\)/g, '').trim(); add(n, '[pessoa]'); add(primeiro(n), '[pessoa]'); }));
  D.vivencias.forEach(v => { const r = String(v.responsavel || '').split(',')[0].trim(); if (/^[A-ZÀ-Ú]/.test(r) && !/^(Fam[íi]lias?|Professor)/.test(r)) { add(r, '[pessoa]'); add(r.replace(/^(Seu|Dona|Sr\.?|Sra\.?|Dr\.?|Dra\.?)\s+/, ''), '[pessoa]'); } });
  D.contatos.forEach(c => add(c.quem && /^[A-ZÀ-Ú]/.test(c.quem) ? c.quem : '', '[pessoa]'));
  add(CFG.escola.nome, '[escola]');
  D.timbrado.forEach(t => String(t.cab || '').split(/\n|·|\|/).forEach(p => { p = p.trim(); add(p, '[escola]'); p.split(/,|–| - /).forEach(q => add(q.trim(), '[escola]')); }));
  return [...m.entries()].filter(([s]) => !/^\d+$/.test(s)).sort((a, b) => b[0].length - a[0].length);
}
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function limparTexto(s, nomes) {
  let n = 0, txt = String(s);
  txt = txt.replace(/[\w.+-]+@[\w-]+(\.[\w-]+)+/g, () => { n++; return '[contato]'; });
  txt = txt.replace(/(\(?\b\d{2}\)?\s?)?\b\d{4,5}[-\s]?\d{4}\b/g, () => { n++; return '[contato]'; });
  for (const [nome, rot] of nomes) {
    const re = new RegExp('(?<![\\p{L}\\p{N}])' + escRe(nome) + '(?![\\p{L}\\p{N}])', 'gu');
    txt = txt.replace(re, () => { n++; return rot; });
  }
  return { txt, n };
}
/* palavras com cara de nome próprio, fora do início da frase */
const PT_COMUNS = new Set('Waldorf Steiner Rudolf Deus Brasil BNCC Natal Páscoa Advento São João Micael Pentecostes Janeiro Fevereiro Março Abril Maio Junho Julho Agosto Setembro Outubro Novembro Dezembro Segunda Terça Quarta Quinta Sexta Sábado Domingo Rubicão Antigo Testamento Novo Grimm Esopo Bíblia Terra Sol Lua Dona Seu Senhor Senhora Professora Professor Época Epígrafe'.split(' '));
function suspeitos(txt) {
  const xs = new Set(); txt = String(txt);
  for (const m of String(txt).matchAll(/\p{Lu}\p{Ll}{2,}/gu)) {
    const w = m[0], prev = txt[m.index - 1] || '', antes = txt.slice(0, m.index).replace(/[\s"“'(«]+$/, ''), ult = antes.slice(-1);
    if (/["“'(«‘]/.test(prev)) continue; /* palavra logo após aspas ou parêntese: título ou citação */
    if (!antes || /[.!?:\n•—–-]/.test(ult) || PT_COMUNS.has(w)) continue;
    if (/[\p{L}]/u.test(txt[m.index - 1] || '')) continue;
    if (new RegExp('(?<![\\p{L}])' + escRe(w.toLowerCase()) + '(?![\\p{L}])', 'u').test(txt)) continue;
    xs.add(w);
  }
  return [...xs];
}
/* percorre todos os textos de um registro (para limpar, conferir e editar) */
function textosDe(r, base, out) {
  out = out || []; base = base || '';
  if (typeof r === 'string') { if (r.trim()) out.push(base); return out; }
  if (Array.isArray(r)) { r.forEach((x, i) => textosDe(x, base ? base + '.' + i : String(i), out)); return out; }
  if (r && typeof r === 'object') Object.keys(r).forEach(k => { if (!PT_NAO_TEXTO.includes(k)) textosDe(r[k], base ? base + '.' + k : k, out); });
  return out;
}
const lerCaminho = (o, p) => p.split('.').reduce((x, k) => x == null ? x : x[k], o);
const porCaminho = (o, p, v) => { const ks = p.split('.'), u = ks.pop(); ks.reduce((x, k) => x[k], o)[u] = v; };

/* ---------- seleção do que pode ir ---------- */
const pegar = (r, campos) => { const o = {}; campos.forEach(k => { if (r[k] !== undefined) o[k] = clone(r[k]); }); return o; };
function copiaPartilhavel(s, r) {
  const P = PARTILHA.pode[s], o = pegar(r, P.vai);
  if (s === 'documentos') {
    o.secoes = (r.secoes || []).filter(x => !P.secoesFora.includes(x.k)).map(x => { const y = pegar(x, P.secoes.vai); if (x.tipo === 'diario') y.dias = []; return y; });
    o.secoes.forEach(x => { if (x.k === 'epocas' && x.cols && x.linhas) { const fora = x.cols.map((c, i) => /início|fim|dias letivos/i.test(c) ? i : -1).filter(i => i >= 0); x.linhas = x.linhas.map(l => l.map((v, i) => fora.includes(i) ? '' : v)); } });
  }
  if (s === 'vivencias') o.info = pegar(r.info || {}, P.info.vai);
  return o;
}
const semRecebido = n => String(n || '').replace(/\s*\(recebido(?: \d+)?\)$/, '');
/* "assinatura" do conteúdo, para achar repetidos; o "(recebido)" no nome não conta */
const assinaturaConteudo = (s, r) => { const o = s === 'festas' ? [semRecebido(r.nome), r.quando, r.passos] : copiaPartilhavel(s, r); if (s !== 'festas' && PT_NOME[s] && o[PT_NOME[s]] != null) o[PT_NOME[s]] = semRecebido(o[PT_NOME[s]]); return JSON.stringify(o, (k, v) => k === 'ordem' ? undefined : v); };
function epocaRef(id) { const c = IX.curriculo[id]; return c ? pegar(c, PARTILHA.pode.curriculo.vai) : null; }
const bibOriginal = r => typeof BIBLIO !== 'undefined' ? BIBLIO.find(x => x.id === r.id) : null;

function candidatos() {
  const xs = [], add = (s, r, extra) => xs.push(Object.assign({ s, r, on: true }, extra || {}));
  const tv = new Set(D.turmas.map(t => t.id));
  D.documentos.filter(d => PARTILHA.pode.documentos.tipos.includes(d.tipo) && tv.has(d.turmaId)).forEach(d => add('documentos', copiaPartilhavel('documentos', d), { ep: d.tipo === 'epoca' ? epocaRef(d.epocaId) : null, orig: rotuloTurma(IX.turmas[d.turmaId]) }));
  D.curriculo.forEach(c => add('curriculo', copiaPartilhavel('curriculo', c)));
  D.programa.forEach(p => add('programa', copiaPartilhavel('programa', p)));
  D.repertorio.forEach(r => add('repertorio', copiaPartilhavel('repertorio', r), { ep: r.epocaId ? epocaRef(r.epocaId) : null }));
  D.biblioteca.filter(b => !b.oculto && !b.partilha && (b.origem === 'proprio' || (bibOriginal(b) && (bibOriginal(b).texto !== b.texto || bibOriginal(b).titulo !== b.titulo)))).forEach(b => add('biblioteca', copiaPartilhavel('biblioteca', b)));
  D.modelosBoletim.forEach(m => add('modelosBoletim', copiaPartilhavel('modelosBoletim', m)));
  D.comunicados.forEach(c => add('comunicados', copiaPartilhavel('comunicados', c)));
  D.vivencias.forEach(v => add('vivencias', copiaPartilhavel('vivencias', v), { ep: v.epocaId ? epocaRef(v.epocaId) : null }));
  if (Array.isArray(CFG.prefs.festas)) CFG.prefs.festas.forEach(f => add('festas', { nome: f.nome, quando: f.quando, passos: clone(f.passos || []) }));
  return xs;
}
function montarPartilha() {
  const nomes = nomesConhecidos(), xs = candidatos();
  xs.forEach(it => { it.trocas = 0; textosDe(it.r).forEach(p => { const v = lerCaminho(it.r, p), l = limparTexto(v, nomes); if (l.n) { porCaminho(it.r, p, l.txt); it.trocas += l.n; } }); if (it.ep) textosDe(it.ep).forEach(p => porCaminho(it.ep, p, limparTexto(lerCaminho(it.ep, p), nomes).txt)); });
  return { itens: xs, de: '', comSenha: false };
}
const tituloItem = it => { const r = it.r, s = it.s; if (s === 'documentos') return (r.titulo || (r.tipo === 'anual' ? 'Planejamento anual' : 'Plano de época')) + (it.orig ? ' · ' + it.orig : ''); if (s === 'modelosBoletim') return 'Seções do boletim do ' + r.serie + 'º ano'; if (s === 'curriculo' || s === 'programa') return (r[PT_NOME[s]] || '') + ' · ' + r.serie + 'º ano'; return r[PT_NOME[s]] || r.titulo || '(sem título)'; };
const realce = txt => e(txt).replace(PT_MARCAS, m => '<mark class="pt-troca">' + m + '</mark>');
function previaItem(it) {
  const ps = textosDe(it.r), sus = new Set();
  const linhas = ps.map(p => { const v = lerCaminho(it.r, p); suspeitos(v).forEach(w => sus.add(w)); return v; });
  let h = linhas.map(v => { let x = realce(v); suspeitos(v).forEach(w => { x = x.replace(new RegExp('(?<![\\p{L}>])' + escRe(w) + '(?![\\p{L}])', 'gu'), '<mark class="pt-susp">' + w + '</mark>'); }); return '<div class="pt-txt">' + x + '</div>'; }).join('');
  return { h: h || '<p class="dica">Sem texto.</p>', sus: sus.size };
}

/* ---------- tela ---------- */
T.partilha = () => {
  if (UI.pt) return telaRevisao(UI.pt);
  const etqs = recebidas();
  let h = '<div class="linha"><button class="btn" data-a="ir" data-t="ajustes">← Ajustes e arquivo</button></div><h1>Partilha pedagógica</h1><p>Compartilhe com outro educador o seu material pedagógico, sem nenhum dado de crianças, famílias, professoras ou da escola, e receba o material de colegas sem mexer no que já é seu.</p>';
  h += '<div class="linha"><button class="btn pri" data-a="ptCompartilhar">Compartilhar planejamentos</button><button class="btn" data-a="ptReceber">Receber partilha</button><button class="btn" data-a="manualEm" data-id="m-partilha">Saiba mais</button></div>';
  h += '<h2>Material recebido</h2>';
  if (!etqs.length) return h + vazio('Nenhuma partilha recebida até agora.');
  return h + etqs.map(g => '<div class="cartao"><div class="linha" style="margin:0"><h3 style="margin:0">Recebido de ' + e(g.de || 'partilha') + '</h3><span class="dica">' + new Date(g.em).toLocaleString('pt-BR') + ' · ' + g.itens.length + ' ' + (g.itens.length === 1 ? 'item' : 'itens') + '</span><span class="espaco"></span><button class="btn perigo" data-a="ptRemover" data-id="' + g.id + '">Remover o que veio desta partilha</button></div><table class="tabela" style="margin-top:.6rem">' +
    g.itens.map(x => '<tr><td style="width:12rem">' + e(rotPt(x.s)) + '</td><td>' + e(x.titulo) + (x.nota ? ' <span class="dica">(' + e(x.nota) + ')</span>' : '') + '</td><td>' + (x.s === 'documentos' ? '<button class="btn peq" data-a="ptAbrirDoc" data-id="' + x.id + '">Abrir</button>' : x.s === 'modelosBoletim' ? '<button class="btn peq" data-a="ptVerModelo" data-id="' + x.id + '">Ver</button>' : '') + '</td></tr>').join('') + '</table></div>').join('');
};
function telaRevisao(P) {
  const grupos = {}; P.itens.forEach((it, i) => { (grupos[it.s] = grupos[it.s] || []).push(i); });
  const n = P.itens.filter(x => x.on).length;
  let h = '<div class="linha"><button class="btn" data-a="ptSair">← Cancelar</button><h1 style="margin:0">Conferir a partilha</h1></div>';
  h += '<div class="alerta" style="background:var(--violC)"><b>Antes de gerar o arquivo:</b> os nomes que a Tecelã conhece foram trocados por marcadores como <mark class="pt-troca">[aluno]</mark>. Palavras com cara de nome próprio que ela não reconheceu aparecem em <mark class="pt-susp">amarelo</mark>: confira e, se for o caso, edite ou desmarque o item. As mudanças valem só para o arquivo; o seu material fica como está.</div>';
  h += '<p class="dica">Direitos autorais: compartilhar poemas, histórias ou trechos de livros protegidos é responsabilidade de quem envia. Na dúvida, desmarque o item ou deixe só o título e a fonte.</p>';
  if (!P.itens.length) return h + vazio('Ainda não há material pedagógico para compartilhar.');
  h += '<div class="linha"><button class="btn" data-a="ptTodos" data-v="1">Marcar tudo</button><button class="btn" data-a="ptTodos" data-v="0">Desmarcar tudo</button></div>';
  Object.keys(grupos).forEach(s => {
    h += '<h2>' + e(rotPt(s)) + ' <span class="dica">(' + grupos[s].length + ')</span></h2>';
    grupos[s].forEach(i => { const it = P.itens[i], pv = previaItem(it);
      h += '<details class="cartao pt-item' + (it.on ? '' : ' suave') + '"><summary><label class="ck" style="display:inline-flex"><input type="checkbox" data-c="ptSel" data-i="' + i + '"' + (it.on ? ' checked' : '') + '> <b>' + e(tituloItem(it)) + '</b></label>' + (it.trocas ? ' <span class="etq viol">' + it.trocas + ' troca' + (it.trocas > 1 ? 's' : '') + '</span>' : '') + (pv.sus ? ' <span class="etq amar">' + pv.sus + ' a conferir</span>' : '') + (it.editado ? ' <span class="etq rasc">editado para a partilha</span>' : '') + '</summary><div class="pt-previa">' + pv.h + '</div><div class="linha"><button class="btn peq" data-a="ptEditar" data-i="' + i + '">Editar o texto para a partilha</button></div></details>'; });
  });
  h += '<div class="cartao"><h3>Gerar o arquivo</h3><div class="duas">' + campo('Assinar como (opcional)', '<input data-c="ptDe" value="' + e(P.de) + '" placeholder="deixe vazio para não levar nome algum">', 'Quem receber verá “recebido de …”. Vazio: o arquivo não leva nome algum.') + '<div><label class="ck"><input type="checkbox" data-c="ptSenha"' + (P.comSenha ? ' checked' : '') + '> <span>Proteger o arquivo com senha</span></label><p class="dica">A senha será pedida ao gerar. Combine-a com quem vai receber por outro meio.</p></div></div>' +
    '<div class="linha"><button class="btn pri" data-a="ptGerar"' + (n ? '' : ' disabled') + '>Gerar o arquivo (' + n + ' ' + (n === 1 ? 'item' : 'itens') + ')</button></div></div>';
  return h;
}
C_.ptSel = el => { const it = UI.pt.itens[Number(el.dataset.i)]; it.on = el.checked; el.closest('.pt-item').classList.toggle('suave', !el.checked); const b = $('[data-a=ptGerar]'), n = UI.pt.itens.filter(x => x.on).length; if (b) { b.disabled = !n; b.textContent = 'Gerar o arquivo (' + n + ' ' + (n === 1 ? 'item' : 'itens') + ')'; } };
C_.ptDe = el => { UI.pt.de = el.value; };
C_.ptSenha = el => { UI.pt.comSenha = el.checked; };
A.ptTodos = d => { UI.pt.itens.forEach(x => x.on = d.v === '1'); render(); };
A.ptSair = () => { UI.pt = null; ir('partilha'); };
const rotCaminho = (it, p) => { const m = p.match(/^secoes\.(\d+)\.(\w+)/); if (m) { const sc = it.r.secoes[Number(m[1])]; return (sc.tit || 'Seção') + (m[2] === 'tit' ? ' (título)' : m[2] === 'linhas' ? ' (tabela)' : ''); } return ({ titulo: 'Título', texto: 'Texto', nome: 'Nome', descricao: 'Descrição', conteudos: 'Conteúdos', objetivos: 'Objetivos', autor: 'Autor', fonte: 'Fonte', comp: 'Componente', duracao: 'Duração' })[p] || p.replace(/^info\./, '').replace(/\./g, ' › '); };
A.ptEditar = async d => {
  const it = UI.pt.itens[Number(d.i)], ps = textosDe(it.r);
  const v = await dlg({ titulo: 'Editar para a partilha', largo: true, ok: 'Usar estes textos', corpo: '<p class="dica">Estas mudanças valem só para o arquivo da partilha; o seu material continua como está.</p>' + ps.map((p, j) => campo(e(rotCaminho(it, p)), '<textarea name="t' + j + '" style="min-height:' + (String(lerCaminho(it.r, p)).length > 80 ? '6rem' : '2.4rem') + '">' + e(lerCaminho(it.r, p)) + '</textarea>')).join('') });
  if (!v) return; ps.forEach((p, j) => porCaminho(it.r, p, v['t' + j])); it.editado = true; render();
};

/* ---------- avisos resumidos ---------- */
async function avisoPartilha(titulo, itens, extra) {
  return dlg({ titulo, ok: 'Continuar', corpo: '<ul class="pt-aviso">' + itens.map(x => '<li>' + x + '</li>').join('') + '</ul>', extra: '<button type="button" class="btn" data-x="saiba">Saiba mais</button>' + (extra || '') });
}
A.ptCompartilhar = async () => {
  const v = await avisoPartilha('Compartilhar planejamentos', [
    'Vão apenas planejamentos, repertório, biblioteca própria, modelos, comunicados, vivências e festas. <b>Nunca</b> vão dados de crianças, famílias, professoras ou da escola.',
    'Os nomes que a Tecelã conhece são trocados por marcadores como [aluno]. Na próxima tela, confira os trechos destacados em amarelo.',
    'Assinar é opcional, e quem receber poderá editar ou apagar o material livremente.']);
  if (!v) return; if (v._botao === 'saiba') return A.manualEm({ id: 'm-partilha' });
  await descarregarFila(); UI.pt = montarPartilha(); ir('partilha');
};
async function cifrarPartilha(senha, texto) {
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), k = await kek(senha, salt);
  return { s: b64(salt), iv: b64(iv), d: b64(new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k, new TextEncoder().encode(texto)))) };
}
async function decifrarPartilha(c, d, senha) { const k = await kek(senha, ub64(c.s)); return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: ub64(c.iv) }, k, ub64(d))); }
async function arquivoPartilha(P, senha) {
  const itens = P.itens.filter(x => x.on).map(x => { const o = { s: x.s, r: x.r }; if (x.ep) o.ep = x.ep; return o; });
  const base = { app: 'Tecela', tipo: 'partilha', formato: 1, versao: VERSAO, gerado: new Date().toISOString(), de: (P.de || '').trim() || null, n: itens.length };
  if (!senha) return JSON.stringify(Object.assign(base, { itens }));
  const c = await cifrarPartilha(senha, JSON.stringify(itens));
  return JSON.stringify(Object.assign(base, { cripto: { kdf: 'PBKDF2-SHA256-250000', cifra: 'AES-256-GCM', s: c.s, iv: c.iv }, itens: c.d }));
}
A.ptGerar = async () => {
  const P = UI.pt; let senha = null;
  if (P.comSenha) {
    if (!temCripto()) return informar('Sem criptografia', '<p>Este navegador não oferece a criptografia necessária. Gere o arquivo sem senha ou use outro navegador.</p>');
    const v = await dlg({ titulo: 'Senha da partilha', ok: 'Gerar', corpo: campo('Senha (mínimo de 6 caracteres)', '<input type="password" name="s1" autofocus autocomplete="new-password">') + campo('Repita a senha', '<input type="password" name="s2" autocomplete="new-password">'), validar: v => v.s1.length < 6 ? 'Use pelo menos 6 caracteres.' : v.s1 !== v.s2 ? 'As senhas não conferem.' : null });
    if (!v) return; senha = v.s1;
  }
  const txt = await arquivoPartilha(P, senha), de = (P.de || '').trim(), nome = 'Partilha_Tecela_' + (de ? nomeArq(de) + '_' : '') + carimbo() + '.tecela-partilha';
  baixar(nome, txt, 'application/json');
  await informar('Arquivo gerado', '<p>O arquivo <b>' + e(nome) + '</b> foi salvo na sua pasta de downloads, com ' + P.itens.filter(x => x.on).length + ' itens.</p><p>Envie-o a quem vai receber' + (senha ? ' e combine a senha por outro meio' : '') + '. Na Tecelã dela, o caminho é Ajustes e arquivo → Partilha pedagógica → Receber partilha.</p>');
};

/* ---------- receber ---------- */
A.ptReceber = async () => {
  const v = await avisoPartilha('Receber partilha', [
    'Nada do que você já tem será alterado ou substituído: tudo entra como item novo, marcado “recebido”.',
    'Itens iguais aos seus são pulados; com o mesmo nome e conteúdo diferente, entram como “(recebido)”.',
    'Dá para desfazer depois, pelo botão “Remover o que veio desta partilha”.',
    'Recomendamos salvar uma cópia de segurança antes.'], '<button type="button" class="btn" data-x="copia">Salvar cópia antes</button>');
  if (!v) return; if (v._botao === 'saiba') return A.manualEm({ id: 'm-partilha' });
  if (v._botao === 'copia') { await guardar(); }
  const f = await escolherArquivo(ACEITA_PARTILHA); if (!f) return;
  let o; try { o = await lerPartilha(await f.text()); } catch (x) { return informar('Não foi possível abrir', '<p>' + x.message + '</p>'); }
  if (!o) return;
  await escolherEImportar(o);
};
async function lerPartilha(txt) {
  let o; try { o = JSON.parse(txt); } catch (x) { throw new Error('Este não é um arquivo da Tecelã.'); }
  if (!o || o.app !== 'Tecela') throw new Error('Este não é um arquivo da Tecelã.');
  if (o.tipo !== 'partilha') throw new Error('Este arquivo é uma <b>cópia de segurança</b> (arquivo de trabalho), não uma partilha. Para abri-lo, use “Abrir outro arquivo”, em Ajustes e arquivo. Atenção: abrir uma cópia substitui os dados deste aparelho.');
  if (o.cripto) {
    if (!temCripto()) throw new Error('Este arquivo tem senha, mas este navegador não oferece a criptografia necessária.');
    let itens = null;
    const r = await dlg({ titulo: 'Partilha protegida por senha', ok: 'Abrir', corpo: '<p>Quem enviou deve ter combinado a senha com você.</p>' + campo('Senha da partilha', '<input type="password" name="senha" autofocus>'), validar: async v => { try { itens = JSON.parse(await decifrarPartilha(o.cripto, o.itens, v.senha)); } catch (x) { return 'Senha incorreta.'; } } });
    if (!r) return null; o.itens = itens;
  }
  if (!Array.isArray(o.itens)) throw new Error('A partilha está vazia ou danificada.');
  o.itens = o.itens.filter(x => x && (x.s === 'festas' || PARTILHA.pode[x.s]) && x.r);
  return o;
}
async function escolherEImportar(o) {
  const ts = turmasVisiveis(), atual = turmaAtual(), precisa = o.itens.some(x => PT_TURMA.includes(x.s)), grupos = {};
  o.itens.forEach((x, i) => (grupos[x.s] = grupos[x.s] || []).push(i));
  const corpo = '<p>' + (o.de ? 'Enviado por <b>' + e(o.de) + '</b>' : 'Partilha sem assinatura') + (o.gerado ? ', em ' + new Date(o.gerado).toLocaleDateString('pt-BR') : '') + '. Escolha o que trazer.</p>' +
    (precisa ? (ts.length ? campo('Turma que recebe os planejamentos, o repertório e as vivências', '<select name="turma">' + ts.map(t => '<option value="' + t.id + '"' + (atual && t.id === atual.id ? ' selected' : '') + '>' + e(rotuloTurma(t)) + '</option>').join('') + '</select>', 'Nada do que já existe nessa turma é alterado.') : '<p class="alerta">Para receber planejamentos, repertório e vivências, cadastre uma turma antes. Os demais itens podem vir agora.</p>') : '') +
    '<div class="pt-lista">' + Object.keys(grupos).map(s => '<h4>' + e(rotPt(s)) + '</h4>' + grupos[s].map(i => { const x = o.itens[i], des = PT_TURMA.includes(x.s) && !ts.length; return '<label class="ck"><input type="checkbox" name="sel" data-multi="1" value="' + i + '"' + (des ? ' disabled' : ' checked') + '> ' + e(tituloItem(x)) + '</label>'; }).join('')).join('') + '</div>';
  const v = await dlg({ titulo: 'Receber partilha', largo: true, ok: 'Trazer os itens marcados', corpo, validar: v => v.sel.length ? null : 'Marque ao menos um item.' });
  if (!v) return;
  const res = await importarPartilha(o, v.sel.map(Number), v.turma || null);
  render(); await informar('Partilha recebida', resumoImport(res));
  return res;
}
function nomeLivre(nome, existe) { if (!existe(nome)) return nome; let n = nome + ' (recebido)', i = 2; while (existe(n)) n = nome + ' (recebido ' + i++ + ')'; return n; }
async function importarPartilha(o, sel, turmaId) {
  const etq = { id: 'p' + uid(), de: o.de || null, em: new Date().toISOString() }, t = turmaId ? IX.turmas[turmaId] : null;
  const res = { etq, entrou: {}, pulados: 0, renomeados: 0, guardados: 0 }, conta = s => res.entrou[s] = (res.entrou[s] || 0) + 1;
  const tag = () => Object.assign({}, etq);
  const mapEpoca = async (ep, criar) => {
    if (!ep || !t) return null; const c = D.curriculo.find(x => x.serie === t.serie && norm1(x.titulo) === norm1(ep.titulo)); if (c) return c.id;
    if (!criar) return null; const n = await salvar('curriculo', Object.assign(pegar(ep, PARTILHA.pode.curriculo.vai), { serie: t.serie, realizadas: [], ordem: D.curriculo.filter(x => x.serie === t.serie).length, partilha: tag() })); return n.id;
  };
  for (const i of sel) {
    const x = o.itens[i]; if (!x) continue; const s = x.s, r = clone(x.r);
    if (PT_TURMA.includes(s) && !t) continue;
    if (s === 'festas') {
      const lista = Array.isArray(CFG.prefs.festas) ? clone(CFG.prefs.festas) : clone(FESTAS_PADRAO), sig = assinaturaConteudo('festas', r);
      if (lista.some(f => assinaturaConteudo('festas', f) === sig)) { res.pulados++; continue; }
      const nome = nomeLivre(r.nome, n => lista.some(f => f.nome === n)); if (nome !== r.nome) res.renomeados++;
      lista.push({ k: 'f' + uid(), nome, quando: r.quando, passos: r.passos || [], partilha: tag() }); await prefs({ festas: lista }); marcarPendente(); conta(s); continue;
    }
    const P = PARTILHA.pode[s]; if (!P) continue;
    const limpo = pegar(r, P.vai); if (s === 'vivencias') limpo.info = pegar(r.info || {}, P.info.vai);
    if (s === 'documentos' && !P.tipos.includes(limpo.tipo)) continue;
    /* escopo: onde procurar repetidos e nomes iguais */
    const escopo = D[s].filter(y => s === 'documentos' ? y.turmaId === t.id && y.tipo === limpo.tipo : PT_TURMA.includes(s) ? y.turmaId === t.id : (s === 'curriculo' || s === 'programa' || s === 'modelosBoletim') ? y.serie === limpo.serie : true);
    const sig = assinaturaConteudo(s, limpo);
    if (escopo.some(y => assinaturaConteudo(s, y) === sig)) { res.pulados++; continue; }
    const nr = Object.assign(limpo, { partilha: tag() });
    if (s === 'documentos') { Object.assign(nr, { turmaId: t.id, cab: {}, versoes: [] }); if (nr.tipo === 'epoca') { nr.epocaId = await mapEpoca(x.ep, true); if (!nr.epocaId) continue; } }
    if (s === 'repertorio') Object.assign(nr, { turmaId: t.id, epocaId: await mapEpoca(x.ep, false), usos: [] });
    if (s === 'vivencias') Object.assign(nr, { turmaId: t.id, data: '', hora: '', local: '', responsavel: '', epocaId: (await mapEpoca(x.ep, false)) || '', todos: true, participantes: [] });
    if (s === 'biblioteca') Object.assign(nr, { id: 'proprio-' + uid(), origem: 'proprio' });
    if (s === 'comunicados') nr.chave = 'c' + uid();
    if (s === 'curriculo') nr.realizadas = [];
    if (s === 'programa' && !D.programa.some(y => y.serie === nr.serie)) { for (const p of progSerie(nr.serie)) await salvar('programa', { serie: nr.serie, comp: p.comp, aulas: p.aulas, texto: p.texto, ordem: p.ordem }); }
    if (s === 'modelosBoletim') { if (escopo.length) { nr.referencia = true; res.guardados++; } }
    const campoNome = PT_NOME[s];
    if (campoNome && nr[campoNome]) {
      const existe = s === 'comunicados' ? n => modelosCom().some(m => m.nome === n) : n => D[s].some(y => y[campoNome] === n && (s === 'documentos' ? y.turmaId === t.id && y.tipo === nr.tipo : PT_TURMA.includes(s) ? y.turmaId === t.id : (s === 'curriculo' || s === 'programa') ? y.serie === nr.serie : true));
      const novo = nomeLivre(nr[campoNome], existe); if (novo !== nr[campoNome]) { nr[campoNome] = novo; res.renomeados++; }
    }
    if (s === 'documentos' && (nr.tipo === 'anual' ? docsDe('anual', y => y.turmaId === t.id && !y.partilha).length : docsDe('epoca', y => y.turmaId === t.id && y.epocaId === nr.epocaId && !y.partilha).length)) res.guardados++;
    await salvar(s, nr); conta(s);
  }
  return res;
}
function resumoImport(res) {
  const ks = Object.keys(res.entrou), tot = ks.reduce((a, k) => a + res.entrou[k], 0);
  const onde = { documentos: 'Planejamento (e Material recebido, aqui na Partilha)', curriculo: 'Currículo e BNCC', programa: 'Planejamento → Rascunhos de todos os anos', repertorio: 'Repertório', biblioteca: 'Biblioteca', modelosBoletim: 'Boletins → seções do boletim', comunicados: 'Comunicados', vivencias: 'Vivências (sem data)', festas: 'Planejamento → Ano letivo → Festas do ano' };
  return '<p><b>' + tot + ' ' + (tot === 1 ? 'item entrou' : 'itens entraram') + '</b>, marcados “recebido de ' + e(res.etq.de || 'partilha') + '”.</p>' +
    (ks.length ? '<table class="tabela"><tr><th>Tipo</th><th>Quantos</th><th>Onde encontrar</th></tr>' + ks.map(k => '<tr><td>' + e(rotPt(k)) + '</td><td>' + res.entrou[k] + '</td><td>' + e(onde[k]) + '</td></tr>').join('') + '</table>' : '') +
    '<ul>' + (res.pulados ? '<li>' + res.pulados + ' repetido(s) pulado(s), porque você já tinha igual.</li>' : '') + (res.renomeados ? '<li>' + res.renomeados + ' ganharam “(recebido)” no nome, porque você já tinha um com o mesmo nome.</li>' : '') + (res.guardados ? '<li>' + res.guardados + ' ficaram guardados à parte, porque a turma ou o ano já tem o seu: abra-os em Ajustes e arquivo → Partilha pedagógica → Material recebido.</li>' : '') + '<li>Nada do que você já tinha foi alterado. Para desfazer, use “Remover o que veio desta partilha”.</li></ul>';
}

/* ---------- material recebido e desfazer ---------- */
function recebidas() {
  const g = {}, add = (s, r, titulo, nota) => { const p = r.partilha; (g[p.id] = g[p.id] || { id: p.id, de: p.de, em: p.em, itens: [] }).itens.push({ s, id: r.id, titulo, nota }); };
  Object.keys(PARTILHA.pode).forEach(s => D[s].filter(r => r.partilha).forEach(r => {
    const principal = s === 'documentos' ? (r.tipo === 'anual' ? anualDe(IX.turmas[r.turmaId] || {}) : planoEpocaDe(IX.turmas[r.turmaId] || {}, r.epocaId)) === r : s === 'modelosBoletim' ? !r.referencia : true;
    add(s, r, tituloItem({ s, r, orig: s === 'documentos' ? rotuloTurma(IX.turmas[r.turmaId]) : '' }), principal ? '' : 'guardado à parte');
  }));
  (Array.isArray(CFG.prefs.festas) ? CFG.prefs.festas : []).filter(f => f.partilha).forEach(f => add('festas', f, f.nome));
  return Object.values(g).sort((a, b) => b.em.localeCompare(a.em));
}
A.ptRemover = async d => {
  const g = recebidas().find(x => x.id === d.id); if (!g) return;
  if (!(await confirmar('Remover o que veio desta partilha?', 'Saem os ' + g.itens.length + ' itens recebidos de ' + e(g.de || 'partilha') + ' em ' + new Date(g.em).toLocaleString('pt-BR') + ', inclusive o que você editou neles. Nada do seu material é tocado.', 'Remover'))) return;
  await removerPartilha(d.id); render(); aviso('Itens da partilha removidos.');
};
async function removerPartilha(id) {
  for (const s of Object.keys(PARTILHA.pode)) for (const r of D[s].filter(r => r.partilha && r.partilha.id === id)) await apagar(s, r.id);
  if (Array.isArray(CFG.prefs.festas) && CFG.prefs.festas.some(f => f.partilha && f.partilha.id === id)) await prefs({ festas: CFG.prefs.festas.filter(f => !(f.partilha && f.partilha.id === id)) });
}
A.ptAbrirDoc = d => { const x = IX.documentos[d.id]; if (!x) return; if (x.turmaId && IX.turmas[x.turmaId]) CFG.prefs.turmaId = x.turmaId; ir('planej', x.id); };
A.ptVerModelo = d => { const m = IX.modelosBoletim[d.id]; if (m) informar('Seções do boletim recebidas (' + m.serie + 'º ano)', (m.referencia ? '<p class="dica">Guardado à parte, porque você já tem o seu modelo deste ano. Use-o como referência para ajustar o seu em Boletins.</p>' : '') + '<ol>' + m.secoes.map(x => '<li>' + e(x.titulo) + (x.ativa ? '' : ' <span class="dica">(desligada)</span>') + '</li>').join('') + '</ol>'); };
/* aviso na tela de planejamento quando há planejamentos recebidos guardados à parte */
function avisoRecebidos(t) {
  const n = D.documentos.filter(d => d.partilha && d.turmaId === t.id && (d.tipo === 'anual' ? anualDe(t) !== d : d.tipo === 'epoca' && planoEpocaDe(t, d.epocaId) !== d)).length;
  return n ? '<div class="alerta" style="background:var(--violC)">Há ' + n + ' planejamento' + (n > 1 ? 's' : '') + ' recebido' + (n > 1 ? 's' : '') + ' por partilha guardado' + (n > 1 ? 's' : '') + ' à parte, porque esta turma já tem os seus. <button class="btn peq" data-a="ir" data-t="partilha">Ver material recebido</button></div>' : '';
}
