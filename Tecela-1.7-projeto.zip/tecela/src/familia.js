/* ==========================================================================
   Tecelã — Famílias e acompanhamento: saúde e segurança de cada criança,
   ficha de emergência e autorização para passeios, entrevista inicial com a
   família, estudo de criança, contatos com as famílias e comunicados.
   Tudo nasce do que já está registrado, para não escrever duas vezes.
   ========================================================================== */
'use strict';

/* ---------- saúde e segurança (cadastro do aluno) ---------- */
const CAMPOS_SEG = [['alergias', 'Alergias e restrições alimentares'], ['medicamentos', 'Medicamentos e cuidados'], ['plano', 'Plano de saúde e carteirinha'], ['emergencia', 'Contato de emergência (além dos responsáveis)'], ['buscam', 'Quem pode buscar a criança']];
function cartaoSaude(a) {
  const s = a.seg || {};
  return '<div class="cartao" data-rec="alunos:' + a.id + '"><h3>Saúde e segurança</h3><p class="dica">Para emergências, passeios e o roteiro do professor substituto. Diferente dos pontos de atenção, estas informações <b>saem impressas</b> na ficha de emergência e no roteiro: escreva só o que quem cuida da criança precisa saber.</p><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">' +
    CAMPOS_SEG.map(([k, r]) => campo(r, area('seg.' + k, s[k], 'style="min-height:2.4rem"'))).join('') + '</div></div>';
}
const alergiasDe = a => [(a.seg || {}).alergias].concat((a.atencao || []).filter(x => x.situacao !== 'resolvido' && x.tipo === 'alergia' && x.sigiloso === false).map(x => x.descricao)).filter(Boolean).join('; ');
const respTxt = a => (a.responsaveis || []).filter(r => r.nome || r.tel).map(r => (r.nome || '') + (r.parentesco ? ' (' + r.parentesco + ')' : '') + (r.tel ? ': ' + r.tel : '')).join('\n');

/* ---------- ficha de emergência e autorização (a partir da vivência) ---------- */
const alunosDaViv = v => { const al = alunosDaTurma(v.turmaId); return v.todos === false ? al.filter(a => (v.participantes || []).includes(a.id)) : al; };
function docEmergencia(v) {
  const t = IX.turmas[v.turmaId] || turmaAtual(), al = alunosDaViv(v), inf = v.info || {};
  const linhas = al.map(a => [a.nome + (a.nasc ? '\n' + dataBR(a.nasc) : ''), respTxt(a), (a.seg || {}).emergencia || '', alergiasDe(a), (a.seg || {}).medicamentos || '', (a.seg || {}).plano || '', (a.seg || {}).buscam || '']);
  const b = [{ t: 'tit', txt: 'Ficha de emergência — ' + v.titulo }, { t: 'pares', linhas: [['Turma', rotuloTurma(t)], ['Data', v.data ? dataBR(v.data) + ' (' + diaSemana(v.data) + ')' : ''], ['Local', v.local || ''], ['Saída e volta', [inf.saida, inf.chegada].filter(Boolean).join(' · ')], ['Adultos', inf.adultos || ''], ['Escola', CFG.escola.nome || '']].filter(x => x[1]) },
    { t: 'tabela', cab: ['Criança', 'Responsáveis e telefones', 'Emergência', 'Alergias e restrições', 'Medicamentos e cuidados', 'Plano de saúde', 'Quem pode buscar'], linhas },
    { t: 'nota', txt: 'Documento com dados pessoais de crianças: leve só durante a vivência e devolva à professora depois.' }];
  return { nome: 'Ficha_emergencia_' + v.titulo, titulo: 'Ficha de emergência — ' + v.titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), paisagem: true, blocos: b };
}
function docAutorizacao(v) {
  const t = IX.turmas[v.turmaId] || turmaAtual(), inf = v.info || {}, quando = v.data ? dataBR(v.data) + ' (' + diaSemana(v.data) + ')' : 'data a combinar', b = [];
  alunosDaViv(v).forEach((a, i) => {
    if (i && i % 2 === 0) b.push({ t: 'quebra' });
    b.push({ t: 'h', txt: v.titulo + ' — ' + quando },
      { t: 'p', txt: [v.local ? 'Local: ' + v.local + '.' : '', inf.saida ? 'Saída da escola: ' + inf.saida + '.' : '', inf.chegada ? 'Volta: ' + inf.chegada + '.' : '', inf.vestimenta ? 'Roupa: ' + inf.vestimenta + '.' : '', inf.alimentacao ? 'Alimentação: ' + inf.alimentacao + '.' : '', inf.orcamento ? 'Custo: ' + inf.orcamento + '.' : ''].filter(Boolean).join(' ') },
      { t: 'centro', linhas: ['- - - - - - - - - - - - - - - ✂  destaque e devolva à professora  - - - - - - - - - - - - - - -'] },
      { t: 'p', txt: substituir('Eu, ________________________________________, responsável por ' + a.nome + ', {o aluno/a aluna} do ' + rotuloTurma(t) + ', autorizo sua participação em “' + v.titulo + '”, em ' + quando + (v.local ? ', em ' + v.local : '') + '.', a, t) },
      { t: 'p', txt: 'Telefone para contato no dia: ____________________    Assinatura: ______________________________    Data: ___/___/______' });
  });
  return { nome: 'Autorizacao_' + v.titulo, titulo: 'Autorização — ' + v.titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
A.vivEmergencia = async d => { await descarregarFila(); const v = IX.vivencias[d.id]; saidaDocumento(docEmergencia(v), { assunto: 'Ficha de emergência — ' + v.titulo }); };
A.vivAutorizacao = async d => { await descarregarFila(); const v = IX.vivencias[d.id]; saidaDocumento(docAutorizacao(v), { assunto: 'Autorização — ' + v.titulo }); };

/* ---------- entrevista inicial com a família (sigilosa) ---------- */
const ENTREVISTA = [['gestacao', 'Gestação e nascimento', 'Como foi a gestação? E o parto? Algo marcante nos primeiros dias?'], ['primeiros', 'Primeiros anos', 'Amamentação, sono do bebê, primeiros passos e primeiras palavras. Como era o temperamento?'], ['saude', 'Saúde', 'Doenças importantes, internações, alergias, visão e audição, acompanhamentos.'], ['sono', 'Sono e despertar', 'Horários, ritual de dormir, sonhos e medos, como acorda.'], ['alimentacao', 'Alimentação', 'O que come bem, o que recusa, restrições, como são as refeições em casa.'], ['brincar', 'Brincar e movimento', 'Do que brinca, sozinha ou com outras crianças, tempo ao ar livre, telas.'], ['familia', 'Família e rotina', 'Quem mora com a criança, irmãos, avós, rotina da semana, mudanças recentes.'], ['escola', 'Escola anterior', 'Por onde passou, como foi a adaptação, o que a família observou.'], ['jeito', 'O jeito da criança', 'Como a família descreve a criança? O que a alegra, o que a assusta, como reage a frustrações?'], ['expectativas', 'Expectativas', 'O que a família espera da escola e desta classe? Como prefere ser contatada?']];
TIPOS_DOC.entrevista = {
  nome: 'Entrevista inicial com a família', auto: false,
  cab: [['data', 'Data da entrevista', 'date'], ['presentes', 'Quem participou']],
  ajuda: 'Documento sigiloso. As perguntas são só um roteiro: escreva o que a família contar, do jeito que contar. O que for escrito aqui aparece na apresentação do Estudo de criança.',
  gerar: d => { const a = IX.alunos[d.alunoId] || {}; return { titulo: 'Entrevista com a família de ' + (a.nome || ''), cab: { data: hojeISO(), presentes: (a.responsaveis || []).map(r => r.nome).filter(Boolean).join(', ') }, secoes: ENTREVISTA.map(([k, tit, q]) => secTexto(k, tit, '(' + q + ')\n')) }; },
  cabDoc: d => { const a = IX.alunos[d.alunoId] || {}, c = d.cab || {}; return ['Criança: ' + (a.nome || ''), 'Data: ' + (c.data ? dataBR(c.data) : ''), 'Participaram: ' + (c.presentes || '')]; }
};
/* o que a família contou, sem as perguntas-roteiro */
const respostaEnt = s => String(s.txt || '').split('\n').filter(l => !/^\(.*\)$/.test(l.trim())).join('\n').trim();

/* ---------- estudo de criança (colegiado, sigiloso) ---------- */
function estudoSecoes(t, a) {
  const m = idadeEm(a.nasc, refTurma(t)), p = ultimoPerfil(a.id), ent = docsDe('entrevista', d => d.alunoId === a.id)[0], pei = peiSecoes(t, a), sec = k => pei.find(s => s.k === k);
  const anots = D.anotacoes.filter(n => !n.sigilo && (n.alunos || []).includes(a.id) && n.turmaId === t.id).sort((x, y) => (y.data || '').localeCompare(x.data || '')).slice(0, 12);
  const ctts = contatosDe(t, a.id).slice(0, 6), refs = reforcosDoAluno(t, a.id), temPei = peiAtivo(t, a.id);
  return [
    secTexto('apresentacao', 'Apresentação da criança', [primeiroNome(a) + ' tem ' + idadeTxt(m) + ' (' + setenio(m) + ')' + (a.entrada ? ', na escola desde ' + dataBR(a.entrada) : '') + '.', a.responsaveis && a.responsaveis.length ? 'Família: ' + a.responsaveis.map(r => r.nome + (r.parentesco ? ' (' + r.parentesco + ')' : '')).filter(x => x.trim()).join(', ') + '.' : ''].concat(ent ? ['Da entrevista com a família (' + dataBR((ent.cab || {}).data || ent.criado.slice(0, 10)) + '):'].concat(ent.secoes.filter(s => respostaEnt(s)).map(s => '- ' + s.tit + ': ' + respostaEnt(s).replace(/\n+/g, ' ').slice(0, 260))) : ['(Ainda não há entrevista com a família.)']).filter(Boolean).join('\n')),
    secTexto('imagem', 'A imagem da criança (perfil)', p ? ['Revisão de ' + dataBR(p.data) + ':'].concat(valoresPerfil(p).map(x => '- ' + x)).join('\n') : '(Ainda não há revisão do perfil.)'),
    Object.assign(sec('obs'), { tit: 'O que a observação do período mostra' }),
    secTexto('anotacoes', 'Anotações recentes', anots.length ? anots.map(n => '- ' + dataBR(n.data).slice(0, 5) + ': ' + n.texto.replace(/\n+/g, ' ')).join('\n') : '(Nenhuma anotação ainda.)'),
    secTexto('apoios', 'Apoios e contatos com a família', [temPei ? '- Tem PEI em ' + t.ano + '.' : '', refs.length ? '- Reforço: ' + refs.map(x => rotRef(x) + (resumoEnc(x) ? ' (' + resumoEnc(x) + ')' : '')).join('; ') + '.' : '', ...ctts.map(c => '- ' + dataBR(c.data).slice(0, 5) + ' · ' + nomeMeio(c.meio) + ': ' + (c.assunto || '') + (c.combinados ? ' Combinado: ' + c.combinados : ''))].filter(Boolean).join('\n') || '(Nenhum apoio ou contato registrado.)'),
    secTexto('perguntas', 'Perguntas ao colegiado', '- \n- '),
    secTexto('colegiado', 'O que o colegiado percebeu', ''),
    secTexto('propostas', 'Propostas e gestos pedagógicos', '- Na classe: \n- Nas aulas de matéria: \n- Com a família: '),
    secTexto('acompanhamento', 'Acompanhamento', '- Rever em: \n- Quem acompanha: ')];
}
TIPOS_DOC.estudo = {
  nome: 'Estudo de criança',
  cab: [['data', 'Data do estudo', 'date'], ['presentes', 'Participantes']],
  ajuda: 'Documento sigiloso, para o estudo de criança no colegiado. As partes com ↻ vêm do que já está registrado (entrevista, perfil, observação, anotações, PEI, reforço e contatos com a família) e podem ser trazidas de novo.',
  gerar: d => { const t = IX.turmas[d.turmaId], a = IX.alunos[d.alunoId]; return { titulo: 'Estudo de criança — ' + a.nome, cab: { data: hojeISO(), presentes: '' }, secoes: estudoSecoes(t, a) }; },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}, a = IX.alunos[d.alunoId] || {}, c = d.cab || {}; return ['Criança: ' + (a.nome || ''), 'Turma: ' + rotuloTurma(t), 'Data: ' + (c.data ? dataBR(c.data) : ''), 'Participantes: ' + (c.presentes || '')]; }
};

/* ---------- contatos com as famílias ---------- */
const MEIOS = [['conversa', 'Conversa'], ['telefone', 'Telefone'], ['mensagem', 'Mensagem'], ['email', 'E-mail'], ['bilhete', 'Bilhete'], ['reuniao', 'Reunião']];
const nomeMeio = k => (MEIOS.find(x => x[0] === k) || ['', 'Contato'])[1];
const contatosDe = (t, aid) => D.contatos.filter(c => c.turmaId === t.id && (!aid || c.alunoId === aid)).sort((x, y) => (y.data || '').localeCompare(x.data || ''));
async function dialogoContato(c) {
  const t = turmaAtual(), al = alunosDaTurma(t.id);
  const v = await dlg({ titulo: c.id ? 'Editar contato' : 'Contato com a família', largo: true, ok: 'Salvar', corpo: '<div class="duas">' + campo('Criança', '<select name="alunoId">' + al.map(a => '<option value="' + a.id + '"' + (a.id === c.alunoId ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select>') + campo('Data', '<input type="date" name="data" value="' + e(c.data || hojeISO()) + '">') + '</div><div class="duas">' + campo('Como', '<select name="meio">' + MEIOS.map(([k, n]) => '<option value="' + k + '"' + (k === c.meio ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + campo('Com quem', '<input name="quem" value="' + e(c.quem || '') + '" placeholder="ex.: a mãe">') + '</div>' + campo('Assunto', '<input name="assunto" value="' + e(c.assunto || '') + '">') + campo('O que foi conversado', '<textarea name="texto" style="min-height:6rem">' + e(c.texto || '') + '</textarea>') + campo('O que foi combinado', '<textarea name="combinados">' + e(c.combinados || '') + '</textarea>') + '<label class="ck"><input type="checkbox" name="sigilo"' + (c.sigilo ? ' checked' : '') + '> <span>Sigiloso (não sai em fichas e relatórios)</span></label>', validar: x => !x.assunto.trim() && !x.texto.trim() ? 'Escreva o assunto ou o que foi conversado.' : null });
  if (!v) return null; return Object.assign(c, { turmaId: t.id, alunoId: v.alunoId, data: v.data, meio: v.meio, quem: v.quem.trim(), assunto: v.assunto.trim(), texto: v.texto.trim(), combinados: v.combinados.trim(), sigilo: !!v.sigilo });
}
A.novoContato = async d => { const c = await dialogoContato({ alunoId: d && d.al }); if (!c) return; await salvar('contatos', c); render(); aviso('Contato registrado.'); };
A.editarContato = async d => { const c = IX.contatos[d.id]; if (!c) return; const x = await dialogoContato(clone(c)); if (!x) return; await salvar('contatos', x); render(); aviso('Contato salvo.'); };
A.apagarContato = d => apagarComDesfazer('contatos', d.id, 'Contato excluído.');
/* para o pré-conselho e a ficha: só os não sigilosos */
const blocosContatos = (t, aid, n) => { const xs = contatosDe(t, aid).filter(c => !c.sigilo).slice(0, n || 5); return xs.length ? [{ t: 'p', txt: 'Contatos com a família: ' + xs.map(c => dataBR(c.data).slice(0, 5) + ' (' + nomeMeio(c.meio).toLowerCase() + ')' + (c.assunto ? ': ' + c.assunto : '') + (c.combinados ? '. Combinado: ' + c.combinados : '')).join('; ') + '.' }] : []; };

/* ---------- tela Acompanhamento: entrevistas, estudos de criança e contatos ---------- */
T.acomp = () => {
  const t = turmaAtual(); if (!t) return '<h1>Acompanhamento</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && IX.documentos[UI.sub]) return editorDoc(IX.documentos[UI.sub], { voltar: 'Acompanhamento', alerta: '<p class="alerta" style="background:var(--violC)">Documento sigiloso. Ele só sai do app quando você exporta.</p>' });
  const aba = UI.aba.acomp || 'contatos', al = alunosDaTurma(t.id);
  let h = '<h1>Acompanhamento das crianças</h1><p>Os contatos com as famílias, a entrevista inicial e o estudo de criança, sempre a partir do que já está registrado.</p>' + abas([['contatos', 'Contatos com as famílias'], ['entrevista', 'Entrevista com a família'], ['estudo', 'Estudo de criança']], aba);
  if (!al.length) return h + vazio('Cadastre os alunos da turma.');
  if (aba === 'contatos') {
    const fa = UI.filtro.ctAl || '', xs = contatosDe(t, fa || null);
    h += '<div class="linha"><button class="btn pri" data-a="novoContato"' + (fa ? ' data-al="' + fa + '"' : '') + '>+ Contato</button><select data-c="ctAl"><option value="">Todas as crianças</option>' + al.map(a => '<option value="' + a.id + '"' + (a.id === fa ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select></div>';
    return h + (xs.length ? '<div class="cartao rolagem"><table class="tabela"><tr><th>Data</th><th>Criança</th><th>Como</th><th>Assunto e combinados</th><th></th></tr>' + xs.map(c => '<tr><td>' + dataBR(c.data) + '</td><td>' + e(primeiroNome(IX.alunos[c.alunoId])) + (c.sigilo ? ' <span class="flag vi">sigiloso</span>' : '') + '</td><td>' + nomeMeio(c.meio) + (c.quem ? '<br><span class="dica">' + e(c.quem) + '</span>' : '') + '</td><td><b>' + e(c.assunto || '') + '</b>' + (c.texto ? '<br>' + e(c.texto) : '') + (c.combinados ? '<br><span class="dica">Combinado: ' + e(c.combinados) + '</span>' : '') + '</td><td style="white-space:nowrap"><button class="btn peq" data-a="editarContato" data-id="' + c.id + '">Editar</button> <button class="icone-btn" data-a="apagarContato" data-id="' + c.id + '" title="Excluir">✕</button></td></tr>').join('') + '</table></div>' : vazio('Nenhum contato registrado. Conversas, telefonemas e bilhetes registrados aqui aparecem no pré-conselho, na ficha da criança e no estudo de criança.'));
  }
  const tipo = aba, nome = TIPOS_DOC[tipo].nome;
  h += '<p class="dica">' + (tipo === 'entrevista' ? 'Um roteiro de conversa para a entrada da criança na escola (ou quando fizer sentido). É sigilosa e alimenta a apresentação do estudo de criança.' : 'Para o estudo de criança no colegiado. O rascunho já traz a entrevista, o perfil, a observação, as anotações, o PEI, o reforço e os contatos com a família.') + '</p>';
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Criança</th><th>' + nome + '</th><th></th></tr>' + al.map(a => { const d = docsDe(tipo, x => x.alunoId === a.id && (tipo === 'entrevista' || x.turmaId === t.id))[0]; return '<tr><td><b>' + e(a.nome) + '</b></td><td>' + (d ? dataBR(((d.cab || {}).data || d.criado || '').slice(0, 10)) + ((d.versoes || []).length ? ' · versão ' + d.versoes.slice(-1)[0].n : ' · rascunho') : '<span class="dica">—</span>') + '</td><td>' + (d ? '<button class="btn peq" data-a="abrirDocSub" data-id="' + d.id + '">Abrir</button>' : '<button class="btn peq" data-a="acompNovo" data-tp="' + tipo + '" data-al="' + a.id + '">Criar</button>') + '</td></tr>'; }).join('') + '</table></div>';
};
C_.ctAl = el => { UI.filtro.ctAl = el.value; render(); };
A.acompNovo = async d => { const t = turmaAtual(), x = await criarDoc(d.tp, { turmaId: t.id, alunoId: d.al }); UI.sub = x.id; render(); window.scrollTo(0, 0); aviso(d.tp === 'estudo' ? 'Rascunho do estudo criado com o que já está registrado.' : 'Roteiro da entrevista criado.'); };

/* ---------- comunicados às famílias (modelos com marcadores) ---------- */
const MODELOS_COM = [
  ['material', 'Material', 'Olá, família!\n\nPara {texto}, {o aluno/a aluna} {nome} vai precisar trazer, até {data}:\n\n- \n- \n\nObrigada pela parceria!\n{Professora} {professora}'],
  ['festa', 'Festa', 'Olá, família!\n\nConvidamos vocês para {texto}, no dia {data}, às {hora}, em {local}.\n\nPreparamos esse momento com muito carinho com as crianças. Contamos com a presença de vocês!\n\n{Professora} {professora}'],
  ['reuniao', 'Reunião de pais', 'Olá, família!\n\nConvidamos para a reunião de pais do {turma}, no dia {data}, às {hora}, em {local}.\n\nAssuntos: {texto}\n\nA presença de cada família é muito importante para a caminhada da classe.\n\n{Professora} {professora}'],
  ['lembrete', 'Lembrete', 'Olá, família!\n\nLembramos que {texto} ({data}).\n\nQualquer dúvida, é só perguntar.\n{Professora} {professora}'],
  ['passeio', 'Passeio ou vivência', 'Olá, família!\n\nNo dia {data}, a classe vai a {local}, para {texto}. A saída será às {hora}.\n\nPedimos que {o aluno/a aluna} {nome} venha com roupa confortável e lanche.\n\n{Professora} {professora}']];
const modelosCom = () => MODELOS_COM.map(([k, n, tx]) => { const p = D.comunicados.find(c => c.chave === k); return { chave: k, nome: p ? p.nome : n, texto: p ? p.texto : tx, proprio: !!p, id: p && p.id }; }).concat(D.comunicados.filter(c => !MODELOS_COM.some(m => m[0] === c.chave)).map(c => ({ chave: c.chave, nome: c.nome, texto: c.texto, proprio: true, novo: true, id: c.id })));
const textoComunicado = (m, v, al, t) => substituir(m.texto.replace(/\{texto\}/g, v.texto || '').replace(/\{data\}/g, v.data ? dataBR(v.data) + ' (' + diaSemana(v.data) + ')' : '').replace(/\{hora\}/g, v.hora ? horaTxt(v.hora) : '').replace(/\{local\}/g, v.local || '').replace(/\{turma\}/g, rotuloTurma(t)).replace(/\{hoje\}/g, dataBR(hojeISO())).replace(/\{professora\}/g, t.professora || ''), al, t).replace(/\n{3,}/g, '\n\n').trim();
T.comunic = () => {
  const t = turmaAtual(); if (!t) return '<h1>Comunicados</h1>' + vazio('Cadastre uma turma primeiro.');
  return '<h1>Comunicados às famílias</h1><p>Modelos prontos com marcadores: o texto se ajusta a cada criança ({nome}, {o aluno/a aluna}) e à turma. Escolha um modelo, complete a data, o horário e o local, e saia com um bilhete por criança ou um comunicado geral, em PDF, Word ou e-mail.</p><div class="linha"><button class="btn" data-a="comNovoModelo">+ Modelo</button></div><div class="grade">' +
    modelosCom().map(m => '<div class="cartao"><div class="linha" style="margin:0"><h3 style="margin:0">' + e(m.nome) + '</h3>' + (m.proprio ? '<span class="etq ' + (m.novo ? 'viol' : 'rasc') + '">' + (m.novo ? 'próprio' : 'editado') + '</span>' : '') + '</div><p class="dica" style="white-space:pre-line;max-height:7.5rem;overflow:hidden">' + e(m.texto) + '</p><div class="linha"><button class="btn pri peq" data-a="comGerar" data-k="' + e(m.chave) + '">Usar</button><button class="btn peq" data-a="comEditar" data-k="' + e(m.chave) + '">Editar o modelo</button></div></div>').join('') + '</div>';
};
A.comEditar = async d => {
  const m = modelosCom().find(x => x.chave === d.k); if (!m) return;
  const v = await dlg({ titulo: 'Modelo: ' + m.nome, largo: true, ok: 'Salvar', corpo: '<p class="dica">Marcadores: {nome}, {texto}, {data}, {hora}, {local}, {turma}, {professora}, {Professora}, {hoje}, e pares como {o/a} ou {o aluno/a aluna}, que se ajustam à criança.</p>' + campo('Nome', '<input name="nome" value="' + e(m.nome) + '">') + campo('Texto', '<textarea name="texto" style="min-height:14rem">' + e(m.texto) + '</textarea>'), extra: m.proprio ? '<button type="button" class="btn" data-x="tirar">' + (m.novo ? 'Excluir o modelo' : 'Voltar ao original') + '</button>' : '' });
  if (!v) return; if (v._botao === 'tirar') { await apagar('comunicados', m.id); render(); return aviso(m.novo ? 'Modelo excluído.' : 'Modelo original restaurado.'); }
  const r = m.id ? IX.comunicados[m.id] : { chave: m.chave }; Object.assign(r, { nome: v.nome.trim() || m.nome, texto: v.texto.trim() }); await salvar('comunicados', r); render(); aviso('Modelo salvo.');
};
A.comNovoModelo = async () => { const r = await salvar('comunicados', { chave: 'c' + uid(), nome: 'Novo modelo', texto: 'Olá, família!\n\n{texto}\n\n{Professora} {professora}' }); render(); A.comEditar({ k: r.chave }); };
A.comGerar = async d => {
  const t = turmaAtual(), m = modelosCom().find(x => x.chave === d.k), al = alunosDaTurma(t.id); if (!m) return;
  const v = await dlg({ titulo: m.nome, largo: true, ok: 'Continuar', corpo: campo('Texto livre ({texto})', '<textarea name="texto" placeholder="ex.: a Festa da Primavera">' + '</textarea>') + '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Data', '<input type="date" name="data">') + campo('Horário', '<input type="time" name="hora">') + campo('Local', '<input name="local">') + '</div>' +
    '<label class="ck"><input type="radio" name="modo" value="cada" checked> <span>Um bilhete por criança (o texto se ajusta a cada uma)</span></label><label class="ck"><input type="radio" name="modo" value="geral"> <span>Um comunicado geral</span></label>' +
    '<details class="mais-campos"><summary>Escolher as crianças (todas marcadas)</summary><div class="chips">' + al.map(a => '<label><input type="checkbox" name="alunos" data-multi="1" value="' + a.id + '" checked> ' + e(primeiroNome(a)) + '</label>').join('') + '</div></details>' });
  if (!v) return; const xs = al.filter(a => (v.alunos || []).includes(a.id)), b = [];
  if (v.modo === 'geral') textoComunicado(m, v, null, t).split(/\n\s*\n/).forEach(p => b.push({ t: 'p', txt: p.replace(/\n/g, ' ') }));
  else xs.forEach((a, i) => { if (i) b.push({ t: 'quebra' }); textoComunicado(m, v, a, t).split(/\n\s*\n/).forEach(p => b.push({ t: 'p', txt: p.replace(/\n/g, ' ') })); });
  const para = [...new Set(xs.flatMap(a => (a.responsaveis || []).map(r => r.email).filter(Boolean)))];
  saidaDocumento(docSimples('Comunicado_' + m.nome + '_' + hojeISO(), m.nome + (v.data ? ' — ' + dataBR(v.data) : ''), b), { assunto: m.nome + ' — ' + rotuloTurma(t), para, corpo: v.modo === 'geral' ? textoComunicado(m, v, null, t) : undefined });
};
