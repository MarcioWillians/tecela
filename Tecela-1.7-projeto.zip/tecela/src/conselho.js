/* ==========================================================================
   Tecelã — Conselho de classe: pré-conselho (relatório preparatório, com os
   sinais de cada criança), conselho (registro e propostas) e pós-conselho
   (propostas viram tarefas; a ata sai pronta).
   ========================================================================== */
'use strict';
const SITUACOES = [['', '—'], ['ok', 'Caminha bem'], ['acomp', 'Acompanhar'], ['acao', 'Pede ação']];
const rotSit = k => (SITUACOES.find(x => x[0] === k) || ['', ''])[1];
const consId = (tid, per) => 'cons:' + tid + ':' + per;
function consRec(t, per, criar) { const id = consId(t.id, per); let r = IX.conselhos[id]; if (!r && criar) { r = { id, turmaId: t.id, periodo: per, data: hojeISO(), participantes: '', decisoes: '', alunos: {} }; D.conselhos.push(r); IX.conselhos[id] = r; } return r || null; }
const consAnterior = (t, per) => D.conselhos.filter(c => c.turmaId === t.id && c.periodo < per).sort((a, b) => b.periodo.localeCompare(a.periodo))[0] || cadeiaTurmas(t).slice(0, -1).reverse().map(x => D.conselhos.filter(c => c.turmaId === x.id).sort((a, b) => b.periodo.localeCompare(a.periodo))[0]).find(Boolean) || null;
const anotDoPeriodo = (a, per) => D.anotacoes.filter(n => (n.alunos || []).includes(a.id) && (n.data || '') >= per.ini && (n.data || '') <= per.fim);

/* sinais de cada criança: dados objetivos que ajudam a decidir de quem falar com mais tempo */
function sinaisCrianca(t, a, per) {
  const s = [], r = obsRec(t.id, a.id, per.id), m = matricula(t.id, a.id) || {}, pf = pctFaltas(t, m.faltas, true), p = ultimoPerfil(a.id), c = (p && p.campos) || {};
  if (pf != null && pf > 15) s.push([pf > 25 ? '' : 'am', 'faltas ' + pf.toFixed(0) + '%']);
  const pa = itensLista('itensObs').filter(i => r && r.marcas[i.chave] === 'a'); if (pa.length >= 3) s.push(['', pa.length + ' itens “pede atenção”']); else if (pa.length) s.push(['am', pa.length + ' item(ns) “pede atenção”']);
  ['pensar', 'sentir', 'querer'].forEach(k => { if (c[k + 'Nivel'] === 'cuidado') s.push(['vi', k + ': pede cuidado']); });
  const pts = (a.atencao || []).filter(x => x.situacao !== 'resolvido'); if (pts.length) s.push(['vi', pts.length + ' ponto(s) de atenção']);
  if (a.nee) s.push(['az', 'NEE']); if (a.acomp) s.push(['az', 'acompanhamento externo']);
  if (peiAtivo(t, a.id)) s.push(['az', 'PEI']); const rf = reforcosDoAluno(t, a.id); if (rf.length) s.push(['az', 'reforço (' + rf.length + ')']);
  const ns = anotDoPeriodo(a, per); if (ns.length < 2) s.push(['am', 'poucas anotações (' + ns.length + ')']);
  const lev = ns.filter(n => n.conselho).length; if (lev) s.push(['az', '⚖ ' + lev + ' para o conselho']);
  if (!temMarcas(r)) s.push(['am', 'sem observação no período']);
  const ant = consAnterior(t, per.id), pa2 = ant && (ant.alunos || {})[a.id]; if (pa2 && pa2.proposta) s.push([pa2.situacao === 'acao' ? '' : 'az', 'proposta anterior']);
  return { s, peso: s.filter(x => x[0] === '').length * 3 + s.filter(x => x[0] === 'vi').length * 2 + s.filter(x => x[0] === 'am').length, pa, ns, pts, ant: pa2 || null, pf, p };
}
const flagsHtml = s => s.map(([c, t]) => '<span class="flag ' + c + '">' + e(t) + '</span>').join('');

T.conselho = () => {
  const t = turmaAtual(); if (!t) return '<h1>Conselho de classe</h1>' + vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id); if (!al.length) return '<h1>Conselho de classe</h1>' + vazio('Cadastre os alunos da turma.');
  const ps = periodosDaTurma(t), per = periodoEscolhido(t, 'consPer'), aba = UI.aba.conselho || 'pre';
  let h = '<h1>Conselho de classe</h1><div class="linha"><select data-c="consPer">' + ps.map(p => '<option value="' + p.id + '"' + (p.id === per.id ? ' selected' : '') + '>' + p.rot + '</option>').join('') + '</select><span class="dica">Os períodos são os mesmos da observação (Ajustes).</span></div>';
  h += abas([['pre', '1. Pré-conselho'], ['reg', '2. Conselho'], ['pos', '3. Pós-conselho']], aba);
  return h + ({ pre: consPre, reg: consReg, pos: consPos }[aba] || consPre)(t, al, per);
};
C_.consPer = el => { UI.filtro.consPer = el.value; render(); };
function consPre(t, al, per) {
  const lista = al.map(a => [a, sinaisCrianca(t, a, per)]).sort((x, y) => y[1].peso - x[1].peso || ordemNome(x[0], y[0])), sint = sinteseTurmaObs(t, per.id);
  let h = '<div class="cartao"><p>O <b>relatório preparatório</b> reúne o que já está registrado: observação do período, anotações marcadas com ⚖, perfil, faltas, pontos de atenção e as propostas do conselho anterior. As crianças com mais sinais aparecem primeiro, para que o tempo do conselho vá para quem mais precisa.</p><div class="linha"><button class="btn pri" data-a="exportarPreConselho">Exportar o relatório preparatório</button><span class="dica">Pontos de atenção e anotações sigilosas só entram se você marcar, na hora de exportar.</span></div></div>';
  if (sint.n) h += '<div class="cartao"><h3>A turma no ' + e(per.curto) + '</h3><p class="dica">' + sint.n + ' de ' + sint.total + ' crianças com observação.</p>' + (sint.alertas.length ? '<p><b>Itens que pedem atenção em várias crianças:</b></p><ul>' + sint.alertas.slice(0, 8).map(([n, qa, q]) => '<li>' + e(n) + ' — ' + qa + ' de ' + q + '</li>').join('') + '</ul>' : '<p class="dica">Nenhum item pede atenção em várias crianças ao mesmo tempo.</p>') + '</div>';
  h += '<div class="cartao rolagem"><table class="tabela"><tr><th>Criança</th><th>Sinais</th><th></th></tr>' + lista.map(([a, x]) => '<tr><td style="white-space:nowrap"><b>' + e(a.nome) + '</b></td><td>' + (flagsHtml(x.s) || '<span class="dica">nenhum sinal</span>') + '</td><td><button class="btn peq" data-a="verPre" data-al="' + a.id + '">Ver</button></td></tr>').join('') + '</table></div>';
  return h;
}
function blocosPreAluno(t, a, per, sig) {
  const x = sinaisCrianca(t, a, per), b = [{ t: 'h', txt: a.nome }], c = (x.p && x.p.campos) || {};
  b.push({ t: 'p', txt: 'Idade: ' + idadeTxt(idadeEm(a.nasc, refTurma(t))) + '. Faltas: ' + somaFaltas((matricula(t.id, a.id) || {}).faltas) + (x.pf != null ? ' (' + x.pf.toFixed(1).replace('.', ',') + '%)' : '') + '.' + (a.nee ? ' Necessidades educacionais especiais.' : '') + (a.acomp ? ' Acompanhamento externo.' : '') });
  if (x.p) b.push({ t: 'p', txt: 'Perfil (' + dataBR(x.p.data) + '): ' + [c.tempPred ? 'temperamento ' + rotTemp(c.tempPred).toLowerCase() : '', c.pensarNivel ? 'pensar ' + rotNivel(c.pensarNivel).toLowerCase() : '', c.sentirNivel ? 'sentir ' + rotNivel(c.sentirNivel).toLowerCase() : '', c.quererNivel ? 'querer ' + rotNivel(c.quererNivel).toLowerCase() : ''].filter(Boolean).join('; ') + '.' });
  const r = obsRec(t.id, a.id, per.id);
  if (temMarcas(r)) { const g = k => itensLista('itensObs').filter(i => r.marcas[i.chave] === k).map(i => i.nome); if (g('a').length) b.push({ t: 'p', txt: 'Pede atenção: ' + g('a').join('; ') + '.' }); if (g('c').length) b.push({ t: 'p', txt: 'Consolidado: ' + g('c').join('; ') + '.' }); }
  else b.push({ t: 'p', txt: 'Sem observação do período.' });
  const ns = x.ns.filter(n => n.conselho && (sig || !n.sigilo)); if (ns.length) b.push({ t: 'lista', itens: ns.map(n => dataBR(n.data) + ' — ' + substituir(n.texto, a, t) + (n.sigilo ? ' [sigilosa]' : '')) });
  if (sig && x.pts.length) b.push({ t: 'p', txt: 'Pontos de atenção [sigiloso]: ' + x.pts.map(p => textoAt(p)).join('; ') + '.' });
  const rf = reforcosDoAluno(t, a.id); if (rf.length) b.push({ t: 'p', txt: 'Reforço: ' + rf.map(r => rotRef(r) + ' (' + (r.datas || []).map(d => dataBR(d).slice(0, 5)).join(', ') + ', ' + nomeSit(r.situacao).toLowerCase() + (resumoEnc(r) ? '; ' + resumoEnc(r) : '') + ')').join('; ') + '.' });
  b.push(...blocosContatos(t, a.id, 3));
  const pei = peiAtivo(t, a.id); if (pei && sig) { const ad = adaptacoesPei(pei); b.push({ t: 'p', txt: 'PEI [sigiloso]: ' + (ad || 'há um plano individualizado em ' + t.ano + '.') }); }
  if (x.ant && x.ant.proposta) b.push({ t: 'p', txt: 'Conselho anterior: ' + (rotSit(x.ant.situacao) ? rotSit(x.ant.situacao) + '. ' : '') + 'Proposta: ' + x.ant.proposta + (x.ant.resp ? ' (' + x.ant.resp + ')' : '') + '.' });
  return b;
}
A.verPre = d => { const t = turmaAtual(), a = IX.alunos[d.al], per = periodoEscolhido(t, 'consPer'), x = sinaisCrianca(t, a, per); informar(a.nome, '<p>' + flagsHtml(x.s) + '</p>' + blocosPreAluno(t, a, per, true).slice(1).map(htmlBloco).join('') + '<p class="dica">Aqui na tela aparecem também os pontos de atenção e as anotações sigilosas, só para você.</p><p><a href="#" data-a="anotar" data-al="' + a.id + '">✎ Anotar sobre ' + e(primeiroNome(a)) + '</a></p>'); };
A.exportarPreConselho = async () => {
  await descarregarFila(); const t = turmaAtual(), per = periodoEscolhido(t, 'consPer');
  const v = await dlg({ titulo: 'Relatório preparatório', ok: 'Continuar', corpo: '<label class="ck"><input type="checkbox" name="sig"> Incluir pontos de atenção e anotações sigilosas (o conselho é reservado; não envie por e-mail)</label><label class="ck"><input type="checkbox" name="todos" checked> Incluir todas as crianças (desmarcado: só as que têm sinais)</label>' }); if (!v) return;
  const al = alunosDaTurma(t.id).map(a => [a, sinaisCrianca(t, a, per)]).filter(([, x]) => v.todos || x.s.length).sort((x, y) => y[1].peso - x[1].peso || ordemNome(x[0], y[0])), sint = sinteseTurmaObs(t, per.id);
  const b = [{ t: 'centro', linhas: [rotuloTurma(t) + ' · ' + per.rot, profTit(t) + ': ' + (t.professora || '')], peq: true }, { t: 'nota', txt: 'Documento de trabalho do conselho de classe. Reúne registros da professora; cada criança é vista em relação a ela mesma.' }];
  b.push({ t: 'h', txt: 'Resumo' }, { t: 'tabela', cab: ['Criança', 'Sinais'], linhas: al.map(([a, x]) => [a.nome, x.s.map(s => s[1]).join('; ') || '—']) });
  if (sint.alertas.length) b.push({ t: 'h', txt: 'Itens que pedem atenção em várias crianças' }, { t: 'lista', itens: sint.alertas.slice(0, 10).map(([n, qa, q]) => n + ' — ' + qa + ' de ' + q) });
  al.forEach(([a]) => b.push(...blocosPreAluno(t, a, per, v.sig)));
  saidaDocumento(docBase('Pre-conselho_' + per.id, 'Relatório preparatório para o conselho de classe', b), { assunto: 'Pré-conselho — ' + rotuloTurma(t) });
};

function consReg(t, al, per) {
  const c = consRec(t, per.id, true), ant = consAnterior(t, per.id);
  let h = '<div data-rec="conselhos:' + c.id + '"><div class="cartao"><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">' + campo('Data do conselho', inp('data', c.data, 'date')) + campo('Participantes', inp('participantes', c.participantes, 'text', 'placeholder="ex.: professores especialistas, coordenação"')) + '</div><div class="linha"><button class="btn pri" data-a="exportarConselho">Exportar o registro</button><button class="btn" data-a="ataConselho">Criar a ata do conselho</button><span class="dica">Tudo é salvo enquanto você escreve.</span></div></div>';
  h += al.map(a => { const x = (c.alunos || {})[a.id] || {}, s = sinaisCrianca(t, a, per), pa = ant && (ant.alunos || {})[a.id]; return '<div class="cartao"><div class="linha"><h3 style="margin:0">' + e(a.nome) + '</h3><span>' + flagsHtml(s.s) + '</span></div>' + (pa && pa.proposta ? '<p class="dica">Conselho anterior: ' + e(pa.proposta) + '</p>' : '') + '<div class="grade" style="grid-template-columns:1fr 3fr">' + campo('Situação', sel('alunos.' + a.id + '.situacao', x.situacao || '', SITUACOES)) + campo('O que o conselho viu', area('alunos.' + a.id + '.fala', x.fala, 'style="min-height:3.2rem"')) + '</div><div class="grade" style="grid-template-columns:3fr 1.5fr 1fr">' + campo('Proposta ou encaminhamento', inp('alunos.' + a.id + '.proposta', x.proposta)) + campo('Responsável', inp('alunos.' + a.id + '.resp', x.resp)) + campo('Prazo', inp('alunos.' + a.id + '.prazo', x.prazo, 'date')) + '</div></div>'; }).join('');
  return h + '<div class="cartao"><h3>Decisões sobre a turma</h3>' + area('decisoes', c.decisoes, 'class="alto"') + '</div></div>';
}
function docConselho(t, c) {
  const per = periodoPorId(c.periodo) || { rot: c.periodo }, al = alunosDaTurma(t.id);
  const b = [{ t: 'centro', linhas: [rotuloTurma(t) + ' · ' + per.rot, 'Conselho realizado em ' + dataBR(c.data)], peq: true }];
  if (c.participantes) b.push({ t: 'p', txt: 'Participantes: ' + c.participantes + '.' });
  const ls = al.map(a => [a, (c.alunos || {})[a.id] || {}]).filter(([, x]) => x.situacao || x.fala || x.proposta);
  b.push({ t: 'tabela', cab: ['Criança', 'Situação', 'O que o conselho viu', 'Proposta', 'Responsável', 'Prazo'], linhas: ls.map(([a, x]) => [a.nome, rotSit(x.situacao), x.fala || '', x.proposta || '', x.resp || '', dataBR(x.prazo)]) });
  if ((c.decisoes || '').trim()) { b.push({ t: 'h', txt: 'Decisões sobre a turma' }); nl2p(c.decisoes).forEach(p => b.push({ t: 'p', txt: p })); }
  return docBase('Conselho_' + c.periodo, 'Registro do conselho de classe', b);
}
A.exportarConselho = async () => { await descarregarFila(); const t = turmaAtual(), c = consRec(t, periodoEscolhido(t, 'consPer').id, true); saidaDocumento(docConselho(t, c), { assunto: 'Conselho de classe — ' + rotuloTurma(t) }); };
A.ataConselho = async () => {
  await descarregarFila(); const t = turmaAtual(), per = periodoEscolhido(t, 'consPer'), c = consRec(t, per.id, true), al = alunosDaTurma(t.id);
  if (c.ataId && IX.atas[c.ataId]) { if (!(await confirmar('Já existe uma ata', 'Este conselho já tem uma ata. Abrir a ata existente?', 'Abrir'))) return; return A.abrirAta({ id: c.ataId }); }
  const tipo = itemLista('tiposAta', 'conselho') ? 'conselho' : 'colegiado', cats = tipoAta(tipo).cats, ano = new Date().getFullYear(), num = proximoNumeroAta(ano);
  const linhas = al.map(a => [a, (c.alunos || {})[a.id] || {}]).filter(([, x]) => x.fala || x.proposta).map(([a, x]) => primeiroNome(a) + (x.situacao ? ' (' + rotSit(x.situacao).toLowerCase() + ')' : '') + ': ' + [x.fala, x.proposta ? 'Proposta: ' + x.proposta + (x.resp ? ', a cargo de ' + x.resp : '') + (x.prazo ? ', até ' + dataBR(x.prazo) : '') + '.' : ''].filter(Boolean).join(' '));
  const parts = [{ nome: t.professora || '', categoria: cats[0], presente: true }].concat(String(c.participantes || '').split(/[,;]\s*/).filter(Boolean).map(n => ({ nome: n, categoria: cats[1] || cats[0], presente: true }))).filter(p => p.nome);
  const a = await salvar('atas', { turmaId: t.id, tipo, subtipo: tipoAta(tipo).subtipos.includes('Conselho de classe') ? 'Conselho de classe' : '', numero: String(num).padStart(2, '0'), livro: '', carater: carateres()[0] || '', data: c.data || hojeISO(), inicio: '', fim: '', local: CFG.escola.nome || '', assunto: 'Conselho de classe do ' + per.rot, pauta: 'Situação de cada criança; propostas e encaminhamentos; decisões sobre a turma.', participantes: parts, secretario: t.professora || '', cabecalho: '', texto: linhas.join('\n\n'), deliberacoes: c.decisoes || '', conclusao: '', encaminhamentos: al.map(x => (c.alunos || {})[x.id]).filter(x => x && x.proposta).map(x => ({ acao: x.proposta, resp: x.resp || '', prazo: x.prazo || '' })), formato: CFG.prefs.ataFormato || 'moderno', papel: TIM('atas').papel, assinaturas: { incluir: true, linhas: null, nomes: true }, estado: 'rascunho' });
  c.ataId = a.id; await salvar('conselhos', c); A.abrirAta({ id: a.id }); aviso('Ata criada com o registro do conselho. Revise e finalize.');
};
function consPos(t, al, per) {
  const c = consRec(t, per.id), props = c ? al.map(a => [a, (c.alunos || {})[a.id] || {}]).filter(([, x]) => x.proposta) : [], lev = D.anotacoes.filter(n => n.turmaId === t.id && n.conselho && !n.conselhoVisto);
  let h = '<div class="cartao rolagem"><h3>Propostas do conselho</h3>' + (props.length ? '<table class="tabela"><tr><th>Criança</th><th>Proposta</th><th>Responsável</th><th>Prazo</th><th>Tarefa</th></tr>' + props.map(([a, x]) => { const tf = D.tarefas.find(y => y.origem && y.origem.conselho === c.id && y.origem.aluno === a.id); return '<tr><td>' + e(a.nome) + '</td><td>' + e(x.proposta) + '</td><td>' + e(x.resp || '') + '</td><td>' + dataBR(x.prazo) + '</td><td>' + (tf ? (tf.feita ? '<span class="etq fin">feita</span>' : '<a href="#" data-a="editarTarefa" data-id="' + tf.id + '">pendente</a>') : '—') + '</td></tr>'; }).join('') + '</table><div class="linha" style="margin-top:.6rem"><button class="btn pri" data-a="consTarefas">Propostas → Tarefas</button><button class="btn" data-a="ataConselho">' + (c && c.ataId && IX.atas[c.ataId] ? 'Abrir a ata do conselho' : 'Criar a ata do conselho') + '</button></div>' : '<p class="dica">Nenhuma proposta registrada neste conselho. Registre-as na aba “2. Conselho”.</p>') + '</div>';
  h += '<div class="cartao"><h3>Anotações levadas ao conselho</h3>' + (lev.length ? '<p>' + lev.length + ' anotação(ões) ainda marcadas com ⚖.</p><button class="btn" data-a="consVistas">Marcar como tratadas</button><p class="dica">Elas continuam guardadas; só deixam de aparecer como pendência.</p>' : '<p class="dica">Nenhuma pendente.</p>') + '</div>';
  const encs = D.atas.filter(a => a.turmaId === t.id && !D.atas.some(x => x.origemId === a.id)).flatMap(a => (a.encaminhamentos || []).map((x, i) => [a, x, i])).filter(([, x]) => x.acao);
  if (encs.length) h += '<div class="cartao rolagem"><h3>Encaminhamentos das atas</h3><table class="tabela"><tr><th>Prazo</th><th>Ação</th><th>Responsável</th><th>Origem</th><th>Situação</th></tr>' + encs.sort((x, y) => (x[1].prazo || '9').localeCompare(y[1].prazo || '9')).map(([a, x, i]) => { const tf = D.tarefas.find(y => y.origem && y.origem.ata === a.id && y.origem.i === i); return '<tr><td>' + dataBR(x.prazo) + '</td><td>' + e(x.acao) + '</td><td>' + e(x.resp || '') + '</td><td><a href="#" data-a="abrirAta" data-id="' + a.id + '">' + e(nomeReuniao(a)) + ' ' + dataBR(a.data) + '</a></td><td>' + (tf ? (tf.feita ? 'feita' : 'em tarefas') : '—') + '</td></tr>'; }).join('') + '</table></div>';
  return h;
}
A.consTarefas = async () => { const t = turmaAtual(), per = periodoEscolhido(t, 'consPer'), c = consRec(t, per.id); if (!c) return; let n = 0; for (const [aid, x] of Object.entries(c.alunos || {})) { if (!x.proposta || D.tarefas.some(y => y.origem && y.origem.conselho === c.id && y.origem.aluno === aid)) continue; await salvar('tarefas', { titulo: primeiroNome(IX.alunos[aid]) + ': ' + x.proposta + (x.resp ? ' (' + x.resp + ')' : ''), data: x.prazo || '', feita: false, avisar: x.prazo ? 2 : null, origem: { conselho: c.id, aluno: aid } }); n++; } render(); aviso(n ? n + ' tarefa(s) criada(s).' : 'As propostas já estão nas tarefas.'); };
A.consVistas = async () => { const t = turmaAtual(); for (const n of D.anotacoes.filter(n => n.turmaId === t.id && n.conselho && !n.conselhoVisto)) { n.conselhoVisto = true; await salvar('anotacoes', n); } render(); aviso('Anotações marcadas como tratadas.'); };
