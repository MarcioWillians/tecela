/* ==========================================================================
   Tecelã — documentos: montagem de atas e boletins num modelo comum de
   blocos, que vira HTML (prévia e impressão/PDF) ou DOCX (biblioteca docx).
   ========================================================================== */
'use strict';

/* ---------- números por extenso (datas das atas) ---------- */
const UNI = ['zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez', 'onze', 'doze', 'treze', 'quatorze', 'quinze', 'dezesseis', 'dezessete', 'dezoito', 'dezenove'];
const DEZ = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa'];
const CEN = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos'];
function extenso(n) {
  n = Math.floor(n); if (n < 20) return UNI[n];
  if (n < 100) return DEZ[Math.floor(n / 10)] + (n % 10 ? ' e ' + UNI[n % 10] : '');
  if (n === 100) return 'cem';
  if (n < 1000) return CEN[Math.floor(n / 100)] + (n % 100 ? ' e ' + extenso(n % 100) : '');
  const m = Math.floor(n / 1000), r = n % 1000;
  return (m === 1 ? 'mil' : extenso(m) + ' mil') + (r ? (r < 100 || r % 100 === 0 ? ' e ' : ' ') + extenso(r) : '');
}
function dataAtaExtenso(iso) {
  if (!iso) return '';
  const d = Number(iso.slice(8, 10)), m = Number(iso.slice(5, 7)), a = Number(iso.slice(0, 4));
  return (d === 1 ? 'Ao primeiro dia' : 'Aos ' + extenso(d) + ' dias') + ' do mês de ' + MESES[m - 1] + ' de ' + extenso(a);
}
const horaTxt = h => h ? h.replace(':', 'h').replace(/h00$/, 'h').replace(/^0(\d)/, '$1') : '';
/* aceita “15h”, “15h30”, “15:30” ou “9” e devolve HH:MM (para campos de horário) */
const paraHora = s => { const m = String(s || '').trim().match(/^(\d{1,2})\s*(?:[h:]\s*(\d{2})?)?\s*(?:min)?$/i); if (!m || Number(m[1]) > 23) return ''; return m[1].padStart(2, '0') + ':' + (m[2] || '00'); };
const saidaTxt = s => paraHora(s) ? horaTxt(paraHora(s)) : (s || '');
function juntarLista(xs) { xs = xs.filter(Boolean); return xs.length <= 1 ? (xs[0] || '') : xs.slice(0, -1).join(', ') + ' e ' + xs[xs.length - 1]; }

/* ---------- marcadores de texto: {nome}, {ele/ela}, {o/a}… ---------- */
function primeiroNome(al) { return al ? (al.chamada || String(al.nome || '').split(' ')[0]) : ''; }
const profTit = t => t && t.genProf === 'o' ? 'Professor' : 'Professora';
function substituir(txt, al, tu) {
  if (!txt) return ''; const f = al && al.genero === 'f', po = tu && tu.genProf === 'o';
  return String(txt).replace(/\{a professora\}/g, po ? 'o professor' : 'a professora').replace(/\{A professora\}/g, po ? 'O professor' : 'A professora').replace(/\{professora\}/g, po ? 'professor' : 'professora').replace(/\{Professora\}/g, po ? 'Professor' : 'Professora').replace(/\{nome\}/gi, m => primeiroNome(al)).replace(/\{nome completo\}/gi, () => al ? al.nome : '')
    .replace(/\{([^{}\/]+)\/([^{}\/]+)\}/g, (m, a, b) => f ? b : a);
}

/* ---------- tipos de reunião ---------- */
/* os tipos de reunião, categorias e caráter vêm de Cadastros (cadastros.js) */
const subtipoProprio = a => a.subtipo && !/^reuni/i.test(a.subtipo);
function nomeReuniao(a) { return subtipoProprio(a) ? a.subtipo : tipoAta(a.tipo).nome; }

/* abertura automática da ata a partir dos dados */
function aberturaAta(a, turma) {
  const pres = (a.participantes || []).filter(p => p.presente !== false && p.nome);
  const porCat = {}; pres.forEach(p => { const c = turma && turma.professora && p.nome === turma.professora && /^professor/i.test(p.categoria || '') ? profTit(turma) : (p.categoria || 'Participante'); (porCat[c] = porCat[c] || []).push(p.nome); });
  const quem = Object.entries(porCat).map(([c, ns]) => juntarLista(ns) + ' (' + c.toLowerCase() + (ns.length > 1 && !/\)$/.test(c) ? 's' : '') + ')');
  let s = dataAtaExtenso(a.data);
  if (a.inicio) s += ', às ' + horaTxt(a.inicio);
  if (a.local) s += ', em ' + a.local;
  const nome = nomeReuniao(a).toLowerCase(), car = a.carater ? nomeItem('carateres', a.carater) : '', base = tipoAta(a.tipo).nome.toLowerCase();
  if (subtipoProprio(a)) s += ', realizou-se a ' + (car && /^reunião/.test(base) ? base.replace(/^reunião/, 'reunião ' + car) : base) + ', na forma de ' + nome;
  else s += ', realizou-se a ' + (car && /^reunião/.test(nome) ? nome.replace(/^reunião/, 'reunião ' + car) : nome + (car ? ' (' + car + ')' : ''));
  if (turma && a.tipo !== 'geral') s += ', referente ao ' + turma.serie + 'º ano ' + (turma.letra || '');
  if (quem.length) s += ', com a presença de ' + juntarLista(quem);
  if (a.assunto) s += ', para tratar do seguinte assunto: ' + a.assunto.replace(/\.$/, '');
  s += '.';
  if (a.pauta) s += ' A pauta foi: ' + a.pauta.replace(/\n+/g, '; ').replace(/\.$/, '') + '.';
  return s;
}
function corpoAta(a, turma) {
  const ps = [];
  ps.push(a.cabecalho && a.cabecalho.trim() ? a.cabecalho.trim() : aberturaAta(a, turma));
  nl2p(a.texto).forEach(p => ps.push(p));
  nl2p(a.deliberacoes).forEach(p => ps.push(p));
  const enc = (a.encaminhamentos || []).filter(x => x.acao);
  if (enc.length) ps.push('Ficaram definidos os seguintes encaminhamentos: ' + enc.map(x => x.acao.replace(/\.$/, '') + (x.resp ? ', sob responsabilidade de ' + x.resp : '') + (x.prazo ? ', até ' + dataBR(x.prazo) : '')).join('; ') + '.');
  const aus = (a.participantes || []).filter(p => p.presente === false && p.nome);
  if (aus.length) ps.push('Ausente' + (aus.length > 1 ? 's' : '') + ': ' + juntarLista(aus.map(p => p.nome + (p.justificada ? ' (ausência justificada)' : ''))) + '.');
  nl2p(a.conclusao).forEach(p => ps.push(p));
  let fim = 'Nada mais havendo a tratar, a reunião foi encerrada' + (a.fim ? ' às ' + horaTxt(a.fim) : '');
  fim += a.secretario ? ', e eu, ' + a.secretario + ', lavrei a presente ata, que, lida e aprovada, vai assinada por mim e pelos demais presentes.' : ', e foi lavrada a presente ata, que, lida e aprovada, vai assinada pelos presentes.';
  ps.push(fim);
  return ps;
}
function docAta(a) {
  const turma = IX.turmas[a.turmaId], b = [];
  b.push({ t: 'tit', txt: 'ATA' + (a.numero ? ' Nº ' + a.numero : '') + ' — ' + nomeReuniao(a).toUpperCase() });
  if (a.livro) b.push({ t: 'centro', linhas: ['Livro ' + a.livro], peq: true });
  const ps = corpoAta(a, turma);
  if ((a.formato || CFG.prefs.ataFormato) === 'tradicional') b.push({ t: 'p', txt: ps.join(' ') });
  else ps.forEach(p => b.push({ t: 'p', txt: p }));
  (a.emTempo || []).forEach(x => b.push({ t: 'p', txt: 'Em tempo (' + dataBR(x.data) + '): ' + x.texto }));
  if (a.substitui) b.push({ t: 'nota', txt: 'Esta ata substitui a ata de ' + dataBR(a.substitui) + ', que permanece arquivada.' });
  const as = a.assinaturas || {};
  if (as.incluir !== false) {
    const pres = (a.participantes || []).filter(p => p.presente !== false && p.nome);
    const n = as.linhas || pres.length || 3;
    b.push({ t: 'assin', n, nomes: as.nomes !== false ? pres.map(p => p.nome) : [] });
  }
  return { nome: 'Ata_' + (a.numero || '') + '_' + (a.data || ''), titulo: 'Ata ' + (a.numero || '') + ' — ' + dataBR(a.data), papel: a.papel || TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}

/* ---------- boletim ---------- */
function docBoletim(bol) {
  const al = IX.alunos[bol.alunoId], tu = IX.turmas[bol.turmaId], mod = modeloDaSerie(tu.serie), b = [];
  const tb = tu.boletim || {};
  b.push({ t: 'pares', linhas: [['Aluno' + (al.genero === 'f' ? 'a' : '') + ': ' + al.nome, 'Sala: ' + tu.serie + 'º ' + (tu.letra || '')], [profTit(tu) + ': ' + (tu.professora || ''), 'Ano: ' + tu.ano]] });
  b.push({ t: 'tit', txt: 'Boletim descritivo' });
  if (tb.citacao) b.push({ t: 'centro', linhas: String(tb.citacao).split('\n').concat(tb.citacaoAutor ? [tb.citacaoAutor] : []), it: true });
  mod.secoes.filter(s => s.ativa).forEach(s => {
    nl2p(substituir((tb.textos || {})[s.key], al, tu)).forEach(p => b.push({ t: 'p', txt: p }));
    nl2p(substituir(((bol.secoes || {})[s.key] || {}).texto, al, tu)).forEach(p => b.push({ t: 'p', txt: p }));
  });
  if (bol.poemaTexto) {
    b.push({ t: 'centro', linhas: ['Poema'].concat(bol.poemaTitulo ? [bol.poemaTitulo] : []), negrito: true, espaco: true });
    b.push({ t: 'poema', estrofes: String(bol.poemaTexto).split(/\n\s*\n/).map(x => x.split('\n')) });
  }
  (bol.emTempo || []).forEach(x => b.push({ t: 'p', txt: 'Em tempo (' + dataBR(x.data) + '): ' + x.texto }));
  const as = bol.assinaturas || tb.assinaturas || {};
  const nomes = []; if (as.prof) nomes.push(tu.professora || profTit(tu)); if (as.coord) nomes.push(as.coordNome || 'Coordenação pedagógica');
  if (nomes.length) b.push({ t: 'assin', n: nomes.length, nomes });
  return { nome: 'Boletim_' + al.nome + '_' + tu.ano, titulo: 'Boletim descritivo — ' + al.nome, papel: TIM('boletins').papel, timbrado: TIM('boletins'), blocos: b };
}

/* ---------- papel timbrado ---------- */
function TIM(tipo) {
  const base = IX.timbrado.atas || { id: 'atas' };
  const t = tipo === 'boletins' && IX.timbrado.boletins && !IX.timbrado.boletins.igual ? IX.timbrado.boletins : base;
  return Object.assign({ papel: 'A4', margens: { s: 20, i: 20, e: 25, d: 20 }, logoPos: 'esquerda', logoAlt: 18, cab: '', rod: '' }, t);
}

/* ---------- fontes dos documentos impressos (Ajustes): texto, títulos e poemas ---------- */
const FONTE_PADRAO = 'Times New Roman';
const fonteDoc = q => (q === 'titulo' && CFG.prefs.fonteTitulo) || (q === 'poema' && CFG.prefs.fontePoema) || CFG.prefs.fonteTexto || FONTE_PADRAO;
const pilhaFonte = f => '\'' + String(f).replace(/['"<>;]/g, '') + '\',' + (f === FONTE_PADRAO ? 'Georgia,serif' : '\'' + FONTE_PADRAO + '\',serif');
const estiloFonteDoc = () => 'style="font-family:' + e(pilhaFonte(fonteDoc('texto'))) + '"';

/* ---------- HTML (prévia e impressão) ---------- */
function htmlBloco(x) {
  switch (x.t) {
    case 'tit': return '<p style="text-align:center;font-weight:bold;font-size:1.12em;margin:.4em 0 1em;font-family:' + e(pilhaFonte(fonteDoc('titulo'))) + '">' + e(x.txt) + '</p>';
    case 'centro': return '<p style="text-align:center;' + (x.it ? 'font-style:italic;' : '') + (x.negrito ? 'font-weight:bold;' : '') + (x.peq ? 'font-size:.9em;' : '') + 'margin:' + (x.espaco ? '1.4em' : '.3em') + ' 0 1em">' + x.linhas.map(e).join('<br>') + '</p>';
    case 'p': return '<p>' + e(x.txt) + '</p>';
    case 'h': return '<p style="font-weight:bold;text-align:left;margin-top:1em">' + e(x.txt) + '</p>';
    case 'nota': return '<p style="font-size:.88em;font-style:italic">' + e(x.txt) + '</p>';
    case 'pares': return '<table style="width:100%;border-collapse:collapse;margin-bottom:1em">' + x.linhas.map(l => '<tr><td style="padding:2px 0">' + e(l[0]) + '</td><td style="text-align:right;padding:2px 0">' + e(l[1]) + '</td></tr>').join('') + '</table>';
    case 'poema': return '<div style="text-align:center;margin-bottom:1em;font-family:' + e(pilhaFonte(fonteDoc('poema'))) + (x.grande ? ';font-size:1.25em;line-height:1.6' : '') + '">' + x.estrofes.map(es => '<p style="text-align:center;margin:0 0 .8em">' + es.map(e).join('<br>') + '</p>').join('') + '</div>';
    case 'lista': return '<ul>' + x.itens.map(i => '<li>' + e(i) + '</li>').join('') + '</ul>';
    case 'tabela': return '<table style="width:100%;border-collapse:collapse;margin:.5em 0 1em;font-size:.92em">' + (x.cab ? '<tr>' + x.cab.map(c => '<th style="border-bottom:1px solid #888;text-align:left;padding:3px 4px">' + e(c) + '</th>').join('') + '</tr>' : '') + x.linhas.map(l => '<tr>' + l.map(c => '<td style="border-bottom:1px solid #ddd;padding:3px 4px;vertical-align:top">' + e(c) + '</td>').join('') + '</tr>').join('') + '</table>';
    case 'svg': return '<div class="grafico" style="margin:.4em 0 1em;break-inside:avoid">' + (x.rot ? '<p style="font-weight:bold;margin:0 0 .3em;text-align:left">' + e(x.rot) + '</p>' : '') + x.svg + '</div>';
    case 'assin': {
      let h = '<div class="assin" style="margin-top:2.2em;display:grid;grid-template-columns:1fr 1fr;gap:2.2em 2.5em">';
      for (let i = 0; i < x.n; i++) h += '<div style="text-align:center;break-inside:avoid"><div style="border-top:1px solid #000;margin-top:1.6em"></div><div style="font-size:.9em">' + e(x.nomes[i] || '') + '</div></div>';
      return h + '</div>';
    }
    case 'quebra': return '<div class="quebra"></div>';
    case 'cal': return '<table style="width:100%;border-collapse:collapse;table-layout:fixed;font-size:.8em;margin:.3em 0"><tr>' + x.cab.map(c => '<th style="border:1px solid #888;padding:3px;background:#f1efe4;text-align:center">' + e(c) + '</th>').join('') + '</tr>' + x.semanas.map(w => '<tr>' + w.map(c => '<td style="border:1px solid #888;vertical-align:top;height:' + (x.alt || 22) + 'mm;padding:2px 3px;overflow:hidden">' + (c ? '<div style="font-weight:bold;text-align:right">' + c.dia + '</div>' + c.itens.map(i => '<div style="border-left:3px solid ' + (i.cor || '#999') + ';padding-left:3px;margin:1px 0;line-height:1.15">' + e(i.txt) + '</div>').join('') : '') + '</td>').join('') + '</tr>').join('') + '</table>';
  }
  return '';
}
function htmlTimbrado(tim) {
  const logo = tim.logo ? '<img src="' + tim.logo + '" style="height:' + (tim.logoAlt || 18) + 'mm;max-width:60mm;object-fit:contain">' : '';
  const txt = tim.cab ? '<div style="flex:1;text-align:' + (tim.logoPos === 'direita' ? 'left' : tim.logoPos === 'centro' ? 'center' : 'right') + ';white-space:pre-line">' + e(tim.cab) + '</div>' : '';
  if (!logo && !txt) return { cab: '', rod: tim.rod ? '<div class="tim-rod" style="white-space:pre-line">' + e(tim.rod) + '</div>' : '' };
  const cab = '<div class="tim-cab" style="' + (tim.logoPos === 'centro' ? 'flex-direction:column;text-align:center' : tim.logoPos === 'direita' ? 'flex-direction:row-reverse' : '') + '">' + logo + txt + '</div>';
  return { cab, rod: tim.rod ? '<div class="tim-rod" style="white-space:pre-line">' + e(tim.rod) + '</div>' : '' };
}
function htmlDoc(doc, previa) {
  const t = htmlTimbrado(doc.timbrado || {}), corpo = doc.blocos.map(htmlBloco).join('');
  if (previa) return '<div ' + estiloFonteDoc() + '>' + t.cab + corpo + t.rod + '</div>';
  return '<div class="doc" ' + estiloFonteDoc() + '><table class="molde"><thead><tr><td>' + t.cab + '</td></tr></thead><tfoot><tr><td>' + t.rod + '</td></tr></tfoot><tbody><tr><td>' + corpo + '</td></tr></tbody></table></div>';
}
const exportarPDF = doc => imprimirHtml(htmlDoc(doc), doc.paisagem ? 'paisagem' : doc.papel === 'Ofício' || doc.papel === 'oficio' ? 'oficio' : 'A4', doc.paisagem ? { s: 12, i: 12, e: 12, d: 12 } : (doc.timbrado || {}).margens, nomeArq(doc.nome));

/* ---------- DOCX ---------- */
function dataUrlBytes(u) { const [cab, d] = u.split(','); return { bytes: ub64(d), tipo: /png/.test(cab) ? 'png' : 'jpg' }; }
function svgParaPng(svg, larg) {
  return new Promise(res => {
    const img = new Image(), url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
    img.onload = () => { const w = larg || 1200, h = Math.round(w * (img.height / img.width || .5)), c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(img, 0, 0, w, h); URL.revokeObjectURL(url); res({ bytes: ub64(c.toDataURL('image/png').split(',')[1]), w, h }); };
    img.onerror = () => { URL.revokeObjectURL(url); res(null); }; img.src = url;
  });
}
async function docxBlob(doc) {
  const X = window.docx; if (!X) throw new Error('Gerador de DOCX indisponível.');
  const tim = doc.timbrado || {}, of = doc.papel === 'Ofício' || doc.papel === 'oficio', mm = v => Math.round(v * 56.7), m = tim.margens || { s: 20, i: 20, e: 25, d: 20 };
  const F = fonteDoc('texto'), FT = fonteDoc('titulo'), FP = fonteDoc('poema'), run = (t, o) => new X.TextRun(Object.assign({ text: t, font: F, size: 24 }, o || {}));
  const par = (t, o, ro) => new X.Paragraph(Object.assign({ children: [run(t, ro)], spacing: { after: 120, line: 360 } }, o || {}));
  const J = X.AlignmentType.JUSTIFIED, CE = X.AlignmentType.CENTER, RI = X.AlignmentType.RIGHT;
  const semBorda = { top: { style: X.BorderStyle.NONE }, bottom: { style: X.BorderStyle.NONE }, left: { style: X.BorderStyle.NONE }, right: { style: X.BorderStyle.NONE } };
  const filhos = [];
  for (const x of doc.blocos) {
    if (x.t === 'tit') filhos.push(par(x.txt, { alignment: CE, spacing: { before: 120, after: 240 } }, { bold: true, size: 26, font: FT }));
    else if (x.t === 'centro') x.linhas.forEach((l, i) => filhos.push(par(l, { alignment: CE, spacing: { before: i === 0 && x.espaco ? 280 : 0, after: i === x.linhas.length - 1 ? 240 : 0, line: 300 } }, { italics: !!x.it, bold: !!x.negrito, size: x.peq ? 21 : 24 })));
    else if (x.t === 'p') filhos.push(par(x.txt, { alignment: J }));
    else if (x.t === 'h') filhos.push(par(x.txt, { spacing: { before: 200, after: 100 } }, { bold: true }));
    else if (x.t === 'nota') filhos.push(par(x.txt, {}, { italics: true, size: 21 }));
    else if (x.t === 'lista') x.itens.forEach(i => filhos.push(par('• ' + i, { indent: { left: 360 } })));
    else if (x.t === 'poema') x.estrofes.forEach(es => es.forEach((l, i) => filhos.push(par(l, { alignment: CE, spacing: { after: i === es.length - 1 ? 240 : 0, line: x.grande ? 360 : 300 } }, { font: FP, size: x.grande ? 30 : 24 }))));
    else if (x.t === 'pares') filhos.push(new X.Table({ width: { size: 100, type: X.WidthType.PERCENTAGE }, borders: X.TableBorders.NONE, rows: x.linhas.map(l => new X.TableRow({ children: [new X.TableCell({ borders: semBorda, children: [par(l[0], { spacing: { after: 60 } })] }), new X.TableCell({ borders: semBorda, children: [par(l[1], { alignment: RI, spacing: { after: 60 } })] })] })) }), par(''));
    else if (x.t === 'tabela') filhos.push(new X.Table({ width: { size: 100, type: X.WidthType.PERCENTAGE }, rows: (x.cab ? [x.cab] : []).concat(x.linhas).map((l, ri) => new X.TableRow({ children: l.map(c => new X.TableCell({ children: [par(String(c), { spacing: { after: 40 } }, { size: 20, bold: !!x.cab && ri === 0 })] })) })) }), par(''));
    else if (x.t === 'svg') { if (x.rot) filhos.push(par(x.rot, {}, { bold: true })); const p = await svgParaPng(x.svg, 1200); if (p) filhos.push(new X.Paragraph({ alignment: CE, children: [new X.ImageRun({ type: 'png', data: p.bytes, transformation: { width: 560, height: Math.round(560 * p.h / p.w) } })] })); }
    else if (x.t === 'assin') { filhos.push(par('', { spacing: { before: 480 } })); for (let i = 0; i < x.n; i++) { filhos.push(par('_______________________________________', { alignment: CE, spacing: { before: 520, after: 0 } })); filhos.push(par(x.nomes[i] || '', { alignment: CE, spacing: { after: 120 } }, { size: 21 })); } }
    else if (x.t === 'quebra') filhos.push(new X.Paragraph({ children: [new X.PageBreak()] }));
    else if (x.t === 'cal') { const bd = { style: X.BorderStyle.SINGLE, size: 4, color: '888888' }, bs = { top: bd, bottom: bd, left: bd, right: bd }, cel = (ch, o) => new X.TableCell(Object.assign({ borders: bs, width: { size: 14, type: X.WidthType.PERCENTAGE }, children: ch }, o || {}));
      filhos.push(new X.Table({ width: { size: 100, type: X.WidthType.PERCENTAGE }, rows: [new X.TableRow({ tableHeader: true, children: x.cab.map(c => cel([par(c, { alignment: CE, spacing: { after: 0 } }, { bold: true, size: 18 })], { shading: { fill: 'F1EFE4' } })) })].concat(x.semanas.map(w => new X.TableRow({ height: { value: mm(x.alt || 22), rule: X.HeightRule ? X.HeightRule.ATLEAST : 'atLeast' }, children: w.map(c => cel(c ? [par(String(c.dia), { alignment: RI, spacing: { after: 0, line: 240 } }, { bold: true, size: 17 })].concat(c.itens.map(i => par(i.txt, { spacing: { after: 0, line: 220 } }, { size: 15, color: (i.cor || '#555555').replace('#', '') }))) : [par('')])) }))) })); }
  }
  const cab = [], rod = [];
  if (tim.logo) { const im = dataUrlBytes(tim.logo); const alt = Math.round((tim.logoAlt || 18) * 3.78); let w = alt; try { const i = new Image(); i.src = tim.logo; await i.decode(); w = Math.round(alt * i.naturalWidth / i.naturalHeight); } catch (x) { } cab.push(new X.Paragraph({ alignment: tim.logoPos === 'centro' ? CE : tim.logoPos === 'direita' ? RI : X.AlignmentType.LEFT, children: [new X.ImageRun({ type: im.tipo, data: im.bytes, transformation: { width: Math.min(w, 240), height: alt } })] })); }
  if (tim.cab) String(tim.cab).split('\n').forEach(l => cab.push(par(l, { alignment: tim.logoPos === 'centro' ? CE : RI, spacing: { after: 0 } }, { size: 19 })));
  if (tim.rod) String(tim.rod).split('\n').forEach(l => rod.push(par(l, { alignment: CE, spacing: { after: 0 } }, { size: 17, color: '555555' })));
  const d = new X.Document({
    creator: 'Tecelã', title: doc.titulo || '', styles: { default: { document: { run: { font: F, size: 24 } } } },
    sections: [{ properties: { page: doc.paisagem ? { size: { width: 11906, height: 16838, orientation: X.PageOrientation.LANDSCAPE }, margin: { top: mm(12), bottom: mm(12), left: mm(12), right: mm(12), header: mm(6), footer: mm(6) } } : { size: { width: of ? 12247 : 11906, height: of ? 18709 : 16838 }, margin: { top: mm(m.s), bottom: mm(m.i), left: mm(m.e), right: mm(m.d), header: mm(8), footer: mm(8) } } }, headers: cab.length ? { default: new X.Header({ children: cab }) } : undefined, footers: rod.length ? { default: new X.Footer({ children: rod }) } : undefined, children: filhos }]
  });
  return X.Packer.toBlob(d);
}
async function exportarDOCX(doc) {
  try { const b = await docxBlob(doc); const r = await salvarComo(nomeArq(doc.nome) + '.docx', b, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Documento do Word'); if (r) aviso('Arquivo salvo: ' + r.nome); }
  catch (x) { informar('Não foi possível gerar o DOCX', '<p>' + e(x.message || x) + '</p>'); }
}
function csvTexto(cab, linhas) { const c = v => { v = String(v == null ? '' : v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }; return '\ufeff' + [cab].concat(linhas).map(l => l.map(c).join(';')).join('\r\n'); }
/* menu de saída comum a todos os documentos */
async function saidaDocumento(doc, opc) {
  opc = opc || {};
  const r = await dlg({
    titulo: 'Exportar ou enviar', ok: 'Continuar', largo: true, corpo:
      '<label class="ck"><input type="radio" name="f" value="pdf" checked> <span><b>PDF</b> — abre a janela de impressão: escolha “Salvar como PDF” ou uma impressora.</span></label>' +
      '<label class="ck"><input type="radio" name="f" value="docx"> <span><b>Word (DOCX)</b> — salva um arquivo editável.</span></label>' +
      (opc.csv ? '<label class="ck"><input type="radio" name="f" value="csv"> <span><b>Planilha (CSV)</b> — abre no Excel, LibreOffice ou Google Planilhas.</span></label>' : '') +
      '<label class="ck"><input type="radio" name="f" value="email"> <span><b>Enviar por e-mail</b> (Word anexado)</span></label>' +
      (opc.para && opc.para.length ? '<p class="dica">Destinatários sugeridos: ' + e(opc.para.join(', ')) + '</p>' : '')+
      /* prévia: como o documento vai sair (aberta nos documentos curtos) */
      '<details class="prev-saida"' + ((doc.blocos || []).length <= 60 ? ' open' : '') + '><summary><b>Prévia</b> <span class="dica">' + e(doc.titulo || '') + '</span></summary><div class="previa" style="max-height:45vh;margin-top:.5rem">' + htmlDoc(doc, true) + '</div></details>'
  });
  if (!r) return;
  if (r.f === 'pdf') exportarPDF(doc);
  else if (r.f === 'docx') exportarDOCX(doc);
  else if (r.f === 'csv') { const r2 = await salvarComo(nomeArq(doc.nome) + '.csv', csvTexto(opc.csv.cab, opc.csv.linhas), 'text/csv', 'Planilha CSV'); if (r2) aviso('Planilha salva: ' + r2.nome); }
  else { try { const b = await docxBlob(doc); await enviarPorEmail({ blob: b, nome: nomeArq(doc.nome) + '.docx', assunto: opc.assunto || doc.titulo, corpo: opc.corpo || 'Segue em anexo: ' + doc.titulo + '.', para: opc.para }); } catch (x) { informar('Não foi possível preparar o envio', '<p>' + e(x.message || x) + '</p>'); } }
}
async function perguntarEnvio(doc, opc) { const r = await confirmar('Enviar por e-mail?', 'Deseja enviar <b>' + e(doc.titulo) + '</b> por e-mail agora?', 'Enviar'); if (r) { try { const b = await docxBlob(doc); await enviarPorEmail({ blob: b, nome: nomeArq(doc.nome) + '.docx', assunto: (opc && opc.assunto) || doc.titulo, corpo: (opc && opc.corpo) || 'Segue em anexo: ' + doc.titulo + '.', para: opc && opc.para }); } catch (x) { informar('Não foi possível preparar o envio', '<p>' + e(x.message || x) + '</p>'); } } }

/* ---------- impressão digital (finalização) ---------- */
function conteudoParaHash(store, r) { const c = clone(r); ['estado', 'finalizadoEm', 'hash', 'emTempo', 'alterado', 'criado', 'importadas'].forEach(k => delete c[k]); return JSON.stringify(c); }
async function finalizar(store, r) {
  await descarregarFila();
  const ok = await confirmar('Finalizar o documento?', 'Depois de finalizado, o documento não pode mais ser editado. Correções serão feitas com “Em tempo” ou com uma nova versão, e o original fica guardado intacto.', 'Finalizar');
  if (!ok) return false;
  r.estado = 'finalizado'; r.finalizadoEm = new Date().toISOString(); r.hash = await sha256(conteudoParaHash(store, r)); await salvar(store, r); aviso('Documento finalizado.'); return true;
}
async function conferirHash(store, r) { const h = await sha256(conteudoParaHash(store, r)); return h === r.hash; }
async function alterarFinalizado(store, r) {
  const v = await dlg({ titulo: 'Este documento está finalizado', ok: false, cancelar: 'Voltar', corpo: '<p>O original não pode ser alterado e continuará guardado. Escolha como prosseguir:</p>', extra: '<button type="button" class="btn" data-x="emtempo">Acrescentar “Em tempo”</button><button type="button" class="btn pri" data-x="nova">Criar nova versão</button>' });
  if (!v) return null;
  if (v._botao === 'emtempo') {
    const t = await dlg({ titulo: 'Em tempo', ok: 'Acrescentar', corpo: '<p class="dica">Nota de correção ou complemento. Será impressa logo após o texto original, com a data de hoje.</p>' + campo('Texto', '<textarea name="t" autofocus class="mao"></textarea>'), validar: v => v.t.trim() ? null : 'Escreva o texto.' });
    if (!t) return null; r.emTempo = (r.emTempo || []).concat([{ data: hojeISO(), texto: t.t.trim() }]); await salvar(store, r); aviso('“Em tempo” acrescentado.'); return r;
  }
  const n = clone(r); n.id = uid(); n.estado = 'rascunho'; delete n.hash; delete n.finalizadoEm; n.emTempo = []; n.origemId = r.id; n.substitui = (r.data || (r.finalizadoEm || '').slice(0, 10)); delete n.criado;
  await salvar(store, n);
  if (store === 'atas') D.marcacoes.filter(m => m.ataId === r.id).forEach(m => salvar('marcacoes', Object.assign(clone(m), { id: uid(), ataId: n.id })));
  aviso('Nova versão criada como rascunho.'); return n;
}
