/* ==========================================================================
   Tecelã — documentos editáveis com seções (Combinados, PEI, Planejamento anual,
   Plano de época e as referências de cada ano). Cada tipo registra em TIPOS_DOC
   como montar o rascunho; aqui ficam o editor, as versões e o relatório.
   Documento: { id, tipo, turmaId?, alunoId?, serie?, epocaId?, titulo, cab:{},
   secoes:[{ k, tit, tipo:'texto'|'tabela'|'diario', txt|cols+linhas|campos+dias, auto?, naoImprimir? }],
   versoes:[{ n, data, nota, hash, conteudo }] }
   ========================================================================== */
'use strict';
const TIPOS_DOC = {};
const secTexto = (k, tit, txt) => ({ k, tit, tipo: 'texto', txt: txt || '' });
const secTabela = (k, tit, cols, linhas) => ({ k, tit, tipo: 'tabela', cols, linhas: linhas && linhas.length ? linhas : [cols.map(() => '')] });
const secDiario = (k, tit, campos, dias) => ({ k, tit, tipo: 'diario', campos, dias: dias || [] });
const listaTxt = xs => (xs || []).filter(Boolean).map(x => '- ' + x).join('\n');
const docsDe = (tipo, f) => D.documentos.filter(d => d.tipo === tipo && (!f || f(d)));

async function criarDoc(tipo, base) {
  const T_ = TIPOS_DOC[tipo], d = Object.assign({ tipo, cab: {}, secoes: [], versoes: [] }, base || {});
  Object.assign(d, T_.gerar(d)); return salvar('documentos', d);
}
/* refaz as seções automáticas, mantendo o que a professora escreveu nas demais */
function regerarSecao(d, k) { const g = TIPOS_DOC[d.tipo].gerar(d); return (g.secoes || []).find(s => s.k === k); }

/* ---------- editor ---------- */
function editorDoc(d, opc) {
  opc = opc || {}; const T_ = TIPOS_DOC[d.tipo], ult = (d.versoes || []).slice(-1)[0];
  let h = '<div class="linha">' + (opc.voltar === false ? '' : '<button class="btn" data-a="voltarSub">← ' + e(opc.voltar || 'Voltar') + '</button>') + '<h2 style="margin:0">' + e(d.titulo || T_.nome) + '</h2><span class="etq ' + (ult ? 'fin' : 'rasc') + '">' + (ult ? 'versão ' + ult.n + ' de ' + dataBR(ult.data.slice(0, 10)) : 'rascunho') + '</span></div>';
  h += '<div class="linha" style="margin:.8rem 0"><button class="btn pri" data-a="docExportar" data-id="' + d.id + '">Imprimir ou exportar</button>' + (T_.versoes === false ? '' : '<button class="btn" data-a="docVersao" data-id="' + d.id + '">Registrar versão</button>' + ((d.versoes || []).length ? '<button class="btn" data-a="docVersoes" data-id="' + d.id + '">Versões (' + d.versoes.length + ')</button>' : '')) + (T_.botoes ? T_.botoes(d) : '') + (T_.auto === false ? '' : '<button class="btn" data-a="docRefazer" data-id="' + d.id + '" title="Monta de novo as partes que vêm do sistema">↻ Refazer o rascunho</button>') + '<span class="espaco"></span><button class="btn perigo" data-a="docExcluir" data-id="' + d.id + '">Excluir</button></div>';
  if (opc.alerta) h += opc.alerta;
  if (T_.ajuda) h += '<p class="dica">' + T_.ajuda + '</p>';
  h += '<fieldset style="border:0;padding:0;margin:0" data-rec="documentos:' + d.id + '">';
  h += '<div class="cartao">' + campo('Título', inp('titulo', d.titulo)) + (T_.cab && T_.cab.length ? '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">' + T_.cab.map(([k, r, tp]) => campo(r, tp === 'area' ? area('cab.' + k, (d.cab || {})[k], 'style="min-height:3rem"') : inp('cab.' + k, (d.cab || {})[k], tp || 'text'))).join('') + '</div>' : '') + '</div>';
  (d.secoes || []).forEach((s, i) => { h += secaoEditor(d, s, i); });
  h += '</fieldset><div class="linha"><button class="btn" data-a="docNovaSec" data-id="' + d.id + '" data-tp="texto">+ Seção de texto</button><button class="btn" data-a="docNovaSec" data-id="' + d.id + '" data-tp="tabela">+ Tabela</button></div>';
  h += '<details class="cartao"><summary><b>Prévia do documento</b></summary><div class="previa" style="margin-top:.6rem">' + htmlDoc(docDe(d), true) + '</div></details>';
  return h;
}
function secaoEditor(d, s, i) {
  const n = d.secoes.length, auto = !!s.k && !s.manual && TIPOS_DOC[d.tipo].auto !== false;
  let h = '<div class="cartao sec-doc' + (s.naoImprimir ? ' suave' : '') + '"' + (s.k ? ' id="sec-' + e(s.k.replace(/[^\w-]/g, '_')) + '"' : '') + '><div class="linha" style="gap:.3rem"><input class="tit-sec" data-b="secoes.' + i + '.tit" value="' + e(s.tit) + '" aria-label="Título da seção (toque para mudar)" title="Toque para mudar o título">' +
    '<button type="button" class="icone-btn" data-a="docMoverSec" data-id="' + d.id + '" data-i="' + i + '" data-d="-1" title="Subir"' + (i ? '' : ' disabled') + '>↑</button><button type="button" class="icone-btn" data-a="docMoverSec" data-id="' + d.id + '" data-i="' + i + '" data-d="1" title="Descer"' + (i < n - 1 ? '' : ' disabled') + '>↓</button>' +
    (auto && s.k ? '<button type="button" class="icone-btn" data-a="docRefazerSec" data-id="' + d.id + '" data-i="' + i + '" title="Trazer de novo do sistema">↻</button>' : '') + '<button type="button" class="icone-btn" data-a="docRemSec" data-id="' + d.id + '" data-i="' + i + '" title="Tirar a seção">✕</button></div>';
  if (s.tipo === 'tabela') {
    const lg = s.cols.map((c, j) => Math.min(60, Math.max(6, String(c).length, ...(s.linhas || []).map(l => String(l[j] || '').length)))), tot = lg.reduce((x, y) => x + y, 0) || 1;
    h += '<div class="rolagem"><table class="tabela tab-doc"><colgroup>' + lg.map(x => '<col style="width:' + Math.round(x / tot * 96) + '%">').join('') + '<col style="width:2.2rem"></colgroup><tr>' + s.cols.map((c, j) => '<th><input class="tit-col" data-b="secoes.' + i + '.cols.' + j + '" value="' + e(c) + '" aria-label="Coluna"></th>').join('') + '<th></th></tr>' +
      (s.linhas || []).map((l, r) => '<tr>' + s.cols.map((c, j) => '<td><textarea rows="1" data-b="secoes.' + i + '.linhas.' + r + '.' + j + '" aria-label="' + e(c) + '">' + e(l[j] || '') + '</textarea></td>').join('') + '<td><button type="button" class="icone-btn" data-a="docRemLinha" data-id="' + d.id + '" data-i="' + i + '" data-r="' + r + '" title="Tirar a linha">✕</button></td></tr>').join('') + '</table></div><button type="button" class="btn peq" data-a="docAddLinha" data-id="' + d.id + '" data-i="' + i + '">+ Linha</button>';
  } else if (s.tipo === 'diario') {
    h += (s.dias || []).length ? s.dias.map((x, j) => '<details class="dia-doc"><summary><b>' + dataBR(x.data).slice(0, 5) + ' · ' + diaSemana(x.data) + '</b>' + (x.aulas ? ' <span class="dica">' + e(x.aulas) + '</span>' : '') + (s.campos.some(([k]) => k !== 'pc' && x[k]) ? ' <span class="etq">preenchido</span>' : '') + '</summary>' + s.campos.map(([k, r]) => campo(r, area('secoes.' + i + '.dias.' + j + '.' + k, x[k], 'style="min-height:2.6rem"'))).join('') + '</details>').join('') : '<p class="dica">Sem dias. Informe o início e o fim e toque em “Montar o diário pelo calendário”.</p>';
  } else h += area('secoes.' + i + '.txt', s.txt, 'class="alto"');
  h += '<label class="ck" style="margin-top:.3rem"><input type="checkbox" data-b="secoes.' + i + '.naoImprimir"' + (s.naoImprimir ? ' checked' : '') + ' data-rr="1"> <span class="dica">Só para mim: não entra no documento impresso</span></label></div>';
  return h;
}
const docAtual = dt => IX.documentos[dt.id];
async function mexer(d, fn) { await descarregarFila(); fn(d); await salvar('documentos', d); render(); }
A.docMoverSec = d => mexer(docAtual(d), x => { const i = Number(d.i), j = i + Number(d.d); [x.secoes[i], x.secoes[j]] = [x.secoes[j], x.secoes[i]]; });
A.docRemSec = async d => { const x = docAtual(d), s = x.secoes[Number(d.i)]; if (!(await confirmar('Tirar a seção?', '“' + e(s.tit) + '” sai deste documento.', 'Tirar'))) return; const copia = clone(s), i = Number(d.i); await mexer(x, y => y.secoes.splice(i, 1)); aviso('Seção retirada.', 'Desfazer', () => mexer(x, y => y.secoes.splice(i, 0, copia))); };
A.docRefazerSec = async d => { const x = docAtual(d), i = Number(d.i), s = x.secoes[i], n = regerarSecao(x, s.k); if (!n) return aviso('Esta seção não vem do sistema.'); if (!(await confirmar('Trazer de novo do sistema?', 'O conteúdo de “' + e(s.tit) + '” será montado de novo a partir dos dados atuais. O que você escreveu nela será substituído.', 'Trazer'))) return; const antes = clone(s); await mexer(x, y => { y.secoes[i] = Object.assign(n, { tit: s.tit }); }); aviso('Seção atualizada.', 'Desfazer', () => mexer(x, y => { y.secoes[i] = antes; })); };
A.docRefazer = async d => { const x = docAtual(d); if (!(await confirmar('Refazer o rascunho?', 'As seções que vêm do sistema serão montadas de novo com os dados atuais. As seções que você criou ficam como estão.', 'Refazer'))) return; const antes = clone(x.secoes), g = TIPOS_DOC[x.tipo].gerar(x); await mexer(x, y => { const proprias = y.secoes.filter(s => !s.k && !g.secoes.some(x => !x.k && x.tit === s.tit)); y.secoes = g.secoes.concat(proprias); if (g.cab) y.cab = Object.assign({}, g.cab, y.cab); }); aviso('Rascunho refeito.', 'Desfazer', () => mexer(x, y => { y.secoes = antes; })); };
A.docNovaSec = async d => { const x = docAtual(d); if (d.tp === 'tabela') { const v = await dlg({ titulo: 'Nova tabela', ok: 'Incluir', corpo: campo('Título', '<input name="t" autofocus>') + campo('Colunas (separadas por vírgula)', '<input name="c" value="Coluna 1, Coluna 2">'), validar: v => v.t.trim() ? null : 'Informe o título.' }); if (!v) return; await mexer(x, y => y.secoes.push(secTabela('', v.t.trim(), v.c.split(',').map(c => c.trim()).filter(Boolean)))); } else { const v = await dlg({ titulo: 'Nova seção', ok: 'Incluir', corpo: campo('Título', '<input name="t" autofocus>'), validar: v => v.t.trim() ? null : 'Informe o título.' }); if (!v) return; await mexer(x, y => y.secoes.push(secTexto('', v.t.trim(), ''))); } };
A.docAddLinha = d => mexer(docAtual(d), x => { const s = x.secoes[Number(d.i)]; s.linhas.push(s.cols.map(() => '')); });
A.docRemLinha = d => mexer(docAtual(d), x => { x.secoes[Number(d.i)].linhas.splice(Number(d.r), 1); });
A.docExcluir = async d => { const x = docAtual(d); if (!(await confirmar('Excluir o documento?', '“' + e(x.titulo) + '” e as versões registradas serão apagados. Você pode desfazer logo em seguida.', 'Excluir'))) return; UI.sub = null; await apagarComDesfazer('documentos', x.id, 'Documento excluído.'); };

/* ---------- versões ---------- */
const conteudoDoc = d => ({ titulo: d.titulo, cab: clone(d.cab || {}), secoes: clone(d.secoes || []) });
A.docVersao = async d => {
  await descarregarFila(); const x = docAtual(d), n = (x.versoes || []).length + 1;
  const v = await dlg({ titulo: 'Registrar a versão ' + n, ok: 'Registrar', corpo: '<p>A versão registrada fica guardada como está, com data, hora e impressão digital. Você continua editando o documento para as próximas versões.</p>' + campo('O que mudou nesta versão', '<textarea name="nota" autofocus>' + (n === 1 ? 'Primeira versão.' : '') + '</textarea>'), validar: v => v.nota.trim() ? null : 'Conte em poucas palavras o que mudou.' });
  if (!v) return; const c = conteudoDoc(x); x.versoes = (x.versoes || []).concat([{ n, data: new Date().toISOString(), nota: v.nota.trim(), hash: await sha256(JSON.stringify(c)), conteudo: c }]); await salvar('documentos', x); render(); aviso('Versão ' + n + ' registrada.');
};
A.docVersoes = async d => {
  const x = docAtual(d);
  const r = await dlg({ titulo: 'Versões de “' + x.titulo + '”', largo: true, ok: false, cancelar: 'Fechar', corpo: '<div class="rolagem"><table class="tabela"><tr><th>Versão</th><th>Data</th><th>O que mudou</th><th></th></tr>' + x.versoes.slice().reverse().map(v => '<tr><td><b>' + v.n + '</b></td><td>' + new Date(v.data).toLocaleString('pt-BR') + '</td><td>' + e(v.nota) + '</td><td style="white-space:nowrap"><button type="button" class="btn peq" data-x="exp' + v.n + '">Exportar</button> <button type="button" class="btn peq" data-x="conf' + v.n + '">Conferir</button> <button type="button" class="btn peq" data-x="rest' + v.n + '">Voltar a esta</button></td></tr>').join('') + '</table></div>' });
  if (!r || !r._botao) return; const n = Number(r._botao.replace(/\D/g, '')), v = x.versoes.find(y => y.n === n);
  if (/^exp/.test(r._botao)) return saidaDocumento(docDe(x, v), { assunto: x.titulo });
  if (/^conf/.test(r._botao)) return informar('Impressão digital', (await sha256(JSON.stringify(v.conteudo))) === v.hash ? '<p>✔ A versão ' + n + ' está idêntica ao momento em que foi registrada.</p>' : '<p class="alerta verm">A versão ' + n + ' não confere com a impressão digital registrada.</p>');
  if (!(await confirmar('Voltar à versão ' + n + '?', 'O texto atual em edição será substituído pelo da versão ' + n + '. As versões registradas continuam guardadas.', 'Voltar'))) return;
  const antes = conteudoDoc(x); await mexer(x, y => Object.assign(y, clone(v.conteudo))); aviso('Texto da versão ' + n + ' em edição.', 'Desfazer', () => mexer(x, y => Object.assign(y, antes)));
};
A.docExportar = async d => {
  await descarregarFila(); const x = docAtual(d), vs = x.versoes || [];
  if (!vs.length) return saidaDocumento(docDe(x), { assunto: x.titulo });
  const r = await dlg({ titulo: 'Qual versão?', ok: 'Continuar', corpo: '<label class="ck"><input type="radio" name="v" value="" checked> <span>O texto atual, em edição</span></label>' + vs.slice().reverse().map(v => '<label class="ck"><input type="radio" name="v" value="' + v.n + '"> <span>Versão ' + v.n + ' — ' + dataBR(v.data.slice(0, 10)) + ' (' + e(v.nota) + ')</span></label>').join('') + '<label class="ck"><input type="checkbox" name="hist" checked> <span>Incluir o histórico de versões no fim</span></label>' });
  if (!r) return; const v = r.v ? vs.find(y => y.n === Number(r.v)) : null; saidaDocumento(docDe(x, v, r.hist), { assunto: x.titulo });
};

/* ---------- documento para impressão / DOCX ---------- */
function blocosTexto(txt) {
  const b = []; let lista = [];
  const fecha = () => { if (lista.length) { b.push({ t: 'lista', itens: lista }); lista = []; } };
  String(txt || '').split('\n').forEach(l => { const s = l.trim(); if (!s) return fecha(); const m = s.match(/^[-•*]\s+(.*)$/); if (m) lista.push(m[1]); else if (/^#{1,3}\s/.test(s)) { fecha(); b.push({ t: 'h', txt: s.replace(/^#+\s*/, '') }); } else { fecha(); b.push({ t: 'p', txt: s }); } });
  fecha(); return b;
}
function docDe(d, versao, hist) {
  const T_ = TIPOS_DOC[d.tipo], c = versao ? versao.conteudo : d, b = [];
  b.push({ t: 'tit', txt: (c.titulo || T_.nome) });
  const cab = T_.cabDoc ? T_.cabDoc(Object.assign({}, d, c)) : []; if (cab.length) { const pares = []; for (let i = 0; i < cab.length; i += 2) pares.push([cab[i], cab[i + 1] || '']); b.push({ t: 'pares', linhas: pares }); }
  if (versao) b.push({ t: 'centro', linhas: ['Versão ' + versao.n + ' · ' + new Date(versao.data).toLocaleDateString('pt-BR')], peq: true });
  (c.secoes || []).filter(s => !s.naoImprimir).forEach(s => {
    if (s.tit) b.push({ t: 'h', txt: s.tit });
    if (s.tipo === 'tabela') { const ls = (s.linhas || []).filter(l => l.some(x => String(x || '').trim())); if (ls.length) b.push({ t: 'tabela', cab: s.cols, linhas: ls.map(l => s.cols.map((x, j) => l[j] || '')) }); }
    else if (s.tipo === 'diario') (s.dias || []).forEach(x => { b.push({ t: 'h', txt: dataBR(x.data).slice(0, 5) + ' – ' + diaSemana(x.data).replace(/^./, m => m.toUpperCase()) }); if (x.aulas) b.push({ t: 'nota', txt: x.aulas }); s.campos.forEach(([k, r]) => b.push({ t: 'p', txt: r + ': ' + (x[k] || '') })); });
    else b.push(...blocosTexto(s.txt));
  });
  if (hist && (d.versoes || []).length) b.push({ t: 'h', txt: 'Histórico de versões' }, { t: 'tabela', cab: ['Versão', 'Data', 'O que mudou'], linhas: d.versoes.filter(v => !versao || v.n <= versao.n).map(v => [String(v.n), new Date(v.data).toLocaleString('pt-BR'), v.nota]) });
  if (T_.fimDoc) b.push(...T_.fimDoc(d));
  return { nome: nomeArq(c.titulo || T_.nome) + (versao ? '_v' + versao.n : ''), titulo: c.titulo || T_.nome, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: b };
}
