/* ==========================================================================
   Tecelã — Cadastros: listas personalizáveis (tipos de ata, participantes,
   caráter, critérios do perfil, papéis no grupo, pontos de atenção, tipos de
   vivência e de evento, componentes do currículo). Itens já usados em algum
   registro são arquivados em vez de apagados, para preservar o histórico.
   ========================================================================== */
'use strict';
const LISTAS = {
  tiposAta: { nome: 'Tipos de reunião (atas)', dica: 'Cada tipo tem suas categorias de participantes e, se quiser, subtipos.', extras: ['cats', 'subtipos'], padrao: [
    ['familias', 'Reunião com as famílias', { cats: ['Professor(a)', 'Familiar', 'Convidado'], subtipos: [] }],
    ['colegiado', 'Reunião do colegiado', { cats: ['Professor(a) do mesmo grau', 'Professor(a) de outro grau', 'Coordenação', 'Convidado'], subtipos: ['Reunião de colegiado', 'Conferência pedagógica', 'Estudo de criança'] }],
    ['geral', 'Reunião geral', { cats: ['Professor(a)', 'Familiar', 'Aluno(a)', 'Convidado', 'Diretoria', 'Coordenação', 'Entidade'], subtipos: [] }],
    ['conselho', 'Conselho de classe', { cats: ['Professor(a) de classe', 'Professor(a) especialista', 'Coordenação', 'Convidado'], subtipos: ['Pré-conselho', 'Conselho de classe', 'Pós-conselho'] }]] },
  carateres: { nome: 'Caráter da reunião', padrao: [['ordinária', 'ordinária'], ['extraordinária', 'extraordinária'], ['agendada', 'agendada'], ['urgente', 'urgente']] },
  criterios: { nome: 'Critérios do perfil (anotações)', dica: 'Ligam as anotações aos blocos do perfil do aluno.', padrao: [['constituicao', 'Constituição e corpo'], ['temperamento', 'Temperamento'], ['pensar', 'Pensar'], ['sentir', 'Sentir'], ['querer', 'Querer'], ['sentidos', 'Sentidos'], ['biografia', 'Momento biográfico'], ['aprendizagem', 'Aprendizagem e expressão'], ['social', 'Social e moral']] },
  papeis: { nome: 'Papéis no grupo', padrao: [['lider', 'Líder'], ['mediador', 'Mediador'], ['colaborador', 'Colaborador'], ['observador', 'Observador'], ['isolado', 'Isolado'], ['provocador', 'Provocador']] },
  atencao: { nome: 'Tipos de ponto de atenção', dica: 'Usados no cadastro do aluno. Pontos de atenção são sigilosos por padrão.', padrao: [['saude', 'Saúde'], ['alergia', 'Alergia ou restrição alimentar'], ['visao-audicao', 'Visão ou audição'], ['sono', 'Sono'], ['emocional', 'Emocional'], ['aprendizagem', 'Aprendizagem'], ['terapia', 'Acompanhamento terapêutico'], ['familia', 'Família e guarda'], ['movimento', 'Movimento e coordenação'], ['outro', 'Outro']] },
  tiposVivencia: { nome: 'Tipos de vivência', padrao: [['oficio', 'Visita a um ofício'], ['oficina', 'Oficina'], ['saida', 'Saída pedagógica'], ['festa', 'Festa do ano'], ['teatro', 'Teatro ou apresentação'], ['mutirao', 'Mutirão'], ['outra', 'Outra']] },
  tiposEvento: { nome: 'Tipos de evento do calendário', extras: ['cor'], padrao: [['epoca', 'Época', { cor: '#2F6AA8' }], ['vivencia', 'Vivência', { cor: '#8A62A8' }], ['reuniao', 'Reunião', { cor: '#55697F' }], ['festa', 'Festa', { cor: '#E9B93A' }], ['feriado', 'Feriado ou recesso', { cor: '#C8452F' }], ['escola', 'Calendário da escola', { cor: '#7DAA6E' }], ['outro', 'Outro', { cor: '#999999' }]] },
  componentes: { nome: 'Componentes do currículo', dica: 'Os ligados a uma área da BNCC entram na comparação com a BNCC.', extras: ['bncc'], padrao: [['LP', 'Língua Portuguesa', { bncc: 'LP' }], ['MA', 'Matemática', { bncc: 'MA' }], ['CI', 'Ciências', { bncc: 'CI' }], ['HI', 'História', { bncc: 'HI' }], ['GE', 'Geografia', { bncc: 'GE' }], ['AR', 'Arte', { bncc: 'AR' }], ['EF', 'Educação Física e jogos', { bncc: 'EF' }], ['LI', 'Língua Inglesa', { bncc: 'LI' }], ['ER', 'Religiosidade', { bncc: 'ER' }], ['euritmia', 'Euritmia', { bncc: '' }], ['trabalhos', 'Trabalhos manuais', { bncc: '' }], ['musica', 'Música', { bncc: 'AR' }], ['jardinagem', 'Jardinagem', { bncc: 'CI' }], ['marcenaria', 'Marcenaria', { bncc: '' }], ['alemao', 'Alemão', { bncc: '' }], ['computacao', 'Computação', { bncc: 'CO' }]] }
};
function garantirCadastros() {
  const novos = [];
  /* v1.3: listas antigas ganham o componente "Computação" (complemento da BNCC) uma única vez */
  if (!CFG.prefs.mig13 && D.cadastros.some(c => c.lista === 'componentes')) {
    CFG.prefs.mig13 = true; SE.gravarPrefs = true;
    if (!IX.cadastros['componentes:computacao']) { const r = { id: 'componentes:computacao', lista: 'componentes', chave: 'computacao', nome: 'Computação', ordem: 99, arquivado: false, bncc: 'CO' }; D.cadastros.push(r); IX.cadastros[r.id] = r; novos.push(r); }
  }
  /* v1.2: listas antigas ganham o tipo de ata "Conselho de classe" uma única vez */
  if (!CFG.prefs.mig12 && D.cadastros.some(c => c.lista === 'tiposAta')) {
    CFG.prefs.mig12 = true; SE.gravarPrefs = true;
    if (!IX.cadastros['tiposAta:conselho']) { const [chave, nome, ext] = LISTAS.tiposAta.padrao.find(x => x[0] === 'conselho'), r = Object.assign({ id: 'tiposAta:conselho', lista: 'tiposAta', chave, nome, ordem: 99, arquivado: false }, clone(ext)); D.cadastros.push(r); IX.cadastros[r.id] = r; novos.push(r); }
  }
  Object.entries(LISTAS).forEach(([lista, def]) => {
    if (D.cadastros.some(c => c.lista === lista)) return;
    def.padrao.forEach(([chave, nome, ext], i) => { const r = Object.assign({ id: lista + ':' + chave, lista, chave, nome, ordem: i, arquivado: false }, clone(ext || {})); D.cadastros.push(r); IX.cadastros[r.id] = r; novos.push(r); });
  });
  return novos;
}
const itensLista = (lista, todos) => D.cadastros.filter(c => c.lista === lista && (todos || !c.arquivado)).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
const itemLista = (lista, chave) => D.cadastros.find(c => c.lista === lista && c.chave === chave);
const nomeItem = (lista, chave) => { const i = itemLista(lista, chave); return i ? i.nome : (chave || ''); };
const opcoesLista = (lista, vazio, atual) => (vazio ? [['', vazio]] : []).concat(itensLista(lista).map(i => [i.chave, i.nome])).concat(atual && itemLista(lista, atual) && itemLista(lista, atual).arquivado ? [[atual, nomeItem(lista, atual) + ' (arquivado)']] : []);
/* substituem as listas fixas da versão 1.0 */
const criterios = () => opcoesLista('criterios', '— nenhum —');
const papeis = () => opcoesLista('papeis', '—');
const carateres = () => itensLista('carateres').map(i => i.chave);
function tipoAta(k) { const i = itemLista('tiposAta', k) || itemLista('tiposAta', 'geral') || { nome: 'Reunião', cats: ['Participante'], subtipos: [] }; return { nome: i.nome, cats: (i.cats && i.cats.length ? i.cats : ['Participante']), subtipos: i.subtipos || [] }; }
function tiposAta() { const r = {}; itensLista('tiposAta').forEach(i => r[i.chave] = tipoAta(i.chave)); return r; }
/* onde cada item é usado: uma linha por registro (para mostrar à professora antes de arquivar) */
function ondeUsado(lista, chave) {
  const nA = a => nomeReuniao(a) + ' nº ' + (a.numero || '') + ' de ' + dataBR(a.data), nAl = id => (IX.alunos[id] || {}).nome || '';
  switch (lista) {
    case 'criterios': return D.anotacoes.filter(n => n.criterio === chave).map(n => 'Anotação de ' + dataBR(n.data) + ' (' + (n.alunos || []).map(id => primeiroNome(IX.alunos[id])).join(', ') + ')').concat(itensLista('blocosObs', true).filter(b => b.criterio === chave).map(b => 'Bloco da observação: ' + b.nome));
    case 'tiposAta': return D.atas.filter(a => a.tipo === chave).map(nA);
    case 'carateres': return D.atas.filter(a => a.carater === chave).map(nA);
    case 'papeis': return D.perfisAluno.filter(p => (p.campos || {}).papel === chave).map(p => 'Perfil de ' + nAl(p.alunoId) + ' (' + dataBR(p.data) + ')');
    case 'atencao': return D.alunos.flatMap(a => (a.atencao || []).filter(x => x.tipo === chave).map(() => 'Ponto de atenção de ' + a.nome));
    case 'tiposVivencia': return D.vivencias.filter(v => v.tipo === chave).map(v => 'Vivência: ' + v.titulo + ' (' + dataBR(v.data) + ')');
    case 'tiposEvento': return D.eventos.filter(v => v.tipo === chave).map(v => 'Evento: ' + v.titulo + ' (' + dataBR(v.data) + ')');
    case 'componentes': return D.curriculo.filter(v => v.componente === chave).map(v => 'Época do ' + v.serie + 'º ano: ' + v.titulo);
    case 'blocosObs': return itensLista('itensObs', true).filter(i => i.bloco === chave).map(i => 'Item da observação: ' + i.nome);
    case 'itensObs': return D.observacoes.filter(r => (r.marcas || {})[chave] || (r.notas || {})[chave]).map(r => 'Observação de ' + nAl(r.alunoId) + ' (' + rotPeriodo(r.periodo) + ')');
  }
  return []; /* frases prontas: o texto é copiado para a anotação, então excluir a frase não muda nada já escrito */
}
const usoItem = (lista, chave) => ondeUsado(lista, chave).length;
A.verUso = d => { const i = IX.cadastros[d.id], xs = ondeUsado(i.lista, i.chave); informar('Onde “' + i.nome + '” é usado', '<p>' + xs.length + ' registro(s). Por isso, em vez de excluído, o item é arquivado: sai das listas de escolha e continua nestes registros.</p><ul>' + xs.slice(0, 60).map(x => '<li>' + e(x) + '</li>').join('') + '</ul>' + (xs.length > 60 ? '<p class="dica">E mais ' + (xs.length - 60) + '.</p>' : '')); };

T.cadastros = () => {
  const lista = UI.aba.cadastros || 'tiposAta', def = LISTAS[lista];
  let h = '<h1>Cadastros</h1><p>Personalize as listas usadas pela Tecelã. O botão de cada item diz o que vai acontecer: <b>Excluir</b>, quando o item não é usado em nenhum registro, ou <b>Arquivar</b>, quando já é usado. O item arquivado sai das listas de escolha, mas continua nos registros antigos, sem perder as relações e o histórico. Toque no número da coluna “Uso” para ver onde ele aparece.</p>';
  h += '<div class="linha" style="margin-bottom:1rem">' + Object.entries(LISTAS).map(([k, d]) => '<button class="btn peq' + (k === lista ? ' pri' : '') + '" data-a="aba" data-v="' + k + '">' + d.nome + '</button>').join('') + '<button class="btn peq" data-a="ir" data-t="bol" data-aba="secoes">Seções do boletim (por série) ↗</button><button class="btn peq" data-a="ir" data-t="ajustes">Períodos das faltas e da observação ↗</button></div>';
  let itens = itensLista(lista, true);
  if (lista === 'itensObs') { const bs = itensLista('blocosObs', true), bk = bs.some(b => b.chave === UI.filtro.cadBloco) ? UI.filtro.cadBloco : (bs[0] || {}).chave; UI.filtro.cadBloco = bk; itens = itens.filter(i => i.bloco === bk); h += '<div class="linha"><span class="dica">Bloco:</span><select data-c="cadBloco">' + bs.map(b => '<option value="' + b.chave + '"' + (b.chave === bk ? ' selected' : '') + '>' + e(b.nome) + '</option>').join('') + '</select></div>'; }
  h += '<div class="cartao"><h3>' + def.nome + '</h3>' + (def.dica ? '<p class="dica">' + def.dica + '</p>' : '') + '<div class="rolagem"><table class="tabela"><tr><th>Nome</th>' + (def.extras || []).map(x => '<th>' + ({ cats: 'Categorias de participantes (uma por linha)', subtipos: 'Subtipos (um por linha)', cor: 'Cor', bncc: 'Área da BNCC', criterio: 'Critério do perfil', secao: 'Seção do boletim', bloco: 'Bloco' }[x]) + '</th>').join('') + '<th>Uso</th><th></th></tr>' +
    itens.map((i, n) => '<tr data-rec="cadastros:' + i.id + '" style="' + (i.arquivado ? 'opacity:.6' : '') + '"><td>' + inp('nome', i.nome) + (i.arquivado ? '<span class="etq">arquivado</span>' : '') + '</td>' +
      (def.extras || []).map(x => '<td>' + (x === 'cor' ? '<input type="color" data-b="cor" value="' + e(i.cor || '#999999') + '" style="width:3rem;height:2.2rem;padding:2px">' : x === 'bncc' ? sel('bncc', i.bncc || '', [['', '— não se aplica —']].concat(Object.entries(BNCC_COMP))) : x === 'criterio' ? sel('criterio', i.criterio || '', criterios()) : x === 'secao' ? sel('secao', i.secao || '', opcoesSecaoCad(lista)) : x === 'bloco' ? sel('bloco', i.bloco || '', opcoesLista('blocosObs', '—', i.bloco), 'data-rr="1"') : '<textarea data-c="listaExtra" data-id="' + i.id + '" data-k="' + x + '" style="min-height:4rem">' + e((i[x] || []).join('\n')) + '</textarea>') + '</td>').join('') +
      (u => '<td>' + (u ? '<a href="#" data-a="verUso" data-id="' + i.id + '" title="Ver onde é usado">' + u + '</a>' : '0') + '</td><td style="white-space:nowrap"><button class="icone-btn" data-a="moverItem" data-id="' + i.id + '" data-d="-1" title="Subir">↑</button><button class="icone-btn" data-a="moverItem" data-id="' + i.id + '" data-d="1" title="Descer">↓</button>' + (i.arquivado ? '<button class="btn peq" data-a="desarquivar" data-id="' + i.id + '">Reativar</button>' + (u ? '' : '<button class="btn peq perigo" data-a="excluirItem" data-id="' + i.id + '">Excluir</button>') : '<button class="btn peq' + (u ? '' : ' perigo') + '" data-a="excluirItem" data-id="' + i.id + '" title="' + (u ? 'Em uso: será arquivado, sem perder o histórico' : 'Sem uso: será excluído') + '">' + (u ? 'Arquivar' : 'Excluir') + '</button>') + '</td></tr>')(usoItem(lista, i.chave))).join('') + '</table></div><button class="btn" data-a="novoItem" data-l="' + lista + '" style="margin-top:.6rem">+ Novo item</button></div>';
  return h;
};
const opcoesSecaoCad = lista => { const t = turmaAtual(), ss = modeloDaSerie(t ? t.serie : 1).secoes; return [['', lista === 'itensObs' ? '— a do bloco —' : '— nenhuma —']].concat(ss.map(s => [s.key, s.titulo + (s.ativa ? '' : ' (desligada)')])); };
C_.cadBloco = el => { UI.filtro.cadBloco = el.value; render(); };
C_.listaExtra = async el => { const i = IX.cadastros[el.dataset.id]; i[el.dataset.k] = el.value.split('\n').map(s => s.trim()).filter(Boolean); await salvar('cadastros', i); };
A.novoItem = async d => {
  const v = await dlg({ titulo: 'Novo item', ok: 'Incluir', corpo: campo('Nome', '<input name="n" autofocus>'), validar: v => v.n.trim() ? null : 'Informe o nome.' }); if (!v) return;
  const itens = itensLista(d.l, true), chave = 'u' + uid(), ext = { tiposAta: { cats: ['Participante'], subtipos: [] }, tiposEvento: { cor: '#2F6AA8' }, componentes: { bncc: '' }, blocosObs: { criterio: '', secao: '' }, itensObs: { bloco: UI.filtro.cadBloco || '', secao: '' } }[d.l] || {};
  await salvar('cadastros', Object.assign({ id: d.l + ':' + chave, lista: d.l, chave, nome: v.n.trim(), ordem: itens.length, arquivado: false }, ext)); render();
};
A.moverItem = async d => { const i = IX.cadastros[d.id], xs = itensLista(i.lista, true), k = xs.indexOf(i), j = k + Number(d.d); if (j < 0 || j >= xs.length) return; [xs[k], xs[j]] = [xs[j], xs[k]]; for (let n = 0; n < xs.length; n++) { xs[n].ordem = n; await salvar('cadastros', xs[n]); } render(); };
A.excluirItem = async d => {
  const i = IX.cadastros[d.id], u = usoItem(i.lista, i.chave);
  if (u) { if (await confirmar('Arquivar “' + e(i.nome) + '”?', 'Este item está em uso em ' + u + ' registro(s). Para não perder as relações e o histórico, ele será <b>arquivado</b>: sai das listas de escolha, mas continua nos registros antigos. Você pode reativá-lo depois.', 'Arquivar')) { i.arquivado = true; await salvar('cadastros', i); render(); aviso('“' + i.nome + '” arquivado.', 'Desfazer', async () => { i.arquivado = false; await salvar('cadastros', i); render(); }); } return; }
  if (await confirmar('Excluir “' + e(i.nome) + '”?', i.lista === 'frases' ? 'A frase sai da lista. As anotações que já usaram esta frase continuam como estão.' : 'Este item não está em uso em nenhum registro e será excluído.', 'Excluir')) await apagarComDesfazer('cadastros', i.id, '“' + i.nome + '” excluído.');
};
A.desarquivar = async d => { const i = IX.cadastros[d.id]; i.arquivado = false; await salvar('cadastros', i); render(); };
