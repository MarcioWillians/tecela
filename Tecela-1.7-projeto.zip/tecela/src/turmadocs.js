/* ==========================================================================
   Tecelã — Combinados da turma (guia amigável com as famílias, com versões no ano)
   e PEI, o Plano Educacional Individualizado (sigiloso, com dados já registrados).
   ========================================================================== */
'use strict';

/* ---------- COMBINADOS ---------- */
const COMBINADOS_MODELO = t => [
  secTexto('', 'Para começar', 'Este caderno foi escrito a muitas mãos, com os combinados e as experiências que a turma do ' + t.serie + 'º ano foi juntando pelo caminho. Não é regulamento de condomínio nem contrato com letra miúda: é um mapa para a vida da nossa sala ficar organizada, divertida e acolhedora para todo mundo.\nNossa sala é um pequeno universo dentro da escola. Os combinados daqui completam as regras da escola, nunca passam por cima delas.\nCom ele, as famílias novas chegam sem se perder e as veteranas relembram o que já sabem (e o que esqueceram nas férias, a gente entende).\nEle não é definitivo: a cada ano revemos tudo, porque a turma cresce, e os combinados crescem junto.'),
  secTexto('', 'Representantes de sala', '- A turma conta com dois representantes de sala: mães, pais ou responsáveis legais.\n- Cada representante fica dois anos, com entrada alternada: todo ano há um veterano, que já sabe onde fica o café, e um que está começando.\n- Como escolhemos: (eleição ou aclamação, na reunião de famílias de ______).\n- O que fazem: ponte entre famílias e professora, organização de festas e mutirões, recados práticos.\n- Como falam com a turma: (grupo de mensagens, e-mail, reunião).'),
  secTexto('', 'Comunicação entre a professora e as famílias', '- Canais: e-mail, caderneta, conversa presencial agendada e, para assuntos coletivos, os representantes.\n- Respondo às mensagens em dias úteis, no horário de trabalho. Família é em tempo integral; a escola tem horário, até para a professora poder preparar a aula com calma.\n- Assuntos sobre uma criança: conversa reservada, nunca no grupo.\n- Urgências do dia: pela secretaria da escola.'),
  secTexto('', 'Encontros da turma', '- Quando: (periodicidade combinada, por exemplo, uma vez por bimestre).\n- Onde: (casa de uma família, parque, escola).\n- Para quê: brincar, conviver e fortalecer os laços. Não é aula, é vida social: e ela também educa.'),
  secTexto('', 'Telas e eletrônicos', 'Combinamos cuidar juntos do uso de telas em casa, porque a imaginação das crianças precisa de espaço para brincar.\n- O que combinamos: (combinado da turma).\n- Por quê: (motivo, em poucas palavras).\n- Revemos este combinado conforme a turma cresce.'),
  secTexto('', 'Ano escolar e férias', '- O calendário da escola é enviado no início do ano. As datas da turma (épocas, vivências, reuniões) também ficam no calendário da turma.\n- Nas férias, vale ler o poema do ano antes de dormir: ele foi escrito para isso.'),
  secTexto('', 'A caixinha da turma', '- O que é e para que serve: vivências, materiais, presentes coletivos e a poupança para os grandes projetos dos anos que vêm (o teatro do 8º ano chega mais rápido do que parece).\n- Quem cuida: (responsáveis escolhidos pelas famílias).\n- Como prestamos contas: (planilha, recibos, periodicidade).\n- Arrecadação: com participação e solidariedade. Ninguém fica para trás.'),
  secTexto('', 'Outros combinados', '- Fotos das crianças: não postamos em redes sociais.\n- Aniversários na escola: bolo simples, e só. A festa é a presença dos amigos.\n- Lanche coletivo: (o que trazer e quando).\n- Eventos fora da escola com caráter pedagógico: avisamos com antecedência.\n- Participar ao vivo das festas e reuniões ensina às crianças, pelo exemplo, que a escola importa.\n- Integração com a turma paralela: cooperação, não competição. “Se quer ir rápido, vá sozinho; se quer ir longe, vá acompanhado.”'),
  secTexto('', 'Revisão dos combinados', 'As relações mudam, a turma cresce, a escola e as leis também mudam. Por isso revemos estes combinados todo ano, em ______ (por exemplo, em novembro, já deixando tudo pronto para o ano seguinte). Ao longo do ano, cada ajuste ganha uma nova versão, com data e o que mudou.')];
TIPOS_DOC.combinados = {
  nome: 'Combinados da turma', auto: false,
  cab: [['professora', 'Professora ou professor'], ['representantes', 'Representantes de sala']],
  ajuda: 'Escreva no tom da turma: amigável, claro e, quando der, com humor. Cada ajuste no ano pode virar uma nova versão (“Registrar versão”), com data e o que mudou.',
  gerar: d => { const t = IX.turmas[d.turmaId]; return { titulo: 'Combinados do ' + t.serie + 'º ano ' + (t.letra || '') + ' · ' + t.ano, cab: { professora: t.professora || '', representantes: '' }, secoes: COMBINADOS_MODELO(t) }; },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}; return [profTit(t) + ': ' + ((d.cab || {}).professora || ''), 'Ano: ' + (t.ano || '')].concat((d.cab || {}).representantes ? ['Representantes de sala: ' + d.cab.representantes, ''] : []); }
};
const combinadosDe = t => docsDe('combinados', d => d.turmaId === t.id)[0];
T.combinados = () => {
  const t = turmaAtual(); if (!t) return '<h1>Combinados da turma</h1>' + vazio('Cadastre uma turma primeiro.');
  const d = combinadosDe(t); if (d) return editorDoc(d, { voltar: false });
  const ant = cadeiaTurmas(t).slice(0, -1).reverse().map(combinadosDe).find(Boolean);
  return '<h1>Combinados da turma</h1><p>O guia da turma com as famílias: representantes, comunicação, encontros, caixinha e os pequenos acordos que deixam o dia a dia leve. Completa as regras da escola, sem passar por cima delas.</p><div class="cartao"><div class="linha">' + (ant ? '<button class="btn pri" data-a="combRepetir" data-id="' + ant.id + '">Repetir os combinados de ' + e(String((IX.turmas[ant.turmaId] || {}).ano || 'antes')) + '</button><button class="btn" data-a="combNovo">Começar com o modelo da Tecelã</button>' : '<button class="btn pri" data-a="combNovo">Começar com o modelo da Tecelã</button>') + '</div><p class="dica">O modelo já vem escrito em tom amigável, com lacunas para completar. Tudo é editável.</p></div>';
};
A.combNovo = async () => { const t = turmaAtual(); await criarDoc('combinados', { turmaId: t.id }); render(); aviso('Combinados criados a partir do modelo.'); };
A.combRepetir = async d => { const t = turmaAtual(), o = IX.documentos[d.id]; const n = await salvar('documentos', { tipo: 'combinados', turmaId: t.id, titulo: 'Combinados do ' + t.serie + 'º ano ' + (t.letra || '') + ' · ' + t.ano, cab: Object.assign(clone(o.cab || {}), { professora: t.professora || (o.cab || {}).professora || '' }), secoes: clone(o.secoes), versoes: [], origemId: o.id }); render(); aviso('Combinados do ano anterior repetidos. Ajuste o que mudou.'); return n; };

/* ---------- PEI ---------- */
const peiDe = (t, aid) => docsDe('pei', d => d.turmaId === t.id && d.alunoId === aid)[0];
function valoresPerfil(p) {
  if (!p) return []; const r = [];
  PERFIL.forEach(bl => bl.campos.forEach(([k, rot, tipo, ops]) => { let v = (p.campos || {})[k]; if (tipo === 's') v = (opsDe(ops, v).find(o => o[0] === v) || ['', ''])[1]; if (tipo === 'm') v = ops.filter(o => v && v[slug(o)]).join(', '); if (v) r.push(rot.replace(/:.*$/, '') + ': ' + v); }));
  return r;
}
function peiSecoes(t, a) {
  const p = ultimoPerfil(a.id), pts = (a.atencao || []).filter(x => x.situacao !== 'resolvido'), m = idadeEm(a.nasc, refTurma(t));
  const per = periodosDaTurma(t).slice().reverse().find(x => temMarcas(obsRec(t.id, a.id, x.id))), r = per && obsRec(t.id, a.id, per.id), g = k => r ? itensLista('itensObs').filter(i => r.marcas[i.chave] === k).map(i => i.nome) : [];
  const comps = {}; D.curriculo.filter(c => c.serie === t.serie).sort((x, y) => (x.ordem || 0) - (y.ordem || 0)).forEach(c => (comps[c.componente] = comps[c.componente] || []).push(c.titulo + (c.conteudos ? ': ' + String(c.conteudos).split(/[.;\n]/)[0] : '')));
  const refs = reforcosDoAluno(t, a.id);
  return [
    secTexto('quem', 'Quem é ' + primeiroNome(a), [primeiroNome(a) + ' tem ' + idadeTxt(m) + ' (' + setenio(m) + ').'].concat(p ? ['Do perfil (revisão de ' + dataBR(p.data) + '):'].concat(valoresPerfil(p).slice(0, 14).map(x => '- ' + x)) : ['(Ainda não há revisão do perfil.)']).join('\n')),
    secTexto('atencao', 'Necessidades e acompanhamentos', [a.nee ? '- Necessidades educacionais especiais.' : '', a.acomp ? '- Acompanhamento externo (terapias, especialistas).' : ''].concat(pts.map(x => '- ' + nomeItem('atencao', x.tipo) + ': ' + (x.descricao || '') + (x.desde ? ' (desde ' + dataBR(x.desde) + ')' : ''))).filter(Boolean).join('\n') || '(Nenhum ponto de atenção registrado.)'),
    secTexto('obs', 'O que a observação mostra', per ? ['Observação do ' + per.rot + ':'].concat(g('a').length ? ['Pede atenção:'].concat(g('a').map(x => '- ' + x)) : []).concat(g('d').length ? ['Em desenvolvimento:'].concat(g('d').map(x => '- ' + x)) : []).concat(g('c').length ? ['Consolidado: ' + g('c').slice(0, 8).join('; ') + (g('c').length > 8 ? '…' : '') + '.'] : []).join('\n') : '(Ainda não há observação do período.)'),
    secTabela('curriculo', 'Conteúdo curricular planejado', ['Componente', 'Para a classe', 'Para ' + primeiroNome(a)], Object.entries(comps).map(([k, xs]) => [nomeItem('componentes', k), xs.join('\n'), 'Acompanha o conteúdo da classe.'])),
    secTexto('adaptacoes', 'Recursos didáticos e adaptações', '- Ambiente e ritmo: \n- Quantidade e tipo de atividades: \n- Momentos de autorregulação: \n- Recursos que ajudam: \n- Como pedir ajuda e o que funciona: '),
    secTexto('objetivos', 'Objetivos para o período', '- \n- \n- '),
    secTexto('reforco', 'Reforço escolar', refs.length ? refs.map(x => '- ' + rotRef(x) + ': ' + (x.datas || []).map(d => dataBR(d).slice(0, 5)).join(', ') + ' (' + nomeSit(x.situacao).toLowerCase() + (resumoEnc(x) ? '; ' + resumoEnc(x) : '') + ')').join('\n') : '(Nenhum reforço registrado.)'),
    secTexto('revisao', 'Acompanhamento e revisão', '- Revisar este plano em: \n- Quem acompanha: \n- Como a família participa: \n- Como avaliamos o que funcionou: ')];
}
TIPOS_DOC.pei = {
  nome: 'Plano Educacional Individualizado',
  cab: [['tutores', 'PC ou tutores'], ['componentes', 'Componentes'], ['professores', 'Professores'], ['vigencia', 'Vigência']],
  ajuda: 'Documento sigiloso: fica só neste aparelho e no seu arquivo, e só sai quando você exporta. As partes com ↻ vêm do que já está registrado (perfil, pontos de atenção, observação, currículo e reforço) e podem ser trazidas de novo a qualquer momento.',
  gerar: d => { const t = IX.turmas[d.turmaId], a = IX.alunos[d.alunoId]; return { titulo: 'PLANO EDUCACIONAL INDIVIDUALIZADO (' + t.ano + ')', cab: { tutores: t.professora || '', componentes: 'Língua Portuguesa / Matemática / Arte / História / Geografia / Ciências', professores: '', vigencia: t.ano }, secoes: peiSecoes(t, a) }; },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}, a = IX.alunos[d.alunoId] || {}, c = d.cab || {}; return ['Nome: ' + (a.nome || ''), 'Ano/Classe: ' + t.serie + 'º ' + (t.letra || ''), 'PC/Tutores: ' + (c.tutores || ''), 'Vigência: ' + (c.vigencia || ''), 'Componentes: ' + (c.componentes || ''), 'Professores: ' + (c.professores || '')]; }
};
const peiAtivo = (t, aid) => { const d = t && peiDe(t, aid); return d || null; };
const adaptacoesPei = d => { const s = (d.secoes || []).find(x => x.k === 'adaptacoes'); return s ? String(s.txt || '').split('\n').map(l => l.replace(/^[-•*]\s*/, '').trim()).filter(l => l && !/:\s*$/.test(l)).join(' · ') : ''; };
T.pei = () => {
  const t = turmaAtual(); if (!t) return '<h1>PEI</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && IX.documentos[UI.sub]) return editorDoc(IX.documentos[UI.sub], { voltar: 'PEI', alerta: '<p class="alerta" style="background:var(--violC)">Documento sigiloso. Ele só sai do app quando você exporta.</p>' });
  const al = alunosDaTurma(t.id); if (!al.length) return '<h1>Plano Educacional Individualizado</h1>' + vazio('Cadastre os alunos da turma.');
  return '<h1>Plano Educacional Individualizado (PEI)</h1><p>Para a criança que precisa de adaptações. O rascunho já traz o perfil, os pontos de atenção, a observação do período, o currículo da série e o reforço. Depois de criado, as adaptações aparecem como lembrete no boletim, no plano de época e no pré-conselho.</p><div class="cartao rolagem"><table class="tabela"><tr><th>Criança</th><th>Sinais</th><th>PEI de ' + t.ano + '</th><th></th></tr>' + al.map(a => { const d = peiDe(t, a.id), ult = d && (d.versoes || []).slice(-1)[0]; return '<tr><td><b>' + e(a.nome) + '</b></td><td>' + [a.nee ? '<span class="flag az">NEE</span>' : '', a.acomp ? '<span class="flag az">acompanhamento</span>' : '', (a.atencao || []).filter(x => x.situacao !== 'resolvido').length ? '<span class="flag vi">pontos de atenção</span>' : ''].join(' ') + '</td><td>' + (d ? (ult ? 'versão ' + ult.n + ' (' + dataBR(ult.data.slice(0, 10)) + ')' : 'rascunho') : '<span class="dica">—</span>') + '</td><td>' + (d ? '<button class="btn peq" data-a="abrirDocSub" data-id="' + d.id + '">Abrir</button>' : '<button class="btn peq" data-a="peiNovo" data-al="' + a.id + '">Criar</button>') + '</td></tr>'; }).join('') + '</table></div>';
};
A.abrirDocSub = d => { UI.sub = d.id; render(); window.scrollTo(0, 0); };
A.peiNovo = async d => { const t = turmaAtual(), x = await criarDoc('pei', { turmaId: t.id, alunoId: d.al }); UI.sub = x.id; render(); window.scrollTo(0, 0); aviso('Rascunho do PEI criado com o que já está registrado.'); };
A.abrirPei = d => { UI.tela = 'pei'; UI.sub = d.id; render(); window.scrollTo(0, 0); };
