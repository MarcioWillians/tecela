/* ==========================================================================
   Tecelã — Repertório da turma: versos, canções, poemas, histórias contadas,
   brincadeiras de roda e jogos rítmicos, com as datas em que foram usados e a
   época a que se ligam. O repertório acompanha a turma de ano em ano, para
   não repetir e para montar a parte rítmica de cada época.
   ========================================================================== */
'use strict';
const TIPOS_REP = [['verso', 'Verso'], ['cancao', 'Canção'], ['poema', 'Poema'], ['historia', 'História contada'], ['roda', 'Brincadeira de roda'], ['ritmo', 'Jogo rítmico'], ['outro', 'Outro']];
const nomeTipoRep = k => (TIPOS_REP.find(x => x[0] === k) || TIPOS_REP[6])[1];
/* o repertório da turma inclui o dos anos anteriores da mesma turma */
const repDaTurma = t => { const ids = new Set(cadeiaTurmas(t).map(x => x.id)); return D.repertorio.filter(r => ids.has(r.turmaId)); };
const ultimoUso = r => (r.usos || []).slice().sort().pop() || '';
function secRepertorio(t, c) {
  const xs = repDaTurma(t).filter(r => r.epocaId === c.id || r.rotina).sort((a, b) => (b.rotina ? 1 : 0) - (a.rotina ? 1 : 0) || a.titulo.localeCompare(b.titulo));
  return secTexto('repertorio', 'Repertório da época', xs.length ? xs.map(r => '- ' + nomeTipoRep(r.tipo) + ': ' + r.titulo + (r.rotina ? ' (rotina diária)' : '') + (r.autor ? ' — ' + r.autor : '')).join('\n') : '- (Ligue versos, canções e histórias a esta época na tela Repertório.)');
}
T.repert = () => {
  const t = turmaAtual(); if (!t) return '<h1>Repertório</h1>' + vazio('Cadastre uma turma primeiro.');
  const f = UI.filtro, ft = f.repTipo || '', fe = f.repEp || '', q = norm(f.repBusca || '');
  const eps = D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  const xs = repDaTurma(t).filter(r => (!ft || r.tipo === ft) && (!fe || (fe === 'rotina' ? r.rotina : r.epocaId === fe)) && (!q || norm(r.titulo + ' ' + (r.texto || '') + ' ' + (r.autor || '')).includes(q))).sort((a, b) => ultimoUso(b).localeCompare(ultimoUso(a)) || a.titulo.localeCompare(b.titulo));
  let h = '<h1>Repertório da turma</h1><p>Versos, canções, poemas, histórias contadas e brincadeiras, com as datas em que foram usados. O repertório acompanha a turma de ano em ano: assim fica fácil não repetir e montar a parte rítmica de cada época. O que é da rotina diária vai também para o roteiro do professor substituto.</p>' +
    '<div class="linha"><button class="btn pri" data-a="novoRep">+ Item</button><select data-c="repTipo"><option value="">Todos os tipos</option>' + TIPOS_REP.map(([k, n]) => '<option value="' + k + '"' + (k === ft ? ' selected' : '') + '>' + n + '</option>').join('') + '</select><select data-c="repEp"><option value="">Todas as épocas</option><option value="rotina"' + (fe === 'rotina' ? ' selected' : '') + '>Rotina diária</option>' + eps.map(c => '<option value="' + c.id + '"' + (c.id === fe ? ' selected' : '') + '>' + e(c.titulo) + '</option>').join('') + '</select><input type="search" data-c="repBusca" placeholder="Procurar no repertório" value="' + e(f.repBusca || '') + '"><button class="btn" data-a="exportarRep">Imprimir ou exportar</button></div>';
  if (!xs.length) return h + vazio(repDaTurma(t).length ? 'Nada com esses filtros.' : 'O repertório está vazio. Comece pelos versos e canções da rotina da manhã.');
  return h + '<div class="cartao rolagem"><table class="tabela"><tr><th>Título</th><th>Tipo</th><th>Época</th><th>Usado</th><th></th></tr>' + xs.map(r => { const ep = IX.curriculo[r.epocaId], tu = IX.turmas[r.turmaId]; return '<tr><td><b>' + e(r.titulo) + '</b>' + (r.autor ? '<br><span class="dica">' + e(r.autor) + '</span>' : '') + (r.turmaId !== t.id && tu ? '<br><span class="dica">do ' + tu.serie + 'º ano (' + tu.ano + ')</span>' : '') + '</td><td>' + nomeTipoRep(r.tipo) + (r.rotina ? ' <span class="etq fin">rotina</span>' : '') + '</td><td>' + (ep ? e(ep.titulo) : '<span class="dica">—</span>') + '</td><td>' + ((r.usos || []).length ? (r.usos.length + ' vez' + (r.usos.length > 1 ? 'es' : '') + '<br><span class="dica">última: ' + dataBR(ultimoUso(r)) + '</span>') : '<span class="dica">ainda não</span>') + '</td><td style="white-space:nowrap"><button class="btn peq" data-a="repUsei" data-id="' + r.id + '" title="Registrar que foi usado hoje">Usei hoje</button> <button class="btn peq" data-a="editarRep" data-id="' + r.id + '">Abrir</button> <button class="icone-btn" data-a="apagarRep" data-id="' + r.id + '" title="Excluir">✕</button></td></tr>'; }).join('') + '</table></div>';
};
C_.repTipo = el => { UI.filtro.repTipo = el.value; render(); };
C_.repEp = el => { UI.filtro.repEp = el.value; render(); };
C_.repBusca = el => { UI.filtro.repBusca = el.value; render(); const i = $('[data-c=repBusca]'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } };
async function dialogoRep(r) {
  const t = turmaAtual(), eps = D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
  const v = await dlg({ titulo: r.id ? r.titulo : 'Novo item do repertório', largo: true, ok: 'Salvar', corpo: '<div class="duas">' + campo('Título', '<input name="titulo" value="' + e(r.titulo || '') + '">') + campo('Tipo', '<select name="tipo">' + TIPOS_REP.map(([k, n]) => '<option value="' + k + '"' + (k === (r.tipo || 'verso') ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + '</div><div class="duas">' + campo('Autor ou fonte', '<input name="autor" value="' + e(r.autor || '') + '">') + campo('Época', '<select name="epocaId"><option value="">—</option>' + eps.map(c => '<option value="' + c.id + '"' + (c.id === r.epocaId ? ' selected' : '') + '>' + e(c.titulo) + '</option>').join('') + '</select>') + '</div>' +
    '<label class="ck"><input type="checkbox" name="rotina"' + (r.rotina ? ' checked' : '') + '> <span>Faz parte da rotina diária (entra no roteiro do professor substituto)</span></label>' + campo('Texto, letra ou resumo', '<textarea name="texto" style="min-height:9rem">' + e(r.texto || '') + '</textarea>', 'Para obras protegidas por direitos autorais, prefira anotar o título, a fonte e um resumo.') + campo('Observações', '<textarea name="obs">' + e(r.obs || '') + '</textarea>') +
    campo('Datas em que foi usado', '<input name="usos" value="' + e((r.usos || []).map(dataBR).join(', ')) + '" placeholder="ex.: 05/11/2026, 12/11/2026">'), validar: x => !x.titulo.trim() ? 'Escreva o título.' : null });
  if (!v) return null;
  const usos = v.usos.split(/[,;]+/).map(s => { const m = s.trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/); return m ? m[3] + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0') : null; }).filter(Boolean).sort();
  return Object.assign(r, { turmaId: r.turmaId || t.id, titulo: v.titulo.trim(), tipo: v.tipo, autor: v.autor.trim(), epocaId: v.epocaId || null, rotina: !!v.rotina, texto: v.texto.trim(), obs: v.obs.trim(), usos });
}
A.novoRep = async () => { const r = await dialogoRep({ epocaId: UI.filtro.repEp && UI.filtro.repEp !== 'rotina' ? UI.filtro.repEp : null, rotina: UI.filtro.repEp === 'rotina', tipo: UI.filtro.repTipo || 'verso' }); if (!r) return; await salvar('repertorio', r); render(); aviso('Item incluído no repertório.'); };
A.editarRep = async d => { const r = IX.repertorio[d.id]; if (!r) return; const x = await dialogoRep(clone(r)); if (!x) return; await salvar('repertorio', x); render(); aviso('Repertório salvo.'); };
A.apagarRep = d => apagarComDesfazer('repertorio', d.id, 'Item excluído do repertório.');
A.repUsei = async d => { const r = IX.repertorio[d.id], h = hojeISO(); r.usos = r.usos || []; if (r.usos.includes(h)) return aviso('Já registrado hoje.'); r.usos.push(h); r.usos.sort(); await salvar('repertorio', r); render(); aviso('“' + r.titulo + '” usado hoje.'); };
A.exportarRep = () => {
  const t = turmaAtual(), xs = repDaTurma(t), b = [{ t: 'p', txt: rotuloTurma(t) + ' · ' + xs.length + ' itens' }];
  TIPOS_REP.forEach(([k, n]) => { const ys = xs.filter(r => r.tipo === k).sort((a, b2) => a.titulo.localeCompare(b2.titulo)); if (!ys.length) return; b.push({ t: 'h', txt: n }, { t: 'tabela', cab: ['Título', 'Autor ou fonte', 'Época', 'Usado em'], linhas: ys.map(r => [r.titulo + (r.rotina ? ' (rotina)' : ''), r.autor || '', (IX.curriculo[r.epocaId] || {}).titulo || '', (r.usos || []).map(x => dataBR(x).slice(0, 5) + '/' + x.slice(2, 4)).join(', ')]) }); });
  saidaDocumento(docBase('Repertorio_' + t.serie + 'ano_' + t.ano, 'Repertório — ' + rotuloTurma(t), b), { assunto: 'Repertório da turma' });
};
