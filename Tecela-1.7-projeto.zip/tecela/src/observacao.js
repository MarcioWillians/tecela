/* ==========================================================================
   Tecelã — Observação do período: roteiro de observação sistemática
   (a partir da planilha "Observações para boletim" da escola), marcado por
   toque: ● consolidado · ◐ em desenvolvimento · ○ pede atenção · (em branco)
   não observado. Alimenta o boletim (rascunhos), o perfil (sugestões),
   os relatórios e o conselho de classe.
   ========================================================================== */
'use strict';
const ROTEIRO = [
  ['pensar', 'Capacidades do pensar', 'pensar', '', ['Memória e recontar: se expressa sozinho ou precisa de ajuda; cria ou repete modelos', 'Fixação e evocação; imitação (lembrar com o corpo); relação esquecer/lembrar', 'Processos temporais: uso do tempo disponível, noção de tempo', 'Estrutura do pensamento: ordenação, definição, clareza das ideias', 'Vocabulário', 'Percepção de ideias alheias', 'Linguagem: recontar oral e escrito', 'Concentração e atenção: facilidade para “ligar e desligar”', 'Capacidade de estudar e apreensão', 'Inteligências: lógico-matemática, linguística, intrapessoal, interpessoal, pictórica, musical, corporal, espacial', 'Capacidade de realização', 'Inter-relação com os conhecimentos adquiridos', 'Julgar conscientemente', 'Relação falar/ouvir', 'Rendimento']],
  ['sentir', 'Movimentos do sentir', 'sentir', '', ['Interesse e vínculo com o conteúdo', 'Imitação', 'Disposição durante as aulas', 'Facilidade para o novo', 'Rivalidades', 'Matérias preferidas', 'Relação com o professor', 'Expressão no desenho, aquarela, trabalhos manuais e formas', 'Intensidade de afeto', 'Equilíbrio das emoções', 'Capacidade de se superar', 'Criatividade', 'Como demonstra afeto', 'Como lida com as frustrações', 'Relação com a alegria e a tristeza', 'Relação com a música (respiração)', 'Esforço para melhorar onde não há dificuldade']],
  ['querer', 'Atitudes do querer (vontade)', 'querer', 'atitudes', ['Como age: impulsiva, pesada, perseverante, oscilante', 'Controla os impulsos', 'Supera derrotas e fracassos', 'Vontade voltada para processos interiores', 'Ação organizada', 'Vontade voltada para muitos interesses', 'Agitação e hiperatividade', 'Vontade para sequência e repetição', 'Concentração', 'Age prontamente, sem precisar de ajuda', 'Organização espaço-tempo', 'Mobiliza-se para realizar seus projetos', 'Executa as tarefas propostas com empenho', 'Esforça-se para superar as dificuldades', ['Feitio dos cadernos: letra, desenhos, organização espacial', 'conteudo'], ['Cópias: perfeição, trocas, capricho, tempo', 'portugues'], 'Coordenação motora fina e grossa', 'Execução e qualidade', ['Desenhos: maturidade, pressão e cor', 'desenho'], ['Desenho de forma: equilíbrio, orientação, fluidez, destreza', 'formas'], ['Aquarela: prazer, tempo, equilíbrio de cores, organização do material', 'aquarela']]],
  ['trabalho', 'Trabalho e estudo', 'aprendizagem', 'atitudes', ['Usa o tempo com sabedoria', 'Prepara seu trabalho com capricho', 'Trabalha com independência', 'Segue as instruções', 'Termina os trabalhos iniciados', 'Empenha-se em melhorar', 'Consegue silenciar para trabalhar', 'Concentração', 'Memorização', 'Organização espaço-temporal', 'Postura corporal', ['Tarefas de casa: organização e confecção', 'licao'], ['Desenho de forma: postura, material, pega do giz, compreensão da forma', 'formas']]],
  ['postura', 'Postura individual', 'social', 'atitudes', ['Postura perante a vida', 'Senso de responsabilidade', 'Respeito no geral', 'Relacionamento com o meio ambiente', 'Desenvolvimento da própria responsabilidade']],
  ['habitos', 'Hábitos gerais', 'social', 'atitudes', ['Interesse', 'Pontualidade e assiduidade escolar', 'Bons hábitos']],
  ['social', 'Atitudes sociais', 'social', 'atitudes', ['Aceita responsabilidades', 'Trabalha e integra-se bem com o grupo', 'Respeita o direito dos outros', 'Pratica o autocontrole', 'Respeita os limites', 'É cuidadoso com bens e materiais', 'É cortês e respeitoso com os professores', 'É colaborador', 'É prestativo', 'Não atrapalha a concentração alheia', 'Cuida das instalações e dos bens comuns', 'Atitudes em excursões, apresentações e festas', 'Resolve sozinho; integra-se na responsabilidade social', 'Atua positivamente perante o grupo', ['Liderança e submissão', 'pausa']]],
  ['mat', 'Matemática', 'aprendizagem', 'matematica', ['Resolve problemas do dia a dia com o que aprendeu', 'Faz bem os cálculos mentais', 'É assertivo']],
  ['port', 'Português (língua materna)', 'aprendizagem', 'portugues', ['Lê bem silenciosamente', 'Lê bem oralmente', 'Lê livros com independência', 'Compreende e interpreta o que é lido', 'Escreve com capricho e em letra legível', 'Expressa suas ideias verbalmente com clareza', 'Esforça-se para corrigir os erros de escrita e fala', 'Reconta histórias com propriedade']],
  ['artes', 'Artes, música e trabalhos manuais', 'sentir', 'aquarela', ['Aquarela: cuidado com o material, organização, atenção à proposta, capricho', 'Expressa as próprias ideias na arte', ['Usa materiais, ferramentas e instrumentos apropriados', 'trabalhos'], ['Aprecia experiências musicais', 'flauta'], ['Tem boa resposta rítmica', 'ritmica'], ['Tem facilidade com a flauta', 'flauta'], ['Apresenta habilidades manuais', 'trabalhos'], ['Desenvolve trabalhos com autonomia, limpeza, qualidade e pontualidade', 'trabalhos'], 'Adapta-se bem ao material oferecido', 'Expressa-se com facilidade através dos materiais', 'Respeita o coletivo']],
  ['jogos', 'Jogos', 'social', 'jogos', ['Assume papéis durante as atividades', 'Tem atenção na aula e nas atividades', 'Compreende e usa as regras propostas', 'Habilidades básicas: orientação espacial, coordenação, preensão, lateralidade', 'Atua e convive bem no grupo']],
  ['epocas', 'Rendimento das épocas', 'aprendizagem', 'conteudo', ['Interesse', 'Participação', 'Contribuição', 'Conclusão das tarefas e trabalhos propostos', 'Alcançou as metas da época', 'Prazer em ouvir e atuar']],
  ['conclusao', 'Conclusão do ano', 'aprendizagem', 'conclusao', ['Amadureceu ao longo do ano', 'Está apto a cursar o ano seguinte', 'Meta para o desenvolvimento no ano seguinte (escreva na nota)']]
];
LISTAS.blocosObs = { nome: 'Observação: blocos', dica: 'Cada bloco do roteiro de observação se liga a um critério do perfil e a uma seção do boletim.', extras: ['criterio', 'secao'], padrao: ROTEIRO.map(([k, n, c, s]) => [k, n, { criterio: c, secao: s }]) };
LISTAS.itensObs = { nome: 'Observação: itens', dica: 'Os itens do roteiro. A seção do boletim é opcional: em branco, vale a do bloco.', extras: ['bloco', 'secao'], padrao: ROTEIRO.flatMap(([k, , , , its]) => its.map((it, i) => { const [t, s] = Array.isArray(it) ? it : [it, '']; return [k + '-' + (i + 1), t, { bloco: k, secao: s }]; })) };
LISTAS.frases = { nome: 'Frases prontas (anotações)', dica: 'Frases que você escreve muitas vezes. Elas aparecem na lista “Frases prontas” do botão ✎ Anotar e da tela Anotações: escolhida a frase, ela entra no texto da anotação, e você completa. Use {nome} para o nome da criança e {o/a}, {ele/ela}, {dele/dela} para o gênero.', padrao: [['f1', '{nome} participou com alegria e atenção.'], ['f2', '{nome} terminou o trabalho com capricho.'], ['f3', '{nome} precisou de ajuda para começar a tarefa.'], ['f4', '{nome} ajudou um colega sem que ninguém pedisse.'], ['f5', '{nome} esqueceu o material.'], ['f6', '{nome} chegou cansad{o/a} e com pouca disposição.']] };
const dotObs = k => k ? '<i class="dot ' + k + '"></i>' : '<i class="dot nada"></i>';
const NIVEIS_OBS = { c: ['●', 'consolidado', '#2F6AA8'], d: ['◐', 'em desenvolvimento', '#C99A00'], a: ['○', 'pede atenção', '#C8452F'] };
const blocosObs = () => itensLista('blocosObs');
const itensDoBloco = k => itensLista('itensObs').filter(i => i.bloco === k);
const secaoDoItem = i => i.secao || ((itemLista('blocosObs', i.bloco) || {}).secao) || '';

/* ---------- períodos ---------- */
const PER_OBS = { anual: [['A', 'ano letivo', '01-01', '12-31']], semestral: [['S1', '1º semestre', '01-01', '06-30'], ['S2', '2º semestre', '07-01', '12-31']], trimestral: [['T1', '1º trimestre', '01-01', '04-30'], ['T2', '2º trimestre', '05-01', '08-31'], ['T3', '3º trimestre', '09-01', '12-31']], bimestral: [['B1', '1º bimestre', '01-01', '04-15'], ['B2', '2º bimestre', '04-16', '06-30'], ['B3', '3º bimestre', '07-01', '09-30'], ['B4', '4º bimestre', '10-01', '12-31']] };
const periodosObs = ano => (PER_OBS[CFG.prefs.periodoObs] || PER_OBS.semestral).map(([k, r, i, f]) => ({ id: ano + '-' + k, rot: r.replace(/^./, m => m.toUpperCase()) + ' de ' + ano, curto: r, ini: ano + '-' + i, fim: ano + '-' + f }));
function periodoAtual(t) { const ps = periodosObs(t.ano), h = hojeISO(); return ps.find(p => h >= p.ini && h <= p.fim) || (h < ps[0].ini ? ps[0] : ps[ps.length - 1]); }
/* qualquer período guardado, mesmo de outra divisão (ex.: um semestre depois de mudar para bimestral) */
function periodoPorId(id) { const [ano, k] = String(id).split('-'); for (const xs of Object.values(PER_OBS)) { const x = xs.find(y => y[0] === k); if (x) return { id, rot: x[1].replace(/^./, m => m.toUpperCase()) + ' de ' + ano, curto: x[1], ini: ano + '-' + x[2], fim: ano + '-' + x[3] }; } return null; }
const rotPeriodo = id => (periodoPorId(id) || { rot: id }).rot;
/* períodos da divisão atual + os de outras divisões que já têm registros nesta turma */
function periodosDaTurma(t) { const ps = periodosObs(t.ano), ids = new Set(ps.map(p => p.id)); D.observacoes.concat(D.conselhos).filter(r => r.turmaId === t.id && !ids.has(r.periodo) && (r.marcas ? temMarcas(r) : true)).forEach(r => { const p = periodoPorId(r.periodo); if (p) { ids.add(p.id); ps.push(Object.assign(p, { rot: p.rot + ' (outra divisão)' })); } }); return ps.sort((a, b) => a.ini.localeCompare(b.ini) || a.fim.localeCompare(b.fim)); }
const periodoEscolhido = (t, chave) => periodosDaTurma(t).find(p => p.id === UI.filtro[chave]) || periodoAtual(t);
const obsId = (tid, aid, per) => 'obs:' + tid + ':' + aid + ':' + per;
function obsRec(tid, aid, per, criar) { const id = obsId(tid, aid, per); let r = IX.observacoes[id]; if (!r && criar) { r = { id, turmaId: tid, alunoId: aid, periodo: per, marcas: {}, notas: {} }; D.observacoes.push(r); IX.observacoes[r.id] = r; } return r || null; }
const temMarcas = r => r && (Object.keys(r.marcas || {}).length || Object.values(r.notas || {}).some(Boolean));
function ultimaObs(tid, aid, ate) { return D.observacoes.filter(r => r.alunoId === aid && (!tid || r.turmaId === tid) && temMarcas(r) && (!ate || r.periodo <= ate)).sort((a, b) => b.periodo.localeCompare(a.periodo))[0] || null; }
function contarBloco(r, bk) { const n = { c: 0, d: 0, a: 0 }; itensDoBloco(bk).forEach(i => { const v = (r && r.marcas || {})[i.chave]; if (v) n[v]++; }); n.total = n.c + n.d + n.a; return n; }

/* ---------- tela ---------- */
T.obs = () => {
  const t = turmaAtual(); if (!t) return '<h1>Observação do período</h1>' + vazio('Cadastre uma turma primeiro.');
  const al = alunosDaTurma(t.id); if (!al.length) return '<h1>Observação do período</h1>' + vazio('Cadastre os alunos da turma.');
  const ps = periodosDaTurma(t), per = periodoEscolhido(t, 'obsPer'), modo = UI.aba.obs || 'crianca';
  let h = '<h1>Observação do período</h1><div class="linha"><select data-c="obsPer">' + ps.map(p => '<option value="' + p.id + '"' + (p.id === per.id ? ' selected' : '') + '>' + p.rot + '</option>').join('') + '</select><button class="btn peq' + (modo === 'crianca' ? ' pri' : '') + '" data-a="aba" data-v="crianca">Uma criança</button><button class="btn peq' + (modo === 'turma' ? ' pri' : '') + '" data-a="aba" data-v="turma">A turma toda</button><span class="espaco"></span><span class="dica">' + Object.entries(NIVEIS_OBS).map(([k, [, r]]) => dotObs(k) + ' ' + r).join(' · ') + ' · em branco = não observado</span></div>';
  h += '<p class="dica">Marque só o que se destaca: o que fica em branco não entra em nenhum relatório. Os itens se ajustam em Cadastros → Observação. Períodos: ' + ({ anual: 'anual', semestral: 'semestrais', trimestral: 'trimestrais', bimestral: 'bimestrais' }[CFG.prefs.periodoObs] || 'semestrais') + ' (ajuste em Ajustes).</p>';
  return h + (modo === 'turma' ? obsTurma(t, al, per) : obsCrianca(t, al, per));
};
C_.obsPer = el => { UI.filtro.obsPer = el.value; render(); };
C_.obsAluno = el => { UI.filtro.obsAluno = el.value; render(); };
function botoesNivel(aid, per, ik, v) { return Object.entries(NIVEIS_OBS).map(([k, [s, r, c]]) => '<button type="button" class="nv' + (v === k ? ' on' : '') + '" style="--c:' + c + '" data-a="obsMarca" data-al="' + aid + '" data-per="' + per + '" data-it="' + ik + '" data-v="' + k + '" title="' + r + '">' + dotObs(k) + '</button>').join(''); }
function obsCrianca(t, al, per) {
  const a = al.find(x => x.id === UI.filtro.obsAluno) || al[0], idx = al.indexOf(a), r = obsRec(t.id, a.id, per.id), tot = itensLista('itensObs').length, feitos = Object.keys((r || {}).marcas || {}).length;
  let h = '<div class="cartao"><div class="linha"><button class="btn" data-a="obsNav" data-d="-1"' + (idx ? '' : ' disabled') + '>‹</button><select data-c="obsAluno">' + al.map(x => '<option value="' + x.id + '"' + (x.id === a.id ? ' selected' : '') + '>' + e(x.nome) + '</option>').join('') + '</select><button class="btn" data-a="obsNav" data-d="1"' + (idx < al.length - 1 ? '' : ' disabled') + '>›</button><span class="dica" id="obsProg">' + feitos + ' de ' + tot + ' itens marcados</span><span class="espaco"></span><button class="btn peq" data-a="obsCopiar" data-al="' + a.id + '" data-per="' + per.id + '">Copiar do período anterior</button><button class="btn peq" data-a="obsLimpar" data-al="' + a.id + '" data-per="' + per.id + '">Limpar</button></div></div>';
  blocosObs().forEach(b => {
    const its = itensDoBloco(b.chave); if (!its.length) return;
    h += '<details class="cartao"' + (contarBloco(r, b.chave).total || b === blocosObs()[0] ? ' open' : '') + '><summary style="cursor:pointer"><b>' + e(b.nome) + '</b> <span class="dica">' + resumoTxt(contarBloco(r, b.chave)) + '</span></summary><table class="tabela obs">' + its.map(i => { const v = (r && r.marcas || {})[i.chave], n = (r && r.notas || {})[i.chave] || ''; return '<tr><td>' + e(i.nome) + '<div class="obs-nota' + (n ? '' : ' oculto') + '"><input type="text" data-c="obsNota" data-al="' + a.id + '" data-per="' + per.id + '" data-it="' + i.chave + '" value="' + e(n) + '" placeholder="Nota (opcional)"></div></td><td class="nvs">' + botoesNivel(a.id, per.id, i.chave, v) + '<button type="button" class="nv nota" data-a="obsNotaAbrir" title="Nota">✎</button></td></tr>'; }).join('') + '</table></details>';
  });
  return h;
}
const resumoTxt = n => n.total ? Object.entries(NIVEIS_OBS).filter(([k]) => n[k]).map(([k]) => dotObs(k) + ' ' + n[k]).join(' &nbsp;') : 'nada marcado';
function obsTurma(t, al, per) {
  let h = '<div class="cartao rolagem" style="max-height:78vh;padding:0"><table class="tabela obs-grade"><thead><tr><th>Item</th>' + al.map(a => '<th title="' + e(a.nome) + '">' + e(primeiroNome(a)) + '</th>').join('') + '</tr></thead><tbody>';
  blocosObs().forEach(b => { const its = itensDoBloco(b.chave); if (!its.length) return; h += '<tr><td colspan="' + (al.length + 1) + '" style="background:var(--papel);font-weight:700">' + e(b.nome) + '</td></tr>' + its.map(i => '<tr><td><a href="#" data-a="obsTodos" data-it="' + i.chave + '" data-per="' + per.id + '" title="Aplicar a toda a turma">' + e(i.nome) + '</a></td>' + al.map(a => { const v = ((obsRec(t.id, a.id, per.id) || {}).marcas || {})[i.chave]; return '<td class="cel" data-a="obsCiclo" data-al="' + a.id + '" data-per="' + per.id + '" data-it="' + i.chave + '" style="color:' + (v ? NIVEIS_OBS[v][2] : '') + '">' + dotObs(v) + '</td>'; }).join('') + '</tr>').join(''); });
  return h + '</tbody></table></div><p class="dica">Toque numa célula para mudar: em branco → consolidado → em desenvolvimento → pede atenção → em branco. Toque no nome do item para aplicar o mesmo nível a toda a turma.</p>';
}
function marcar(aid, per, ik, v) { const t = turmaAtual(), r = obsRec(t.id, aid, per, true); if (v) r.marcas[ik] = v; else delete r.marcas[ik]; salvarDepois('observacoes', r); return r; }
A.obsMarca = (d, el) => { const r = obsRec(turmaAtual().id, d.al, d.per), atual = r && r.marcas[d.it], v = atual === d.v ? null : d.v; marcar(d.al, d.per, d.it, v); el.parentNode.querySelectorAll('.nv[data-v]').forEach(b => b.classList.toggle('on', b.dataset.v === v)); const p = $('#obsProg'); if (p) p.textContent = Object.keys(obsRec(turmaAtual().id, d.al, d.per).marcas).length + ' de ' + itensLista('itensObs').length + ' itens marcados'; };
A.obsCiclo = (d, el) => { const ord = [null, 'c', 'd', 'a'], r = obsRec(turmaAtual().id, d.al, d.per), v = ord[(ord.indexOf((r && r.marcas[d.it]) || null) + 1) % 4]; marcar(d.al, d.per, d.it, v); el.innerHTML = dotObs(v); };
A.obsNotaAbrir = (d, el) => { const w = el.closest('tr').querySelector('.obs-nota'); w.classList.remove('oculto'); w.querySelector('input').focus(); };
C_.obsNota = el => { const r = obsRec(turmaAtual().id, el.dataset.al, el.dataset.per, true); if (el.value.trim()) r.notas[el.dataset.it] = el.value.trim(); else delete r.notas[el.dataset.it]; salvarDepois('observacoes', r); };
A.obsNav = d => { const al = alunosDaTurma(turmaAtual().id), i = al.findIndex(a => a.id === (UI.filtro.obsAluno || al[0].id)) + Number(d.d); if (al[i]) { UI.filtro.obsAluno = al[i].id; render(); window.scrollTo(0, 0); } };
A.obsCopiar = async d => { const t = turmaAtual(), ant = D.observacoes.filter(r => r.alunoId === d.al && r.periodo < d.per && temMarcas(r)).sort((a, b) => b.periodo.localeCompare(a.periodo))[0]; if (!ant) return aviso('Não há observação anterior desta criança.'); const r = obsRec(t.id, d.al, d.per, true); r.marcas = Object.assign({}, ant.marcas, r.marcas); await salvar('observacoes', r); render(); aviso('Marcas copiadas de ' + rotPeriodo(ant.periodo) + '. Ajuste só o que mudou.'); };
A.obsLimpar = async d => { const r = obsRec(turmaAtual().id, d.al, d.per); if (!r) return; const antes = clone(r); r.marcas = {}; r.notas = {}; await salvar('observacoes', r); render(); aviso('Observação limpa.', 'Desfazer', async () => { Object.assign(r, antes); await salvar('observacoes', r); render(); }); };
A.obsTodos = async d => { const it = itemLista('itensObs', d.it), v = await dlg({ titulo: 'Aplicar a toda a turma', ok: 'Aplicar', corpo: '<p><b>' + e(it.nome) + '</b></p>' + Object.entries(NIVEIS_OBS).map(([k, [s, r]]) => '<label class="ck"><input type="radio" name="v" value="' + k + '"> ' + dotObs(k) + ' ' + r + '</label>').join('') + '<label class="ck"><input type="radio" name="v" value=""> Limpar (não observado)</label><label class="ck"><input type="checkbox" name="so" checked> Só nas crianças ainda sem marca neste item</label>' }); if (!v || v.v == null) return; alunosDaTurma(turmaAtual().id).forEach(a => { const r = obsRec(turmaAtual().id, a.id, d.per); if (v.so && r && r.marcas[d.it]) return; marcar(a.id, d.per, d.it, v.v || null); }); await descarregarFila(); render(); };

/* ---------- reaproveitamento: rascunho do boletim e sugestão do perfil ---------- */
const NOMES_SUBST = new Set('interesse participação contribuição criatividade concentração memorização organização postura imitação rivalidades inteligências linguagem vocabulário bons pontualidade tarefas desenhos desenho aquarela cópias execução feitio sentimentos capacidade facilidade disposição intensidade relação matérias julgar processos fixação inter-relação vontade esforço atenção habilidades compreensão liderança atitudes cuidados desenvolvimento prazer meta memória estrutura percepção expressão equilíbrio agitação coordenação como amadureceu'.split(' '));
function frasesItem(txt) { const t = txt.replace(/\s*\(.*?\)\s*$/, '').trim(), w = t.split(/[\s:]/)[0].toLowerCase(); if (/[?]/.test(t) || NOMES_SUBST.has(w)) return { tipo: 'nome', t: t[0].toLowerCase() + t.slice(1) }; return { tipo: 'verbo', t: t[0].toLowerCase() + t.slice(1).replace(/^(.*?)\s*:\s*/, '$1: ') }; }
/* seções do boletim que recebem itens do roteiro (direto ou pelo bloco) */
const secoesComObs = () => new Set(itensLista('itensObs').map(secaoDoItem).filter(Boolean));
function motivoSemRascunho(b, secKey) {
  const t = IX.turmas[b.turmaId], al = IX.alunos[b.alunoId], nome = e(primeiroNome(al)), sec = e(nomeSecao(secKey, t.serie)), r = ultimaObs(t.id, al.id);
  if (!secoesComObs().has(secKey)) return '<p>Nenhum item do roteiro de observação está ligado à seção <b>' + sec + '</b>.</p><p class="dica">O rascunho não traz as anotações (elas vêm pelo botão “Trazer novas anotações”). Ele usa só as marcas da Observação do período. Para ligar itens a esta seção, vá a Cadastros → Observação: itens.</p>';
  if (!r) return '<p>Ainda não há Observação do período para ' + nome + '.</p><p class="dica">Marque os itens em Dia a dia → Observação do período e volte aqui.</p>';
  return '<p>Na observação de ' + e(rotPeriodo(r.periodo)) + ', nenhum dos itens ligados à seção <b>' + sec + '</b> foi marcado para ' + nome + '.</p>';
}
function rascunhoObs(b, secKey) {
  const t = IX.turmas[b.turmaId], al = IX.alunos[b.alunoId], r = ultimaObs(t.id, al.id); if (!r) return '';
  const its = itensLista('itensObs').filter(i => secaoDoItem(i) === secKey), g = { c: [], d: [], a: [] }, notas = [];
  its.forEach(i => { const v = r.marcas[i.chave]; if (v) g[v].push(frasesItem(i.nome)); if (r.notas[i.chave]) notas.push(r.notas[i.chave].replace(/\.?$/, '.')); });
  const lista = xs => juntarLista(xs.map(x => x.t)), ps = [];
  const vc = g.c.filter(x => x.tipo === 'verbo'), nc = g.c.filter(x => x.tipo === 'nome');
  if (vc.length) ps.push('{nome} ' + lista(vc) + '.'); if (nc.length) ps.push('Mostra-se bem desenvolvid{o/a} em ' + lista(nc) + '.');
  if (g.d.length) ps.push('Está em desenvolvimento: ' + lista(g.d) + '.'); if (g.a.length) ps.push('Pede mais atenção: ' + lista(g.a) + '.');
  if (notas.length) ps.push(notas.join(' '));
  return substituir(ps.join(' '), al, t);
}
function sugestaoPerfil(aid) {
  const r = ultimaObs(null, aid); if (!r) return null; const s = {};
  blocosObs().filter(b => ['pensar', 'sentir', 'querer'].includes(b.criterio)).forEach(b => { const n = contarBloco(r, b.chave); if (n.total < 3) return; s[b.criterio] = n.a / n.total >= .35 ? 'cuidado' : n.c / n.total >= .6 ? 'fortalecido' : 'equilibrado'; });
  return Object.keys(s).length ? { periodo: r.periodo, niveis: s } : null;
}
function sinteseTurmaObs(t, per) {
  const al = alunosDaTurma(t.id), rs = al.map(a => obsRec(t.id, a.id, per)).filter(temMarcas), blocos = [], alertas = [];
  blocosObs().forEach(b => { const n = { c: 0, d: 0, a: 0 }; rs.forEach(r => { const x = contarBloco(r, b.chave); n.c += x.c; n.d += x.d; n.a += x.a; }); if (n.c + n.d + n.a) blocos.push({ rot: b.nome, v: n }); });
  itensLista('itensObs').forEach(i => { const qa = rs.filter(r => r.marcas[i.chave] === 'a').length, q = rs.filter(r => r.marcas[i.chave]).length; if (qa >= 2 && qa >= q / 3) alertas.push([i.nome, qa, q]); });
  return { n: rs.length, total: al.length, blocos, alertas: alertas.sort((a, b) => b[1] - a[1]) };
}
