/* ==========================================================================
   Tecelã — Relatórios e análises. A criança é comparada só com ela mesma,
   e a turma, só com ela mesma, ao longo dos anos.
   ========================================================================== */
'use strict';
const RELATORIOS = [
  ['ficha', 'Ficha da criança', 'Tudo sobre uma criança num só documento, montado para a finalidade: reunião com a família, estudo de criança, conselho de classe ou evolução ao longo dos anos.'],
  ['obs', 'Observação do período', 'Síntese do roteiro de observação: o que está consolidado, em desenvolvimento ou pede atenção, na turma e em cada criança.'],
  ['conselho', 'Conselho de classe', 'Relatório preparatório, registro do conselho e propostas (abre a tela do conselho).'],
  ['perfilTurma', 'Perfil da turma', 'Retrato do grupo no ano: temperamentos, trimembração, papéis, faltas e a sua análise.'],
  ['evolTurma', 'Evolução da turma', 'A turma comparada com ela mesma, ano a ano: perfil do grupo, faltas, anotações, vivências e reuniões.'],
  ['olhar', 'Equilíbrio do olhar', 'Quantas anotações cada criança recebeu no período. Ajuda a observar todas com o mesmo cuidado.'],
  ['lugares', 'Disposição dos lugares por temperamento', 'Os grupos de mesmo temperamento, para organizar os lugares na sala.'],
  ['freq', 'Frequência', 'Faltas por período e crianças perto do limite de 25% exigido pela LDB.'],
  ['ano', 'O ano da turma', 'Épocas, vivências, reuniões e eventos do ano, para a coordenação.'],
  ['cobertura', 'Currículo e BNCC', 'Habilidades contempladas no mesmo ano, em outro ano ou não contempladas.'],
  ['planoAnual', 'Planejamento anual', 'O planejamento do ano da turma: épocas, datas, conteúdos, objetivos e habilidades da BNCC (abre a tela do planejamento).'],
  ['planoEpoca', 'Planos de época', 'Cada época com objetivos, conteúdos, rotina da manhã e o diário dia a dia (abre a tela do planejamento).'],
  ['combinados', 'Combinados da turma', 'O guia de combinados da turma com as famílias, com as versões do ano.'],
  ['pei', 'Plano Educacional Individualizado', 'Os PEIs das crianças que precisam de adaptações (abre a tela do PEI).'],
  ['reforco', 'Reforço escolar', 'Lista geral da turma ou de uma criança, com matérias, datas e situação.'],
  ['aniver', 'Aniversariantes do ano', 'Por mês, com o dia da semana e sugestão de data quando cai no fim de semana ou em dia sem aula.'],
  ['poemas', 'Poemas', 'Um poema, todos os poemas de uma criança ou os poemas de um ano de toda a turma, um por folha.'],
  ['pauta', 'Pauta da reunião', 'A pauta para imprimir ou enviar antes da reunião, a partir da ata em rascunho.']];
const FINALIDADES = [['familia', 'Reunião com a família'], ['estudo', 'Estudo de criança'], ['conselho', 'Conselho de classe'], ['evolucao', 'Evolução ao longo dos anos']];
const docBase = (nome, titulo, blocos) => ({ nome, titulo, papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: titulo }].concat(blocos) });
T.relat = () => {
  const t = turmaAtual(); if (!t) return '<h1>Relatórios</h1>' + vazio('Cadastre uma turma primeiro.');
  if (UI.sub && REL[UI.sub]) { const r = REL[UI.sub](t); return '<div class="linha"><button class="btn" data-a="voltarSub">← Relatórios</button><h2 style="margin:0">' + e(RELATORIOS.find(x => x[0] === UI.sub)[1]) + '</h2><span class="espaco"></span>' + (r.doc ? '<button class="btn pri" data-a="exportarRel">Imprimir, exportar ou enviar</button>' : '') + '</div>' + (r.controles ? '<div class="cartao">' + r.controles + '</div>' : '') + (r.aviso || '') + (r.html ? r.html : r.doc ? '<div class="cartao rolagem">' + r.doc.blocos.slice(1).map(htmlBloco).join('') + '</div>' : ''); }
  return '<h1>Relatórios e análises</h1><div class="principio"><b>Princípio orientador:</b> ' + PRINCIPIO + ' Por isso, a Tecelã compara cada criança só com ela mesma, e a turma só com ela mesma.</div><div class="grade">' + RELATORIOS.map(([k, n, d]) => '<div class="cartao" style="cursor:pointer" data-a="abrirRel" data-k="' + k + '"><h3 style="margin-top:0">' + n + '</h3><p class="dica" style="margin:0">' + d + '</p></div>').join('') + '</div>';
};
A.abrirRel = d => { if (d.k === 'cobertura') { UI.aba.curric = 'comp'; return ir('curric'); } if (d.k === 'conselho') return ir('conselho'); if (d.k === 'planoAnual') return ir('planej', null, 'anual'); if (d.k === 'planoEpoca') return ir('planej', null, 'epocas'); if (d.k === 'combinados') return ir('combinados'); if (d.k === 'pei') return ir('pei'); ir('relat', d.k); };
C_.fichaFin = el => { UI.filtro.fichaFin = el.value; render(); };
C_.relObsAl = el => { UI.filtro.relObsAl = el.value; render(); };
C_.relPer = el => { UI.filtro.relPer = el.value; render(); };
A.exportarRel = async () => { await descarregarFila(); const r = REL[UI.sub](turmaAtual()); if (r.doc) saidaDocumento(r.doc, { csv: r.csv, assunto: r.doc.titulo }); };
const selAluno = (lista, atual, c) => '<select data-c="' + (c || 'relAluno') + '">' + lista.map(a => '<option value="' + a.id + '"' + (a.id === atual ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select>';
C_.relAluno = el => { UI.filtro.relAluno = el.value; render(); };
C_.relDesde = el => { UI.filtro.relDesde = el.value; render(); };
C_.relSig = el => { UI.filtro.relSig = el.checked; render(); };
const selPeriodo = (t, atual) => '<select data-c="relPer">' + periodosDaTurma(t).map(p => '<option value="' + p.id + '"' + (p.id === atual ? ' selected' : '') + '>' + p.rot + '</option>').join('') + '</select>';
const alunoRel = t => { const al = alunosDaTurma(t.id); return al.find(a => a.id === UI.filtro.relAluno) || al[0]; };
const resumoPerfil = p => { const c = (p && p.campos) || {}; return [rotTemp(c.tempPred) + (c.tempSec ? ' / ' + rotTemp(c.tempSec) : ''), rotNivel(c.pensarNivel), rotNivel(c.sentirNivel), rotNivel(c.quererNivel), rotPapel(c.papel)]; };
const textoAt = (x, sig) => nomeItem('atencao', x.tipo) + ': ' + (x.descricao || '') + (x.desde ? ' (desde ' + dataBR(x.desde) + ')' : '') + (x.situacao === 'resolvido' ? ' — resolvido' : '') + (sig && x.sigiloso !== false ? ' [sigiloso]' : '');

const REL = {
  ficha(t) {
    const f = FINALIDADES.some(x => x[0] === UI.filtro.fichaFin) ? UI.filtro.fichaFin : 'familia', r = { familia: REL.reuniao, estudo: REL.estudo, evolucao: REL.evolAluno, conselho: REL.fichaConselho }[f](t);
    r.controles = '<div class="linha"><span class="dica">Finalidade:</span><select data-c="fichaFin">' + FINALIDADES.map(([k, n]) => '<option value="' + k + '"' + (k === f ? ' selected' : '') + '>' + n + '</option>').join('') + '</select></div>' + (r.controles || '');
    return r;
  },
  fichaConselho(t) {
    const al = alunosDaTurma(t.id); if (!al.length) return { aviso: vazio('Cadastre os alunos da turma.') };
    const a = alunoRel(t), per = periodoEscolhido(t, 'relPer'), sig = !!UI.filtro.relSig, b = blocosPreAluno(t, a, per, sig);
    b[0] = { t: 'p', txt: a.nome + ' · ' + rotuloTurma(t) + ' · ' + per.rot + '.' };
    const r = obsRec(t.id, a.id, per.id); if (temMarcas(r)) { b.push({ t: 'h', txt: 'Roteiro de observação por bloco' }, { t: 'tabela', cab: ['Bloco', '● consolidado', '◐ em desenvolvimento', '○ pede atenção'], linhas: blocosObs().map(bl => [bl.nome, contarBloco(r, bl.chave)]).filter(([, n]) => n.total).map(([nm, n]) => [nm, String(n.c), String(n.d), String(n.a)]) }); }
    const c = consRec(t, per.id), x = c && (c.alunos || {})[a.id]; if (x && (x.fala || x.proposta)) b.push({ t: 'h', txt: 'Registro do conselho' }, { t: 'p', txt: [rotSit(x.situacao), x.fala, x.proposta ? 'Proposta: ' + x.proposta : ''].filter(Boolean).join('. ') + '.' });
    return { controles: '<div class="linha">' + selAluno(al, a.id) + selPeriodo(t, per.id) + '<label class="ck"><input type="checkbox" data-c="relSig"' + (sig ? ' checked' : '') + '> Incluir pontos de atenção e anotações sigilosas</label></div>', doc: docBase('Ficha_conselho_' + a.nome, 'Ficha para o conselho de classe — ' + a.nome, b) };
  },
  obs(t) {
    const per = periodoEscolhido(t, 'relPer'), al = alunosDaTurma(t.id), s = sinteseTurmaObs(t, per.id), its = itensLista('itensObs');
    const det = al.find(a => a.id === UI.filtro.relObsAl) || null, nomes = (r, k) => its.filter(i => r && r.marcas[i.chave] === k).map(i => i.nome);
    const ctr = '<div class="linha">' + selPeriodo(t, per.id) + '<select data-c="relObsAl"><option value="">Resumo da turma</option>' + al.map(a => '<option value="' + a.id + '"' + (det && det.id === a.id ? ' selected' : '') + '>Detalhar: ' + e(a.nome) + '</option>').join('') + '</select><a href="#" data-a="ir" data-t="obs">Abrir a observação</a></div>';
    if (!s.n) return { controles: ctr, aviso: '<div class="cartao"><p>Ainda não há marcas na Observação do período de <b>' + e(per.rot) + '</b>.</p><p class="dica">Escolha outro período acima ou marque os itens em Dia a dia → Observação do período.</p></div>' };
    const b = [];
    if (det) {
      const r = obsRec(t.id, det.id, per.id);
      b.push({ t: 'p', txt: det.nome + ' · ' + per.rot + '. Só entra o que foi marcado; o que ficou em branco não foi observado.' });
      if (!temMarcas(r)) b.push({ t: 'p', txt: 'Sem marcas neste período.' });
      else blocosObs().forEach(bl => { const n = contarBloco(r, bl.chave); if (!n.total) return; b.push({ t: 'h', txt: bl.nome }); [['c', 'Consolidado'], ['d', 'Em desenvolvimento'], ['a', 'Pede atenção']].forEach(([k, rot]) => { const xs = itensDoBloco(bl.chave).filter(i => r.marcas[i.chave] === k).map(i => i.nome + (r.notas[i.chave] ? ' (' + r.notas[i.chave] + ')' : '')); if (xs.length) b.push({ t: 'p', txt: rot + ': ' + xs.join('; ') + '.' }); }); });
      return { controles: ctr, doc: docBase('Observacao_' + nomeArq(det.nome) + '_' + per.id, 'Observação do período — ' + det.nome, b) };
    }
    b.push({ t: 'p', txt: rotuloTurma(t) + ' · ' + per.rot + ' · ' + s.n + ' de ' + s.total + ' crianças com observação. Só entra o que foi marcado; o que ficou em branco não foi observado.' });
    b.push({ t: 'h', txt: 'A turma por bloco (número de marcas)' }, { t: 'tabela', cab: ['Bloco', 'Consolidado', 'Em desenvolvimento', 'Pede atenção'], linhas: s.blocos.map(x => [x.rot, String(x.v.c), String(x.v.d), String(x.v.a)]) });
    if (s.alertas.length) b.push({ t: 'h', txt: 'Itens que pedem atenção em várias crianças' }, { t: 'lista', itens: s.alertas.map(([n, qa, q]) => n + ' — ' + qa + ' de ' + q + ' crianças observadas') });
    const linhas = al.map(a => { const r = obsRec(t.id, a.id, per.id); return [a.nome, String(nomes(r, 'c').length), String(nomes(r, 'd').length), String(nomes(r, 'a').length), String(its.length - Object.keys((r || {}).marcas || {}).length)]; });
    b.push({ t: 'h', txt: 'Cada criança (número de itens)' }, { t: 'tabela', cab: ['Criança', 'Consolidado', 'Em desenvolvimento', 'Pede atenção', 'Não observado'], linhas });
    b.push({ t: 'h', txt: 'O que pede atenção em cada criança' });
    al.forEach(a => { const xs = nomes(obsRec(t.id, a.id, per.id), 'a'); b.push({ t: 'p', txt: a.nome + ': ' + (xs.length ? xs.join('; ') + '.' : 'nenhum item marcado como “pede atenção”.') }); });
    b.push({ t: 'nota', txt: 'Para ver tudo o que foi marcado para uma criança, escolha “Detalhar” acima.' });
    return { controles: ctr, doc: docBase('Observacao_' + per.id, 'Observação do período — ' + rotuloTurma(t), b), csv: { cab: ['Criança', 'Consolidado', 'Em desenvolvimento', 'Pede atenção', 'Não observado'], linhas } };
  },
  perfilTurma(t) {
    const d = dadosTurma(t); if (!d.n) return { aviso: vazio('Cadastre os alunos da turma.') };
    return { html: abaPerfilTurma(), doc: docRelatorioTurma(d, perfilTurmaRec(t)) };
  },
  evolAluno(t) {
    const cad = cadeiaTurmas(t), todos = [...new Map(cad.flatMap(x => alunosDaTurma(x.id)).map(a => [a.id, a])).values()].sort(ordemNome);
    if (!todos.length) return { aviso: vazio('Cadastre os alunos da turma.') };
    const a = todos.find(x => x.id === UI.filtro.relAluno) || todos[0], mats = D.matriculas.filter(m => m.alunoId === a.id).map(m => [m, IX.turmas[m.turmaId]]).filter(x => x[1]).sort((x, y) => x[1].ano - y[1].ano);
    const b = [{ t: 'p', txt: a.nome + (a.nasc ? ', nascido(a) em ' + dataBR(a.nasc) : '') + '. A criança é comparada só com ela mesma.' }];
    b.push({ t: 'h', txt: 'Ano a ano' }, { t: 'tabela', cab: ['Ano', 'Turma', 'Idade (dez.)', 'Faltas', 'Anotações', 'Vivências', 'Boletim'], linhas: mats.map(([m, tu]) => [String(tu.ano), tu.serie + 'º ' + (tu.letra || ''), idadeTxt(idadeEm(a.nasc, tu.ano + '-12-01')), String((m.faltas || []).reduce((s, x) => s + (Number(x) || 0), 0)), String(D.anotacoes.filter(n => n.turmaId === tu.id && (n.alunos || []).includes(a.id)).length), String(D.vivencias.filter(v => v.turmaId === tu.id && (v.todos !== false || (v.participantes || []).includes(a.id))).length), (D.boletins.find(bo => bo.turmaId === tu.id && bo.alunoId === a.id) || {}).estado || '—']) });
    const ps = perfisDe(a.id).slice().reverse();
    if (ps.length) b.push({ t: 'h', txt: 'Revisões do perfil' }, { t: 'tabela', cab: ['Data', 'Temperamento', 'Pensar', 'Sentir', 'Querer', 'Papel no grupo'], linhas: ps.map(p => [dataBR(p.data)].concat(resumoPerfil(p))) });
    const crits = itensLista('criterios', true), anos = mats.map(x => x[1]);
    if (anos.length) b.push({ t: 'h', txt: 'Anotações por critério' }, { t: 'tabela', cab: ['Critério'].concat(anos.map(x => String(x.ano))), linhas: crits.map(c => [c.nome].concat(anos.map(tu => String(D.anotacoes.filter(n => n.turmaId === tu.id && n.criterio === c.chave && (n.alunos || []).includes(a.id)).length)))).filter(l => l.slice(1).some(v => v !== '0')) });
    const at = (a.atencao || []).filter(x => UI.filtro.relSig || x.sigiloso === false).sort((x, y) => (x.desde || '').localeCompare(y.desde || ''));
    if (at.length) b.push({ t: 'h', txt: 'Pontos de atenção (linha do tempo)' }, { t: 'lista', itens: at.map(x => textoAt(x, true)) });
    const ctr = selAluno(todos, a.id) + ' <label class="ck" style="display:inline-flex"><input type="checkbox" data-c="relSig"' + (UI.filtro.relSig ? ' checked' : '') + '> Incluir pontos de atenção sigilosos (só para uso próprio)</label>';
    return { controles: ctr, doc: docBase('Evolucao_' + a.nome, 'Evolução de ' + a.nome, b) };
  },
  evolTurma(t) {
    const ds = cadeiaTurmas(t).map(dadosTurma);
    if (ds.length < 2) return { aviso: '<div class="cartao"><p>A evolução compara os anos da mesma turma e aparece depois da primeira virada do ano (ou depois de importar os boletins de anos anteriores).</p></div>' };
    const d = docEvolucao(ds); d.blocos.splice(3, 0, { t: 'tabela', cab: ['Ano', 'Anotações', 'Vivências', 'Reuniões (atas)', 'Pontos de atenção ativos'], linhas: ds.map(x => [String(x.t.ano), String(x.anotTotal), String(D.vivencias.filter(v => v.turmaId === x.t.id).length), String(Object.values(x.atas).reduce((s, n) => s + n, 0)), String(Object.values(x.atencao).reduce((s, n) => s + n, 0))]) });
    return { doc: d };
  },
  olhar(t) {
    const al = alunosDaTurma(t.id), desde = UI.filtro.relDesde || somaDias(hojeISO(), -30), ns = D.anotacoes.filter(n => n.turmaId === t.id && (n.data || '') >= desde);
    const cont = al.map(a => ({ a, n: ns.filter(n => (n.alunos || []).includes(a.id)).length, ult: D.anotacoes.filter(n => (n.alunos || []).includes(a.id)).map(n => n.data).sort().pop() })).sort((x, y) => x.n - y.n || x.a.nome.localeCompare(y.a.nome));
    const media = cont.reduce((s, x) => s + x.n, 0) / (cont.length || 1);
    const b = [{ t: 'p', txt: 'Anotações desde ' + dataBR(desde) + '. Média de ' + media.toFixed(1) + ' por criança. As crianças com menos anotações aparecem primeiro: talvez seja hora de olhar para elas com mais atenção.' }, { t: 'svg', svg: svgBarras(cont.map(x => ({ rot: primeiroNome(x.a), v: x.n, cor: x.n < media / 2 ? '#EA6A55' : '#4F8FCC' })), 'Anotações por criança') }, { t: 'tabela', cab: ['Criança', 'Anotações no período', 'Última anotação'], linhas: cont.map(x => [x.a.nome, String(x.n), x.ult ? dataBR(x.ult) : '—']) }];
    return { controles: campo('Desde', '<input type="date" data-c="relDesde" value="' + desde + '">'), doc: docBase('Equilibrio_do_olhar', 'Equilíbrio do olhar — ' + rotuloTurma(t), b) };
  },
  reuniao(t) {
    const al = alunosDaTurma(t.id); if (!al.length) return { aviso: vazio('Cadastre os alunos da turma.') };
    const a = alunoRel(t), ultima = D.atas.filter(x => x.turmaId === t.id && x.tipo === 'familias' && x.data < hojeISO()).map(x => x.data).sort().pop();
    const desde = UI.filtro.relDesde || ultima || t.ano + '-01-01', ns = D.anotacoes.filter(n => (n.alunos || []).includes(a.id) && (n.data || '') >= desde && (UI.filtro.relSig || !n.sigilo)).sort((x, y) => (x.data || '').localeCompare(y.data || ''));
    const p = ultimoPerfil(a.id), m = matricula(t.id, a.id) || {}, b = [{ t: 'p', txt: a.nome + ' · ' + idadeTxt(idadeEm(a.nasc, hojeISO())) + ' · ' + rotuloTurma(t) + '. Registros desde ' + dataBR(desde) + '.' }];
    if (p) b.push({ t: 'h', txt: 'Perfil atual (' + dataBR(p.data) + ')' }, { t: 'tabela', cab: ['Temperamento', 'Pensar', 'Sentir', 'Querer', 'Papel no grupo'], linhas: [resumoPerfil(p)] });
    b.push({ t: 'p', txt: 'Faltas no ano: ' + (m.faltas || []).reduce((s, x) => s + (Number(x) || 0), 0) + '.' });
    b.push(...blocosContatos(t, a.id, 6));
    b.push({ t: 'h', txt: 'Anotações do período' }); if (ns.length) b.push({ t: 'tabela', cab: ['Data', 'Seção · critério', 'Anotação'], linhas: ns.map(n => [dataBR(n.data), [nomeSecao(n.secao, t.serie), nomeCrit(n.criterio)].filter(Boolean).join(' · '), substituir(n.texto, a, t) + (n.sigilo ? ' [sigilosa]' : '')]) }); else b.push({ t: 'p', txt: 'Nenhuma anotação no período.' });
    const at = (a.atencao || []).filter(x => x.situacao !== 'resolvido' && (UI.filtro.relSig || x.sigiloso === false)); if (at.length) b.push({ t: 'h', txt: 'Pontos de atenção' }, { t: 'lista', itens: at.map(x => textoAt(x, true)) });
    b.push({ t: 'h', txt: 'Para conversar com a família' }, { t: 'p', txt: '______________________________________________________________________________' }, { t: 'p', txt: '______________________________________________________________________________' });
    return { controles: '<div class="linha">' + selAluno(al, a.id) + campo('Desde', '<input type="date" data-c="relDesde" value="' + desde + '">') + '<label class="ck"><input type="checkbox" data-c="relSig"' + (UI.filtro.relSig ? ' checked' : '') + '> Incluir anotações e pontos sigilosos (só para você; não leve impresso à reunião)</label></div>', doc: docBase('Reuniao_' + a.nome, 'Preparação para a reunião — ' + a.nome, b) };
  },
  estudo(t) {
    const al = alunosDaTurma(t.id); if (!al.length) return { aviso: vazio('Cadastre os alunos da turma.') };
    const a = alunoRel(t), m = idadeEm(a.nasc, hojeISO()), sig = !!UI.filtro.relSig, b = [{ t: 'p', txt: a.nome + ' · ' + (a.nasc ? 'nascido(a) em ' + dataBR(a.nasc) + ' · ' : '') + idadeTxt(m) + ' · ' + setenio(m) + ' · ' + rotuloTurma(t) + (a.entrada ? ' · na escola desde ' + dataBR(a.entrada) : '') }];
    if ((a.responsaveis || []).some(r => r.nome)) b.push({ t: 'p', txt: 'Família: ' + a.responsaveis.filter(r => r.nome).map(r => r.nome + (r.parentesco ? ' (' + r.parentesco + ')' : '')).join(', ') + '.' });
    const at = (a.atencao || []).filter(x => sig || x.sigiloso === false); if (at.length) b.push({ t: 'h', txt: 'Pontos de atenção' }, { t: 'lista', itens: at.map(x => textoAt(x, true)) });
    const ps = perfisDe(a.id), p = ps[0];
    if (p) { b.push({ t: 'h', txt: 'Perfil (revisão de ' + dataBR(p.data) + ')' }); PERFIL.forEach(bl => { const ls = bl.campos.map(([k, rot, tipo, ops]) => { let v = (p.campos || {})[k]; if (tipo === 's') v = (opsDe(ops, v).find(o => o[0] === v) || ['', ''])[1]; if (tipo === 'm') v = ops.filter(o => v && v[slug(o)]).join(', '); return v ? rot + ': ' + v : ''; }).filter(Boolean); if (ls.length) { b.push({ t: 'p', txt: bl.bloco }); b.push({ t: 'lista', itens: ls }); } }); }
    if (ps.length > 1) b.push({ t: 'h', txt: 'Como o perfil mudou' }, { t: 'tabela', cab: ['Data', 'Temperamento', 'Pensar', 'Sentir', 'Querer', 'Papel'], linhas: ps.slice().reverse().map(x => [dataBR(x.data)].concat(resumoPerfil(x))) });
    const ns = D.anotacoes.filter(n => (n.alunos || []).includes(a.id) && (sig || !n.sigilo)).sort((x, y) => (x.data || '').localeCompare(y.data || ''));
    if (ns.length) { b.push({ t: 'h', txt: 'Anotações por critério' }); const gr = {}; ns.forEach(n => (gr[n.criterio || ''] = gr[n.criterio || ''] || []).push(n)); Object.entries(gr).forEach(([k, xs]) => { b.push({ t: 'p', txt: (k ? nomeCrit(k) : 'Sem critério') + ' (' + xs.length + ')' }); b.push({ t: 'lista', itens: xs.map(n => dataBR(n.data) + ' — ' + substituir(n.texto, a, t)) }); }); }
    const mt = D.matriculas.filter(x => x.alunoId === a.id).map(x => [x, IX.turmas[x.turmaId]]).filter(x => x[1]); b.push({ t: 'p', txt: 'Faltas: ' + mt.map(([x, tu]) => tu.ano + ': ' + (x.faltas || []).reduce((s, v) => s + (Number(v) || 0), 0)).join(' · ') + '.' });
    b.push({ t: 'h', txt: 'Imagem da criança (para o colegiado completar)' }, { t: 'p', txt: '______________________________________________________________________________' }, { t: 'p', txt: '______________________________________________________________________________' });
    return { controles: '<div class="linha">' + selAluno(al, a.id) + '<label class="ck"><input type="checkbox" data-c="relSig"' + (sig ? ' checked' : '') + '> Incluir anotações e pontos sigilosos (o estudo de criança é sigiloso)</label><a href="#" data-a="ir" data-t="acomp" data-aba="estudo">Estudo de criança editável, com versões</a></div>', doc: docBase('Estudo_de_crianca_' + a.nome, 'Estudo de criança — ' + a.nome, b) };
  },
  lugares(t) {
    const al = alunosDaTurma(t.id), gr = {}; al.forEach(a => { const p = ultimoPerfil(a.id), k = ((p || {}).campos || {}).tempPred || ''; (gr[k] = gr[k] || []).push(a); });
    const b = [{ t: 'p', txt: 'Uma prática conhecida na pedagogia Waldorf é sentar juntas as crianças de mesmo temperamento, para que se moderem mutuamente, e oferecer a cada grupo imagens e tarefas que dialoguem com seu modo de ser. Use os grupos abaixo como ponto de partida, sempre com o seu olhar sobre cada criança.' }];
    TEMPS.slice(1).concat([['', 'Sem perfil']]).forEach(([k, n]) => { if (!(gr[k] || []).length) return; b.push({ t: 'h', txt: n + ' (' + gr[k].length + ')' }, { t: 'lista', itens: gr[k].map(a => { const c = (ultimoPerfil(a.id) || {}).campos || {}; return a.nome + (c.tempSec ? ' — secundário: ' + rotTemp(c.tempSec) : ''); }) }); });
    const ref = IX.biblioteca.temperamentos; if (ref && !ref.oculto && ref.texto) b.push({ t: 'nota', txt: ref.titulo + ': ' + ref.texto.replace(/\n+/g, ' ') + (ref.fonte ? ' Fonte: ' + ref.fonte : '') });
    return { doc: docBase('Lugares_por_temperamento', 'Disposição dos lugares por temperamento — ' + rotuloTurma(t), b) };
  },
  freq(t) {
    const per = CFG.prefs.periodos || [], dl = t.diasLetivos || [], al = alunosDaTurma(t.id), ult = per.reduce((u, _, i) => al.some(a => { const v = ((matricula(t.id, a.id) || {}).faltas || [])[i]; return v !== null && v !== undefined && v !== ''; }) ? i : u, -1), tot = dl.slice(0, ult + 1).reduce((s, x) => s + (Number(x) || 0), 0);
    const ctr = '<div data-rec="turmas:' + t.id + '"><p class="dica">Dias letivos de cada período (para calcular o percentual de faltas):</p><div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))">' + per.map((p, i) => campo(e(p), inp('diasLetivos.' + i, dl[i], 'number', 'min="0" data-rr="1"'))).join('') + '</div></div>';
    const linhas = al.map(a => { const f = (matricula(t.id, a.id) || {}).faltas || [], soma = f.reduce((s, x) => s + (Number(x) || 0), 0), pc = tot ? 100 * soma / tot : null; return [a.nome].concat(per.map((_, i) => String(f[i] == null ? '' : f[i]))).concat([String(soma), pc == null ? '—' : pc.toFixed(1) + '%' + (pc >= 25 ? ' ⚠ acima do limite' : pc >= 15 ? ' · atenção' : '')]); });
    const b = [{ t: 'p', txt: tot ? 'Dias letivos considerados: ' + tot + ' (até o ' + per[ult] + ', último período com faltas lançadas). A LDB exige frequência mínima de 75%, ou seja, no máximo 25% de faltas.' : 'Informe os dias letivos de cada período para calcular os percentuais.' }, { t: 'tabela', cab: ['Aluno'].concat(per).concat(['Total', '% de faltas']), linhas }];
    return { controles: ctr, doc: docBase('Frequencia_' + t.ano, 'Frequência — ' + rotuloTurma(t), b), csv: { cab: ['Aluno'].concat(per).concat(['Total', '% de faltas']), linhas } };
  },
  ano(t) {
    const ini = t.ano + '-01-01', fim = t.ano + '-12-31', eps = D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)), vs = D.vivencias.filter(v => v.turmaId === t.id).sort((a, b) => (a.data || '').localeCompare(b.data || '')), atas = D.atas.filter(a => a.turmaId === t.id && !D.atas.some(x => x.origemId === a.id)).sort((a, b) => (a.data || '').localeCompare(b.data || '')), evs = D.eventos.filter(v => (v.turmaId === t.id) && v.data >= ini && v.data <= fim).sort((a, b) => a.data.localeCompare(b.data));
    const b = [{ t: 'p', txt: rotuloTurma(t) + ' · ' + profTit(t) + ': ' + (t.professora || '') + ' · ' + alunosDaTurma(t.id).length + ' alunos.' }];
    b.push({ t: 'h', txt: 'Épocas do ' + t.serie + 'º ano' }); b.push(eps.length ? { t: 'tabela', cab: ['Época', 'Componente', 'Período', 'Realizada'], linhas: eps.map(c => [c.titulo, nomeItem('componentes', c.componente), c.periodo || '', (c.realizadas || []).includes(t.id) ? 'sim' : '—']) } : { t: 'p', txt: 'Currículo não cadastrado.' });
    b.push({ t: 'h', txt: 'Vivências' }); b.push(vs.length ? { t: 'tabela', cab: ['Data', 'Vivência', 'Tipo', 'Local'], linhas: vs.map(v => [dataBR(v.data), v.titulo, nomeItem('tiposVivencia', v.tipo), v.local || '']) } : { t: 'p', txt: 'Nenhuma vivência registrada.' });
    b.push({ t: 'h', txt: 'Reuniões' }); b.push(atas.length ? { t: 'tabela', cab: ['Data', 'Reunião', 'Assunto'], linhas: atas.map(a => [dataBR(a.data), nomeReuniao(a), a.assunto || '']) } : { t: 'p', txt: 'Nenhuma ata registrada.' });
    if (evs.length) b.push({ t: 'h', txt: 'Eventos da turma' }, { t: 'tabela', cab: ['Data', 'Evento', 'Observação'], linhas: evs.map(v => [dataBR(v.data), v.titulo, v.obs || '']) });
    return { doc: docBase('Ano_da_turma_' + t.ano, 'O ano da turma — ' + rotuloTurma(t), b) };
  }
};
