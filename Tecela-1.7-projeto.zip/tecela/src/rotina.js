/* ==========================================================================
   Tecelã — Rotina e ano letivo: chamada rápida no Painel, roteiro para o
   professor substituto, dias letivos e carga horária, festas do ano, lista de
   materiais e conferência dos textos do boletim.
   ========================================================================== */
'use strict';

/* ---------- períodos das faltas com datas (os mesmos cortes da observação do período) ---------- */
function periodosComDatas(t) {
  const n = (CFG.prefs.periodos || []).length || 4, k = { 1: 'anual', 2: 'semestral', 3: 'trimestral', 4: 'bimestral' }[n];
  if (k) return PER_OBS[k].map(([, , i, f], j) => ({ i: j, rot: CFG.prefs.periodos[j], ini: t.ano + '-' + i, fim: t.ano + '-' + f }));
  return (CFG.prefs.periodos || []).map((r, j) => { const a = Math.floor(12 * j / n) + 1, b = Math.floor(12 * (j + 1) / n); return { i: j, rot: r, ini: t.ano + '-' + String(a).padStart(2, '0') + '-01', fim: t.ano + '-' + String(b).padStart(2, '0') + '-' + String(new Date(t.ano, b, 0).getDate()).padStart(2, '0') }; });
}
const periodoDaData = (t, iso) => (periodosComDatas(t).find(p => iso >= p.ini && iso <= p.fim) || { i: -1 }).i;

/* ---------- chamada rápida: um toque marca a falta de hoje, que vai para a frequência ---------- */
function cartaoChamada(t) {
  const h = hojeISO(); if (String(t.ano) !== h.slice(0, 4) || !ehLetivo(h)) return '';
  const al = alunosDaTurma(t.id); if (!al.length) return '';
  const faltam = al.filter(a => ((matricula(t.id, a.id) || {}).ausencias || []).includes(h));
  return '<div class="cartao"><div class="linha" style="margin:0"><h3 style="margin:0">Chamada de hoje</h3><span class="dica">' + dataBR(h) + ' · toque em quem faltou</span><span class="espaco"></span><span class="dica">' + (faltam.length ? faltam.length + ' falta' + (faltam.length > 1 ? 's' : '') : 'todos presentes') + '</span></div><div class="chips chamada">' +
    al.map(a => { const f = faltam.includes(a); return '<button class="chip-ch' + (f ? ' faltou' : '') + '" data-a="chamada" data-al="' + a.id + '" aria-pressed="' + f + '">' + e(primeiroNome(a)) + (f ? ' · faltou' : '') + '</button>'; }).join('') + '</div><p class="dica" style="margin:.4rem 0 0">A falta entra sozinha no total do período, em Faltas e no boletim.</p></div>';
}
A.chamada = async d => {
  const t = turmaAtual(), h = hojeISO(), m = matricula(t.id, d.al); if (!m) return; const p = periodoDaData(t, h);
  m.ausencias = m.ausencias || []; m.faltas = m.faltas || []; const i = m.ausencias.indexOf(h), a = IX.alunos[d.al];
  if (i < 0) { m.ausencias.push(h); if (p >= 0) m.faltas[p] = (Number(m.faltas[p]) || 0) + 1; } else { m.ausencias.splice(i, 1); if (p >= 0) m.faltas[p] = Math.max(0, (Number(m.faltas[p]) || 0) - 1); }
  await salvar('matriculas', m); render(); aviso(primeiroNome(a) + (i < 0 ? ': falta marcada.' : ': presença.'));
};

/* ---------- roteiro para o professor substituto ---------- */
function docSubstituto(t, iso) {
  const al = alunosDaTurma(t.id), its = aulasDe(t, new Date(iso + 'T12:00').getDay()) || [], b = [];
  const ep = D.eventos.find(v => v.tipo === 'epoca' && (!v.turmaId || v.turmaId === t.id) && v.data <= iso && (v.dataFim || v.data) >= iso);
  const plano = docsDe('epoca', d => d.turmaId === t.id && d.cab && d.cab.inicio <= iso && d.cab.fim >= iso)[0], dia = plano && ((plano.secoes.find(s => s.k === 'diario') || {}).dias || []).find(x => x.data === iso);
  const ant = plano && ((plano.secoes.find(s => s.k === 'diario') || {}).dias || []).filter(x => x.data < iso && (x.conteudo || x.registro)).pop();
  b.push({ t: 'pares', linhas: [['Turma', rotuloTurma(t) + ' · ' + al.length + ' crianças'], ['Professor(a) de classe', t.professora || ''], ['Escola', CFG.escola.nome || ''], ['Época', plano ? plano.titulo.replace(/^Época /, '') : ep ? ep.titulo : '']].filter(x => x[1]) });
  b.push({ t: 'h', txt: 'O dia' }); b.push(its.length ? { t: 'tabela', cab: ['Horário', 'Aula', 'Quem dá'], linhas: its.map(x => { const m = materiaDe(t, x.m); return [horarioAula(x), x.m, m.quem === 'PC' ? 'Professor(a) de classe' : m.prof ? m.prof + ' (PM)' : 'Professor(a) de matéria']; }) } : { t: 'p', txt: 'O horário semanal deste dia não está cadastrado.' });
  const rot = (plano && plano.secoes.find(s => /rotina/i.test(s.k + ' ' + s.tit))) || null;
  if (rot) { b.push({ t: 'h', txt: 'Rotina da manhã' }); if (rot.tipo === 'tabela') b.push({ t: 'tabela', cab: rot.cols, linhas: rot.linhas }); else b.push(...blocosTexto(rot.txt)); }
  const rep = repDaTurma(t).filter(r => r.rotina || (plano && r.epocaId === plano.epocaId));
  if (rep.length) b.push({ t: 'h', txt: 'Versos, canções e histórias' }, { t: 'lista', itens: rep.map(r => nomeTipoRep(r.tipo) + ': ' + r.titulo + (r.rotina ? ' (todos os dias)' : '') + (r.texto && r.texto.length < 400 ? ' — ' + r.texto.replace(/\n+/g, ' / ') : '')) });
  if (ant || dia) { b.push({ t: 'h', txt: 'Onde estamos na época' }); if (ant) b.push({ t: 'p', txt: 'Último dia registrado (' + dataBR(ant.data) + '): ' + [ant.conteudo, ant.registro].filter(Boolean).join(' · ') }); if (dia && (dia.conteudo || dia.licao)) b.push({ t: 'p', txt: 'Previsto para hoje: ' + [dia.conteudo, dia.licao ? 'lição de casa: ' + dia.licao : ''].filter(Boolean).join(' · ') }); }
  b.push({ t: 'h', txt: 'Para propor hoje' }, { t: 'p', txt: '______________________________________________________________________________' }, { t: 'p', txt: '______________________________________________________________________________' });
  const cuid = al.map(a => [a.nome, alergiasDe(a), (a.seg || {}).medicamentos || '', (a.seg || {}).buscam || '', (a.atencao || []).filter(x => x.situacao !== 'resolvido' && x.sigiloso === false && x.tipo !== 'alergia').map(x => x.descricao).join('; ')]).filter(l => l.slice(1).some(Boolean));
  b.push({ t: 'h', txt: 'Cuidados com as crianças' }); b.push(cuid.length ? { t: 'tabela', cab: ['Criança', 'Alergias e restrições', 'Medicamentos e cuidados', 'Quem pode buscar', 'Atenção'], linhas: cuid } : { t: 'p', txt: 'Nenhum cuidado especial registrado.' });
  const an = al.filter(a => a.nasc && a.nasc.slice(5) === iso.slice(5)); if (an.length) b.push({ t: 'p', txt: 'Aniversário hoje: ' + an.map(primeiroNome).join(', ') + '.' });
  b.push({ t: 'lista', itens: ['Lista da turma: ' + al.map(primeiroNome).join(', ') + '.'] }, { t: 'nota', txt: 'Documento com dados de crianças: devolva à professora ou à coordenação ao fim do dia.' });
  return { nome: 'Roteiro_substituto_' + iso, titulo: 'Roteiro para o professor substituto — ' + dataBR(iso) + ' (' + diaSemana(iso) + ')', papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Roteiro para o professor substituto' }, { t: 'p', txt: dataBR(iso) + ' (' + diaSemana(iso) + ')' }].concat(b) };
}
A.substituto = async () => {
  const t = turmaAtual(); if (!t) return; const h = ehLetivo(hojeISO()) ? hojeISO() : letivoDepois(hojeISO());
  const v = await dlg({ titulo: 'Roteiro para o professor substituto', ok: 'Montar o roteiro', corpo: '<p>Horário semanal do dia, rotina e versos, a época em curso e o que estava no diário, alergias, cuidados e quem pode buscar cada criança.</p>' + campo('Dia', '<input type="date" name="d" value="' + h + '">') + '<p class="dica">Os pontos de atenção sigilosos não entram. Para os cuidados, use “Saúde e segurança” no cadastro de cada criança.</p>' });
  if (!v || !v.d) return; await descarregarFila(); saidaDocumento(docSubstituto(t, v.d), { assunto: 'Roteiro do dia ' + dataBR(v.d) + ' — ' + rotuloTurma(t) });
};

/* ---------- dias letivos e carga horária ---------- */
/* mínimos definidos pela legislação (LDB, art. 24, em 2026): ajustáveis em Ajustes, se a lei mudar */
const minDias = () => Number(CFG.prefs.minDias) || 200, minHoras = () => Number(CFG.prefs.minHoras) || 800;
const minutos = h => { const m = String(h || '').match(/^(\d{1,2}):(\d{2})$/); return m ? Number(m[1]) * 60 + Number(m[2]) : null; };
/* horas de aula de um dia da semana, pelo horário semanal (do início da primeira aula ao fim da última) */
function horasDoDia(t, w) { const its = aulasDe(t, w) || [], ini = Math.min(...its.map(x => minutos(x.ini)).filter(x => x != null)), fim = Math.max(...its.map(x => minutos(x.fim)).filter(x => x != null)); return isFinite(ini) && isFinite(fim) && fim > ini ? (fim - ini) / 60 : null; }
function contagemLetiva(t) {
  const ini = inicioDoAno(t), fimAno = t.ano + '-12-31', hp = Number(CFG.prefs.horasDia) || 4;
  const ps = periodosComDatas(t).map(p => { const ds = diasLetivos(p.ini < ini ? ini : p.ini, p.fim > fimAno ? fimAno : p.fim).filter(d => !ultimoDiaLetivo(t) || d <= ultimoDiaLetivo(t)); const hs = ds.reduce((s, d) => s + (horasDoDia(t, new Date(d + 'T12:00').getDay()) || hp), 0); return Object.assign({}, p, { ini: p.ini < ini ? ini : p.ini, fim: ultimoDiaLetivo(t) && p.fim > ultimoDiaLetivo(t) ? ultimoDiaLetivo(t) : p.fim, dias: ds.length, horas: hs }); }).filter(p => p.ini <= p.fim || p.dias);
  return { ps, dias: ps.reduce((s, p) => s + p.dias, 0), horas: ps.reduce((s, p) => s + p.horas, 0), ini, hp };
}
/* fim do ano letivo: evento com “fim das aulas”, “término do ano letivo” ou “encerramento” */
const ultimoDiaLetivo = t => { const ev = D.eventos.find(v => (v.data || '').startsWith(String(t.ano)) && /fim (das aulas|do ano letivo)|t[ée]rmino (das aulas|do ano letivo)|[úu]ltimo dia de aula/i.test(v.titulo || '')); return ev ? ev.data : ''; };
function abaAnoLetivo(t) {
  const c = contagemLetiva(t), fx = n => String(Math.round(n * 10) / 10).replace('.', ',');
  let h = '<div class="cartao"><h3>Dias letivos e carga horária de ' + t.ano + '</h3><p class="dica">Contados pelo calendário: a partir do início do ano letivo (' + dataBR(c.ini) + ')' + (ultimoDiaLetivo(t) ? ' até o último dia de aula (' + dataBR(ultimoDiaLetivo(t)) + ')' : '') + ', sem domingos, feriados e recessos, com os sábados letivos. As horas de cada dia vêm do horário semanal (do início da primeira aula ao fim da última); onde o horário semanal não tem a hora das aulas, conta ' + c.hp + ' horas.</p>' +
    '<div class="rolagem"><table class="tabela"><tr><th>Período</th><th>De</th><th>Até</th><th>Dias letivos</th><th>Horas</th></tr>' + c.ps.map(p => '<tr><td>' + e(p.rot) + '</td><td>' + dataBR(p.ini) + '</td><td>' + dataBR(p.fim) + '</td><td>' + p.dias + '</td><td>' + fx(p.horas) + '</td></tr>').join('') + '<tr><td><b>Total</b></td><td></td><td></td><td><b>' + c.dias + '</b> ' + (c.dias >= minDias() ? '<span class="flag az">mínimo de ' + minDias() + ' ✓</span>' : '<span class="flag">faltam ' + (minDias() - c.dias) + ' para ' + minDias() + '</span>') + '</td><td><b>' + fx(c.horas) + '</b> ' + (c.horas >= minHoras() ? '<span class="flag az">mínimo de ' + minHoras() + ' ✓</span>' : '<span class="flag">faltam ' + fx(minHoras() - c.horas) + ' para ' + minHoras() + '</span>') + '</td></tr></table></div>' +
    '<div class="linha"><button class="btn pri" data-a="usarDiasLetivos">Usar estes dias nas faltas e no boletim</button><button class="btn" data-a="exportarLetivos">Imprimir ou exportar</button>' + campo('Horas por dia sem horário', '<input type="number" min="1" max="10" step="0.5" data-c="horasDia" value="' + c.hp + '" style="width:5rem">') + '</div><p class="dica">Mínimos usados na comparação: ' + minDias() + ' dias letivos e ' + minHoras() + ' horas, definidos pela legislação (hoje, a LDB, art. 24). Se a legislação mudar, ajuste em <a href="#" data-a="ir" data-t="ajustes">Ajustes → Ano letivo</a>. Confira sempre com a secretaria da escola, que é quem responde por essa contagem.</p></div>';
  h += cartaoFestas(t);
  h += '<div class="cartao"><h3>Lista de materiais do ano</h3><p>Sugestão montada a partir do ano e das épocas do currículo (aquarela, giz de cera em bloco, flauta, cadernos de época…), para revisar e enviar às famílias.</p>' + (docsDe('materiais', d => d.turmaId === t.id)[0] ? '<button class="btn" data-a="abrirDocSub" data-id="' + docsDe('materiais', d => d.turmaId === t.id)[0].id + '">Abrir a lista</button>' : '<button class="btn" data-a="materiaisNovo">Montar a lista de materiais</button>') + '</div>';
  return h;
}
C_.horasDia = async el => { await prefs({ horasDia: Number(el.value) || 4 }); render(); };
A.usarDiasLetivos = async () => { const t = turmaAtual(), c = contagemLetiva(t); if (!(await confirmar('Usar os dias letivos contados?', 'Os dias letivos de cada período (' + c.ps.map(p => p.rot + ': ' + p.dias).join('; ') + ') vão para a tela Faltas, para o cálculo da frequência e para o boletim.', 'Usar'))) return; t.diasLetivos = c.ps.map(p => p.dias); await salvar('turmas', t); render(); aviso('Dias letivos atualizados.'); };
A.exportarLetivos = () => { const t = turmaAtual(), c = contagemLetiva(t), fx = n => String(Math.round(n * 10) / 10).replace('.', ','); saidaDocumento(docBase('Dias_letivos_' + t.ano, 'Dias letivos e carga horária — ' + rotuloTurma(t), [{ t: 'p', txt: 'Início do ano letivo: ' + dataBR(c.ini) + '.' }, { t: 'tabela', cab: ['Período', 'De', 'Até', 'Dias letivos', 'Horas'], linhas: c.ps.map(p => [p.rot, dataBR(p.ini), dataBR(p.fim), String(p.dias), fx(p.horas)]).concat([['Total', '', '', String(c.dias), fx(c.horas)]]) }, { t: 'nota', txt: 'Contagem feita pelo calendário da Tecelã. Mínimos definidos pela legislação: ' + minDias() + ' dias letivos e ' + minHoras() + ' horas.' }]), { assunto: 'Dias letivos ' + t.ano }); };

/* ---------- festas do ano (hemisfério sul), com a preparação em tarefas ---------- */
function pascoa(a) { const b = a % 19, c = Math.floor(a / 100), d = a % 100, f = Math.floor(c / 4), g = c % 4, h = Math.floor((8 * c + 13) / 25), i = (19 * b + c - f - h + 15) % 30, j = Math.floor(d / 4), k = d % 4, l = (32 + 2 * g + 2 * j - i - k) % 7, m = Math.floor((b + 11 * i + 22 * l) / 451), mes = Math.floor((i + l - 7 * m + 114) / 31), dia = ((i + l - 7 * m + 114) % 31) + 1; return a + '-' + String(mes).padStart(2, '0') + '-' + String(dia).padStart(2, '0'); }
const advento = a => { let d = a + '-12-24'; while (new Date(d + 'T12:00').getDay() !== 0) d = somaDias(d, -1); return somaDias(d, -21); };
/* As festas padrão. A data é “MM-DD” (fixa) ou relativa à Páscoa (“pascoa:+0”) ou ao 1º domingo do Advento
   (“advento:-2”); os passos são [dias antes da festa, o que fazer]. A professora pode editar, incluir e excluir:
   a lista dela fica em CFG.prefs.festas (sem ela, vale a padrão). */
const FESTAS_PADRAO = [
  { k: 'colheita', nome: 'Festa da Colheita', quando: '03-20', passos: [[21, 'Escolher com as crianças o que será colhido e preparado'], [14, 'Comunicado às famílias: o que cada uma traz'], [7, 'Ensaiar as canções e os versos da colheita'], [1, 'Preparar a mesa e os enfeites com as crianças']] },
  { k: 'pascoa', nome: 'Páscoa', quando: 'pascoa:+0', passos: [[21, 'Preparar os versos e as canções da Páscoa'], [14, 'Comunicado às famílias sobre a festa'], [7, 'Preparar o jardim e os ninhos com as crianças']] },
  { k: 'lanternas', nome: 'Festa das Lanternas', quando: '05-29', passos: [[28, 'Escolher o modelo da lanterna e separar o material'], [21, 'Confeccionar as lanternas com as crianças'], [14, 'Ensaiar as canções das lanternas'], [7, 'Comunicado às famílias: horário, percurso e agasalho']] },
  { k: 'saojoao', nome: 'Festa de São João', quando: '06-24', passos: [[30, 'Ensaiar as danças e as canções'], [21, 'Comunicado às famílias: comidas, trajes e barracas'], [7, 'Preparar os enfeites com as crianças'], [2, 'Organizar a fogueira e a segurança']] },
  { k: 'micael', nome: 'Festa de Micael', quando: '09-29', passos: [[28, 'Contar a lenda de São Jorge e o dragão; preparar a peça ou as provas de coragem'], [14, 'Preparar o percurso das provas de coragem'], [7, 'Comunicado às famílias'], [2, 'Pão do dragão: ingredientes e forno']] },
  { k: 'primavera', nome: 'Festa da Primavera', quando: '09-22', passos: [[21, 'Ensaiar as canções e a roda da primavera'], [14, 'Comunicado às famílias: flores e trajes'], [3, 'Preparar as coroas de flores']] },
  { k: 'advento', nome: 'Espiral do Advento', quando: 'advento:-2', passos: [[21, 'Ensaiar a canção e o verso da espiral'], [10, 'Pedir às famílias maçãs e velas'], [3, 'Montar a espiral de ramos'], [1, 'Combinar com a escola o silêncio e a luz da sala']] },
  { k: 'natal', nome: 'Auto de Natal e encerramento', quando: '12-11', passos: [[35, 'Escolher o auto ou a peça e distribuir os papéis'], [28, 'Ensaiar com as crianças'], [14, 'Comunicado às famílias: data, horário e figurino'], [3, 'Ensaio geral']] }];
const festasLista = () => Array.isArray(CFG.prefs.festas) ? CFG.prefs.festas : FESTAS_PADRAO;
function dataFesta(f, a) {
  const m = String(f.quando || '').match(/^(pascoa|advento):([+-]?\d+)$/);
  if (m) return somaDias(m[1] === 'pascoa' ? pascoa(a) : advento(a), Number(m[2]));
  return /^\d{2}-\d{2}$/.test(f.quando) ? a + '-' + f.quando : '';
}
const rotQuando = f => { const m = String(f.quando || '').match(/^(pascoa|advento):([+-]?\d+)$/); if (!m) return /^\d{2}-\d{2}$/.test(f.quando) ? 'todo ano em ' + f.quando.slice(3) + '/' + f.quando.slice(0, 2) : '—'; const n = Number(m[2]), b = m[1] === 'pascoa' ? 'Páscoa' : '1º domingo do Advento'; return n ? Math.abs(n) + ' dia' + (Math.abs(n) > 1 ? 's' : '') + (n < 0 ? ' antes ' : ' depois ') + (m[1] === 'pascoa' ? 'da ' : 'do ') + b : 'no dia ' + (m[1] === 'pascoa' ? 'da ' : 'do ') + b; };
const rotPasso = ([d, x]) => (d > 0 ? d + ' dia' + (d > 1 ? 's' : '') + ' antes: ' : 'no dia: ') + x;
async function gravarFestas(xs, msg) { await prefs({ festas: xs }); marcarPendente(); render(); if (msg) aviso(msg); }
function cartaoFestas(t) {
  const xs = festasLista(), ja = new Set(D.eventos.filter(v => v.festa && (v.data || '').startsWith(String(t.ano))).map(v => v.festa));
  return '<div class="cartao"><h3>Festas do ano</h3><p>As festas do ano com a lista de preparação de cada uma. Ao colocar no calendário, a festa entra na agenda e cada passo vira uma tarefa com prazo. A lista é sua: edite, inclua ou exclua festas.</p>' +
    (xs.length ? '<div class="rolagem"><table class="tabela"><tr><th>Festa</th><th>Data em ' + t.ano + '</th><th>Preparação</th><th></th></tr>' + xs.map((f, i) => '<tr><td><b>' + e(f.nome) + '</b>' + (ja.has(f.k) ? ' <span class="etq fin">no calendário</span>' : '') + '<br><span class="dica">' + e(rotQuando(f)) + '</span></td><td>' + (dataFesta(f, t.ano) ? dataBR(dataFesta(f, t.ano)) + '<br><span class="dica">' + diaSemana(dataFesta(f, t.ano)) + '</span>' : '—') + '</td><td class="dica">' + (f.passos || []).map(x => e(rotPasso(x))).join('<br>') + '</td><td style="white-space:nowrap"><button class="btn peq" data-a="festaEditar" data-i="' + i + '">Editar</button> <button class="icone-btn" data-a="festaExcluir" data-i="' + i + '" title="Excluir da lista">✕</button></td></tr>').join('') + '</table></div>' : vazio('Nenhuma festa na lista.')) +
    '<div class="linha"><button class="btn pri" data-a="festas">Colocar no calendário</button><button class="btn" data-a="festaNova">+ Festa</button>' + (Array.isArray(CFG.prefs.festas) ? '<button class="btn" data-a="festasPadrao">Voltar à lista original</button>' : '') + '</div></div>';
}
async function dialogoFesta(f) {
  const m = String(f.quando || '').match(/^(pascoa|advento):([+-]?\d+)$/), tipo = m ? m[1] : 'fixa', n = m ? Number(m[2]) : 0, t = turmaAtual();
  const v = await dlg({ titulo: f.nome ? 'Editar: ' + f.nome : 'Nova festa', largo: true, ok: 'Salvar', corpo: campo('Nome da festa', '<input name="nome" value="' + e(f.nome || '') + '">') +
    '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr))">' + campo('A data é', '<select name="tipo"><option value="fixa"' + (tipo === 'fixa' ? ' selected' : '') + '>Fixa (o mesmo dia todo ano)</option><option value="pascoa"' + (tipo === 'pascoa' ? ' selected' : '') + '>Ligada à Páscoa</option><option value="advento"' + (tipo === 'advento' ? ' selected' : '') + '>Ligada ao 1º domingo do Advento</option></select>') +
    campo('Dia fixo', '<input type="date" name="dia" value="' + (tipo === 'fixa' && /^\d{2}-\d{2}$/.test(f.quando || '') ? t.ano + '-' + f.quando : '') + '">', 'Só o dia e o mês contam.') + campo('Dias depois (ou antes, com “-”)', '<input type="number" name="n" value="' + n + '">', 'Para datas ligadas à Páscoa ou ao Advento. Ex.: -2 = dois dias antes.') + '</div>' +
    campo('Preparação: um passo por linha, com os dias antes da festa', '<textarea name="passos" style="min-height:9rem" placeholder="21: Ensaiar as canções&#10;7: Comunicado às famílias&#10;0: Arrumar a sala no dia">' + e((f.passos || []).map(([d, x]) => d + ': ' + x).join('\n')) + '</textarea>', 'Escreva o número de dias antes da festa, dois-pontos e o que fazer. Use 0 para o próprio dia.'),
    validar: x => !x.nome.trim() ? 'Escreva o nome da festa.' : x.tipo === 'fixa' && !x.dia ? 'Escolha o dia da festa.' : null });
  if (!v) return null;
  const passos = v.passos.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const q = l.match(/^(\d+)\s*(?:dias?\s*(?:antes)?)?\s*[:\-–]\s*(.+)$/i); return q ? [Number(q[1]), q[2].trim()] : [0, l]; }).sort((a, b) => b[0] - a[0]);
  return Object.assign({}, f, { k: f.k || 'f' + uid(), nome: v.nome.trim(), quando: v.tipo === 'fixa' ? v.dia.slice(5) : v.tipo + ':' + (Number(v.n) >= 0 ? '+' : '') + (Number(v.n) || 0), passos });
}
A.festaEditar = async d => { const xs = clone(festasLista()), i = Number(d.i), f = await dialogoFesta(xs[i]); if (!f) return; xs[i] = f; await gravarFestas(xs, 'Festa salva.'); };
A.festaNova = async () => { const f = await dialogoFesta({ quando: '', passos: [] }); if (!f) return; await gravarFestas(clone(festasLista()).concat([f]), 'Festa incluída.'); };
A.festaExcluir = async d => { const xs = clone(festasLista()), f = xs[Number(d.i)]; if (!(await confirmar('Excluir “' + e(f.nome) + '” da lista?', 'A festa sai da lista de festas do ano. O que já foi colocado no calendário (o evento e as tarefas) continua lá: apague no calendário, se quiser.', 'Excluir'))) return; xs.splice(Number(d.i), 1); await gravarFestas(xs, 'Festa excluída da lista.'); };
A.festasPadrao = async () => { if (!(await confirmar('Voltar à lista original?', 'As festas que você editou, incluiu ou excluiu voltam a ser as da lista original da Tecelã. O que já está no calendário não muda.', 'Voltar'))) return; await prefs({ festas: null }); marcarPendente(); render(); aviso('Lista original de festas restaurada.'); };
A.festas = async () => {
  const t = turmaAtual(), a = t.ano, xs = festasLista(), ja = new Set(D.eventos.filter(v => v.festa && (v.data || '').startsWith(String(a))).map(v => v.festa));
  if (!xs.length) return aviso('A lista de festas está vazia. Use “+ Festa”.');
  const v = await dlg({ titulo: 'Festas de ' + a, largo: true, ok: 'Colocar no calendário', corpo: '<p class="dica">Marque as festas e confira as datas com o calendário da escola. Cada passo vira uma tarefa, com prazo contado a partir da data da festa.</p><div class="rolagem"><table class="tabela"><tr><th></th><th>Festa</th><th>Data</th><th>Preparação</th></tr>' +
    xs.map(f => '<tr><td><input type="checkbox" name="f_' + f.k + '"' + (ja.has(f.k) ? ' disabled' : '') + '></td><td><b>' + e(f.nome) + '</b>' + (ja.has(f.k) ? '<br><span class="dica">já está no calendário</span>' : '') + '</td><td><input type="date" name="d_' + f.k + '" value="' + dataFesta(f, a) + '"></td><td class="dica">' + (f.passos || []).map(x => e(rotPasso(x))).join('<br>') + '</td></tr>').join('') + '</table></div>' });
  if (!v) return; let n = 0;
  for (const f of xs) { if (!v['f_' + f.k] || !v['d_' + f.k]) continue; const d = v['d_' + f.k]; await salvar('eventos', { turmaId: null, data: d, titulo: f.nome, tipo: 'festa', festa: f.k, obs: '' }); for (const [o, x] of f.passos || []) await salvar('tarefas', { titulo: f.nome + ': ' + x, data: somaDias(d, -o), obs: 'Preparação: ' + f.nome + ' (' + dataBR(d) + ').', avisar: 3, feita: false }); n++; }
  render(); aviso(n ? n + ' festa' + (n > 1 ? 's' : '') + ' no calendário, com as tarefas de preparação.' : 'Nenhuma festa escolhida.');
};

/* ---------- lista de materiais do ano ---------- */
const MATERIAIS_BASE = ['Cadernos de época sem pauta (um por época), formato grande', 'Giz de cera em bloco e em bastão', 'Lápis de cor de boa qualidade', 'Papel e tintas de aquarela (azul, amarelo e vermelho), pincel chato largo, pote de água e esponja', 'Cera de abelha para modelar', 'Estojo de tecido', 'Avental para pintura'];
const MATERIAIS_SERIE = {
  1: ['Flauta pentatônica', 'Agulhas de tricô de madeira e lã natural'], 2: ['Flauta pentatônica', 'Agulhas de tricô de madeira e lã natural'], 3: ['Flauta doce soprano', 'Agulha de crochê e linha de algodão', 'Caderno de lição de casa'],
  4: ['Flauta doce soprano', 'Agulha, bastidor e linha para bordado', 'Caneta-tinteiro ou caneta de ponta fina'], 5: ['Flauta doce', 'Régua de 30 cm', 'Caneta-tinteiro', 'Agulhas para tricô de meias'], 6: ['Compasso, régua, esquadros e transferidor', 'Flauta doce contralto (se a escola pedir)', 'Lápis grafite 2B e 6B'],
  7: ['Compasso, régua, esquadros e transferidor', 'Lápis grafite e carvão para desenho', 'Calculadora simples (a combinar)'], 8: ['Compasso, régua, esquadros e transferidor', 'Lápis grafite e carvão para desenho', 'Material de costura (a combinar)'], 9: ['Compasso, régua, esquadros e transferidor', 'Lápis grafite e carvão para desenho']};
const MATERIAIS_EPOCA = [[/geometria|formas/i, 'compasso, régua e esquadros (ou giz de cera em bloco, para o desenho de formas)'], [/medida|peso|comprimento/i, 'fita métrica e balança de cozinha (para a classe)'], [/dinheiro|com[eé]rcio/i, 'moedas de brinquedo ou sementes para contar'], [/casa|constru|of[ií]cio|profiss/i, 'argila, gravetos e caixas para maquetes'], [/agricultura|plantio|gr[aã]o|jardinagem|horta/i, 'sementes, luvas e ferramentas pequenas de jardinagem'], [/tempo|rel[oó]gio|calend[aá]rio/i, 'bastão e giz para o relógio de sol'], [/bot[aâ]nica|plantas/i, 'lupa e prensa de flores'], [/zoologia|animais|homem e animal/i, 'lápis de cor e papel para estudos de animais'], [/geografia|mapa|local|regi[aã]o/i, 'papel kraft grande para mapas'], [/f[ií]sica|ac[uú]stica|[oó]tica|eletricidade/i, 'materiais simples para experimentos (a combinar)'], [/astronomia|c[eé]u|estrelas/i, 'papel preto e giz pastel para o céu'], [/qu[ií]mica|combust/i, 'avental e óculos de proteção (a combinar)']];
TIPOS_DOC.materiais = {
  nome: 'Lista de materiais do ano',
  cab: [['entrega', 'Entregar até', 'date']],
  ajuda: 'Sugestão a partir do ano e das épocas do currículo. Tire, acrescente e ajuste à sua escola; as partes com ↻ podem ser montadas de novo.',
  gerar: d => {
    const t = IX.turmas[d.turmaId], eps = D.curriculo.filter(c => c.serie === t.serie).sort((a, b) => (a.ordem || 0) - (b.ordem || 0)), linhas = [];
    eps.forEach(c => { const ms = MATERIAIS_EPOCA.filter(([re]) => re.test(c.titulo + ' ' + (c.componente || '') + ' ' + (c.conteudos || ''))).map(x => x[1]); if (ms.length) linhas.push([c.titulo, [...new Set(ms)].join('; ')]); });
    return { titulo: 'Lista de materiais — ' + rotuloTurma(t), cab: { entrega: '' }, secoes: [secTexto('apresentacao', 'Para as famílias', 'Queridas famílias, estes são os materiais do ' + t.serie + 'º ano. Na pedagogia Waldorf, cuidamos para que sejam bonitos, simples e de boa qualidade: eles acompanham as crianças o ano inteiro. Sempre que possível, marque cada material com o nome da criança.'), secTexto('gerais', 'Materiais do ano', MATERIAIS_BASE.map(x => '- ' + x).join('\n')), secTexto('serie', 'Próprios do ' + t.serie + 'º ano', (MATERIAIS_SERIE[t.serie] || []).map(x => '- ' + x).join('\n')), secTabela('epocas', 'Para as épocas', ['Época', 'Material sugerido'], linhas.length ? linhas : [['', '']])] };
  },
  cabDoc: d => { const t = IX.turmas[d.turmaId] || {}, c = d.cab || {}; return ['Turma: ' + rotuloTurma(t), c.entrega ? 'Entregar até: ' + dataBR(c.entrega) : '']; }
};
A.materiaisNovo = async () => { const t = turmaAtual(), x = await criarDoc('materiais', { turmaId: t.id }); UI.sub = x.id; render(); window.scrollTo(0, 0); aviso('Lista de materiais montada. Revise antes de enviar.'); };

/* ---------- conferência dos textos do boletim ---------- */
const frasesDe = txt => String(txt || '').split(/(?<=[.!?])\s+|\n+/).map(f => f.trim()).filter(f => f.split(/\s+/).length >= 6);
function conferirBoletins(t) {
  const al = alunosDaTurma(t.id), bols = boletinsAtuais(t.id), mod = modeloDaSerie(t.serie), ativas = mod.secoes.filter(s => s.ativa), r = { repetidas: [], tamanho: [], genero: [] };
  const frases = {}; al.forEach(a => { const b = bols[a.id]; if (!b) return; ativas.forEach(s => frasesDe(((b.secoes || {})[s.key] || {}).texto).forEach(f => { const k = norm(f.split(primeiroNome(a)).join('{nome}').split(a.nome).join('{nome}')); (frases[k] = frases[k] || { f, quem: new Set() }).quem.add(primeiroNome(a)); })); });
  Object.values(frases).filter(x => x.quem.size >= 3).sort((x, y) => y.quem.size - x.quem.size).forEach(x => r.repetidas.push(x));
  ativas.forEach(s => { const ns = al.map(a => [a, String((((bols[a.id] || {}).secoes || {})[s.key] || {}).texto || '').trim().split(/\s+/).filter(Boolean).length]).filter(x => x[1]); if (ns.length < 3) return; const ord = ns.map(x => x[1]).sort((a, b) => a - b), med = ord[Math.floor(ord.length / 2)]; ns.forEach(([a, n]) => { if (n < med * .35) r.tamanho.push([a, s.titulo || s.key, n + ' palavras (a turma tem cerca de ' + med + ')', 'curta']); else if (n > med * 2.6) r.tamanho.push([a, s.titulo || s.key, n + ' palavras (a turma tem cerca de ' + med + ')', 'longa']); }); });
  const ELE = /\b(o aluno|ele|dele|nele|sozinho|atento|tranquilo|cuidadoso|concentrado|o menino)\b/i, ELA = /\b(a aluna|ela|dela|nela|sozinha|atenta|tranquila|cuidadosa|concentrada|a menina)\b/i;
  al.forEach(a => { const b = bols[a.id]; if (!b) return; const tx = ativas.map(s => ((b.secoes || {})[s.key] || {}).texto || '').join(' '), m = (a.genero === 'f' ? ELE : ELA).exec(tx); if (m) r.genero.push([a, '“' + m[0] + '”', tx.slice(Math.max(0, m.index - 50), m.index + 50).replace(/\s+/g, ' ')]); });
  return r;
}
A.conferirBol = async () => {
  await descarregarFila(); const t = turmaAtual(), r = conferirBoletins(t), tot = r.repetidas.length + r.tamanho.length + r.genero.length;
  informar('Conferência dos textos', tot ? (r.repetidas.length ? '<h3>Frases iguais em três ou mais boletins</h3><p class="dica">Cada criança merece um texto só dela: veja se vale reescrever.</p><ul>' + r.repetidas.slice(0, 12).map(x => '<li>“' + e(x.f.slice(0, 160)) + '” — ' + e([...x.quem].join(', ')) + '</li>').join('') + '</ul>' : '') +
    (r.tamanho.length ? '<h3>Seções muito curtas ou muito longas</h3><ul>' + r.tamanho.map(([a, s, n, k]) => '<li><a href="#" data-x="c" data-a="abrirBol" data-al="' + a.id + '">' + e(primeiroNome(a)) + '</a> · ' + e(s) + ': ' + (k === 'curta' ? 'curta' : 'longa') + ', ' + e(n) + '</li>').join('') + '</ul>' : '') +
    (r.genero.length ? '<h3>Concordância de gênero para conferir</h3><ul>' + r.genero.map(([a, w, ctx]) => '<li><a href="#" data-x="c" data-a="abrirBol" data-al="' + a.id + '">' + e(primeiroNome(a)) + '</a> (' + (a.genero === 'f' ? 'feminino' : 'masculino') + '): ' + e(w) + ' em “…' + e(ctx) + '…”</li>').join('') + '</ul>' : '') + '<p class="dica">É só um apoio: o olhar final é sempre seu.</p>' : '<p>Nada a apontar: sem frases repetidas, sem seções muito fora do tamanho da turma e sem concordância de gênero para conferir.</p>');
};
