#!/usr/bin/env python3
"""Gera src/bncc-computacao.js a partir do PDF "BNCC Computação — completo diagramado"
(complemento de Computação à BNCC, Parecer CNE/CEB nº 2/2022 e Resolução CNE/CEB nº 1/2022).

Uso: python3 -I ferramentas/extrair_computacao.py caminho/BNCCComputaoCompletodiagramado.pdf
Precisa do pdfplumber. Lê as tabelas do Ensino Fundamental (eixo, objeto de conhecimento,
habilidade) e as páginas da direita (explicação da habilidade e exemplos), que são casadas
com cada habilidade pela posição vertical das linhas. As habilidades "por etapa" (EF15 e EF69)
entram marcadas com etapa=1; as EF69 levam a explicação da habilidade equivalente do ano.
"""
import sys, re, json, difflib, pathlib
import pdfplumber

RAIZ = pathlib.Path(__file__).resolve().parent.parent
TS = {"text_x_tolerance": 1.2, "text_y_tolerance": 3}
limpa = lambda s: re.sub(r'\s+', ' ', (s or '').replace('\n', ' ')).strip()
hifen = lambda t: re.sub(r'(\w)- (\w)', r'\1-\2', t)

def eixo_de(s):
    s = (s or '').replace('\n', '').replace(' ', '').upper()
    if 'LANOICATUPMOC' in s or 'COMPUTACIONAL' in s: return 'Pensamento computacional'
    if 'ODNUM' in s or 'MUNDO' in s: return 'Mundo digital'
    if 'ARUTLUC' in s or 'CULTURA' in s: return 'Cultura digital'

def ler(pdf_path):
    pdf = pdfplumber.open(pdf_path); hab, pend, carry = [], [], {}
    for pi, p in enumerate(pdf.pages):
        if pi < 14 or pi >= 64: continue          # páginas do Ensino Fundamental
        for tb in p.find_tables(TS):
            t, rows = tb.extract(x_tolerance=1.2, y_tolerance=3), tb.rows
            cab = [limpa(c).upper() for c in t[0]]
            if any('OBJETO' in c for c in cab):
                pend = []
                for r, row in zip(t[1:], rows[1:]):
                    cells = [limpa(c) for c in r]; e = eixo_de(r[0])
                    if e: carry['eixo'] = e
                    k = [i for i, c in enumerate(cells) if re.match(r'\(EF\d\dCO0?\d\d\)', c)]
                    for i in range(1, len(cells)):
                        if cells[i] and (not k or i < k[0]): carry[i] = cells[i]
                    if not k: continue
                    i = k[0]; m = re.match(r'\((EF\d\dCO)0?(\d\d)\)\s*(.*)', cells[i]); cb = row.cells[i]
                    h = {'cod': m.group(1) + m.group(2), 'eixo': carry.get('eixo'), 'objs': [carry.get(j, '') for j in range(1, i)], 'txt': m.group(3),
                         'y': (cb[1], cb[3]) if cb else (row.bbox[1], row.bbox[3]), 'exp': [], 'ex': []}
                    hab.append(h); pend.append(h)
            elif any('EXPLICA' in c for c in cab) and pend:
                ix = [i for i, c in enumerate(cab) if 'EXPLICA' in c][0]; iex = [i for i, c in enumerate(cab) if 'EXEMPLO' in c][0]
                for r, row in zip(t[1:], rows[1:]):
                    y0, y1 = row.bbox[1], row.bbox[3]
                    best = max(pend, key=lambda h: min(y1, h['y'][1]) - max(y0, h['y'][0]))
                    if limpa(r[ix]): best['exp'].append(limpa(r[ix]))
                    if limpa(r[iex]): best['ex'].append(limpa(r[iex]))
    return hab

def main():
    hab = ler(sys.argv[1]); anos = [h for h in hab if h['cod'][2:4] in ('06', '07', '08', '09')]
    junta = lambda xs: hifen(re.sub(r'\s+([,.;:])', r'\1', ' '.join(xs)).strip())
    out = []
    for h in hab:
        a = h['cod'][2:4]; rng = [1, 2, 3, 4, 5] if a == '15' else [6, 7, 8, 9] if a == '69' else [int(a)]
        meta = {'e': h['eixo'], 'o': ' › '.join(x for x in h['objs'][:2] if x) if a in ('06', '07', '08', '09', '69') else (h['objs'][0] if h['objs'] else '')}
        exp, ex = junta(h['exp']), junta(h['ex'])
        if a == '69':   # a página da direita desta tabela vem embaralhada no PDF: usa a habilidade igual do ano
            b = max(anos, key=lambda x: difflib.SequenceMatcher(None, x['txt'], h['txt']).ratio()); exp, ex = junta(b['exp']), junta(b['ex']); meta['eq'] = b['cod']
        if a in ('15', '69'): meta['etapa'] = 1
        meta['x'], meta['ex'] = exp, ex
        txt = hifen(h['txt'].strip()); txt += '' if txt.endswith('.') else '.'
        out.append([h['cod'], 'CO', rng, txt, meta])
    out.sort(key=lambda r: (r[0][2:4] in ('15', '69'), r[0]))
    print(json.dumps(out, ensure_ascii=False))

if __name__ == '__main__':
    main()
