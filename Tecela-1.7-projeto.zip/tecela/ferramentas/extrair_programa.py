#!/usr/bin/env python3
"""Converte um "Conteúdo programático" (.docx, organizado por ano e componente, com "(N aulas)")
em src/programa-dados.js, sem identificar a escola de origem.
Uso: python3 ferramentas/extrair_programa.py Conteudo_Programatico.docx > src/programa-dados.js"""
import json, re, subprocess, sys
txt = subprocess.run(['pandoc', '-t', 'plain', '--wrap=none', sys.argv[1]], capture_output=True, text=True).stdout
ESCONDE = re.compile(r'escola|waldorf rudolf|EWRS|elaborado pela', re.I)
COMP = re.compile(r'^\s*([^()]{3,90}?)\s*:?\s*\((\d+)\s*aulas\)\s*:?\s*(.*)$')
ANO = re.compile(r'^\s*(\d{1,2})º Ano:?\s*$')
prog, serie, atual = {}, None, None
for linha in txt.split('\n'):
    s = linha.rstrip()
    if not s.strip(): continue
    if re.match(r'^\s*ADENDO', s): atual = {'comp': 'Adendo: Olimpíadas gregas', 'aulas': None, 'linhas': []}; prog[serie].append(atual); continue
    m = ANO.match(s)
    if m:
        serie = int(m.group(1)) if int(m.group(1)) <= 9 else None; atual = None
        if serie: prog[serie] = []
        continue
    if serie is None: continue
    m = COMP.match(s)
    if m:
        nome = re.sub(r'\s*:\s*', ': ', m.group(1)).strip().rstrip(':').strip()
        nome = re.sub(r'^Arte – Música: Música$', 'Arte – Música', nome)
        atual = {'comp': nome.strip(), 'aulas': int(m.group(2)), 'linhas': []}; prog[serie].append(atual)
        if m.group(3).strip(): atual['linhas'].append(m.group(3).strip())
        continue
    if atual is None or ESCONDE.search(s): continue
    t = s.strip()
    sub = len(t) < 45 and not re.search(r'[.;,–\-]', t) and t[0].isupper()
    atual['linhas'].append(('## ' if sub else '') + t)
out = {str(k): [{'comp': c['comp'], 'aulas': c['aulas'], 'texto': '\n'.join(('- ' + l) if not l.startswith('## ') else l for l in c['linhas'])} for c in v] for k, v in prog.items()}
print('/* Conteúdo programático de referência (1º ao 8º ano), por componente, com o número de aulas no ano.')
print('   Adaptado do conteúdo programático de uma escola Waldorf brasileira (2026), sem identificar a escola.')
print('   Gerado por ferramentas/extrair_programa.py. */')
print('const PROG_REF = ' + json.dumps(out, ensure_ascii=False, separators=(',', ':')) + ';')
