#!/usr/bin/env python3
"""Extrai as habilidades do Ensino Fundamental da BNCC (texto do pdftotext) para src/bncc-dados.js.
Uso: pdftotext BNCC_EI_EF_110518_versaofinal_site.pdf bncc.txt
     python3 ferramentas/extrair_bncc.py bncc.txt src/bncc-dados.js
"""
import re, sys, json
COMP = {'LP': 'Língua Portuguesa', 'AR': 'Arte', 'EF': 'Educação Física', 'LI': 'Língua Inglesa', 'MA': 'Matemática',
        'CI': 'Ciências', 'GE': 'Geografia', 'HI': 'História', 'ER': 'Ensino Religioso'}
ANOS = {'12': [1, 2], '15': [1, 2, 3, 4, 5], '35': [3, 4, 5], '67': [6, 7], '69': [6, 7, 8, 9], '89': [8, 9]}
txt = open(sys.argv[1], encoding='utf-8').read().replace('\f', '\n')
txt = re.sub(r'-\n(?=[a-zà-ú])', '', txt)
partes = re.split(r'\((EF\d{2}[A-Z]{2}\d{2})\)', txt)
hab = {}
for i in range(1, len(partes), 2):
    cod, resto = partes[i], partes[i + 1]
    t = re.split(r'\n\s*\n', resto.strip(), 1)[0]
    t = re.sub(r'\s+', ' ', t).strip()
    t = re.sub(r'\s*\d{1,3}\s*(BASE NACIONAL COMUM CURRICULAR|$)', '', t).strip()
    if len(t) < 15: continue
    if cod not in hab or (len(hab[cod]) < 40 < len(t)): hab[cod] = t
dados = []
for cod in sorted(hab):
    a, c = cod[2:4], cod[4:6]
    anos = ANOS.get(a, [int(a)])
    dados.append([cod, c, anos, hab[cod]])
js = ('/* BNCC — habilidades do Ensino Fundamental, extraídas da versão homologada\n'
      '   (BNCC_EI_EF_110518_versaofinal_site.pdf, MEC). Formato: [código, componente, anos, texto]. */\n'
      "'use strict';\nconst BNCC_COMP = " + json.dumps(COMP, ensure_ascii=False) + ';\nconst BNCC = ' +
      json.dumps(dados, ensure_ascii=False, separators=(',', ':')) + ';\n')
open(sys.argv[2], 'w', encoding='utf-8').write(js)
print(len(dados), 'habilidades;', round(len(js) / 1024), 'KB')
from collections import Counter; print(Counter(d[1] for d in dados))
