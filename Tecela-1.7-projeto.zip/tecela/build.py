#!/usr/bin/env python3
"""Monta o HTML único da Tecelã: dist/Tecela.html.

Uso:  python3 build.py
Junta src/index.html + src/estilo.css + vendor/docx.min.js + src/*.js (na ordem
abaixo) e injeta os logotipos de assets/ e o texto da licença (LICENSE). Não precisa de internet.
"""
import json, pathlib, re, urllib.parse

RAIZ = pathlib.Path(__file__).resolve().parent
SRC, VENDOR, ASSETS, DIST = RAIZ / "src", RAIZ / "vendor", RAIZ / "assets", RAIZ / "dist"
ORDEM = ["nucleo.js", "cadastros.js", "bncc-dados.js", "documentos.js", "docmotor.js", "biblioteca.js", "telas-base.js", "telas-docs.js",
         "telas-perfis.js", "calendario.js", "curriculo.js", "bncc-computacao-dados.js", "bncc-computacao.js", "relatorios.js", "apoio.js",
         "turmadocs.js", "programa-dados.js", "planejamento-dados.js", "planejamento.js", "familia.js", "repertorio.js", "rotina.js", "observacao.js", "conselho.js", "rapido.js",
         "telas-config.js", "partilha.js", "importar.js", "ajuda.js", "demo.js", "app.js"]


def ler(p):
    return p.read_text(encoding="utf-8")


def script(codigo, nome):
    codigo = re.sub(r"</(script)", r"<\\/\1", codigo, flags=re.I)
    return f"<script>/* {nome} */\n{codigo}\n</script>"


def main():
    html = ler(SRC / "index.html")
    logos = {k: ler(ASSETS / f"tecela-{n}.svg").strip() for k, n in (("H", "horizontal"), ("V", "vertical"), ("I", "icone"))}
    # o logotipo no app não precisa de largura/altura fixas
    logos = {k: re.sub(r'\swidth="\d+" height="\d+"', "", v, count=1) for k, v in logos.items()}
    js = []
    js.append(script(ler(VENDOR / "docx.min.js"), "docx 9.7.1 · MIT · https://github.com/dolanmiu/docx"))
    for n in ORDEM:
        c = ler(SRC / n)
        for k, v in logos.items():
            c = c.replace(f"'__LOGO_{k}__'", json.dumps(v, ensure_ascii=False))
        # o texto da licença (termos adicionais + GNU GPL v3) vai dentro do app, nos Créditos
        c = c.replace("'__LICENCA__'", json.dumps(ler(RAIZ / "LICENSE"), ensure_ascii=False))
        js.append(script(c, n))
    favicon = "data:image/svg+xml," + urllib.parse.quote(logos["I"])
    html = (html.replace("/*__CSS__*/", ler(SRC / "estilo.css"))
                .replace("__FAVICON__", favicon)
                .replace("<!--__SCRIPTS__-->", "\n".join(js)))
    DIST.mkdir(exist_ok=True)
    saida = DIST / "Tecela.html"
    saida.write_text(html, encoding="utf-8")
    print(f"{saida}  ({saida.stat().st_size / 1024:.0f} KB)")


if __name__ == "__main__":
    main()
