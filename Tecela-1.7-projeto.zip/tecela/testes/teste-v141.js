// Teste das versões 1.4.1 e 1.4.2: seletor do arquivo .tecela em cada aparelho.
// Android: tipos de documento (BIN, JSON, texto), sem imagens, para abrir o seletor de arquivos e não Câmera/Galeria.
// iPhone: sem filtro ("Escolher arquivo"). Computador: filtro pela extensão. Abre um .tecela fictício nos dois celulares.
// Uso: LOG=log.txt node testes/teste-v141.js
const { chromium, devices } = require('playwright');
const path = require('path'), fs = require('fs'), os = require('os');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  // 1. gera um .tecela fictício a partir do modelo
  const pc = await (await b.newContext()).newPage(); pc.on('pageerror', x => erros.push('pc: ' + x.message));
  await pc.goto(APP); await pc.click('[data-a=entrarDemo]'); await pc.waitForTimeout(2500);
  const txt = await pc.evaluate(async () => await pacoteCopia());
  const arq = path.join(os.tmpdir(), 'teste-ficticio.tecela'); fs.writeFileSync(arq, txt);
  certo(await pc.evaluate(() => ACEITA_TECELA === '.tecela,.json,application/json'), 'computador: o seletor continua filtrando .tecela');
  // 2. celular Android: sem filtro e o arquivo abre
  for (const [nome, disp] of [['Android', devices['Galaxy S9+']], ['iPhone', devices['iPhone 13']]]) {
    const ctx = await b.newContext({ ...disp }); await ctx.addInitScript(() => { window.showOpenFilePicker = undefined; });
    const p = await ctx.newPage(); p.on('pageerror', x => erros.push(nome + ': ' + x.message));
    await p.goto(APP); await p.waitForTimeout(800);
    const ac = await p.evaluate(() => ACEITA_TECELA);
    if (nome === 'Android') certo(ac.includes('application/octet-stream') && ac.includes('application/json') && !/image|video|audio|\*/.test(ac), 'Android: filtro de documentos (BIN e JSON), sem câmera nem galeria');
    else certo(ac === '', nome + ': sem filtro (Escolher arquivo)');
    await p.check('#ckLgpd').catch(() => { });
    const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('[data-a=abrirArquivo]')]);
    certo((await fc.element().getAttribute('accept') || '') === ac, nome + ': o campo de arquivo usa esse filtro');
    await fc.setFiles(arq); await p.waitForTimeout(2500);
    certo(await p.evaluate(() => SE.app && D.alunos.length === 9), nome + ': arquivo .tecela aberto (9 crianças fictícias)');
    await ctx.close();
  }
  // 3. arquivo errado é recusado com aviso
  const ctx = await b.newContext({ ...devices['Galaxy S9+'] }); await ctx.addInitScript(() => { window.showOpenFilePicker = undefined; });
  const p = await ctx.newPage(); await p.goto(APP); await p.waitForTimeout(800); await p.check('#ckLgpd').catch(() => { });
  const errado = path.join(os.tmpdir(), 'foto.jpg'); fs.writeFileSync(errado, 'não é tecela');
  const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('[data-a=abrirArquivo]')]); await fc.setFiles(errado); await p.waitForTimeout(1200);
  certo((await p.textContent('#modais')).includes('não é um arquivo da Tecelã'), 'arquivo de outro tipo: aviso e nada alterado');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
