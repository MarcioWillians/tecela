// Varredura: abre todas as telas, abas e relatórios do modelo (computador e celular, tema claro
// e escuro), procura erros no console, telas com erro e conteúdo mais largo que a tela;
// abre os diálogos de todos os botões que só perguntam algo e os cancela.
// Uso: LOG=log.txt node testes/teste-varredura.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), erros = [], log = s => fs.appendFileSync(LOG, s + '\n');
  for (const [nome, vp, tema] of [['computador', { width: 1280, height: 900 }, 'claro'], ['celular', { width: 390, height: 820 }, 'claro'], ['tablet escuro', { width: 820, height: 1100 }, 'escuro']]) {
    const ctx = await b.newContext({ viewport: vp }), p = await ctx.newPage();
    p.on('pageerror', x => erros.push(nome + ' pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push(nome + ' console: ' + m.text()); });
    p.on('dialog', d => d.dismiss());
    await p.goto(APP); await p.waitForTimeout(400);
    const ini = await p.evaluate(() => { if (document.documentElement.scrollWidth <= innerWidth + 1) return ''; const w = innerWidth, x = [...document.querySelectorAll('#app *')].reverse().find(el => el.getBoundingClientRect().right > w + 2); return x ? x.tagName + '.' + x.className + ' ' + (x.innerText || '').slice(0, 50) : '?'; }); if (ini) erros.push(nome + ': tela inicial mais larga que a tela → ' + ini);
    await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2200);
    await p.evaluate(t => { CFG.prefs.tema = t; render(); }, tema);
    const telas = await p.evaluate(() => {
      const r = []; TELAS.forEach(([k]) => r.push([k, null, null]));
      [['turma', ['alunos', 'turma', 'virada', 'arquivo']], ['bol', ['alunos', 'turma', 'poemas', 'secoes']], ['obs', ['crianca', 'turma']], ['conselho', ['pre', 'reg', 'pos']], ['agenda', ['mes', 'lista', 'ano']], ['tarefas', ['pend', 'feitas']], ['curric', ['escola', 'bncc', 'comp']], ['timbrado', ['atas', 'boletins']], ['ajuda', ['manual', 'creditos', 'privacidade', 'sobre']]].forEach(([t, as]) => as.forEach(a => r.push([t, a, null])));
      Object.keys(LISTAS).forEach(k => r.push(['cadastros', k, null]));
      RELATORIOS.forEach(([k]) => { if (k !== 'cobertura' && k !== 'conselho') r.push(['relat', null, k]); });
      r.push(['atas', null, 'ata1'], ['atas', null, 'ataCons1'], ['bol', null, 'bAna'], ['bol', null, 'bBento'], ['viv', null, 'viv1'], ['turma', 'alunos', 'tomas'], ['biblio', null, 'rubicao']);
      return r;
    });
    for (const [t, a, s] of telas) {
      const res = await p.evaluate(([t, a, s]) => { if (a) UI.aba[t] = a; UI.tela = t; UI.sub = s; render(); const txt = $('#app').innerText; return { erro: /Erro ao montar/.test(txt), larg: document.documentElement.scrollWidth > innerWidth + 1, el: (() => { const w = innerWidth; const fora = el => { const r = el.getBoundingClientRect(); return r.right > w + 2 && !el.closest('.rolagem') && getComputedStyle(el).position !== 'fixed'; }; const x = [...document.querySelectorAll('#app *')].reverse().find(el => fora(el) && ![...el.children].some(fora)); return x ? x.tagName + '.' + x.className + ' ' + (x.innerText || '').slice(0, 40) : ''; })() }; }, [t, a, s]);
      if (res.erro) erros.push(nome + ': erro ao montar ' + [t, a, s].join('/'));
      if (res.larg) erros.push(nome + ': mais larga que a tela em ' + [t, a, s].filter(Boolean).join('/') + ' → ' + res.el);
    }
    for (const f of ['familia', 'estudo', 'conselho', 'evolucao']) { const ok = await p.evaluate(f => { UI.filtro.fichaFin = f; UI.tela = 'relat'; UI.sub = 'ficha'; render(); return !/Erro ao montar/.test($('#app').innerText); }, f); if (!ok) erros.push(nome + ': ficha ' + f); }
    if (nome === 'computador') {
      // diálogos: abre e cancela
      for (const [tela, sub, acao, ds] of [['anot', null, 'anotar', {}], ['atas', null, 'novaAta', {}], ['agenda', null, 'novoEvento', {}], ['agenda', null, 'variosEventos', {}], ['agenda', null, 'imprimirMes', {}], ['agenda', null, 'exportarIcs', {}], ['tarefas', null, 'novaTarefa', {}], ['tarefas', null, 'exportarTarefas', {}], ['bol', null, 'zipBoletins', {}], ['conselho', null, 'exportarPreConselho', {}], ['turma', null, 'novoAluno', null], ['painel', null, 'mais', {}]]) {
        if (ds === null) continue;
        await p.evaluate(([t, s, a, d]) => { UI.tela = t; UI.sub = s; render(); A[a](d); }, [tela, sub, acao, ds]); await p.waitForTimeout(250);
        const m = await p.$('#modais .modal'); if (!m) { erros.push('diálogo não abriu: ' + acao); continue; }
        await p.evaluate(() => { const x = $('#modais [data-x=c]'); if (x) x.click(); else $('#modais').innerHTML = ''; }); await p.waitForTimeout(150);
      }
      // todos os documentos geram DOCX
      const docs = await p.evaluate(async () => { const r = []; const t = turmaAtual(); for (const [k] of RELATORIOS) { if (!REL[k]) continue; const x = REL[k](t); if (x.doc) r.push([k, (await docxBlob(x.doc)).size]); } r.push(['ata', (await docxBlob(docAta(IX.atas.ataCons1))).size], ['boletim', (await docxBlob(docBoletim(IX.boletins.bAna))).size]); return r; });
      docs.forEach(([k, n]) => { if (!(n > 3000)) erros.push('DOCX pequeno demais: ' + k); }); log('documentos: ' + docs.map(x => x.join(' ')).join(', '));
    }
    log(nome + ': ' + telas.length + ' telas percorridas');
    await ctx.close();
  }
  log(erros.length ? 'ERROS:\n' + erros.join('\n') : 'Sem erros'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
