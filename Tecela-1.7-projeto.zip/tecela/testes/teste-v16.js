// Testes da versão 1.6: correções (datas, menu, reforço, PDF), pedidos da professora (Salvar, finalizar todos,
// excluir e arquivar turma, virada com pendências, 9º ano oculto, licença e autoria) e as funções novas
// (substituto, emergência e autorização, entrevista, estudo de criança, contatos, comunicados, repertório,
// avaliação da época, dias letivos, festas, materiais, conferência do boletim e chamada).
// Uso: LOG=log.txt node testes/teste-v16.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR' }), p = await ctx.newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  const fechar = async () => { const m = p.locator('#modais .modal').last(); if (await m.count()) { if (await m.locator('[data-x=c]').count()) await m.locator('[data-x=c]').first().click(); else await m.locator('button.pri').click(); } await p.waitForTimeout(150); };
  const texto = () => p.textContent('#app');
  const docTxt = f => p.evaluate(f => JSON.stringify(eval(f).blocos), f);

  // tela inicial: versão e autoria
  await p.goto(APP); let t = await texto();
  certo(/Versão 1\.[67]/.test(t) && /criada por Márcio Willians Barreto de Andrade/.test(t) && /Contra a pirataria/.test(t), 'tela inicial com a versão e o aviso de autoria');
  await p.click('[data-a=verLicenca]'); let m = await modal(); const lic = await m.textContent(); certo(/GNU GENERAL PUBLIC LICENSE/.test(lic) && /TERMOS ADICIONAIS/.test(lic) && /não tem responsabilidade sobre as alterações/.test(lic), 'licença GPL v3 com os termos adicionais'); await fechar();
  await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);

  // A5/A6: Salvar e indicador
  t = await texto(); certo(/💾 Salvar/.test(t) && !/💾 Guardar/.test(t), 'botão “Salvar”');
  certo(await p.locator('.estado-salvo').count() === 1, 'indicador de salvamento no topo');
  await p.click('.estado-salvo'); m = await modal(); certo(/gravado sozinho/.test(await m.textContent()) && /arquivo \.tecela é a cópia que vale/.test(await m.textContent()), 'explicação de como a Tecelã salva'); await fechar();

  // A3: o menu mantém a posição da rolagem
  await p.evaluate(() => { document.querySelector('.lado').scrollTop = 300; }); const y0 = await p.evaluate(() => document.querySelector('.lado').scrollTop);
  await p.click('.lado .nav button[data-t=reforco]'); await p.waitForTimeout(300);
  certo(y0 > 50 && Math.abs(await p.evaluate(() => document.querySelector('.lado').scrollTop) - y0) < 5, 'menu lateral mantém a rolagem ao trocar de tela');
  certo(/Recentes/.test(await p.textContent('.lado .nav')), 'menu com telas recentes');
  await p.click('.lado .nav button.grupo[data-g="Ajustar"]'); await p.waitForTimeout(200); certo(await p.locator('.lado .nav button[data-t=cadastros]').count() === 0, 'grupo do menu recolhe'); await p.click('.lado .nav button.grupo[data-g="Ajustar"]');

  // A2: data de nascimento digitada
  await p.evaluate(() => { UI.sub = null; ir('turma', null, 'alunos'); }); await p.click('[data-a=novoAluno]'); await p.waitForTimeout(500);
  await p.click('[data-b=nasc]'); await p.keyboard.type('05122018', { delay: 90 }); await p.click('h2'); await p.waitForTimeout(600);
  certo(await p.evaluate(() => /^2018-/.test(IX.alunos[UI.sub].nasc)), 'data de nascimento com o ano certo ao digitar');
  certo(/Saúde e segurança/.test(await texto()), 'cadastro com saúde e segurança');
  await p.evaluate(async () => { const a = IX.alunos[UI.sub]; await apagar('alunos', a.id); const m = D.matriculas.find(x => x.alunoId === a.id); if (m) await apagar('matriculas', m.id); UI.sub = null; });

  // A10/A13: reforço com horário de saída e encontros
  await p.evaluate(() => ir('reforco')); await p.click('[data-a=editarReforco]'); m = await modal();
  certo(await m.locator('input[name=saida][type=time]').count() === 1 && await m.locator('input[name=saida]').inputValue() === '15:00', 'saída do reforço em campo de horário'); await fechar();
  const rid = await p.evaluate(() => D.reforcos[0].id), d0 = await p.evaluate(() => D.reforcos[0].datas[0]);
  await p.click('[data-a=refEncontro][data-d="' + d0 + '"]'); m = await modal(); await m.locator('label:has(input[value=realizado])').click(); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(([id, d]) => { const x = IX.reforcos[id]; return x.encontros[d] === 'realizado' && !itensAgenda(d, d).some(i => i.origem === 'reforço'); }, [rid, d0]), 'encontro realizado sai da agenda');
  certo(await p.evaluate(id => /Davi está sendo chamado/.test(textoBilhete(IX.reforcos[id], IX.alunos.davi, turmaAtual())) && /saída será às 15h/.test(textoBilhete(IX.reforcos[id], IX.alunos.davi, turmaAtual())), rid), 'bilhete com o horário de saída');

  // A11: nome do PDF
  certo(await p.evaluate(() => { let tit = ''; const pr = window.print; window.print = () => { tit = document.title; }; exportarPDF(docGrade(turmaAtual())); return new Promise(r => setTimeout(() => { window.print = pr; window.dispatchEvent(new Event('afterprint')); r(tit === 'Horario_semanal_3ano_2026' && document.title !== tit); }, 150)); }), 'PDF com o nome do documento');

  // B8: prévia na saída
  await p.evaluate(() => { saidaDocumento(docGrade(turmaAtual()), {}); }); m = await modal(); certo(await m.locator('.prev-saida .previa').count() === 1, 'prévia antes de exportar'); await fechar();

  // A4: finalizar todos os boletins prontos
  await p.evaluate(() => { UI.sub = null; ir('bol'); }); await p.click('[data-a=finalizarTodos]'); m = await modal(); const txf = await m.textContent();
  certo(/Ficam de fora|Nenhum boletim pronto|Serão finalizados/.test(txf), 'finalizar todos lista prontos e incompletos');
  if (/Serão finalizados/.test(txf)) { await m.locator('button.pri').click(); await p.waitForTimeout(600); certo(await p.evaluate(() => Object.values(boletinsAtuais(turmaAtual().id)).filter(b => b.estado === 'finalizado').every(b => b.hash)), 'boletins finalizados com impressão digital'); } else await fechar();
  await p.click('[data-a=conferirBol]'); m = await modal(); certo(/Conferência dos textos/.test(await m.textContent()), 'conferência dos textos do boletim'); await fechar();
  certo(await p.evaluate(() => { const t = turmaAtual(), b = Object.values(boletinsAtuais(t.id))[0]; const a = IX.alunos[b.alunoId]; const k = Object.keys(b.secoes)[0]; const old = b.secoes[k].texto; b.secoes[k].texto = old + (a.genero === 'f' ? ' Ele ficou muito atento.' : ' Ela ficou muito atenta.'); const r = conferirBoletins(t); b.secoes[k].texto = old; return r.genero.some(x => x[0].id === a.id); }), 'conferência aponta concordância de gênero');

  // A7: arquivar e excluir turma
  const tid = await p.evaluate(async () => { const x = await salvar('turmas', { serie: 4, letra: 'B', ano: 2026, professora: 'Teste', boletim: { textos: {} } }); await salvar('matriculas', { alunoId: 'bento', turmaId: x.id, faltas: [] }); return x.id; });
  await p.evaluate(() => { UI.sub = null; ir('turma', null, 'turma'); }); await p.click('[data-a=arquivarTurma][data-id="' + tid + '"]'); await p.waitForTimeout(300);
  certo(await p.evaluate(id => IX.turmas[id].arquivada && !turmasVisiveis().some(x => x.id === id), tid), 'turma arquivada sai do seletor');
  await p.click('[data-a=excluirTurma][data-id="' + tid + '"]'); m = await modal(); certo(/1 matrículas/.test(await m.textContent()), 'excluir turma mostra o que vai junto'); await m.locator('button.pri').click(); await p.waitForTimeout(500);
  certo(await p.evaluate(id => !IX.turmas[id] && !D.matriculas.some(x => x.turmaId === id) && !!IX.alunos.bento, tid), 'turma excluída, criança de outra turma mantida');

  // A9: virada mostra pendências
  await p.evaluate(() => ir('turma', null, 'virada')); t = await texto(); certo(/continua aberto/.test(t) && /Pendências de 2026/.test(t) && await p.locator('input[name=tarefas]').count() === 1, 'virada avisa que o ano anterior segue editável e lista pendências');

  // A14: 9º ano oculto
  await p.evaluate(() => ir('turma', null, 'turma')); certo(!(await p.locator('select[data-b=serie] option[value="9"]').count()), '9º ano oculto por padrão');
  await p.evaluate(() => ir('ajustes')); certo(await p.locator('[data-c=mostrar9]').count() === 1 && /início do ensino médio/.test(await texto()), 'opção de mostrar o 9º ano em Ajustes');

  // C13: chamada
  await p.evaluate(() => { UI.sub = null; ir('painel'); });
  if (await p.locator('[data-a=chamada]').count()) { const f0 = await p.evaluate(() => somaFaltas(matricula(turmaAtual().id, 'bento').faltas)); await p.click('[data-a=chamada][data-al=bento]'); await p.waitForTimeout(400); certo(await p.evaluate(f0 => somaFaltas(matricula(turmaAtual().id, 'bento').faltas) === f0 + 1, f0), 'chamada: a falta entra no total do período'); await p.click('[data-a=chamada][data-al=bento]'); await p.waitForTimeout(300); } else certo(true, 'chamada (hoje não é dia letivo)');

  // C1: substituto
  certo(await p.evaluate(() => { const d = docSubstituto(turmaAtual(), '2026-11-05'), s = JSON.stringify(d.blocos); const sig = D.alunos.flatMap(a => (a.atencao || []).filter(x => x.sigiloso !== false).map(x => x.descricao)).filter(x => x && x.length > 8); return /Aula principal/.test(s) && /7h30–9h30/.test(s) && /Cuidados com as crianças/.test(s) && !sig.some(x => s.includes(x)); }), 'roteiro do substituto com a grade do dia e os cuidados, sem os pontos sigilosos');

  // C2: vivência
  const v0 = await p.evaluate(() => D.vivencias[0].id);
  await p.evaluate(async id => { IX.alunos.ana.seg = { alergias: 'Amendoim', buscam: 'Avó Lúcia' }; await salvar('alunos', IX.alunos.ana); ir('viv', id); }, v0);
  certo(await p.locator('[data-a=vivEmergencia]').count() === 1 && await p.locator('[data-a=vivAutorizacao]').count() === 1, 'vivência com ficha de emergência e autorização');
  certo(await p.evaluate(id => { const s = JSON.stringify(docEmergencia(IX.vivencias[id]).blocos); return /Amendoim/.test(s) && /Avó Lúcia/.test(s); }, v0), 'ficha de emergência com alergias e quem busca');
  await p.click('[data-a=vivAutorizacao]'); m = await modal(); certo(/Exportar ou enviar/.test(await m.textContent()) && /destaque e devolva/.test(await m.textContent()), 'botão Autorização abre a saída do documento'); await fechar();
  certo(await p.evaluate(id => { const s = JSON.stringify(docAutorizacao(IX.vivencias[id]).blocos); return /destaque e devolva/.test(s) && /autorizo sua participação em/.test(s); }, v0), 'autorização com parte destacável');

  // C6/C5/C7: acompanhamento
  await p.evaluate(() => ir('acomp', null, 'contatos')); await p.click('[data-a=novoContato]'); m = await modal(); await m.locator('select[name=alunoId]').selectOption('bento'); await m.locator('input[name=assunto]').fill('Sono agitado'); await m.locator('textarea[name=combinados]').fill('Família vai adiantar o horário de dormir'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(/Sono agitado/.test(await texto()), 'contato com a família registrado');
  certo(await p.evaluate(() => JSON.stringify(blocosPreAluno(turmaAtual(), IX.alunos.bento, periodosDaTurma(turmaAtual()).slice(-1)[0], false)).includes('Sono agitado')), 'contato aparece no pré-conselho');
  await p.evaluate(() => ir('acomp', null, 'entrevista')); await p.click('[data-a=acompNovo][data-al=bento]'); await p.waitForTimeout(500); certo(/Gestação e nascimento/.test(await texto()), 'entrevista com a família criada com o roteiro');
  await p.evaluate(() => { const d = IX.documentos[UI.sub]; d.secoes[0].txt = '(pergunta)\nGestação tranquila, parto em casa.'; });
  await p.evaluate(() => { UI.sub = null; ir('acomp', null, 'estudo'); }); await p.click('[data-a=acompNovo][data-al=bento]'); await p.waitForTimeout(500); t = await texto();
  certo(/Estudo de criança — Bento/.test(t) && /parto em casa/.test(t) && /Sono agitado/.test(t), 'estudo de criança traz entrevista e contatos');

  // C8: comunicados
  await p.evaluate(() => { UI.sub = null; ir('comunic'); }); certo(/Reunião de pais/.test(await texto()), 'modelos de comunicados');
  await p.click('[data-a=comGerar][data-k=reuniao]'); m = await modal(); await m.locator('textarea[name=texto]').fill('o ritmo da classe'); await m.locator('button.pri').click(); m = await modal();
  certo(/Exportar ou enviar/.test(await m.textContent()) && /reunião de pais do 3º ano A/.test(await m.textContent()), 'comunicado gerado com a turma e o texto'); await fechar();

  // C3/C4: repertório e plano de época
  await p.evaluate(() => ir('repert')); await p.click('[data-a=novoRep]'); m = await modal(); await m.locator('input[name=titulo]').fill('Verso da manhã'); await m.locator('input[name=rotina]').check(); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  await p.click('[data-a=repUsei]'); await p.waitForTimeout(300); certo(/1 vez/.test(await texto()), 'repertório registra o uso');
  certo(await p.evaluate(async () => { const t = turmaAtual(), c = epocasDaSerie(3)[0]; const d = await criarDoc('epoca', { turmaId: t.id, epocaId: c.id }); return d.secoes.some(s => s.k === 'repertorio' && /Verso da manhã/.test(s.txt)) && d.secoes.some(s => s.k === 'avaliacao' && s.naoImprimir); }), 'plano de época com repertório e avaliação da época');
  certo(await p.evaluate(async () => { const t = turmaAtual(), c = epocasDaSerie(3)[1]; const outra = await salvar('turmas', { serie: 3, letra: 'B', ano: 2027, boletim: { textos: {} } }); const d1 = await criarDoc('epoca', { turmaId: t.id, epocaId: c.id }); d1.secoes.find(s => s.k === 'avaliacao').txt = '- O que funcionou: o teatro das profissões'; const d2 = await criarDoc('epoca', { turmaId: outra.id, epocaId: c.id }); const ok = d2.secoes.some(s => s.k === 'anterior' && /teatro das profissões/.test(s.txt)); await apagar('documentos', d2.id); await apagar('turmas', outra.id); return ok; }), 'avaliação da época volta no plano de outra turma');
  certo(await p.evaluate(() => JSON.stringify(docSubstituto(turmaAtual(), '2026-11-05').blocos).includes('Verso da manhã')), 'roteiro do substituto traz o repertório da rotina');

  // C10/C9/C11: ano letivo
  await p.evaluate(() => { UI.sub = null; ir('planej', null, 'ano'); }); t = await texto();
  certo(/Dias letivos e carga horária de 2026/.test(t) && /Festas do ano/.test(t) && /Lista de materiais do ano/.test(t), 'aba Ano letivo');
  certo(await p.evaluate(() => { const c = contagemLetiva(turmaAtual()); return c.dias > 150 && c.dias < 230 && c.ps.length === 4 && c.horas > c.dias * 4; }), 'dias letivos e horas contados pelo calendário e pela grade');
  await p.evaluate(() => ir('ajustes')); await p.locator('[data-c=minDias]').fill('210'); await p.locator('[data-c=minDias]').press('Tab'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => CFG.prefs.minDias === 210) && /definidos pela legislação/.test(await texto()), 'mínimo de dias letivos ajustável em Ajustes');
  await p.evaluate(() => ir('planej', null, 'ano')); certo(/para 210|mínimo de 210/.test(await texto()), 'contagem usa o mínimo ajustado'); await p.evaluate(async () => { await prefs({ minDias: 200 }); render(); });
  await p.click('[data-a=festas]'); m = await modal(); await m.locator('input[name=f_micael]').check(); const nt = await p.evaluate(() => D.tarefas.length); await m.locator('button.pri').click(); await p.waitForTimeout(500);
  certo(await p.evaluate(nt => D.eventos.some(v => v.festa === 'micael') && D.tarefas.length >= nt + 4, nt), 'festa no calendário com as tarefas de preparação');
  await p.click('[data-a=festaNova]'); m = await modal(); await m.locator('input[name=nome]').fill('Festa do Pão'); await m.locator('input[name=dia]').fill('2026-08-15'); await m.locator('textarea[name=passos]').fill('10: Pedir a farinha às famílias\n0: Assar o pão com as crianças'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const f = festasLista().find(x => x.nome === 'Festa do Pão'); return f && f.quando === '08-15' && f.passos[0][0] === 10 && dataFesta(f, 2026) === '2026-08-15'; }), 'incluir uma festa na lista');
  const iPao = await p.evaluate(() => festasLista().findIndex(x => x.nome === 'Festa do Pão'));
  await p.click('[data-a=festaEditar][data-i="' + iPao + '"]'); m = await modal(); await m.locator('select[name=tipo]').selectOption('pascoa'); await m.locator('input[name=n]').fill('-3'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const f = festasLista().find(x => x.nome === 'Festa do Pão'); return f.quando === 'pascoa:-3' && dataFesta(f, 2026) === '2026-04-02'; }), 'editar a data de uma festa (ligada à Páscoa)');
  await p.click('[data-a=festaExcluir][data-i="' + iPao + '"]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => !festasLista().some(x => x.nome === 'Festa do Pão')), 'excluir uma festa da lista');
  certo(await p.evaluate(() => pascoa(2026) === '2026-04-05' && pascoa(2027) === '2027-03-28'), 'data da Páscoa');
  await p.click('[data-a=materiaisNovo]'); await p.waitForTimeout(500); t = await texto(); certo(/Giz de cera em bloco/.test(t) && /Flauta doce soprano/.test(t), 'lista de materiais do ano');

  // B6: atalhos
  await p.evaluate(() => { UI.sub = null; ir('painel'); }); await p.keyboard.press('Control+k'); certo(await p.evaluate(() => document.activeElement.classList.contains('busca')), 'Ctrl+K vai para a busca');
  await p.keyboard.press('Escape'); await p.click('h1'); await p.keyboard.press('Alt+n'); m = await modal(); certo(/Anota/i.test(await m.textContent()), 'Alt+N abre a anotação rápida'); await fechar();

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
