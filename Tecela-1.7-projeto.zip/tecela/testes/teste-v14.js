// Testes da versão 1.4: BNCC como categoria da Biblioteca, novo verbete com "Inserir na Biblioteca",
// categorias, excluir e ocultar verbetes, e Cadastros com Excluir/Arquivar e "onde é usado".
// Uso: LOG=log.txt node testes/teste-v14.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);
  // BNCC na Biblioteca
  await p.evaluate(() => { UI.filtro.bibAno = '3'; ir('biblio'); });
  certo((await p.textContent('#app')).includes('BNCC — Ensino Fundamental'), 'categoria BNCC na Biblioteca');
  certo(await p.evaluate(() => verbetesBncc().filter(v => v.ano === 3).length >= 9), 'verbetes da BNCC por componente e ano');
  await p.evaluate(() => ir('biblio', 'bncc:MA:3')); const t = await p.textContent('#app'); certo(/EF03MA01/.test(t) && /somente leitura/.test(t) && !(await p.$('#fVerbete')), 'verbete da BNCC com texto oficial, só leitura');
  await p.evaluate(() => ir('biblio', 'bncc:CO:sobre')); certo((await p.textContent('#app')).includes('Pensamento computacional') && (await p.textContent('#app')).includes('desplugada'), 'verbete de apresentação da Computação');
  const nb = await p.evaluate(async () => (await docxBlob({ nome: 'x', titulo: 'x', papel: 'A4', timbrado: {}, blocos: blocosVerbeteBncc('bncc:CO:5').blocos })).size); certo(nb > 5000, 'verbete da BNCC em DOCX');
  await p.fill('.busca', 'EF04CO05'); await p.press('.busca', 'Enter'); await p.waitForTimeout(400); certo((await p.textContent('#app')).includes('EF04CO05'), 'busca encontra a habilidade');
  // novo verbete
  await p.evaluate(() => { UI.sub = null; ir('biblio'); }); await p.click('[data-a=novoVerbete]'); let m = await modal();
  certo((await m.textContent()).includes('Inserir na Biblioteca'), 'novo verbete tem o botão “Inserir na Biblioteca”');
  await m.locator('[data-x=c]').click(); await p.waitForTimeout(200); certo(await p.evaluate(() => !D.biblioteca.some(r => r.titulo === 'Novo verbete')), 'cancelar não cria verbete');
  await p.click('[data-a=novoVerbete]'); m = await modal(); await m.locator('[name=titulo]').fill('Rodas e cantigas'); await m.locator('[name=grupo]').selectOption('Prática escolar'); await m.locator('[name=texto]').fill('As rodas abrem o dia.'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  const nv = await p.evaluate(() => D.biblioteca.find(r => r.titulo === 'Rodas e cantigas')); certo(nv && nv.grupo === 'Prática escolar' && nv.origem === 'proprio', 'verbete inserido numa categoria existente');
  await p.click('[data-a=novoVerbete]'); m = await modal(); await m.locator('[name=titulo]').fill('Jogos de roda'); await m.locator('[name=grupo]').selectOption('__nova'); await m.locator('[name=grupoNovo]').fill('Brincadeiras'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => (D.biblioteca.find(r => r.titulo === 'Jogos de roda') || {}).grupo === 'Brincadeiras'), 'verbete numa categoria nova');
  // editar com Salvar e sair sem salvar
  await p.evaluate(id => ir('biblio', id), nv.id); await p.fill('#fVerbete [name=texto]', 'Texto mudado.'); await p.click('[data-a=voltarVerbete] >> nth=0'); m = await modal(); certo((await m.textContent()).includes('Sair sem salvar'), 'avisa ao sair com alterações não salvas'); await m.locator('[data-x=c]').click();
  await p.click('#fVerbete button.pri'); await p.waitForTimeout(300); certo(await p.evaluate(id => IX.biblioteca[id].texto === 'Texto mudado.', nv.id), '“Salvar alterações” grava o verbete');
  // excluir próprio e ocultar original
  await p.click('[data-a=apagarVerbete]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300); certo(await p.evaluate(id => !IX.biblioteca[id], nv.id), 'excluir verbete próprio');
  await p.click('#aviso button'); await p.waitForTimeout(300); certo(await p.evaluate(id => !!IX.biblioteca[id], nv.id), 'desfazer a exclusão do verbete');
  await p.evaluate(() => ir('biblio', 'temperamentos')); certo(!(await p.$('[data-a=apagarVerbete]')) && !!(await p.$('[data-a=ocultarVerbete]')), 'verbete original: ocultar, não excluir');
  await p.click('[data-a=ocultarVerbete]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => IX.biblioteca.temperamentos.oculto && /Verbetes ocultos/.test($('#app').innerText)), 'verbete ocultado vai para “Verbetes ocultos”');
  certo(await p.evaluate(() => !REL.lugares(turmaAtual()).doc.blocos.some(b => /temperamentos/i.test(b.txt || '') && /Fonte/.test(b.txt || ''))), 'verbete oculto sai dos relatórios');
  await p.click('details summary:has-text("Verbetes ocultos")'); await p.click('[data-a=reexibirVerbete]'); await p.waitForTimeout(300); certo(await p.evaluate(() => !IX.biblioteca.temperamentos.oculto), 'reexibir verbete');
  // cadastros
  await p.evaluate(() => { UI.aba.cadastros = 'tiposAta'; ir('cadastros'); });
  certo(await p.evaluate(() => $$('[data-a=excluirItem]').map(x => x.textContent).includes('Arquivar')), 'item em uso mostra “Arquivar”');
  await p.click('[data-a=verUso] >> nth=0'); m = await modal(); certo((await m.textContent()).includes('nº 01'), '“onde é usado” lista os registros'); await m.locator('button.pri').click();
  await p.evaluate(() => { UI.aba.cadastros = 'frases'; ir('cadastros'); }); certo(await p.evaluate(() => $$('[data-a=excluirItem]').every(x => x.textContent === 'Excluir')), 'frases prontas sempre podem ser excluídas');
  await p.click('[data-a=excluirItem] >> nth=0'); m = await modal(); certo((await m.textContent()).includes('continuam como estão'), 'aviso específico das frases'); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !IX.cadastros['frases:f1']), 'frase excluída');
  await p.evaluate(() => { UI.aba.cadastros = 'criterios'; ir('cadastros'); }); await p.click('[data-a=excluirItem][data-id="criterios:sentir"]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => IX.cadastros['criterios:sentir'].arquivado && D.anotacoes.some(n => n.criterio === 'sentir')), 'item em uso é arquivado e mantém as anotações');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
