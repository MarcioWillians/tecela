// Testes da versão 1.3: exceções em eventos que se repetem, Computação da BNCC (2022) e
// atualização dos verbetes da Biblioteca que a professora não editou.
// Uso: LOG=log.txt node testes/teste-v13.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);
  // exceções
  const ev = await p.evaluate(() => D.eventos.find(v => v.repete).id);
  const nov = () => p.evaluate(id => itensAgenda('2026-11-01', '2026-11-30').filter(x => x.id === id).map(x => x.data), ev);
  const antes = await nov();
  await p.evaluate(() => { UI.mes = '2026-11'; UI.aba.agenda = 'mes'; ir('agenda'); });
  certo((await p.textContent('#app')).includes('↻'), 'evento que se repete aparece com ↻');
  await p.click('[data-a=editarEvento][data-id="' + ev + '"][data-dia="' + antes[1] + '"]'); let m = await modal();
  certo((await m.textContent()).includes('Apagar só'), 'diálogo oferece apagar só esta data');
  await m.locator('[data-x=apagaDia]').click(); await p.waitForTimeout(400);
  const depois = await nov(); certo(depois.length === antes.length - 1 && !depois.includes(antes[1]), 'apagar só uma data tira só aquela data (' + antes[1] + ')');
  await p.click('[data-a=editarEvento][data-id="' + ev + '"][data-dia="' + antes[2] + '"]'); m = await modal(); await m.locator('[data-x=separa]').click(); m = await modal();
  await m.locator('[name=hora]').fill('14:00'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(([id, d]) => { const s = D.eventos.find(v => v.origemSerie === id); return s && s.data === d && s.hora === '14:00' && !s.repete && IX.eventos[id].excecoes.includes(d); }, [ev, antes[2]]), 'mudar só uma data cria um evento avulso e tira a data da série');
  await p.click('[data-a=editarEvento][data-id="' + ev + '"][data-dia="' + antes[0] + '"]'); m = await modal(); certo((await m.textContent()).includes('Datas apagadas'), 'diálogo lista as datas apagadas');
  await m.locator('[data-x=restaura]').click(); await p.waitForTimeout(300); certo(await p.evaluate(id => !IX.eventos[id].excecoes.length, ev), 'trazer de volta as datas apagadas');
  const ics = await p.evaluate(() => { const v = D.eventos.find(x => x.repete); v.excecoes = [v.data]; return true; }); certo(ics, 'exceções guardadas no evento');
  // computação
  certo(await p.evaluate(() => BNCC.filter(h => h[1] === 'CO' && !ehEtapa(h)).length === 83 && BNCC.filter(h => h[1] === 'CO' && ehEtapa(h)).length === 21 && !!IXBNCC.EF03CO02 && BNCC_COMP.CO), 'Computação: 83 habilidades por ano e 21 por etapa');
  certo(await p.evaluate(() => /verdadeiro/.test(IXBNCC.EF03CO01[3]) && IXBNCC.EF03CO01[4].e === 'Pensamento computacional' && IXBNCC.EF03CO01[4].x.length > 100 && IXBNCC.EF03CO01[4].ex.length > 50), 'Computação: texto oficial, eixo, explicação e exemplos');
  certo(await p.evaluate(() => !compararBncc(3, 'CO').some(x => ehEtapa(x.h)) && compararBncc(3, 'CO').length === 9), 'habilidades por etapa fora da comparação');
  certo(await p.evaluate(() => [1, 2, 3, 4, 5, 6, 7, 8, 9].every(a => BNCC.some(h => h[1] === 'CO' && h[2][0] === a))), 'Computação do 1º ao 9º ano');
  certo(await p.evaluate(() => !!itemLista('componentes', 'computacao')), 'componente “Computação” nos cadastros');
  certo(await p.evaluate(() => buscarBncc('algoritmos', 'CO', 3).length > 0), 'busca na Computação');
  await p.evaluate(() => ir('ajustes')); await p.uncheck('[data-c=bnccComputacao]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !BNCC.some(h => h[1] === 'CO') && !BNCC_COMP.CO && !!IXBNCC.EF01CO01), 'desligar a Computação tira das consultas e mantém as ligações');
  await p.check('[data-c=bnccComputacao]'); await p.waitForTimeout(300); certo(await p.evaluate(() => BNCC.filter(h => h[1] === 'CO').length === 104), 'ligar de novo');
  const n = await p.evaluate(async () => (await docxBlob(docComparacao(3))).size); certo(n > 3000, 'comparação com Computação em DOCX');
  // biblioteca
  certo(await p.evaluate(() => /povos originários/.test(IX.biblioteca['serie-4'].texto) && /Ribeirão Preto/.test(IX.biblioteca['serie-4'].fonte)), 'verbete do 4º ano conferido');
  const sinc = await p.evaluate(() => { const r = IX.biblioteca['serie-5'], t = r.texto; r.texto = 'texto antigo'; const a = sincronizarBiblioteca().length; const ok1 = r.texto === t; r.texto = 'editado por mim'; r.origem = 'editado'; const b = sincronizarBiblioteca().length; return [a, ok1, b, r.texto]; });
  certo(sinc[0] === 1 && sinc[1] && sinc[2] === 0 && sinc[3] === 'editado por mim', 'atualiza verbete original e preserva verbete editado');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
