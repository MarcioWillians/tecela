// Testes das novidades da versão 1.2: observação do período, rascunho do boletim, poema do ano,
// conselho de classe, anotar rápido, faltas, busca, desfazer, calendário (repetição, vários,
// grade do mês), ZIP de boletins e importador de boletins dentro do app.
// Uso: LOG=log.txt [DOCX=pasta_com_boletins_docx] node testes/teste-v12.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), ctx = await b.newContext({ viewport: { width: 1280, height: 900 }, acceptDownloads: true }), p = await ctx.newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);
  certo(await p.evaluate(() => document.title.length > 0 && $$('.nav .grupo').length === 5), 'menu agrupado em 5 grupos');
  certo(await p.evaluate(() => itensLista('itensObs').length > 100 && itensLista('blocosObs').length === 13), 'roteiro de observação nos Cadastros (13 blocos)');
  // observação: marcar por toque
  await p.evaluate(() => { UI.aba.obs = 'crianca'; UI.filtro.obsAluno = 'rafael'; UI.filtro.obsPer = '2026-S2'; ir('obs'); });
  await p.click('[data-a=obsMarca][data-it="pensar-1"][data-v=a]'); await p.waitForTimeout(600);
  certo(await p.evaluate(() => IX.observacoes['obs:t26:rafael:2026-S2'].marcas['pensar-1'] === 'a'), 'marcar “pede atenção” com um toque');
  await p.click('[data-a=obsMarca][data-it="pensar-1"][data-v=a]'); await p.waitForTimeout(600);
  certo(await p.evaluate(() => !IX.observacoes['obs:t26:rafael:2026-S2'].marcas['pensar-1']), 'tocar de novo desmarca (não observado)');
  await p.evaluate(() => { UI.aba.obs = 'turma'; render(); }); const antes = await p.evaluate(() => (IX.observacoes['obs:t26:ana:2026-S2'] || {}).marcas['mat-1'] || null);
  await p.click('td.cel[data-al=ana][data-it="mat-1"]'); await p.waitForTimeout(600);
  certo(await p.evaluate(a => { const ord = [null, 'c', 'd', 'a']; return IX.observacoes['obs:t26:ana:2026-S2'].marcas['mat-1'] === ord[(ord.indexOf(a) + 1) % 4] || (!IX.observacoes['obs:t26:ana:2026-S2'].marcas['mat-1'] && a === 'a'); }, antes), 'grade da turma: toque passa ao nível seguinte');
  certo(await p.evaluate(() => { CFG.prefs.periodoObs = 'bimestral'; const n = periodosObs(2026).length; CFG.prefs.periodoObs = 'trimestral'; const m = periodosObs(2026).length; CFG.prefs.periodoObs = 'semestral'; return n === 4 && m === 3 && periodosObs(2026).length === 2; }), 'períodos semestral, trimestral e bimestral');
  // rascunho do boletim e sugestão de perfil
  const ras = await p.evaluate(() => rascunhoObs(IX.boletins[Object.keys(boletinsAtuais('t26')).map(k => boletinsAtuais('t26')[k]).find(b => b.alunoId === 'davi').id], 'matematica'));
  certo(/\{nome\}|Mostra-se|desenvolvimento|atenção/.test(ras), 'rascunho de seção a partir da observação: ' + ras.slice(0, 80));
  const n = await p.evaluate(() => { const b = boletinsAtuais('t26').davi; return preencherVazias(b); }); certo(n >= 5, 'preencher seções vazias com o rascunho (' + n + ')');
  certo(await p.evaluate(() => !!sugestaoPerfil('tomas') && Object.keys(sugestaoPerfil('tomas').niveis).length === 3), 'sugestão de pensar/sentir/querer para o perfil');
  // poema do ano
  await p.evaluate(() => { UI.aba.bol = 'poemas'; ir('bol'); }); certo((await p.textContent('#app')).includes('poemas escritos'), 'aba Poema do ano');
  certo(await p.evaluate(() => poemasDe('ana').length === 2), 'histórico de poemas da criança (2025 e 2026)');
  // anotar rápido com sugestão e conselho
  await p.click('.fab'); let m = await modal(); await m.locator('label:has(input[value=joaquim])').click(); await m.locator('[name=texto]').fill('Joaquim chorou depois da briga com um colega no recreio'); await p.waitForTimeout(200);
  certo(await m.locator('[name=secao]').inputValue() === 'pausa' && await m.locator('[name=criterio]').inputValue() === 'social', 'sugestão automática de seção e critério');
  await m.locator('[name=conselho]').check(); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  const nid = await p.evaluate(() => D.anotacoes.find(n => /chorou depois da briga/.test(n.texto)).id); certo(await p.evaluate(id => IX.anotacoes[id].conselho === true, nid), 'anotação “levar ao conselho”');
  await p.click('#aviso button'); await p.waitForTimeout(300); certo(await p.evaluate(id => !IX.anotacoes[id], nid), 'desfazer remove a anotação recém-lançada');
  // conselho
  certo(await p.evaluate(() => { const t = turmaAtual(), per = periodosObs(2026)[1]; const x = alunosDaTurma(t.id).map(a => [a.id, sinaisCrianca(t, a, per).peso]).sort((a, b) => b[1] - a[1]); return x[0][1] > x[x.length - 1][1]; }), 'pré-conselho ordena as crianças por sinais');
  const tam = await p.evaluate(async () => { const t = turmaAtual(), c = IX.conselhos['cons:t26:2026-S1']; return (await docxBlob(docConselho(t, c))).size; }); certo(tam > 4000, 'registro do conselho em DOCX');
  await p.evaluate(() => { UI.filtro.consPer = '2026-S1'; UI.aba.conselho = 'pos'; ir('conselho'); }); await p.click('[data-a=consTarefas]'); await p.waitForTimeout(400);
  certo(await p.evaluate(() => D.tarefas.filter(t => t.origem && t.origem.conselho === 'cons:t26:2026-S1').length >= 3), 'propostas do conselho viram tarefas');
  await p.evaluate(() => { UI.filtro.consPer = '2026-S2'; UI.aba.conselho = 'reg'; ir('conselho'); }); await p.fill('[data-b="alunos.tomas.proposta"]', 'Padrinho na pausa'); await p.waitForTimeout(700);
  await p.evaluate(() => A.ataConselho()); await p.waitForTimeout(600); certo(await p.evaluate(() => { const c = IX.conselhos['cons:t26:2026-S2'], a = IX.atas[c.ataId]; return a && a.tipo === 'conselho' && a.encaminhamentos.some(x => x.acao === 'Padrinho na pausa'); }), 'ata do conselho criada a partir do registro');
  // faltas
  await p.evaluate(() => ir('faltas')); const f = p.locator('#gradeFaltas tr[data-rec^="matriculas"] input').first(); await f.fill('9'); await f.press('Enter'); await p.waitForTimeout(600);
  certo(await p.evaluate(() => (D.matriculas.find(m => m.turmaId === 't26' && m.alunoId === alunosDaTurma('t26')[0].id).faltas[0]) === 9), 'grade de faltas grava e Enter vai à próxima célula');
  // busca
  await p.fill('.busca', 'ferreiro'); await p.press('.busca', 'Enter'); await p.waitForTimeout(400); certo((await p.textContent('#app')).includes('Vivência'), 'busca em tudo encontra a vivência');
  // calendário
  certo(await p.evaluate(() => itensAgenda('2026-11-01', '2026-11-30').filter(x => /Euritmia/.test(x.titulo)).length === 4), 'evento semanal aparece em todas as quintas de novembro');
  await p.evaluate(() => { UI.mes = '2026-11'; ir('agenda'); }); await p.click('[data-a=variosEventos]'); m = await modal(); await m.locator('[name=txt]').fill('24/11 - Saída ao parque\n25/11 a 27/11 - Semana da leitura\nlinha ruim'); await m.locator('button.pri').click();
  m = await modal(); certo((await m.textContent()).includes('linha ruim'), 'vários eventos: avisa linhas não reconhecidas'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => D.eventos.some(v => v.titulo === 'Semana da leitura' && v.dataFim === '2026-11-27')), 'vários eventos de uma vez');
  certo(await p.evaluate(() => typeof lerCalendario === 'undefined' && typeof A.importarCalendario === 'undefined'), 'importação do calendário da escola removida');
  await p.click('[data-a=imprimirMes]'); m = await modal(); certo((await m.textContent()).includes('Grade do mês'), 'imprimir o mês oferece a grade, como na tela'); await m.locator('[data-x=c]').click();
  const calDoc = await p.evaluate(async () => { const [a, mm] = UI.mes.split('-').map(Number); const blocos = [{ t: 'cal', cab: DIAS_SEM, semanas: [[null, { dia: 1, itens: [{ txt: 'Teste', cor: '#2F6AA8' }] }, null, null, null, null, null]] }]; const d = { nome: 'x', titulo: 'x', paisagem: true, papel: 'A4', timbrado: {}, blocos }; return [(await docxBlob(d)).size, htmlDoc(d).includes('Teste')]; });
  certo(calDoc[0] > 3000 && calDoc[1], 'grade do mês em DOCX (paisagem) e HTML');
  // tarefas exportáveis
  certo(await p.evaluate(() => typeof A.exportarTarefas === 'function'), 'lista de tarefas exportável');
  // ZIP
  const z = await p.evaluate(async () => { const zb = await zipBlob([{ nome: 'a.txt', blob: new Blob(['olá']) }, { nome: 'b.txt', blob: new Blob(['mundo']) }]); const u = new Uint8Array(await zb.arrayBuffer()); return [u[0], u[1], u[2], u[3], u.length]; });
  certo(z[0] === 0x50 && z[1] === 0x4b && z[4] > 100, 'arquivo .zip gerado');
  // intro da turma
  await p.evaluate(() => { UI.aba.bol = 'turma'; ir('bol'); }); p.once('dialog', d => d.accept()); await p.click('[data-a=rascunhoIntro]'); await p.waitForTimeout(300); const mm = await p.$('#modais .modal'); if (mm) await p.click('#modais button.pri'); await p.waitForTimeout(400);
  certo(await p.evaluate(() => /reuniu 8 crianças/.test(IX.turmas.t26.boletim.textos.intro)), 'rascunho da introdução da turma');
  // ata a partir de outra
  await p.evaluate(() => { UI.tela = 'atas'; UI.sub = 'ata1'; render(); }); await p.click('[data-a=ataAPartir]'); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const a = IX.atas[UI.sub]; return a.id !== 'ata1' && a.tipo === 'familias' && a.participantes.length === IX.atas.ata1.participantes.length && !a.texto; }), 'nova ata a partir de outra (participantes, sem texto)');
  // celular: barra inferior e botão Anotar
  await p.setViewportSize({ width: 390, height: 800 }); await p.evaluate(() => ir('painel')); await p.waitForTimeout(300);
  certo(await p.evaluate(() => getComputedStyle($('.barra-movel')).display === 'flex' && getComputedStyle($('.nav')).display === 'none'), 'celular: barra inferior no lugar do menu lateral');
  if (process.env.SAIDA) await p.screenshot({ path: path.resolve(process.env.SAIDA, 'v12-celular.png') });
  await p.click('[data-a=mais]'); m = await modal(); certo((await m.textContent()).includes('Conselho de classe'), 'celular: “Mais” mostra todas as telas'); await m.locator('[data-x=c]').first().click();
  await p.setViewportSize({ width: 1280, height: 900 });
  // importador de boletins dentro do app
  if (process.env.DOCX) {
    const arqs = fs.readdirSync(process.env.DOCX).filter(x => x.endsWith('.docx')).map(x => path.join(process.env.DOCX, x));
    await p.evaluate(() => { IMP.bols = []; ir('importar'); }); await p.waitForTimeout(300);
    const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.evaluate(() => { A.impEscolher(); })]); await fc.setFiles(arqs); await p.waitForTimeout(2500);
    const r = await p.evaluate(() => IMP.bols.map(b => [b.nome, b.serie, b.ano, (b.pars || []).length, !!b.erro, !!b.poemaTitulo]));
    fs.appendFileSync(LOG, '     importador: ' + JSON.stringify(r) + '\n'); certo(r.length === arqs.length && r.every(x => !x[4] && x[0] && x[1] && x[2] && x[3] > 3), 'importador lê nome, série, ano e parágrafos dos boletins .docx');
  }
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
