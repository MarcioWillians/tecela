// Teste do uso real: primeiro uso com senha, cadastro, anotação, ata com marcação,
// boletim, cópia de segurança, reabertura com senha, restauração, CSV, virada e e-mail offline.
// Uso: node testes/teste-fluxo.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const ARQ = 'file://' + path.resolve(__dirname, '../dist/Tecela.html');
const OUT = process.env.SAIDA || path.resolve(__dirname, 'saida');
fs.mkdirSync(OUT, { recursive: true });
const SENHA = 'aquarela123';
(async () => {
  const b = await chromium.launch(), ctx = await b.newContext({ viewport: { width: 1280, height: 860 }, acceptDownloads: true });
  await ctx.addInitScript(() => { window.showSaveFilePicker = undefined; window.print = () => { }; });
  const p = await ctx.newPage(); const erros = [], ok = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (cond, msg) => { (cond ? ok : erros).push(msg); require('fs').appendFileSync(process.env.LOG || '/dev/null', (cond ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal', { timeout: 15000 }); return p.locator('#modais .modal').last(); };
  await p.goto(ARQ); await p.waitForTimeout(400);
  // primeiro uso
  await p.click('[data-a=novo]:not([data-bol])'); certo(await p.textContent('#aviso') !== '', 'exige marcar o aviso LGPD');
  await p.check('#ckLgpd'); await p.click('[data-a=novo]:not([data-bol])');
  let m = await modal(); await m.locator('button.pri').click(); // ligar senha
  m = await modal(); await m.locator('[name=s1]').fill(SENHA); await m.locator('[name=s2]').fill(SENHA); await m.locator('button.pri').click();
  await p.waitForSelector('#modais .chave', { timeout: 30000 }); m = await modal(); const chave = (await p.textContent('#modais .chave')).trim(); await m.locator('[name=ok]').check(); await m.locator('button.pri').click();
  certo(/^[0-9A-Z]{4}(-[0-9A-Z]{4}){7}$/.test(chave), 'chave de recuperação gerada: ' + chave);
  m = await modal(); await m.locator('button.pri').click(); // biblioteca pronta
  m = await modal(); await m.locator('[name=escola]').fill('Escola Teste'); await m.locator('[name=serie]').selectOption('3'); await m.locator('[name=letra]').fill('B'); await m.locator('[name=ano]').fill('2026'); await m.locator('[name=prof]').fill('Rui Souza'); await m.locator('button.pri').click(); certo((await m.locator('.erro').textContent()).includes('professora ou professor'), 'professora/professor é obrigatório'); await m.locator('[name=gen]').selectOption('o'); await m.locator('button.pri').click();
  await p.waitForTimeout(500); await p.screenshot({ path: OUT + '/f01-turma.png' });
  // aluno
  await p.click('[data-a=novoAluno]'); await p.waitForTimeout(300);
  await p.fill('[data-b=nome]', 'Maria Teste da Silva'); await p.fill('[data-b=chamada]', 'Maria'); await p.selectOption('[data-b=genero]', 'f'); await p.fill('[data-b=nasc]', '2017-05-10');
  await p.fill('[data-b="responsaveis.0.nome"]', 'Joana Silva'); await p.fill('[data-b="responsaveis.0.email"]', 'joana@exemplo.com'); await p.fill('[data-b="faltas.0"]', '3');
  await p.waitForTimeout(700);
  // CSV
  const csv = path.join(OUT, 'alunos.csv'); fs.writeFileSync(csv, '﻿nome;chamada;nascimento;genero;responsavel;email;telefone\nPedro Teste;Pedro;02/08/2017;M;Ana Teste;ana@exemplo.com;123\nLuiza Teste;;15/01/2017;F;Carlos Teste;carlos@exemplo.com;456\n');
  await p.evaluate(() => { UI.sub = null; render(); });
  const [fc] = await Promise.all([p.waitForEvent('filechooser'), p.click('[data-a=importarCSV]')]); await fc.setFiles(csv);
  m = await modal(); certo((await m.textContent()).includes('Luiza Teste'), 'prévia do CSV'); await m.locator('button.pri').click(); await p.waitForTimeout(500);
  certo(await p.evaluate(() => alunosDaTurma(turmaAtual().id).length) === 3, 'três alunos na turma');
  // anotação
  await p.evaluate(() => ir('anot'));
  const maria = await p.evaluate(() => D.alunos.find(a => a.chamada === 'Maria').id);
  await p.check('input[name=alunos][value="' + maria + '"]'); await p.selectOption('#fAnot [name=secao]', 'aquarela'); await p.selectOption('#fAnot [name=criterio]', 'sentir');
  await p.fill('#fAnot [name=texto]', '{nome} pintou o céu com azuis profundos; {ela/ela} sorriu ao ver o verde nascer.'.replace('{ela/ela}', '{ele/ela}')); await p.click('#fAnot button.pri'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => D.anotacoes.length) === 1, 'anotação lançada');
  // ata com marcação
  await p.evaluate(() => ir('atas')); await p.click('[data-a=novaAta]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  await p.fill('[data-b=assunto]', 'reunião de meio de ano'); await p.fill('[data-b=inicio]', '19:00'); await p.fill('[data-b=fim]', '20:30');
  await p.fill('[data-b=texto]', 'A professora contou que Maria tem lido com muita alegria os livros da biblioteca da sala.');
  await p.click('[data-a=addFamilias]'); await p.waitForTimeout(400);
  await p.focus('[data-b=texto]'); await p.evaluate(() => { const t = $('[data-b=texto]'); const i = t.value.indexOf('Maria tem'); t.setSelectionRange(i, i + 'Maria tem lido com muita alegria os livros da biblioteca da sala'.length); });
  await p.click('[data-a=marcarTrecho]'); m = await modal(); certo((await m.locator('[name=trecho]').inputValue()).startsWith('Maria tem lido'), 'trecho selecionado vai para o diálogo');
  await m.locator('input[name=alunos][value="' + maria + '"]').check(); await m.locator('[name=secao]').selectOption('portugues'); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  await p.click('[data-a=finalizarAta]'); m = await modal(); await m.locator('button.pri').click(); m = await modal(); certo((await m.textContent()).includes('Enviar por e-mail'), 'pergunta de envio após finalizar'); await m.locator('[data-x=c]').click();
  await p.waitForTimeout(300); await p.screenshot({ path: OUT + '/f02-ata.png', fullPage: true });
  const ata = await p.evaluate(() => { const a = D.atas[0]; return { estado: a.estado, texto: docAta(a).blocos.map(x => x.txt || '').join(' ') }; });
  certo(ata.estado === 'finalizado', 'ata finalizada'); certo(/realizou-se a reunião ordinária com as famílias/.test(ata.texto), 'abertura automática: ' + ata.texto.slice(0, 160));
  // tentar editar ata finalizada: os campos ficam desabilitados
  certo(await p.evaluate(() => $('fieldset[data-rec]').disabled), 'ata finalizada fica bloqueada');
  // boletim
  await p.evaluate(() => { UI.aba.bol = 'alunos'; ir('bol'); }); await p.click('[data-a=abrirBol][data-al="' + maria + '"]'); await p.waitForTimeout(400);
  const bol = await p.evaluate(() => { const b = IX.boletins[UI.sub]; return { aq: (b.secoes.aquarela || {}).texto, pt: (b.secoes.portugues || {}).texto, prev: $('#previaBol').textContent }; });
  certo(bol.aq && bol.aq.includes('{nome} pintou'), 'anotação com estrela entrou no boletim'); certo(bol.pt && bol.pt.includes('Maria tem lido'), 'marcação da ata entrou no boletim'); certo(bol.prev.includes('Maria pintou o céu') && bol.prev.includes('ela sorriu'), 'marcadores {nome} e {ele/ela} substituídos');
  certo(bol.prev.includes('Professor: Rui Souza'), 'boletim usa “Professor:”');
  certo(await p.evaluate(() => { const n = D.anotacoes.find(x => x.origem && x.origem.tipo === 'ata'); return !!n && n.texto.startsWith('Maria tem lido') && n.estrela; }), 'trecho da ata virou anotação do aluno');
  await p.screenshot({ path: OUT + '/f03-boletim.png', fullPage: true });
  // dados criptografados no IndexedDB
  const cru = await p.evaluate(() => new Promise(r => { const q = indexedDB.open('tecela'); q.onsuccess = () => { const g = q.result.transaction('alunos').objectStore('alunos').getAll(); g.onsuccess = () => r(g.result); }; }));
  certo(cru.length === 3 && cru.every(x => x._e && !x.nome), 'registros cifrados no IndexedDB');
  // cópia de segurança
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-a=copia]')]); const copia = path.join(OUT, 'copia.json'); await dl.saveAs(copia);
  const cj = JSON.parse(fs.readFileSync(copia, 'utf8')); certo(cj.app === 'Tecela' && cj.cripto && typeof cj.dados === 'string', 'arquivo guardado criptografado');
  certo(await p.evaluate(() => CFG.prefs.pendente) === false, 'guardar zera a pendência');
  // nova alteração e reabertura: pede senha e depois a cópia
  await p.evaluate(() => ir('anot')); await p.check('input[name=alunos][value="' + maria + '"]'); await p.fill('#fAnot [name=texto]', 'Outra observação.'); await p.click('#fAnot button.pri'); await p.waitForTimeout(500);
  p.once('dialog', d => d.accept()); await p.reload(); await p.waitForSelector('[data-a=continuar]'); certo((await p.textContent('#app')).includes('alterações ainda não salvas no arquivo'), 'tela inicial: Continuar avisa alterações não guardadas'); await p.click('[data-a=continuar]'); await p.waitForSelector('#fSenha');
  await p.fill('#senha', 'errada'); await p.click('#fSenha button'); await p.waitForTimeout(1200); certo((await p.textContent('#erroSenha')).includes('incorreta'), 'senha errada recusada');
  await p.fill('#senha', SENHA); await p.click('#fSenha button'); m = await modal(); certo((await m.textContent()).includes('sem salvar'), 'pede para guardar na abertura após sair sem guardar'); await m.locator('[data-x=c]').click();
  certo(await p.evaluate(() => D.anotacoes.length) === 3, 'dados abertos com a senha');
  // chave de recuperação
  await p.evaluate(() => travar()); await p.waitForSelector('#fSenha'); await p.check('#ckRec'); await p.fill('#chaveRec', chave.toLowerCase()); await p.click('#fSenha button');
  m = await modal(); await m.locator('[name=s1]').fill('novaSenha9'); await m.locator('[name=s2]').fill('novaSenha9'); await m.locator('button.pri').click(); await p.waitForTimeout(500);
  m = await modal(); certo((await m.textContent()).includes('Salvar'), 'após a chave, pede para guardar o pendente'); await m.locator('[data-x=c]').click();
  certo(await p.evaluate(() => SE.app && D.alunos.length === 3), 'entrada com a chave de recuperação e nova senha');
  // virada do ano
  await p.evaluate(() => { UI.aba.turma = 'virada'; ir('turma'); }); p.on('dialog', d => d.accept());
  const pedro = await p.evaluate(() => D.alunos.find(a => a.chamada === 'Pedro').id); await p.selectOption('select[name="r_' + pedro + '"]', 'transferido');
  await p.click('#fVirada button.pri'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(600);
  const v = await p.evaluate(() => ({ t: rotuloTurma(turmaAtual()), n: alunosDaTurma(turmaAtual().id).length, ped: D.alunos.find(a => a.chamada === 'Pedro').situacao }));
  certo(v.t === '4º ano B de 2027' && v.n === 2 && v.ped === 'transferido', 'virada do ano: ' + JSON.stringify(v));
  await p.evaluate(() => { ir('relat', 'evolTurma'); }); await p.screenshot({ path: OUT + '/f04-evolucao.png', fullPage: true });
  // e-mail sem internet
  await ctx.setOffline(true); await p.evaluate(() => { enviarPorEmail({ blob: new Blob(['x']), nome: 'x.docx', assunto: 'a', corpo: 'b', para: [] }); });
  m = await modal(); certo((await m.textContent()).includes('Sem conexão'), 'sem internet: avisa e oferece tentar de novo'); await m.locator('[data-x=c]').click(); await ctx.setOffline(false);
  // restaurar a cópia num navegador novo
  const ctx2 = await b.newContext({ acceptDownloads: true }); const p2 = await ctx2.newPage(); p2.on('pageerror', x => erros.push('p2: ' + x.message));
  await p2.goto(ARQ); await p2.evaluate(() => { window.showOpenFilePicker = undefined; }); await p2.check('#ckLgpd'); const [fc2] = await Promise.all([p2.waitForEvent('filechooser'), p2.click('[data-a=abrirArquivo]')]); await fc2.setFiles(copia);
  m = await p2.waitForSelector('#modais .modal'); await p2.fill('#modais [name=senha]', SENHA); await p2.click('#modais button.pri'); await p2.waitForTimeout(1500);
  certo(await p2.evaluate(() => SE.app && D.alunos.length === 3 && D.atas.length === 1 && !!CFG.cripto), 'restauração em outro navegador');
  await p2.reload(); await p2.click('[data-a=continuar]'); await p2.waitForSelector('#fSenha'); certo(true, 'após restaurar, pede a senha da cópia');
  // saída
  await p.evaluate(() => { A.sair(); }); m = await modal(); await m.locator('[data-x=sem]').click(); await p.waitForTimeout(300); certo((await p.textContent('#app')).includes('Até breve'), 'tela de saída');
  console.log('OK: ' + ok.length + '\n- ' + ok.join('\n- ')); console.log(erros.length ? 'ERROS:\n' + erros.join('\n') : 'Sem erros');
  await b.close();
})().catch(x => { console.error('FALHOU:', x); process.exit(1); });
