// Testes da versão 1.5: aniversariantes, poemas, pauta, reforço e bilhete, vivência completa,
// combinados com versões, PEI, conteúdo programático, horário semanal, planejamento anual e plano
// de época com diário, fontes dos documentos e nome do arquivo com data e hora.
// Uso: LOG=log.txt node testes/teste-v15.js   (FOTOS=pasta guarda capturas de tela)
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null', FOTOS = process.env.FOTOS;
(async () => {
  const b = await chromium.launch(), p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const foto = async n => { if (FOTOS) { fs.mkdirSync(FOTOS, { recursive: true }); await p.screenshot({ path: path.join(FOTOS, n + '.png'), fullPage: false }); } };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  const texto = async () => p.textContent('#app');
  const docTxt = fn => p.evaluate(fn => { const d = (new Function('return ' + fn))()(); return d.blocos.map(x => x.txt || (x.linhas || []).join(' ') || (x.itens || []).join(' ') || (x.estrofes || []).flat().join(' ') || '').join('\n'); }, fn.toString());
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);

  // nome do arquivo com data e hora
  certo(await p.evaluate(() => /^Tecela_Escola_Waldorf_Tecela_\d{4}-\d{2}-\d{2}_\d{2}h\d{2}\.tecela$/.test(nomeArquivoPadrao()) && /_\d{2}h\d{2}\.tecela$/.test(nomeComData('Tecela_X_2025-01-01_10h00.tecela')) && !/2025-01-01/.test(nomeComData('Tecela_X_2025-01-01_10h00.tecela'))), 'nome do arquivo leva data e hora (e troca a anterior)');
  certo(await p.evaluate(() => STORES.includes('documentos') && STORES.includes('reforcos') && STORES.includes('programa')), 'novas coleções no banco');

  // aniversariantes
  await p.evaluate(() => ir('relat', 'aniver')); let t = await texto();
  certo(/Aniversariantes do ano/.test(t) && /Dia da semana/.test(t) && /anos/.test(t), 'relatório de aniversariantes com dia da semana e idade');
  certo(await p.evaluate(() => { const xs = aniversariantes(turmaAtual()); return xs.length > 0 && xs.every(x => x.dia) && xs.some(x => /comemorar em|fim de semana/.test(x.obs) || true); }), 'aniversariantes calculados');
  certo(await p.evaluate(() => !aniversariantes(turmaAtual()).some(x => /Marina/.test(x.a.nome))), 'professora fora dos aniversariantes');
  await foto('01-aniversariantes');

  // poemas
  await p.evaluate(() => { UI.filtro.poeModo = 'turma'; ir('relat', 'poemas'); }); t = await texto();
  certo(/poema\(s\), um por folha/.test(t), 'poemas de um ano da turma, um por folha');
  certo(await p.evaluate(() => { const r = REL.poemas(turmaAtual()); return r.doc && r.doc.blocos.some(x => x.t === 'quebra') && r.doc.blocos.some(x => x.t === 'poema' && x.grande); }), 'documento de poemas com quebra de página');
  await p.evaluate(() => { UI.filtro.poeModo = 'crianca'; UI.filtro.relAluno = 'ana'; render(); }); certo(await p.evaluate(() => REL.poemas(turmaAtual()).doc.blocos.filter(x => x.t === 'poema').length >= 1), 'todos os poemas de uma criança');
  await foto('02-poemas');

  // pauta
  certo(await p.evaluate(() => { const a = D.atas.find(x => x.estado === 'rascunho' && x.pauta) || D.atas.find(x => x.estado === 'rascunho'); a.pauta = 'Boas-vindas\nCaixinha da turma\nFesta da colheita'; const d = docPauta(a); return d.blocos.some(x => x.t === 'lista' && x.itens[0] === '1. Boas-vindas'); }), 'pauta numerada a partir da ata');
  await p.evaluate(() => ir('atas', D.atas.find(x => x.estado === 'rascunho').id)); certo(await p.locator('[data-a=pautaAta]').count() === 1, 'botão da pauta na ata');

  // reforço
  await p.evaluate(() => ir('reforco')); t = await texto(); certo(/Davi/.test(t) && /divisão/.test(t), 'reforço do modelo listado');
  await p.click('[data-a=novoReforco]'); let m = await modal();
  await m.locator('label:has(input[value=bento])').click(); await m.locator('[name=componente]').selectOption('LP'); await m.locator('[name=topico]').fill('ortografia: SS e Ç');
  await m.locator('[name=ini]').fill('2026-11-10'); await m.locator('[name=n]').fill('3'); await m.locator('[name=hora]').fill('13:30'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  const rf = await p.evaluate(() => D.reforcos.find(x => x.alunos.includes('bento'))); certo(rf && rf.datas.length === 3 && rf.datas[0] === '2026-11-10' && rf.datas[1] === '2026-11-17', 'reforço semanal: 3 terças seguidas');
  const bil = await p.evaluate(() => textoBilhete(D.reforcos.find(x => x.alunos.includes('bento')), IX.alunos.bento, turmaAtual()));
  certo(/O aluno Bento/.test(bil) && /chamado/.test(bil) && /três terças-feiras seguidas, nos dias 10, 17 e 24 de novembro de 2026/.test(bil) && /Língua Portuguesa — ortografia/.test(bil) && /15h/.test(bil) && /Professora Marina/.test(bil), 'bilhete com texto ajustado à criança e às datas');
  const bil2 = await p.evaluate(() => textoBilhete(Object.assign({}, D.reforcos.find(x => x.alunos.includes('davi'))), IX.alunos.ana, turmaAtual())); certo(/A aluna Ana/.test(bil2) && /chamada/.test(bil2), 'bilhete no feminino');
  certo(await p.evaluate(() => itensAgenda('2026-11-01', '2026-11-30').some(x => x.origem === 'reforço' && /Bento/.test(x.titulo))), 'datas do reforço no calendário');
  certo(await p.evaluate(() => sinaisCrianca(turmaAtual(), IX.alunos.davi, periodosDaTurma(turmaAtual())[1]).s.some(x => /reforço/.test(x[1]))), 'reforço como sinal no pré-conselho');
  await p.evaluate(() => { UI.filtro.refModo = 'geral'; ir('relat', 'reforco'); }); certo(/Criança\(s\)/.test(await texto()) && /Bento/.test(await texto()), 'lista geral de reforço');
  await foto('03-reforco');

  // vivência completa
  await p.evaluate(() => ir('viv', D.vivencias[0].id)); certo(/Antes da vivência: informações para as famílias/.test(await texto()), 'cartão de informações completas na vivência');
  await p.evaluate(() => { const v = D.vivencias[0]; v.info = { programacao: [{ hora: '8h', ativ: 'Recepção e café da manhã' }, { hora: '9h', ativ: 'Oficina' }], vestimenta: 'Roupa que possa sujar.', orcamento: 'R$ 100,00 por estudante (fictício).' }; render(); });
  certo(await p.evaluate(() => { const d = docInfoViv(D.vivencias[0]); return d.blocos.some(x => x.t === 'tabela' && x.linhas[0][1] === 'Recepção e café da manhã') && d.blocos.some(x => x.txt === 'Vestimenta'); }), 'documento de informações da vivência');
  certo(await p.evaluate(() => restricoesTurma(turmaAtual(), null).some(([a]) => a.id === 'ana')), 'restrições alimentares vindas dos pontos de atenção');
  await foto('04-vivencia');

  // combinados com versões e repetição
  await p.evaluate(() => ir('combinados')); await p.click('[data-a=combNovo]'); await p.waitForTimeout(400);
  t = await texto(); certo(/Representantes de sala/.test(t) && /caixinha/i.test(t), 'combinados a partir do modelo');
  await p.click('[data-a=docVersao]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  const cb = await p.evaluate(() => D.documentos.find(d => d.tipo === 'combinados')); certo(cb.versoes.length === 1 && cb.versoes[0].hash.length === 64, 'versão 1 registrada com impressão digital');
  await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'combinados'); d.secoes[0].txt += '\nNovo combinado.'; }); await p.click('[data-a=docVersao]'); m = await modal(); await m.locator('[name=nota]').fill('Acrescentado um combinado.'); await m.locator('button.pri').click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'combinados'); const doc = docDe(d, d.versoes[1], true); return d.versoes.length === 2 && doc.blocos.some(x => x.t === 'tabela' && x.cab[0] === 'Versão') && doc.blocos.some(x => /Versão 2/.test((x.linhas || [])[0] || '')); }), 'versão 2 e histórico no documento');
  certo(await p.evaluate(async () => { await prefs({ turmaId: 't25' }); const t = turmaAtual(); await prefs({ turmaId: 't26' }); return !combinadosDe(t); }), 'combinados ficam na turma do ano');
  certo(await p.evaluate(async () => { const o = D.documentos.find(x => x.tipo === 'combinados'); o.turmaId = 't25'; await prefs({ turmaId: 't26' }); render(); return /Repetir os combinados de 2025/.test(document.querySelector('#app').textContent); }), 'oferece repetir os combinados do ano anterior');
  await p.click('[data-a=combRepetir]'); await p.waitForTimeout(400); certo(await p.evaluate(() => { const n = combinadosDe(turmaAtual()); return n && n.versoes.length === 0 && /Novo combinado/.test(n.secoes[0].txt); }), 'repetir os combinados do ano anterior');
  await foto('05-combinados');

  // PEI
  await p.evaluate(() => ir('pei')); await p.click('[data-a=peiNovo][data-al=tomas]'); await p.waitForTimeout(500); t = await texto();
  certo(/PLANO EDUCACIONAL INDIVIDUALIZADO \(2026\)/.test(t) && /Conteúdo curricular planejado/.test(t) && /sigiloso/i.test(t), 'PEI criado com o que já está registrado');
  certo(await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'pei'), s = d.secoes.find(x => x.k === 'curriculo'); return s.linhas.length > 2 && s.linhas.every(l => l[2] === 'Acompanha o conteúdo da classe.'); }), 'PEI traz o currículo da classe');
  await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'pei'); d.secoes.find(x => x.k === 'adaptacoes').txt = '- Ritmo em outra sala, já com espaço livre.'; });
  certo(await p.evaluate(() => sinaisCrianca(turmaAtual(), IX.alunos.tomas, periodosDaTurma(turmaAtual())[1]).s.some(x => x[1] === 'PEI')), 'PEI como sinal no pré-conselho');
  await p.evaluate(async () => { const b = await boletimDe(turmaAtual(), IX.alunos.tomas); UI.tela = 'bol'; UI.sub = b.id; render(); }); certo(/PEI de Tomás/.test(await texto()) && /Ritmo em outra sala/.test(await texto()), 'lembrete do PEI no boletim');
  await foto('06-pei');

  // conteúdo programático, épocas de referência e grade
  await p.evaluate(() => { UI.filtro.curSerie = 4; UI.aba.curric = 'prog'; ir('curric'); }); t = await texto(); certo(/Conhecimentos Pátrios/.test(t) && /174 aulas/.test(t) && !/Rudolf Steiner em/i.test(t), 'conteúdo programático de referência do 4º ano, sem identificar a escola');
  await p.click('[data-a=progUsar]'); await p.waitForTimeout(400); certo(await p.evaluate(() => D.programa.filter(x => x.serie === 4).length >= 8), 'conteúdo programático copiado para editar');
  certo(await p.evaluate(() => !JSON.stringify(PROG_REF).match(/RUDOLF STEINER EM|ELABORADO PELA/i)), 'nenhuma identificação da escola no conteúdo de referência');
  await p.evaluate(() => { UI.aba.curric = 'escola'; ir('curric'); }); certo(await p.locator('[data-a=epocasRef]').count() === 1, 'oferece carregar épocas de referência');
  await p.click('[data-a=epocasRef]'); await p.waitForTimeout(500); certo(await p.evaluate(() => epocasDaSerie(4).length === EPOCAS_REF[4].length), 'épocas de referência do 4º ano carregadas');
  await p.evaluate(() => ir('turma', null, 'grade')); certo(/Horário semanal de 3º ano A/.test(await texto()), 'horário semanal da turma');
  certo(await p.evaluate(() => { const a = aulasDoDia(turmaAtual(), '2026-10-22'); return /10h10–10h55 Jardinagem – 11h–11h45 Música/.test(a.aulas) && a.pc === '11h50–12h35 Caderno de profissões'; }), 'aulas do dia vindas da grade, com os horários');

  // dias letivos
  certo(await p.evaluate(() => !ehLetivo('2026-10-12') && !ehLetivo('2026-11-02') && ehLetivo('2026-11-03') && ehLetivo('2026-03-14') && !ehLetivo('2026-03-15') && diasLetivos('2026-10-05', '2026-11-06').length === 19), 'dias letivos sem feriados e recessos, com sábado letivo');

  // planejamento anual
  await p.evaluate(() => ir('planej', null, 'anual')); await p.click('[data-a=anualNovo]'); await p.waitForTimeout(600); t = await texto();
  certo(/Justificativa antropológica/.test(t) && /Rubicão/.test(t) && /Épocas do ano/.test(t) && /Conteúdo programático do ano/.test(t), 'planejamento anual com as seções da referência');
  const tab = await p.evaluate(() => D.documentos.find(d => d.tipo === 'anual').secoes.find(s => s.k === 'epocas').linhas);
  certo(tab.length >= 6 && /\d{2}\/\d{2}\/2026/.test(tab[0][3]) && Number(tab[0][5]) > 5 && tab.every((l, i) => !i || !l[3] || !tab[i - 1][4] || l[3].split('/').reverse().join('') > tab[i - 1][4].split('/').reverse().join('')), 'épocas com datas sequenciais e dias letivos pelo calendário');
  certo(await p.evaluate(() => D.documentos.find(d => d.tipo === 'anual').secoes.some(s => /^ep:/.test(s.k) && /Habilidades da BNCC/.test(s.txt) && /\(EF/.test(s.txt))), 'épocas com habilidades da BNCC');
  await foto('07-planejamento-anual');
  certo(await p.evaluate(async () => { const n = (await docxBlob(docDe(D.documentos.find(d => d.tipo === 'anual')))).size; return n > 8000; }), 'planejamento anual em DOCX');

  // plano de época com diário
  await p.evaluate(() => { UI.sub = null; ir('planej', null, 'epocas'); });
  const ep = await p.evaluate(() => epocasDaSerie(3).find(c => /O tempo/.test(c.titulo)).id);
  await p.click('[data-a=epocaNovo][data-id="' + ep + '"]'); await p.waitForTimeout(600); t = await texto();
  certo(/Objetivos específicos \(Pedagogia Waldorf\)/.test(t) && /Estrutura da aula/.test(t) && /Diário da época/.test(t), 'plano de época com as seções do modelo');
  const di = await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'epoca'); return { cab: d.cab, dias: d.secoes.find(s => s.k === 'diario').dias }; });
  certo(di.cab.inicio && di.dias.length > 5 && di.dias.every(x => ![0].includes(new Date(x.data + 'T12:00').getDay())) && di.dias.some(x => /Alemão/.test(x.aulas)), 'diário montado pelo calendário, com as aulas da grade');
  await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'epoca'); d.secoes.find(s => s.k === 'diario').dias[0].conteudo = 'Relógio de ponteiros'; d.cab.fim = somaDias(d.cab.fim, 7); });
  await p.click('[data-a=epocaDiario]'); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const d = D.documentos.find(x => x.tipo === 'epoca'), s = d.secoes.find(x => x.k === 'diario'); return s.dias[0].conteudo === 'Relógio de ponteiros'; }), 'remontar o diário mantém o que já foi escrito');
  certo(/Lembretes dos PEIs/.test(await texto()) && /Tomás/.test(await texto()), 'lembrete do PEI no plano de época');
  await foto('08-plano-epoca');

  // referências de cada ano
  await p.evaluate(() => { UI.sub = null; UI.filtro.refSerie = 4; ir('planej', null, 'ref'); }); await p.click('[data-a=refAnualNovo]'); await p.waitForTimeout(500);
  certo(/Planejamento anual de referência — 4º ano/.test(await texto()) && /Conhecimentos Pátrios/.test(await texto()), 'referência do 4º ano com o conteúdo programático');
  certo(await p.evaluate(() => { const r = refAnualDe(4); r.secoes[0].txt = 'Texto da escola para o 4º ano.'; return true; }), 'referência editável');
  await foto('09-referencia');

  // seções: mover, tirar com desfazer, refazer seção
  await p.evaluate(() => { UI.sub = D.documentos.find(d => d.tipo === 'anual').id; ir('planej', null, 'anual'); UI.sub = D.documentos.find(d => d.tipo === 'anual').id; render(); });
  const n0 = await p.evaluate(() => D.documentos.find(d => d.tipo === 'anual').secoes.length);
  await p.locator('[data-a=docRemSec]').first().click(); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(n => D.documentos.find(d => d.tipo === 'anual').secoes.length === n - 1, n0), 'tirar uma seção');
  await p.locator('#aviso button').click(); await p.waitForTimeout(300); certo(await p.evaluate(n => D.documentos.find(d => d.tipo === 'anual').secoes.length === n, n0), 'desfazer a retirada');

  // fontes
  await p.evaluate(async () => { await prefs({ fonteTexto: 'Arial', fontePoema: 'Georgia' }); });
  certo(await p.evaluate(() => /Arial/.test(htmlDoc(docPauta(D.atas[0]))) && /Georgia/.test(htmlBloco({ t: 'poema', estrofes: [['a']] }))), 'fontes escolhidas no HTML do documento');
  certo(await p.evaluate(async () => { const z = await docxBlob(docPauta(D.atas[0])); const tx = await z.text(); return z.size > 3000; }), 'DOCX gerado com a fonte escolhida');
  await p.evaluate(() => ir('ajustes')); certo(/Fontes dos documentos impressos/.test(await texto()), 'cartão de fontes em Ajustes'); await foto('10-fontes');
  await p.evaluate(async () => { await prefs({ fonteTexto: '', fontePoema: '' }); });

  // telas novas no celular, sem estourar a largura
  await p.setViewportSize({ width: 390, height: 800 });
  for (const tl of ['planej', 'reforco', 'combinados', 'pei']) { await p.evaluate(tl => { UI.sub = null; ir(tl); }, tl); const ok = await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1); certo(ok, 'celular sem rolagem lateral: ' + tl); }

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
