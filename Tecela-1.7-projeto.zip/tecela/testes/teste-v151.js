// Testes da versão 1.5.1: rascunhos de todos os anos, links do plano de época para o currículo,
// matérias do horário semanal com Professor de Classe ou de Matéria (e a grade impressa), período anual da
// observação, lista dos alunos com colunas escolhidas e vivência separada em antes e depois.
// Uso: LOG=log.txt node testes/teste-v151.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch(), p = await (await b.newContext({ viewport: { width: 1280, height: 900 } })).newPage(), erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  const texto = () => p.textContent('#app');
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);

  // grade: matérias do ano com PC/PM
  await p.evaluate(() => ir('turma', null, 'grade')); let t = await texto();
  certo(/Matérias de 2026, quem dá a aula/.test(t) && /Aquarela \(PC\)/.test(t) && /Euritmia \(PM\)/.test(t) && /Aula principal/.test(t), 'matérias do ano com Professor de Classe ou de Matéria e a Aula principal');
  certo(await p.evaluate(() => { const a = aulasDoDia(turmaAtual(), '2026-10-21'); return a.aulas.includes('Inglês') && !a.aulas.includes('Aquarela') && a.pc === '11h–11h45 Aquarela' && !a.pc.includes('Aula principal'); }), 'aulas do PC vão para o campo PC do diário');
  await p.click('[data-a=gradeAddAula][data-k="1"]'); await p.waitForTimeout(400); const ult = await p.evaluate(() => turmaAtual().grade[1].itens.length - 1); await p.locator('[data-b="grade.1.itens.' + ult + '.m"]').selectOption('Aquarela'); await p.waitForTimeout(400);
  certo(await p.evaluate(() => { const x = turmaAtual().grade[1].itens; return x[x.length - 1].m === 'Aquarela' && x[x.length - 1].ini === '12:35'; }), 'acrescentar uma aula num dia, começando onde a anterior termina');
  await p.locator('[data-b="materias.0.quem"]').selectOption('PC'); await p.waitForTimeout(700);
  certo(await p.evaluate(() => turmaAtual().materias[0].quem === 'PC' && aulasDoDia(turmaAtual(), '2026-10-19').pc.includes('Religiosidade')), 'mudar quem dá a aula muda o diário');
  certo(await p.evaluate(() => { const d = docGrade(turmaAtual()); const tb = d.blocos.find(x => x.t === 'tabela'); return tb.cab.join() === 'Aula,Segunda,Terça,Quarta,Quinta,Sexta' && /7h30–9h30 · Aula principal \(PC\)/.test(tb.linhas[0][1]) && d.blocos.some(x => x.t === 'quebra') && d.blocos.some(x => x.t === 'tabela' && x.cab[1] === 'Quem dá a aula') && d.blocos.some(x => x.t === 'p' && /Alemão em horário especial/.test(x.txt)); }), 'grade impressa em tabela, com observações e matérias em folha separada');
  certo(await p.evaluate(async () => (await docxBlob(docGrade(turmaAtual()))).size > 3000), 'grade em DOCX');
  certo(await p.evaluate(() => { const t = { id: 'x', serie: 3, grade: { 1: { aulas: 'Inglês, Euritmia', pc: 'Aquarela' }, 2: { lista: ['Música'], obs: 'sai às 12h' } } }; gradeDe(t); return t.grade[1].itens.map(x => x.m).join() === 'Inglês,Euritmia,Aquarela' && t.materias.find(m => m.nome === 'Aquarela').quem === 'PC' && t.grade[2].itens[0].m === 'Música' && /Terça: sai às 12h/.test(t.gradeObs) && !('lista' in t.grade[2]); }), 'grades antigas convertidas para o novo formato');
  certo(await p.evaluate(() => { const t = turmaAtual(), n = t.materias.length; A.gradeDoPrograma(); return true; }), 'trazer matérias do conteúdo programático');
  await p.waitForTimeout(400); certo(await p.evaluate(() => turmaAtual().materias.some(m => m.nome === 'Alemão')), 'matérias do conteúdo programático sem repetir');

  // planejamento: links e rascunhos de todos os anos
  await p.evaluate(() => { UI.sub = null; ir('planej', null, 'epocas'); }); t = await texto();
  certo(await p.locator('[data-a=irCurriculo]').count() > 0 && await p.locator('[data-a=irColarEpocas]').count() > 0, 'plano de época com links para Currículo e BNCC e colar lista de épocas');
  await p.click('[data-a=irColarEpocas]'); let m = await modal(); certo(/época/i.test(await m.textContent()) && await p.evaluate(() => UI.tela === 'curric'), 'colar uma lista de épocas a partir do planejamento'); await m.locator('[data-x=c]').click();
  await p.evaluate(() => { UI.sub = null; ir('planej', null, 'ref'); }); t = await texto();
  certo(/Rascunhos de todos os anos/.test(t) && /8º ano/.test(t) && !/9º ano/.test(t) && /Montar os rascunhos de todos os anos/.test(t), 'visão dos rascunhos de todos os anos (9º ano oculto por padrão)');
  await p.click('[data-a=refTodos]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(3000);
  certo(await p.evaluate(() => [1, 2, 3, 4, 5, 6, 7, 8].every(s => epocasDaSerie(s).length && refAnualDe(s) && epocasDaSerie(s).every(c => refEpocaDe(c.id)))), 'rascunhos montados para todos os anos, do 1º ao 8º');
  const n1 = await p.evaluate(() => D.documentos.length); await p.click('[data-a=refTodos]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(800);
  certo(await p.evaluate(n => D.documentos.length === n, n1), 'montar de novo não duplica');
  await p.click('[data-a=refVer][data-s="7"]'); await p.waitForTimeout(200); certo(/Planejamento anual de referência — 7º ano/.test(await texto()), 'ver um ano na lista');

  // observação anual
  certo(await p.evaluate(async () => { await prefs({ periodoObs: 'anual' }); const ps = periodosObs(2026); const ok = ps.length === 1 && ps[0].id === '2026-A' && ps[0].rot === 'Ano letivo de 2026'; await prefs({ periodoObs: 'semestral' }); return ok; }), 'período anual da observação e do conselho');
  await p.evaluate(() => ir('ajustes')); certo(await p.locator('[data-c=periodoObs] option[value=anual]').count() === 1, 'opção anual em Ajustes');

  // lista dos alunos
  await p.evaluate(() => { UI.sub = null; ir('turma', null, 'alunos'); }); await p.click('[data-a=exportarAlunos]'); m = await modal();
  for (const k of ['genero', 'email', 'nee', 'atencao', 'idade']) await m.locator('input[value=' + k + ']').check();
  await m.locator('button.pri').click(); m = await modal(); certo(/Exportar ou enviar/.test(await m.textContent()), 'lista dos alunos com colunas escolhidas'); await m.locator('[data-x=c]').click();
  certo(await p.evaluate(() => UI.filtro.listaCols.includes('atencao') && UI.filtro.listaCols.includes('genero')), 'colunas escolhidas lembradas');

  // vivência: antes e depois
  await p.evaluate(() => ir('viv', D.vivencias[0].id)); t = await texto();
  certo(/Antes da vivência: informações para as famílias/.test(t) && /Depois da vivência: registro/.test(t), 'vivência separada em antes e depois');
  certo(await p.evaluate(() => { const v = D.vivencias[0]; v.info = { apresentacao: 'Vamos conhecer a forja.' }; const d = docInfoViv(v), txt = JSON.stringify(d.blocos); return txt.includes('Vamos conhecer a forja.') && !txt.includes(v.descricao.slice(0, 30)); }), 'informações para as famílias sem o registro do que aconteceu');
  certo(await p.evaluate(() => { const v = D.vivencias[0], txt = JSON.stringify(blocosViv(v)); return txt.includes(v.descricao.slice(0, 30)) && !txt.includes('Vamos conhecer'); }), 'relatório da vivência sem os itens da preparação');

  // 1.5.2: busca nos documentos, diário mais fácil de achar, virada leva as matérias
  await p.evaluate(async () => { const t = turmaAtual(), c = epocasDaSerie(3).find(x => /O tempo/.test(x.titulo)); const d = await criarDoc('epoca', { turmaId: t.id, epocaId: c.id }); d.secoes.find(s => s.k === 'diario').dias[0].conteudo = 'Relógio de sol no pátio'; UI.sub = null; ir('planej', null, 'epocas'); });
  certo(/diário: 1 de \d+ dias/.test(await texto()), 'lista de épocas mostra os dias preenchidos do diário');
  await p.evaluate(() => { UI.filtro.busca = 'relógio de sol'; ir('busca'); }); certo(/Plano de época/.test(await texto()), 'busca encontra texto do diário da época');
  await p.locator('tr.clic[data-a=abrirDocBusca]').first().click(); await p.waitForTimeout(300); certo(await p.evaluate(() => UI.tela === 'planej' && IX.documentos[UI.sub].tipo === 'epoca'), 'resultado da busca abre o plano');
  await p.click('[data-a=irDiario]'); await p.waitForTimeout(600); certo(await p.evaluate(() => { const r = document.getElementById('sec-diario').getBoundingClientRect(); return r.top < innerHeight && r.bottom > 0; }), 'botão “Ir para o diário”');
  await p.evaluate(() => { UI.filtro.busca = 'divisão com dois'; ir('busca'); }); certo(/Reforço/.test(await texto()), 'busca encontra reforço');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
