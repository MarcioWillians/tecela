// Teste das novidades da versão 1.1, sobre o modelo de demonstração.
// Uso: LOG=log.txt node testes/teste-novidades.js
const { chromium } = require('playwright'); const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null', OUT = process.env.SAIDA || path.dirname(LOG);
const erros = [], certo = (c, m) => { if (!c) erros.push(m); fs.appendFileSync(LOG, (c ? 'ok   ' : 'ERRO ') + m + '\n'); };
(async () => {
  const b = await chromium.launch(), ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 900 } });
  await ctx.addInitScript(() => { window.showSaveFilePicker = undefined; window.print = () => { }; });
  const p = await ctx.newPage(); p.on('pageerror', x => erros.push('pageerror ' + x.message));
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2500);
  // sigilosa desliga "usar no boletim"
  await p.evaluate(() => ir('anot')); await p.check('#fAnot [name=sigilo]'); certo(await p.evaluate(() => { const f = $('#fAnot'); return f.estrela.disabled && !f.estrela.checked; }), 'anotação sigilosa desliga “Usar no boletim”');
  // cadastros: arquivar item usado, excluir item sem uso
  await p.evaluate(() => { UI.aba.cadastros = 'criterios'; ir('cadastros'); });
  await p.click('[data-a=excluirItem][data-id="criterios:sentir"]'); let m = await modal(); certo((await m.textContent()).includes('Arquivar'), 'item em uso é arquivado, não excluído'); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => IX.cadastros['criterios:sentir'].arquivado && !criterios().some(c => c[0] === 'sentir') && nomeCrit('sentir') === 'Sentir'), 'arquivado sai das escolhas e continua nos registros');
  await p.click('[data-a=desarquivar]'); await p.click('[data-a=novoItem][data-l=criterios]'); m = await modal(); await m.locator('[name=n]').fill('Vida rítmica'); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  const novo = await p.evaluate(() => D.cadastros.find(c => c.nome === 'Vida rítmica').id); await p.click('[data-a=excluirItem][data-id="' + novo + '"]'); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(id => !IX.cadastros[id], novo), 'item sem uso é excluído');
  // tipo de ata personalizado aparece na nova ata
  await p.evaluate(async () => { const r = await salvar('cadastros', { id: 'tiposAta:conselho', lista: 'tiposAta', chave: 'conselho', nome: 'Conselho de classe', ordem: 9, cats: ['Professor(a)', 'Coordenação'], subtipos: [] }); });
  await p.evaluate(() => ir('atas')); await p.click('[data-a=novaAta]'); m = await modal(); certo((await m.textContent()).includes('Conselho de classe'), 'tipo de ata criado em Cadastros aparece na nova ata'); await m.locator('[data-x=c]').click();
  // .ics
  await p.evaluate(() => ir('agenda')); await p.click('[data-a=exportarIcs]'); m = await modal(); const [dl] = await Promise.all([p.waitForEvent('download'), m.locator('button.pri').click()]); const ics = path.join(OUT, 'teste.ics'); await dl.saveAs(ics); const icst = fs.readFileSync(ics, 'utf8');
  certo(/BEGIN:VCALENDAR[\s\S]*BEGIN:VEVENT[\s\S]*END:VCALENDAR/.test(icst) && /VALARM/.test(icst) && /RRULE:FREQ=DAILY;INTERVAL=30/.test(icst), 'arquivo .ics com eventos, avisos e repetição');
  // tarefa repetida avança ao concluir
  const antes = await p.evaluate(() => { const x = D.tarefas.find(t => t.titulo === 'Revisar os perfis da turma'); return proximaData(x); });
  await p.evaluate(() => ir('tarefas')); const tid = await p.evaluate(() => D.tarefas.find(t => t.titulo === 'Revisar os perfis da turma').id); await p.check('[data-c=tarefaFeita][data-id="' + tid + '"]'); await p.waitForTimeout(300);
  const depois = await p.evaluate(id => proximaData(IX.tarefas[id]), tid); certo(depois > antes, 'tarefa que se repete avança ao ser concluída (' + antes + ' → ' + depois + ')');
  // vivência: observação vira anotação
  await p.evaluate(() => { UI.tela = 'viv'; UI.sub = 'viv1'; render(); }); await p.click('[data-a=obsViv]'); m = await modal(); await m.locator('input[name=alunos][value=helena]').check(); await m.locator('[name=texto]').fill('{nome} desenhou a forja com detalhes.'); await m.locator('button.pri').click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => D.anotacoes.some(n => n.origem && n.origem.id === 'viv1' && n.alunos[0] === 'helena')), 'observação da vivência vira anotação');
  // pontos de atenção: aparecem no editor do boletim, nunca no documento
  const at = await p.evaluate(async () => { const b = await boletimDe(IX.turmas.t26, IX.alunos.tomas); UI.tela = 'bol'; UI.sub = b.id; render(); return { tela: $('#app').textContent.includes('Usa óculos'), doc: JSON.stringify(docBoletim(b)).includes('óculos') }; });
  certo(at.tela && !at.doc, 'pontos de atenção aparecem no editor do boletim e não no documento');
  // currículo e BNCC
  const cb = await p.evaluate(() => { const c = D.curriculo.find(x => x.titulo === 'Medidas e dinheiro'); return { s: sugerirBncc(c, 5).map(h => h[0]), comp: compararBncc(3, 'MA').filter(x => x.st === 'mesmo').length }; });
  certo(cb.s.length > 0 && cb.comp > 0, 'sugestões da BNCC e comparação (' + cb.s.join(', ') + ')');
  // relatórios exportam DOCX sem erro
  for (const k of ['ficha', 'fichaConselho', 'obs', 'perfilTurma', 'evolAluno', 'evolTurma', 'olhar', 'reuniao', 'estudo', 'lugares', 'freq', 'ano']) { const n = await p.evaluate(async k => { UI.filtro.relAluno = 'tomas'; const r = REL[k](turmaAtual()); if (!r.doc) return -1; const blob = await docxBlob(r.doc); return blob.size; }, k); certo(n > 3000, 'relatório ' + k + ' gera DOCX (' + n + ' bytes)'); }
  const n2 = await p.evaluate(async () => (await docxBlob(docComparacao(3))).size); certo(n2 > 3000, 'comparação com a BNCC gera DOCX');
  // modelo de demonstração acessível de dentro do app (com dados reais)
  certo(true, 'fim');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.message + '\n'); process.exit(1); });
