// Teste automático do modelo de demonstração: percorre as telas, gera DOCX e PDF.
// Uso: node testes/teste-demo.js   (precisa do Playwright com Chromium)
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const ARQ = 'file://' + path.resolve(__dirname, '../dist/Tecela.html');
const OUT = process.env.SAIDA || path.resolve(__dirname, 'saida');
fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await chromium.launch(), ctx = await b.newContext({ viewport: { width: 1280, height: 860 }, acceptDownloads: true });
  const p = await ctx.newPage(); const erros = [];
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  await p.goto(ARQ); await p.waitForTimeout(500);
  await p.screenshot({ path: OUT + '/01-boas-vindas.png', fullPage: true });
  await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(1500);
  const shot = async (n) => { await p.waitForTimeout(250); const t = await p.textContent('#app'); if (/Erro ao montar/.test(t)) erros.push('tela com erro: ' + n); await p.screenshot({ path: OUT + '/' + n + '.png', fullPage: true }); };
  await shot('02-painel');
  const ir = async (t, aba) => { await p.evaluate(([t, aba]) => { UI.aba[t] = aba || UI.aba[t]; ir(t); }, [t, aba]); };
  for (const [t, aba, n] of [['turma', 'alunos', '03-alunos'], ['turma', 'turma', '04-turmas'], ['turma', 'virada', '05-virada'], ['turma', 'arquivo', '06-arquivo'], ['anot', null, '07-anotacoes'], ['atas', null, '08-atas'], ['bol', 'alunos', '09-boletins'], ['bol', 'turma', '10-bol-turma'], ['bol', 'secoes', '11-bol-secoes'], ['perfis', 'aluno', '12-perfil-aluno'], ['obs', 'crianca', '13-obs-crianca'], ['obs', 'turma', '14-obs-turma'], ['faltas', null, '14b-faltas'], ['conselho', 'pre', '60-conselho-pre'], ['conselho', 'reg', '61-conselho-reg'], ['conselho', 'pos', '62-conselho-pos'], ['bol', 'poemas', '63-poemas'], ['agenda', 'ano', '64-calendario-ano'], ['biblio', null, '15-biblioteca'], ['timbrado', 'atas', '16-timbrado'], ['ajustes', null, '17-ajustes'], ['ajuda', 'manual', '18-manual'], ['ajuda', 'creditos', '19-creditos'], ['cadastros', 'tiposAta', '40-cadastros'], ['agenda', 'mes', '41-calendario'], ['agenda', 'lista', '42-calendario-lista'], ['viv', null, '43-vivencias'], ['tarefas', 'pend', '44-tarefas'], ['curric', 'escola', '45-curriculo'], ['curric', 'bncc', '46-bncc'], ['curric', 'comp', '47-comparacao'], ['relat', null, '48-relatorios']]) { await ir(t, aba); await shot(n); }
  await p.evaluate(() => { UI.mes = '2026-11'; UI.aba.agenda = 'mes'; ir('agenda'); }); await shot('41b-calendario-nov');
  for (const k of ['ficha', 'obs', 'perfilTurma', 'evolTurma', 'olhar', 'lugares', 'freq', 'ano']) { await p.evaluate(k => { UI.filtro.relAluno = 'tomas'; ir('relat', k); }, k); await shot('50-rel-' + k); }
  for (const f of ['familia', 'estudo', 'conselho', 'evolucao']) { await p.evaluate(f => { UI.filtro.fichaFin = f; UI.filtro.relAluno = 'tomas'; ir('relat', 'ficha'); }, f); await shot('50-ficha-' + f); }
  await p.evaluate(() => { UI.filtro.busca = 'flauta'; ir('busca'); }); await shot('65-busca');
  await p.evaluate(() => { A.anotar({}); }); await p.waitForTimeout(300); await p.fill('.modal [name=texto]', 'Tomás errou a tabuada do 7 mas persistiu'); await p.waitForTimeout(200);
  const sug = await p.evaluate(() => [$('.modal [name=secao]').value, $('.modal [name=criterio]').value]); if (sug[0] !== 'matematica') erros.push('sugestão de seção: ' + sug); await shot('66-anotar'); await p.click('.modal [data-x=c]');
  await p.evaluate(() => { UI.tela = 'viv'; UI.sub = 'viv1'; render(); }); await shot('51-vivencia');
  await p.evaluate(() => { UI.aba.curric = 'escola'; UI.tela = 'curric'; UI.sub = D.curriculo.find(c => c.titulo === 'Medidas e dinheiro').id; render(); }); await shot('52-epoca');
  await p.evaluate(() => { UI.tela = 'turma'; UI.aba.turma = 'alunos'; UI.sub = 'tomas'; render(); }); await shot('53-aluno-atencao');
  // ata finalizada e boletim
  await p.evaluate(() => { UI.tela = 'atas'; UI.sub = 'ata1'; render(); }); await shot('20-ata1');
  await p.evaluate(() => { UI.tela = 'bol'; UI.sub = 'bAna'; render(); }); await shot('21-boletim-ana');
  // conferência de hash
  const hashOk = await p.evaluate(async () => [await conferirHash('atas', IX.atas.ata1), await conferirHash('atas', IX.atas.ata2)]);
  if (!hashOk.every(Boolean)) erros.push('hash não confere: ' + hashOk);
  // DOCX de ata, boletim e relatório
  for (const [n, f] of [['ata1', "docAta(IX.atas.ata1)"], ['boletim-ana', "docBoletim(IX.boletins.bAna)"], ['relatorio-turma', "docRelatorioTurma(dadosTurma(IX.turmas.t26), perfilTurmaRec(IX.turmas.t26))"]]) {
    const b64 = await p.evaluate(async (f) => { const blob = await docxBlob(eval(f)); const buf = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (let i = 0; i < buf.length; i++) s += String.fromCharCode(buf[i]); return btoa(s); }, f);
    fs.writeFileSync(OUT + '/' + n + '.docx', Buffer.from(b64, 'base64'));
  }
  // PDF pela impressão (mesmo HTML que vai para a janela de impressão)
  for (const [n, f] of [['ata1', "docAta(IX.atas.ata1)"], ['boletim-ana', "docBoletim(IX.boletins.bAna)"], ['relatorio-turma', "docRelatorioTurma(dadosTurma(IX.turmas.t26), perfilTurmaRec(IX.turmas.t26))"]]) {
    await p.evaluate((f) => { window.print = () => { }; exportarPDF(eval(f)); }, f); await p.waitForTimeout(300);
    await p.emulateMedia({ media: 'print' }); await p.pdf({ path: OUT + '/' + n + '.pdf', preferCSSPageSize: true }); await p.emulateMedia({ media: 'screen' });
  }
  // celular
  await p.setViewportSize({ width: 390, height: 844 });
  await p.evaluate(() => { UI.sub = null; ir('painel'); }); await shot('30-celular-painel');
  await p.evaluate(() => { UI.tela = 'bol'; UI.sub = 'bBento'; render(); }); await shot('31-celular-boletim');
  await p.evaluate(() => { UI.sub = null; ir('anot'); }); await shot('32-celular-anotacoes');
  console.log(erros.length ? 'ERROS:\n' + erros.join('\n') : 'OK sem erros');
  await b.close();
})();
