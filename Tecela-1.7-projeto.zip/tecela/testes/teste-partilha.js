// Testes da Partilha pedagógica: classificação de todas as coleções e campos, avisos, limpeza dos nomes,
// tela de revisão e edição, arquivo com e sem senha, nenhum dado de pessoa ou da escola no arquivo,
// importação em base com dados (nada alterado) e em base vazia, desfazer, recusas cruzadas com a cópia.
// Só dados fictícios. Uso: LOG=log.txt node testes/teste-partilha.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const novaPagina = async () => { const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR', acceptDownloads: true }), p = await ctx.newPage(); p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); }); return p; };
  const p = await novaPagina();
  const modal = async (pg) => { pg = pg || p; await pg.waitForTimeout(250); await pg.waitForSelector('#modais .modal'); return pg.locator('#modais .modal').last(); };
  const texto = () => p.textContent('#app');
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);

  // ---------- 1. classificação de todas as coleções e campos ----------
  await p.evaluate(async () => {
    const t = IX.turmas.t26; CFG.prefs.turmaId = 't26';
    const an = await criarDoc('anual', { turmaId: t.id }), c = epocasDaSerie(t.serie)[0], ep = await criarDoc('epoca', { turmaId: t.id, epocaId: c.id });
    const sx = ep.secoes.find(s => s.tipo === 'texto' && s.k !== 'avaliacao'); sx.txt = 'A Ana Clara e o Bento recitam o verso. Combinar com Juliana Moreira (juliana.moreira@exemplo.com, (11) 98765-4321) e com a Dona Zuleica, na Escola Waldorf Tecelã.';
    const av = ep.secoes.find(s => s.k === 'avaliacao'); if (av) av.txt = 'SEGREDO-AVALIACAO: a Helena ainda não lê.';
    const di = ep.secoes.find(s => s.k === 'diario'); if (di && di.dias[0]) di.dias[0].notas = 'SEGREDO-DIARIO';
    await salvar('documentos', ep); await salvar('documentos', an);
    await salvar('biblioteca', { id: 'proprio-x1', grupo: 'Fundamentos', titulo: 'Meu verbete', texto: 'Texto do meu verbete sobre o ritmo.', fonte: 'anotações próprias', origem: 'proprio', ordem: 99 });
    await salvar('comunicados', { chave: 'cteste', nome: 'Bilhete do piquenique', texto: 'Olá, família! Traga uma toalha. Ligar para Rodrigo Lima.' });
    const v = IX.vivencias.viv1; v.info = { programacao: [{ hora: '08:30', ativ: 'Saída para a oficina' }], vestimenta: 'Roupa confortável', endereco: 'SEGREDO-ENDERECO Rua do Ferro, 10', orcamento: 'SEGREDO-ORCAMENTO R$ 30', contato: 'SEGREDO-CONTATO' }; await salvar('vivencias', v);
    await prefs({ festas: clone(FESTAS_PADRAO).concat([{ k: 'pao', nome: 'Festa do Pão', quando: '08-15', passos: [[7, 'Pedir farinha às famílias']] }]) });
    const r = D.repertorio.find(x => x.turmaId === 't26'); r.texto = 'Bom dia, Davi, bom dia, sol.'; await salvar('repertorio', r);
  });
  const cls = await p.evaluate(() => {
    const falta = [], todas = Object.keys(PARTILHA.pode).concat(PARTILHA.nunca);
    STORES.forEach(s => { if (!todas.includes(s)) falta.push('coleção sem classificação: ' + s); });
    todas.forEach(s => { if (!STORES.includes(s)) falta.push('classificada mas inexistente: ' + s); });
    Object.keys(PARTILHA.pode).forEach(s => { if (PARTILHA.nunca.includes(s)) falta.push('nas duas listas: ' + s); });
    Object.entries(PARTILHA.pode).forEach(([s, P]) => { const ok = new Set(P.vai.concat(P.fica, PT_META));
      D[s].forEach(r => Object.keys(r).forEach(k => { if (!ok.has(k)) falta.push(s + '.' + k); }));
      if (P.secoes) D[s].forEach(r => (r.secoes || []).forEach(x => Object.keys(x).forEach(k => { if (!P.secoes.vai.includes(k) && !P.secoes.fica.includes(k)) falta.push(s + '.secoes.' + k); })));
      if (P.info) D[s].forEach(r => Object.keys(r.info || {}).forEach(k => { if (!P.info.vai.includes(k) && !P.info.fica.includes(k)) falta.push(s + '.info.' + k); }));
      if (s === 'vivencias') { /* todos os campos do formulário da vivência */ CAMPOS_VIV.forEach(([k]) => { if (!P.info.vai.includes(k) && !P.info.fica.includes(k)) falta.push('vivencias.info.' + k); }); }
    });
    return [...new Set(falta)];
  });
  certo(!cls.length, 'toda coleção e todo campo estão classificados' + (cls.length ? ': ' + cls.join(', ') : ''));

  // ---------- 2. aviso ao compartilhar ----------
  await p.evaluate(() => ir('ajustes')); certo(/Partilha pedagógica/.test(await texto()), 'cartão da Partilha pedagógica em Ajustes');
  await p.click('#m-partilha-aj [data-a=ptCompartilhar]'); let m = await modal(); let mt = await m.textContent();
  certo(/Nunca/.test(mt) && /\[aluno\]/.test(mt) && /opcional/.test(mt) && await m.locator('[data-x=saiba]').count() === 1 && await m.locator('[data-x=c]').count() === 1, 'aviso resumido ao compartilhar, com Continuar, Saiba mais e Cancelar');
  await m.locator('button.pri').click(); await p.waitForTimeout(600);
  let t = await texto(); certo(/Conferir a partilha/.test(t) && /Direitos autorais/.test(t), 'tela de revisão com o aviso de direitos autorais');
  certo(await p.locator('mark.pt-troca').count() > 0, 'trechos trocados destacados');
  const sus = await p.locator('mark.pt-susp').allTextContents(); certo(sus.includes('Zuleica'), 'nome não reconhecido marcado em amarelo (Zuleica)');
  const st = await p.evaluate(() => UI.pt.itens.map(x => x.s)); certo(['documentos', 'repertorio', 'biblioteca', 'comunicados', 'vivencias', 'festas', 'curriculo', 'modelosBoletim'].every(s => st.includes(s)), 'todos os tipos de material aparecem para conferir');

  // edição só na partilha
  const iDoc = await p.evaluate(() => UI.pt.itens.findIndex(x => x.s === 'documentos' && x.r.tipo === 'epoca'));
  await p.evaluate(i => { document.querySelectorAll('details.pt-item')[i].open = true; }, iDoc);
  await p.locator('[data-a=ptEditar][data-i="' + iDoc + '"]').click(); m = await modal();
  const ta = m.locator('textarea').filter({ hasText: 'Zuleica' }); await ta.fill((await ta.inputValue()).replace('Dona Zuleica', 'a cozinheira'));
  await m.locator('button.pri').click(); await p.waitForTimeout(300);
  const ed = await p.evaluate(i => ({ pt: JSON.stringify(UI.pt.itens[i].r), orig: JSON.stringify(D.documentos.filter(d => d.tipo === 'epoca').map(d => d.secoes)) }), iDoc);
  certo(!/Zuleica/.test(ed.pt) && /a cozinheira/.test(ed.pt) && /Zuleica/.test(ed.orig), 'edição vale só para a partilha; o original fica como está');

  // ---------- 3. gerar sem senha, com assinatura ----------
  await p.fill('[data-c=ptDe]', 'Professora Teste (fictícia)'); await p.dispatchEvent('[data-c=ptDe]', 'change');
  let dl = p.waitForEvent('download'); await p.click('[data-a=ptGerar]'); let d = await dl; const arq1 = path.join(require('os').tmpdir(), 'p1.tecela-partilha'); await d.saveAs(arq1);
  certo(/\.tecela-partilha$/.test(d.suggestedFilename()) && /Professora_Teste/.test(d.suggestedFilename()), 'arquivo .tecela-partilha com o nome de quem assina');
  m = await modal(); await m.locator('button.pri').click();
  const txt1 = fs.readFileSync(arq1, 'utf8'), o1 = JSON.parse(txt1);
  certo(o1.app === 'Tecela' && o1.tipo === 'partilha' && Array.isArray(o1.itens) && o1.de === 'Professora Teste (fictícia)', 'formato da partilha');
  // nenhum dado de pessoa ou da escola no arquivo
  const proibidos = await p.evaluate(() => { const xs = []; const sf = s => String(s || '').replace(/\s*\(fict[íi]ci[oa]\)/gi, '').trim();
    D.alunos.forEach(a => { xs.push(sf(a.nome), sf(a.nome).split(' ')[0]); (a.responsaveis || []).forEach(r => { xs.push(sf(r.nome), r.email, r.tel); }); const sg = a.seg || {}; Object.values(sg).forEach(v => { if (typeof v === 'string' && v.length > 8) xs.push(v.slice(0, 20)); }); });
    D.turmas.forEach(t => xs.push(sf(t.professora), sf(t.professora).split(' ')[0]));
    xs.push(sf(CFG.escola.nome), 'Hortênsias', 'Ferraria Martelo', 'Antônio', 'Rodrigo Lima', 'juliana.moreira', '98765-4321', 'SEGREDO');
    D.contatos.forEach(c => xs.push(c.texto.slice(0, 25)));
    return [...new Set(xs.filter(x => x && x.length >= 3))]; });
  const vaz = proibidos.filter(x => txt1.includes(x));
  certo(!vaz.length, 'nenhum nome, contato, dado de saúde ou da escola no arquivo (' + proibidos.length + ' conferidos)' + (vaz.length ? ': ' + vaz.join(', ') : ''));
  certo(/\[aluno\]/.test(txt1) && /\[responsável\]/.test(txt1) && /\[contato\]/.test(txt1) && /\[escola\]/.test(txt1), 'marcadores no lugar dos nomes, contatos e escola');
  certo(!/"turmaId"|"alunoId"|"usos"|"participantes"|"realizadas"|"versoes"/.test(txt1), 'sem vínculos com turma, alunos, usos e versões');
  certo(/Saída para a oficina/.test(txt1) && /Roupa confortável/.test(txt1) && /Festa do Pão/.test(txt1) && /Meu verbete/.test(txt1) && /Bilhete do piquenique/.test(txt1), 'roteiro e textos da vivência, festa, verbete e comunicado vão');

  // ---------- 4. com senha ----------
  await p.check('[data-c=ptSenha]'); await p.dispatchEvent('[data-c=ptSenha]', 'change');
  await p.click('[data-a=ptGerar]'); m = await modal(); await m.locator('[name=s1]').fill('segredo1'); await m.locator('[name=s2]').fill('segredo1');
  dl = p.waitForEvent('download'); await m.locator('button.pri').click(); d = await dl; const arq2 = path.join(require('os').tmpdir(), 'p2.tecela-partilha'); await d.saveAs(arq2); m = await modal(); await m.locator('button.pri').click();
  const o2 = JSON.parse(fs.readFileSync(arq2, 'utf8')); certo(o2.cripto && typeof o2.itens === 'string' && !/Festa do Pão/.test(fs.readFileSync(arq2, 'utf8')), 'partilha com senha fica cifrada');
  await p.evaluate(() => { UI.pt = null; ir('painel'); });

  // ---------- 5. recusas cruzadas ----------
  const rc = await p.evaluate(async t => { const r = {}; try { await lerCopia(t); } catch (x) { r.copia = x.message; } try { await lerPartilha(await pacoteCopia()); } catch (x) { r.part = x.message; } return r; }, txt1);
  certo(/partilha pedagógica/.test(rc.copia || '') && /Receber partilha/.test(rc.copia || ''), 'abrir uma partilha como arquivo de trabalho é recusado com explicação');
  certo(/cópia de segurança/.test(rc.part || ''), 'receber uma cópia de segurança como partilha é recusado com explicação');

  // ---------- 6. importar na base com dados ----------
  await p.evaluate(async () => { const c = D.comunicados.find(x => x.chave === 'cteste'); c.texto = 'Outro texto meu.'; await salvar('comunicados', c); const bb = IX.biblioteca['proprio-x1']; bb.texto = 'Mudei o meu verbete.'; await salvar('biblioteca', bb);
    await prefs({ festas: CFG.prefs.festas.map(f => f.k === 'pao' ? Object.assign({}, f, { quando: '08-16' }) : f) }); await criarDoc('anual', { turmaId: 't25' }); });
  const antes = await p.evaluate(() => JSON.stringify({ d: DADOS.map(s => [s, D[s].map(r => JSON.stringify(r)).sort()]), f: CFG.prefs.festas }));
  const contagem = () => p.evaluate(() => DADOS.reduce((a, s) => a + D[s].length, 0));
  const n0 = await contagem();
  const injetar = async (pg, txt) => pg.evaluate(t => { window.escolherArquivo = async () => new File([t], 'x.tecela-partilha', { type: 'application/json' }); window.guardar = async () => { window._guardou = true; return true; }; }, txt);
  await injetar(p, txt1);
  await p.evaluate(() => ir('partilha')); await p.click('[data-a=ptReceber]'); m = await modal(); mt = await m.textContent();
  certo(/Nada do que você já tem será alterado ou substituído/.test(mt) && /\(recebido\)/.test(mt) && /Remover o que veio desta partilha/.test(mt) && await m.locator('[data-x=copia]').count() === 1 && await m.locator('[data-x=saiba]').count() === 1, 'aviso resumido ao receber, com Salvar cópia antes e Saiba mais');
  await m.locator('[data-x=copia]').click(); m = await modal(); mt = await m.textContent();
  certo(await p.evaluate(() => !!window._guardou), '“Salvar cópia antes” salva o arquivo antes de importar');
  certo(/Professora Teste/.test(mt) && await m.locator('[name=turma]').count() === 1, 'lista do que veio, com a escolha da turma');
  await m.locator('[name=turma]').selectOption('t25'); await m.locator('button.pri').click(); m = await modal(); mt = await m.textContent();
  certo(/entraram/.test(mt) && /repetido\(s\) pulado/.test(mt) && /Nada do que você já tinha foi alterado/.test(mt) && /Onde encontrar/.test(mt), 'resumo do que entrou, dos repetidos e onde encontrar');
  await m.locator('button.pri').click();
  const depois = await p.evaluate(() => { const r = { mud: [], novos: 0 }; return r; });
  const cmp = await p.evaluate(a => { a = JSON.parse(a); const mud = []; a.d.forEach(([s, xs]) => { const atual = new Set(D[s].map(r => JSON.stringify(r))); xs.forEach(x => { if (!atual.has(x)) mud.push(s + ':' + JSON.parse(x).id); }); });
    const fa = a.f.map(f => JSON.stringify(f)), fb = new Set(CFG.prefs.festas.map(f => JSON.stringify(f))); fa.forEach(f => { if (!fb.has(f)) mud.push('festa'); }); return mud; }, antes);
  certo(!cmp.length, 'nenhum registro existente foi alterado ou substituído' + (cmp.length ? ': ' + cmp.join(', ') : ''));
  const n1 = await contagem(); certo(n1 > n0, 'itens novos acrescentados (' + (n1 - n0) + ')');
  const rec = await p.evaluate(() => ({ docs: D.documentos.filter(d => d.partilha && d.turmaId === 't25').length, epCriada: D.curriculo.some(c => c.partilha && c.serie === 2), festa: CFG.prefs.festas.some(f => f.nome === 'Festa do Pão (recebido)' && f.partilha && f.partilha.de === 'Professora Teste (fictícia)'), festaRep: CFG.prefs.festas.filter(f => f.nome === 'Festa da Colheita').length, com: D.comunicados.some(c => c.nome === 'Bilhete do piquenique (recebido)'), bib: D.biblioteca.some(r => r.titulo === 'Meu verbete (recebido)' && r.partilha), viv: D.vivencias.filter(v => v.partilha).every(v => v.turmaId === 't25' && !v.data && !(v.info || {}).endereco), marca: JSON.stringify(D.documentos.filter(d => d.partilha)).includes('[aluno]') }));
  certo(rec.docs >= 2 && rec.epCriada, 'planejamentos entram na turma escolhida; a época que faltava é criada no ano dela');
  certo(rec.festa && rec.festaRep === 1, 'festa de mesmo nome entra como “(recebido)”, marcada com quem enviou; festa igual não duplica');
  certo(rec.com && rec.bib, 'mesmo nome e conteúdo diferente: entra com “(recebido)”, o seu é mantido');
  certo(rec.viv, 'vivências entram sem data, local e informações das famílias');
  certo(rec.marca, 'marcadores [aluno] permanecem como texto');
  // planejamento da turma continua sendo o dela
  const princ = await p.evaluate(() => { const t = IX.turmas.t25, an = anualDe(t); return { proprio: !an || !an.partilha }; });
  certo(princ.proprio, 'o planejamento da turma continua sendo o dela');
  // reimportar a mesma partilha não duplica
  await p.evaluate(() => ir('partilha')); await p.click('[data-a=ptReceber]'); m = await modal(); await m.locator('button.pri').click(); m = await modal(); await m.locator('[name=turma]').selectOption('t25'); await m.locator('button.pri').click(); m = await modal(); mt = await m.textContent(); await m.locator('button.pri').click();
  certo(/0 itens entraram/.test(mt), 'receber de novo a mesma partilha não duplica nada' + (/0 itens entraram/.test(mt) ? '' : ': ' + mt.slice(0, 400)));
  // material recebido e desfazer
  await p.evaluate(() => ir('partilha')); t = await texto(); certo(/Material recebido/.test(t) && /Recebido de Professora Teste/.test(t), 'lista do material recebido, com a etiqueta');
  if (await p.locator('[data-a=ptAbrirDoc]').count()) { await p.locator('[data-a=ptAbrirDoc]').first().click(); await p.waitForTimeout(300); certo(/Prévia do documento/.test(await texto()), 'planejamento recebido abre no editor'); }
  await p.evaluate(() => ir('partilha'));
  const nEtq = await p.locator('[data-a=ptRemover]').count();
  for (let i = 0; i < nEtq; i++) { await p.locator('[data-a=ptRemover]').first().click(); m = await modal(); await m.locator('button.pri').click(); await p.waitForTimeout(300); }
  const voltou = await p.evaluate(a => JSON.stringify({ d: DADOS.map(s => [s, D[s].map(r => JSON.stringify(r)).sort()]), f: CFG.prefs.festas }) === a, antes);
  certo(voltou, '“Remover o que veio desta partilha” deixa tudo exatamente como antes');

  // ---------- 7. base vazia ----------
  const q = await novaPagina(); await q.goto(APP); await q.waitForTimeout(400);
  await q.check('#ckLgpd'); await q.click('[data-a=novo]:not([data-bol])');
  let mq = await modal(q); await mq.locator('[data-x=c]').first().click();
  mq = await modal(q); await mq.locator('button.pri').click();
  mq = await modal(q); await mq.locator('[name=escola]').fill('Escola Nova (fictícia)'); await mq.locator('[name=serie]').selectOption('3'); await mq.locator('[name=letra]').fill('A'); await mq.locator('[name=ano]').fill('2026'); await mq.locator('[name=prof]').fill('Lia Prado (fictícia)'); await mq.locator('[name=gen]').selectOption({ index: 1 }); await mq.locator('button.pri').click(); await q.waitForTimeout(800);
  // a senha
  const tq = await q.evaluate(() => turmaAtual() && turmaAtual().id);
  certo(!!tq, 'base nova só com a turma');
  await injetar(q, fs.readFileSync(arq2, "utf8"));
  await q.evaluate(() => ir('partilha')); await q.click('[data-a=ptReceber]'); mq = await modal(q); await mq.locator('button.pri').click();
  mq = await modal(q); await mq.locator('[name=senha]').fill('errada'); await mq.locator('button.pri').click(); await q.waitForTimeout(1500); certo(/Senha incorreta/.test(await mq.textContent()), 'senha errada é recusada');
  await mq.locator('[name=senha]').fill('segredo1'); await mq.locator('button.pri').click();
  mq = await modal(q); await mq.locator('button.pri').click(); mq = await modal(q); mt = await mq.textContent(); await mq.locator('button.pri').click();
  const vz = await q.evaluate(() => ({ fest: CFG.prefs.festas.some(f => f.nome === 'Festa do Pão'), padrao: CFG.prefs.festas.some(f => f.nome === 'Festa da Colheita' && !f.partilha), docs: D.documentos.filter(d => d.partilha).length, rep: D.repertorio.filter(r => r.partilha).length, com: D.comunicados.some(c => c.nome === 'Bilhete do piquenique'), alunos: D.alunos.length }));
  certo(/entraram/.test(mt) && vz.fest && vz.padrao && vz.docs >= 2 && vz.rep > 0 && vz.com && vz.alunos === 0, 'importação em base vazia (com senha): material entra, festas originais mantidas, nenhum aluno');
  for (const tela of ['planej', 'repert', 'comunic', 'viv', 'biblio', 'partilha', 'ajustes']) { await q.evaluate(t => { UI.sub = null; ir(t); }, tela); if (/Erro ao montar/.test(await q.textContent('#app'))) erros.push('base vazia, tela ' + tela); }
  // turma sem cadastro: itens que precisam de turma ficam desabilitados
  const semTurma = await q.evaluate(async t => { const o = JSON.parse(t); const tur = D.turmas.slice(); D.turmas.length = 0; const pr = escolherEImportar(o); await new Promise(r => setTimeout(r, 300)); const m = document.querySelector('#modais .modal'), tx = m.textContent, dis = m.querySelectorAll('input[name=sel]:disabled').length; m.querySelector('[data-x=c]').click(); await pr; tur.forEach(x => D.turmas.push(x)); return { tx, dis }; }, txt1);
  certo(/cadastre uma turma antes/.test(semTurma.tx) && semTurma.dis > 0, 'sem turma, planejamentos, repertório e vivências ficam desabilitados com explicação');

  // ---------- 8. manual ----------
  await p.evaluate(() => A.manualEm({ id: 'm-partilha' })); await p.waitForTimeout(300); t = await texto();
  certo(/Partilha pedagógica/.test(t) && /Para quem envia/.test(t) && /Para quem recebe/.test(t), 'manual com a seção da Partilha pedagógica para quem envia e para quem recebe');

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
