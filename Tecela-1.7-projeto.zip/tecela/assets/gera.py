# Gera o símbolo da Tecelã: trama 3x3 de fios em aquarela (vermelho, amarelo, azul)
VERM, AMAR, AZUL, AZUL2, VIOL = "#C8452F", "#E9B93A", "#2F6AA8", "#4F8FCC", "#8A62A8"
TINTA, PAPEL = "#2B4460", "#F7F5E8"

def simbolo(uid, wash=True, w=6.5):
    import math
    R, A, K, N = 32, 9, 3, 360
    fios = [(0, VERM), (2*math.pi/3, AMAR), (4*math.pi/3, AZUL)]
    def pt(t, f):
        r = R + A * math.sin(K * t + f)
        return 60 + r * math.cos(t), 60 + r * math.sin(t)
    def caminho(f):
        p = [pt(2*math.pi*i/N, f) for i in range(N + 1)]
        return "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in p) + "Z"
    def trecho(f, t, d=0.3, n=20):
        p = [pt(t - d + 2*d*i/n, f) for i in range(n + 1)]
        return "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in p)
    def fio(f, c, sw=w, extra="", t=None):
        d = caminho(f) if t is None else trecho(f, t)
        return f'<path d="{d}" stroke="{c}" stroke-width="{sw}" stroke-linejoin="round" fill="none" {extra}/>'
    out = []
    if wash:
        out.append(f'<g filter="url(#borra-{uid})" opacity=".8"><circle cx="60" cy="60" r="48" fill="url(#lavagem-{uid})"/></g>')
    g = [fio(f, c) for f, c in fios]
    clips, n = [], 0
    for a in range(3):
        for b in range(a + 1, 3):
            fa, ca = fios[a]; fb, cb = fios[b]
            for i in range(N):
                t0, t1 = 2*math.pi*i/N, 2*math.pi*(i+1)/N
                d0 = math.sin(K*t0+fa) - math.sin(K*t0+fb)
                d1 = math.sin(K*t1+fa) - math.sin(K*t1+fb)
                if d0 == 0 or d0 * d1 < 0:
                    t = (t0 + t1) / 2
                    za, zb = math.cos(K*t+fa), math.cos(K*t+fb)
                    f, c = (fa, ca) if za > zb else (fb, cb)
                    x, y = pt(t, f)
                    n += 1; cid = f"k{uid}{n}"
                    clips.append(f'<clipPath id="{cid}"><circle cx="{x:.2f}" cy="{y:.2f}" r="{w*1.7:.2f}"/></clipPath>')
                    g.append(f'<g clip-path="url(#{cid})">' + fio(f, PAPEL, w + 3.5, t=t) + fio(f, c, t=t) + '</g>')
    out.append('<defs>' + "".join(clips) + '</defs>')
    out.append(f'<g filter="url(#aquarela-{uid})" opacity=".95">' + "".join(g) + '</g>')
    return "".join(out)

def defs(uid):
    return f'''<defs>
<filter id="aquarela-{uid}" x="-10%" y="-10%" width="120%" height="120%">
<feTurbulence type="fractalNoise" baseFrequency="0.06" numOctaves="2" seed="7" result="r"/>
<feDisplacementMap in="SourceGraphic" in2="r" scale="2.6" xChannelSelector="R" yChannelSelector="G" result="d"/>
<feGaussianBlur in="d" stdDeviation=".35"/></filter>
<filter id="borra-{uid}" x="-30%" y="-30%" width="160%" height="160%">
<feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="3" seed="3" result="r"/>
<feDisplacementMap in="SourceGraphic" in2="r" scale="14" xChannelSelector="R" yChannelSelector="G" result="d"/>
<feGaussianBlur in="d" stdDeviation="3"/></filter>
<radialGradient id="lavagem-{uid}" cx="40%" cy="38%" r="70%">
<stop offset="0" stop-color="#F6D355" stop-opacity=".55"/><stop offset=".45" stop-color="#EA6A55" stop-opacity=".28"/>
<stop offset=".8" stop-color="#4F8FCC" stop-opacity=".30"/><stop offset="1" stop-color="#4F8FCC" stop-opacity="0"/></radialGradient>
</defs>'''

FONTE_T = "Marcellus, 'Lora', Georgia, serif"
SLOGAN = "Fio a fio, tecendo as linhas da vida escolar"
POPPINS = "/usr/share/fonts/truetype/google-fonts/Poppins-Regular.ttf"

def texto_em_curvas(txt, tam, x, y, cor, meio=False, fonte_arq=None):
    """Desenha o texto como contornos (Poppins, licença SIL OFL), para o slogan aparecer igual em qualquer aparelho."""
    from fontTools.ttLib import TTFont
    from fontTools.pens.svgPathPen import SVGPathPen
    from fontTools.pens.transformPen import TransformPen
    f = TTFont(fonte_arq or POPPINS); gs, cm, hm = f.getGlyphSet(), f.getBestCmap(), f['hmtx']
    k = tam / f['head'].unitsPerEm
    larg = sum(hm[cm[ord(c)]][0] for c in txt) * k
    x0 = x - larg / 2 if meio else x
    pen, cx = SVGPathPen(gs), 0
    for c in txt:
        n = cm[ord(c)]
        gs[n].draw(TransformPen(pen, (k, 0, 0, -k, x0 + cx * k, y)))
        cx += hm[n][0]
    return f'<path fill="{cor}" d="{pen.getCommands()}"><title>{txt}</title></path>'

FONTE_S = "Nunito, 'Poppins', system-ui, sans-serif"

def horizontal():
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 140" width="1080" height="280">{defs("h")}
<g transform="translate(10 10)">{simbolo("h")}</g>
<g transform="translate(148 80) scale(.062)" fill="{TINTA}"><path d="{PALAVRA}"/></g>
{texto_em_curvas(SLOGAN, 15, 150, 108, VERM)}</svg>'''

def vertical():
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 300" width="640" height="600">{defs("v")}
<g transform="translate(90 14) scale(1.17)">{simbolo("v")}</g>
<g transform="translate({160 - LARG*.058/2:.1f} 216) scale(.058)" fill="{TINTA}"><path d="{PALAVRA}"/></g>
{texto_em_curvas(SLOGAN, 12.6, 160, 246, VERM, meio=True)}</svg>'''

def icone():
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="512" height="512">{defs("i")}
<rect width="120" height="120" rx="26" fill="{PAPEL}"/>{simbolo("i", wash=True, w=7.5)}</svg>'''

import pathlib, subprocess, sys
d = pathlib.Path(__file__).parent
_o = subprocess.run([sys.executable, "-I", str(d / "palavra.py"), sys.argv[1]], capture_output=True, text=True, check=True).stdout
LARG, PALAVRA = float(_o.split("|", 1)[0]), _o.split("|", 1)[1].strip()
(d / "tecela-horizontal.svg").write_text(horizontal())
(d / "tecela-vertical.svg").write_text(vertical())
(d / "tecela-icone.svg").write_text(icone())
