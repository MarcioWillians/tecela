# Converte "Tecelã" em contornos SVG com a fonte Antropos (o "ã" = "a" + til da própria fonte)
import sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

fonte = TTFont(sys.argv[1])
gs, cm, hm = fonte.getGlyphSet(), fonte.getBestCmap(), fonte['hmtx']

def contorno(nome, dx, dy=0):
    pen = SVGPathPen(gs)
    gs[nome].draw(TransformPen(pen, (1, 0, 0, -1, dx, dy)))
    return pen.getCommands()

def caixa(nome):
    b = BoundsPen(gs); gs[nome].draw(b); return b.bounds

x, partes = 0, []
for ch in "Tecela":
    n = cm[ord(ch)]
    partes.append(contorno(n, x))
    ultimo_a = (n, x)
    x += hm[n][0]
# til sobre o último "a": centrado na caixa do "a", acima da altura-x
na, xa = ultimo_a
ax0, ay0, ax1, ay1 = caixa(na)
tx0, ty0, tx1, ty1 = caixa('tilde')
dx = xa + (ax0 + ax1) / 2 - (tx0 + tx1) / 2
dy_alvo = ay1 + 70            # base do til 70 unidades acima do topo do "a"
partes.append(contorno('tilde', dx, -(dy_alvo - ty0)))
largura = x
print(f'{largura}|' + " ".join(partes))
