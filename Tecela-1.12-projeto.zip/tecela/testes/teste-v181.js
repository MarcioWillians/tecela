// Testes da versão 1.8.1: troca dos períodos das faltas (de bimestre para mensal) numa turma nova, digitação dos
// dias letivos e das faltas, e as telas Faltas e Relatórios › Frequência sem erro; conserto de dados já gravados.
// Uso: LOG=log.txt node testes/teste-v181.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const p = await (await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR' })).newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const semErroTela = async () => !/Erro ao montar/.test(await p.textContent('#app'));
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  // turma nova, sem dias letivos nem faltas
  await p.evaluate(async () => { const t = await salvar('turmas', { serie: 3, letra: 'B', ano: 2026, professora: 'Teste (fictícia)' }); window._t = t.id; const a = await salvar('alunos', { nome: 'Criança Teste (fictícia)', chamada: 'Criança', genero: 'f', situacao: 'ativo' }); await salvar('matriculas', { alunoId: a.id, turmaId: t.id }); CFG.prefs.turmaId = t.id; });
  // Ajustes: de bimestre para mensal
  await p.evaluate(() => ir('ajustes'));
  await p.fill('[data-c=periodos]', 'fevereiro, março, abril, maio, junho, agosto, setembro, outubro, novembro, dezembro'); await p.dispatchEvent('[data-c=periodos]', 'change'); await p.waitForTimeout(400);
  if (await p.locator('#modais .modal').count()) await p.locator('#modais .modal button.pri').click();
  // tela Faltas: digitar dias letivos e faltas em meses depois do 4º
  await p.evaluate(() => ir('faltas')); await p.waitForTimeout(300);
  certo(await semErroTela(), 'tela Faltas abre com os períodos mensais');
  await p.fill('[data-b="diasLetivos.5"]', '20'); await p.dispatchEvent('[data-b="diasLetivos.5"]', 'change');
  await p.fill('#gradeFaltas [data-b="faltas.5"]', '2'); await p.dispatchEvent('#gradeFaltas [data-b="faltas.5"]', 'change'); await p.waitForTimeout(800);
  const tipos = await p.evaluate(() => ({ dl: Array.isArray(IX.turmas[window._t].diasLetivos), f: Array.isArray(D.matriculas.find(m => m.turmaId === window._t).faltas) }));
  certo(tipos.dl && tipos.f, 'dias letivos e faltas gravados como lista');
  await p.evaluate(() => { UI.sub = null; ir('faltas'); }); await p.waitForTimeout(300);
  certo(await semErroTela() && /10,0%/.test(await p.textContent('#gradeFaltas')), 'tela Faltas mostra o percentual (2 faltas em 20 dias = 10,0%)');
  await p.evaluate(() => A.abrirRel({ k: 'freq' })); await p.waitForTimeout(400);
  certo(await semErroTela() && /10\.0%/.test(await p.textContent('#app')), 'Relatórios › Frequência abre sem erro, com o percentual');
  // conserto de dados gravados como objeto por versões anteriores
  const cons = await p.evaluate(() => { const t = IX.turmas[window._t], m = D.matriculas.find(x => x.turmaId === window._t); t.diasLetivos = { 0: 18, 5: 20 }; m.faltas = { 5: 2 }; indexar('turmas'); indexar('matriculas'); return Array.isArray(t.diasLetivos) && t.diasLetivos[5] === 20 && Array.isArray(m.faltas) && m.faltas[5] === 2; });
  certo(cons, 'dados antigos gravados como objeto são consertados ao abrir');
  await p.evaluate(() => { t = IX.turmas[window._t]; t.diasLetivos = { 0: 18, 5: 20 }; ir('faltas'); }); await p.waitForTimeout(300);
  certo(await semErroTela(), 'mesmo com dados antigos no formato errado, a tela Faltas não quebra');
  await p.evaluate(() => A.abrirRel({ k: 'freq' })); await p.waitForTimeout(300);
  certo(await semErroTela(), 'mesmo com dados antigos no formato errado, a Frequência não quebra');
  // aviso ao mudar a divisão com números já digitados
  await p.evaluate(() => ir('ajustes'));
  await p.fill('[data-c=periodos]', '1º bimestre, 2º bimestre, 3º bimestre, 4º bimestre'); await p.dispatchEvent('[data-c=periodos]', 'change'); await p.waitForTimeout(500);
  const av = await p.locator('#modais .modal').count() ? await p.locator('#modais .modal').last().textContent() : '';
  certo(/continuam na mesma posição/.test(av), 'ao mudar os períodos com números digitados, a Tecelã avisa para conferir');
  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
