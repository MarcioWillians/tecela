// Testes da versão 1.12: clicar no painel de conferência abre o boletim já na seção; botão Copiar em cada seção;
// botão “Continuar” da tela inicial que cabe no celular; nome do arquivo sem datas acumuladas e sem “.json”;
// boia da cópia de segurança desenhada (sem o emoji 🛟, que falta no Windows 10). Só dados fictícios.
// Uso: LOG=log.txt node testes/teste-v112.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const ctx = await b.newContext({ viewport: { width: 1280, height: 820 }, locale: 'pt-BR' });
  await ctx.addInitScript(() => { window._copiado = null; try { Object.defineProperty(navigator, 'clipboard', { value: { writeText: async t => { window._copiado = t; } }, configurable: true }); } catch (x) { } });
  const p = await ctx.newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  await p.evaluate(() => { CFG.prefs.turmaId = 't26'; ir('bol'); }); await p.waitForTimeout(300);

  // ---------- 1. painel de conferência ----------
  const cel = p.locator('.tabela.conf td.cel-bol[data-al="helena"][data-sec="brincar"]');
  const temCel = await cel.count();
  const sec = temCel ? 'brincar' : await p.evaluate(() => $('.tabela.conf td.cel-bol').dataset.sec);
  const alId = temCel ? 'helena' : await p.evaluate(() => $('.tabela.conf td.cel-bol').dataset.al);
  const alvo = p.locator('.tabela.conf td.cel-bol[data-al="' + alId + '"][data-sec="' + sec + '"]');
  certo(await p.locator('.tabela.conf td.cel-bol').count() > 20 && /Abrir o boletim de .* em /.test(await alvo.getAttribute('title')), 'células do painel clicáveis, com a explicação ao passar o mouse');
  await p.evaluate(() => { const g = $('.grade-fixa'); g.scrollLeft = 120; window.scrollTo(0, 200); });
  const antes = await p.evaluate(() => ({ x: $('.grade-fixa').scrollLeft, y: window.scrollY }));
  await alvo.evaluate(el => el.click()); await p.waitForTimeout(500);
  const r1 = await p.evaluate(s => { const a = document.activeElement, box = $('#sec-' + s); return { sub: !!UI.sub, foco: !!(box && box.contains(a) && a.tagName === 'TEXTAREA'), dest: box && box.classList.contains('destaque'), vis: box && box.getBoundingClientRect().top < innerHeight && box.getBoundingClientRect().bottom > 0 }; }, sec);
  certo(r1.sub && r1.foco && r1.dest && r1.vis, 'clique na célula: boletim aberto na seção, com o cursor no texto individual e a seção destacada');
  await p.click('[data-a=voltarSub]'); await p.waitForTimeout(300);
  const r2 = await p.evaluate(() => ({ x: $('.grade-fixa').scrollLeft, y: window.scrollY, mapa: !!$('.tabela.conf') }));
  certo(r2.mapa && r2.x === antes.x && Math.abs(r2.y - antes.y) < 5 && (antes.x > 0 || antes.y > 0), '← Boletins volta ao painel na mesma posição (' + JSON.stringify(r2) + ')');
  await p.locator('.tabela.conf td.cel-bol[data-sec="poema"]').first().click(); await p.waitForTimeout(400);
  certo(await p.evaluate(() => document.activeElement && document.activeElement.dataset.b === 'poemaTexto'), 'coluna do poema abre no poema');
  await p.click('[data-a=voltarSub]'); await p.waitForTimeout(200);
  await p.locator('.tabela.conf tr.clic td').first().click(); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !!UI.sub && window.scrollY === 0), 'o nome da criança continua abrindo o boletim no topo');

  // ---------- 2. copiar a seção ----------
  const ta = p.locator('#sec-' + sec + ' textarea');
  await ta.fill('Texto fictício da seção para copiar.'); await p.click('h2');
  await p.click('#sec-' + sec + ' [data-a=copiarSec]'); await p.waitForTimeout(200);
  certo(await p.evaluate(() => window._copiado) === 'Texto fictício da seção para copiar.' && /Texto copiado/.test(await p.textContent('#aviso')), 'botão 📋 copia o texto individual da seção inteiro');
  const vazia = await p.evaluate(() => { const s = [...document.querySelectorAll('.secao-bol')].find(x => x.querySelector('textarea') && !x.querySelector('textarea').value.trim()); return s && s.id; });
  if (vazia) { await p.click('#' + vazia + ' [data-a=copiarSec]'); await p.waitForTimeout(150); certo(/ainda não tem texto individual/.test(await p.textContent('#aviso')), 'seção vazia: avisa em vez de copiar'); }

  // ---------- 3. nome do arquivo e tipo ----------
  const nomes = await p.evaluate(() => [semCarimbo('Tecela_Escola_X_2026-11-07_16h56.tecela_2026-11-07_22h47.tecela_2026-11-07_23h03.tecela.json'), semCarimbo('Tecela_Escola_X_2026-11-07_16h56 (1).tecela'), semCarimbo('Tecela_Escola_X_2026-11-07_16h56.tecela'), nomeComData('Tecela_Escola_X_2026-11-07_16h56.tecela_2026-11-07_22h47.tecela.json')]);
  certo(nomes[0] === 'Tecela_Escola_X' && nomes[1] === 'Tecela_Escola_X' && nomes[2] === 'Tecela_Escola_X', 'datas, extensões e “(1)” acumulados saem do nome');
  certo(/^Tecela_Escola_X_\d{4}-\d{2}-\d{2}_\d{2}h\d{2}\.tecela$/.test(nomes[3]), 'nome novo limpo: ' + nomes[3]);
  const tipo = await p.evaluate(async () => { let t = null; const o = window.salvarComo; window.salvarComo = async (n, c, tp) => { t = tp; return { nome: n, escolheu: false }; }; SE.demo = false; try { await guardar(true); } finally { SE.demo = true; window.salvarComo = o; } return t; });
  certo(tipo === 'application/octet-stream', 'o arquivo vai com tipo genérico (o Android não acrescenta “.json”)');

  // ---------- 4. boia desenhada ----------
  certo(await p.locator('.topo [data-a=copiaSeg] svg.ico-boia, [data-a=copiaSeg] svg.ico-boia').count() >= 1 && !(await p.evaluate(() => document.body.innerHTML.replace(/<script[\s\S]*?<\/script>/g, ''))).includes('🛟'), 'boia da cópia de segurança desenhada, sem o emoji 🛟');
  certo(await p.evaluate(() => !MANUAL_HTML.includes('🛟') && MANUAL_HTML.includes('ico-boia')), 'manual com a boia desenhada');

  // ---------- 5. tela inicial no celular, com nome comprido ----------
  const cel2 = await b.newContext({ viewport: { width: 360, height: 760 }, isMobile: true, hasTouch: true, locale: 'pt-BR' });
  const m = await cel2.newPage(); m.on('pageerror', x => erros.push('pageerror cel: ' + x.message));
  await m.goto(APP); await m.waitForTimeout(400);
  await m.check('#ckLgpd'); await m.click('[data-a=novo]:not([data-bol])');
  const md = async () => { await m.waitForTimeout(250); await m.waitForSelector('#modais .modal'); return m.locator('#modais .modal').last(); };
  let d = await md(); await d.locator('[data-x=c]').click(); d = await md(); await d.locator('button.pri').click();
  d = await md(); await d.locator('[name=escola]').fill('Escola Teste (fictício)'); await d.locator('[name=ano]').fill('2026'); await d.locator('[name=prof]').fill('Rui Teste'); await d.locator('[name=gen]').selectOption('o'); await d.locator('button.pri').click();
  await m.waitForTimeout(800);
  await m.evaluate(() => prefs({ arquivoNome: 'Tecela_Escola_Teste_ficticia_2026-11-07_16h56.tecela_2026-11-07_22h47.tecela_2026-11-07_23h03.tecela.json', ultimaCopia: new Date().toISOString() }));
  await m.waitForTimeout(300); await m.reload(); await m.waitForTimeout(800);
  const ini = await m.evaluate(() => ({ txt: $('[data-a=continuar]').textContent.trim(), larg: document.documentElement.scrollWidth <= innerWidth + 1, arq: ($('.arq-continuar') || {}).textContent || '' }));
  certo(ini.txt === 'Continuar' && /…/.test(ini.arq) && /salvo em/.test(ini.arq), 'tela inicial: botão “Continuar” e o nome do arquivo encurtado embaixo');
  certo(ini.larg, 'tela inicial cabe na largura do celular');
  await cel2.close();
  certo(await p.evaluate(() => VERSAO === '1.12'), 'versão 1.12');

  await b.close();
  const real = erros.filter(x => !/favicon|net::ERR/.test(x));
  fs.appendFileSync(LOG, (real.length ? 'FALHOU: ' + real.join(' | ') : 'TUDO CERTO') + '\n');
  console.log(real.length ? 'FALHOU\n' + real.join('\n') : 'TUDO CERTO'); process.exit(real.length ? 1 : 0);
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU: ' + x.message + '\n'); console.log('FALHOU', x); process.exit(1); });
