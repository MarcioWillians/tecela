// Testes da versão 1.10: períodos mensais pelas datas reais; faltas no boletim ("Atualizar faltas" e Finalizar);
// dias letivos no Calendário (intervalos, sábados/domingos, grade, exceções da turma, frequência só leitura);
// relatório anual dos dias letivos com as agendas; reuniões com as famílias (grade, indisponíveis, convite, ata,
// acompanhamento, impressão). Só dados fictícios. Uso: LOG=log.txt node testes/teste-v110.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
  await ctx.addInitScript(() => { const F = new Date('2026-11-19T12:00:00-03:00').getTime(), R = Date; class D2 extends R { constructor(...a) { super(...(a.length ? a : [F])); } static now() { return F; } } window.Date = D2; });
  const p = await ctx.newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const texto = () => p.textContent('#app'), semErro = async () => !/Erro ao montar/.test(await texto());
  const modal = async () => { await p.waitForTimeout(250); await p.waitForSelector('#modais .modal'); return p.locator('#modais .modal').last(); };
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  await p.evaluate(() => { CFG.prefs.turmaId = 't26'; });

  // ---------- 1. períodos com nome de mês ----------
  const pm = await p.evaluate(() => { CFG.prefs.periodos = ['fevereiro', 'março', 'abril', 'maio', 'junho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']; const ps = periodosComDatas(IX.turmas.t26); return { fev: ps[0].ini + '..' + ps[0].fim, ago: ps[5].ini, p: periodoDaData(IX.turmas.t26, '2026-11-12') }; });
  certo(pm.fev === '2026-02-01..2026-02-28' && pm.ago === '2026-08-01' && pm.p === 8, 'períodos com nome de mês usam as datas reais do mês (falta de 12/11 vai para novembro)');
  await p.evaluate(() => { CFG.prefs.periodos = ['1º bimestre', '2º bimestre', '3º bimestre', '4º bimestre']; });

  // ---------- 2. faltas no boletim ----------
  await p.evaluate(async () => { const b = await boletimDe(IX.turmas.t26, IX.alunos.ana); ir('bol', b.id); });
  certo(await p.locator('[data-a=atualizarFaltasBol]').count() === 1 && await p.locator('[data-a=finalizarBol][disabled]').count() === 1, 'botão Atualizar faltas ao lado de Finalizar; Finalizar desabilitado antes de atualizar');
  const antes = await p.evaluate(() => { const b = IX.boletins[UI.sub], k = secaoFaltasDe(modeloDaSerie(3)); return { k, tx: ((b.secoes || {})[k] || {}).texto || '' }; });
  await p.click('[data-a=atualizarFaltasBol]'); await p.waitForTimeout(400);
  const dep = await p.evaluate(() => { const b = IX.boletins[UI.sub], k = secaoFaltasDe(modeloDaSerie(3)), n = somaFaltas(matricula('t26', 'ana').faltas); return { tx: b.secoes[k].texto, n }; });
  const fr = 'Até o presente momento, Ana Clara ' + (dep.n ? 'teve ' + dep.n + ' falta' + (dep.n > 1 ? 's' : '') : 'não teve faltas') + '.';
  certo(antes.k === 'atitudes' && dep.tx.split('\n')[0] === fr && dep.tx.endsWith(antes.tx.trim()), 'frase com o nome da criança na primeira linha da seção de assiduidade, mantendo o texto escrito (' + fr + ')');
  certo(await p.locator('[data-a=finalizarBol]:not([disabled])').count() === 1, 'depois de atualizar, Finalizar fica disponível');
  await p.click('[data-a=atualizarFaltasBol]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => { const b = IX.boletins[UI.sub]; return b.secoes.atitudes.texto.split('\n').filter(l => /^Até o presente momento/.test(l)).length === 1; }), 'atualizar de novo não repete a frase');
  // nova falta lançada depois: volta a pedir atualização
  await p.evaluate(async () => { const m = matricula('t26', 'ana'); m.faltas = comoLista(m.faltas); m.faltas[3] = (Number(m.faltas[3]) || 0) + 1; await salvar('matriculas', m); render(); }); await p.waitForTimeout(300);
  certo(await p.locator('[data-a=finalizarBol][disabled]').count() === 1 && /clique antes em/i.test(await texto()), 'falta lançada depois: Finalizar volta a pedir “Atualizar faltas”');
  await p.click('[data-a=atualizarFaltasBol]'); await p.waitForTimeout(300);
  certo(/teve \d+ falta/.test(await p.evaluate(() => IX.boletins[UI.sub].secoes.atitudes.texto.split('\n')[0])) && await p.locator('[data-a=finalizarBol]:not([disabled])').count() === 1, 'atualizada a nova falta, Finalizar volta a ficar disponível');
  // sem faltas: "não teve faltas"
  certo(await p.evaluate(() => { const m = matricula('t26', 'helena'), f = m.faltas; m.faltas = []; const r = fraseFaltas(IX.turmas.t26, IX.alunos.helena); m.faltas = f; return /^Até o presente momento, Helena não teve faltas\.$/.test(r); }), 'sem faltas: “não teve faltas”');
  // coletivo
  await p.evaluate(() => { UI.sub = null; UI.aba.bol = 'alunos'; ir('bol'); }); await p.waitForTimeout(300);
  certo(await p.locator('[data-a=atualizarFaltasTodos]').count() === 1 && await p.locator('[data-a=finalizarTodos][disabled]').count() === 1, 'no coletivo: Atualizar faltas de todos; Finalizar os prontos desabilitado antes');
  await p.click('[data-a=atualizarFaltasTodos]'); await p.waitForTimeout(600);
  certo(await p.locator('[data-a=finalizarTodos]:not([disabled])').count() === 1 && await p.evaluate(() => Object.values(boletinsAtuais('t26')).every(faltasAtualizadas)), 'depois de atualizar todos, Finalizar os prontos fica disponível');
  certo(await p.evaluate(() => { const b = Object.values(boletinsAtuais('t26')).find(x => x.estado !== 'finalizado'); return statusBoletim(b) && true; }), 'a frase não conta como texto da seção na conferência');
  // escolher a seção / não incluir
  await p.evaluate(() => { UI.aba.bol = 'secoes'; ir('bol'); });
  certo(await p.locator('[data-b=secaoFaltas]').count() === 1, 'em Seções do ano, escolha da seção da frase das faltas');
  await p.selectOption('[data-b=secaoFaltas]', 'nenhuma'); await p.waitForTimeout(500);
  certo(await p.evaluate(async () => { await descarregarFila(); return secaoFaltasDe(modeloDaSerie(3)) === null && Object.values(boletinsAtuais('t26')).every(faltasAtualizadas); }), '“Não incluir a frase” libera o Finalizar sem a frase');
  await p.selectOption('[data-b=secaoFaltas]', 'auto'); await p.waitForTimeout(400);

  // ---------- 3. dias letivos ----------
  await p.evaluate(() => { UI.sub = null; ir('agenda'); });
  certo(await p.locator('[data-a=ir][data-t=letivos]').count() >= 1 && await p.locator('[data-a=ir][data-t=reunioes]').count() >= 1, 'Calendário com os botões Dias letivos e Reuniões com as famílias');
  await p.click('#app [data-a=ir][data-t=letivos]'); await p.waitForTimeout(300);
  certo(await semErro() && /Nenhum intervalo ainda/.test(await texto()), 'tela Dias letivos abre, sem intervalos');
  await p.click('[data-a=letNovaFaixa]'); await p.waitForTimeout(300);
  certo(await p.locator('[data-c=letSemDom]:checked').count() === 1 && await p.locator('[data-c=letSemSab]:checked').count() === 0, 'domingo marcado e sábado desmarcado por padrão');
  await p.fill('[data-c=letFaixa][data-i="0"][data-k=ini]', '2026-02-02'); await p.dispatchEvent('[data-c=letFaixa][data-i="0"][data-k=ini]', 'change'); await p.click('h1'); await p.waitForTimeout(300);
  await p.fill('[data-c=letFaixa][data-i="0"][data-k=fim]', '2026-07-03'); await p.dispatchEvent('[data-c=letFaixa][data-i="0"][data-k=fim]', 'change'); await p.click('h1'); await p.waitForTimeout(300);
  await p.click('[data-a=letNovaFaixa]'); await p.waitForTimeout(300);
  await p.fill('[data-c=letFaixa][data-i="1"][data-k=ini]', '2026-08-03'); await p.dispatchEvent('[data-c=letFaixa][data-i="1"][data-k=ini]', 'change'); await p.click('h1'); await p.waitForTimeout(300);
  await p.fill('[data-c=letFaixa][data-i="1"][data-k=fim]', '2026-12-11'); await p.dispatchEvent('[data-c=letFaixa][data-i="1"][data-k=fim]', 'change'); await p.click('h1'); await p.waitForTimeout(300);
  const L = await p.evaluate(() => ({ f: CFG.prefs.letivos['2026'].faixas, jul: ehLetivo('2026-07-15'), sab: ehLetivo('2026-11-21'), dom: ehLetivo('2026-11-22'), fer: ehLetivo('2026-11-20'), seg: ehLetivo('2026-11-23'), fora: ehLetivo('2026-12-14') }));
  certo(L.f.length === 2 && !L.jul && L.seg && !L.dom && !L.fer && !L.fora, 'dias letivos pelos intervalos: fora deles e domingos/feriados não contam');
  certo(L.sab === true, 'sábado dentro do intervalo conta quando “Excluir sábados” está desmarcado');
  await p.check('[data-c=letSemSab]'); await p.dispatchEvent('[data-c=letSemSab]', 'change'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !ehLetivo('2026-11-21') && ehLetivo('2026-08-29')), 'com “Excluir sábados”, sábados saem, menos os marcados como letivos no calendário');
  // grade: tirar e devolver um dia (escola)
  await p.evaluate(() => { UI.letMes = '2026-11'; render(); }); await p.waitForTimeout(200);
  certo(await p.locator('td.dia-let.st-fora[data-a]').count() === 0 && await p.locator('td.dia-let.st-fds[data-a]').count() === 0, 'dias fora dos intervalos e fins de semana excluídos ficam desabilitados');
  await p.click('td[data-d="2026-11-25"]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !ehLetivo('2026-11-25', IX.turmas.t25) && !ehLetivo('2026-11-25', IX.turmas.t26)), 'tocar num dia letivo o tira dos dias letivos de todas as turmas');
  await p.click('td[data-d="2026-11-25"]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => ehLetivo('2026-11-25')), 'tocar de novo devolve o dia');
  await p.click('td[data-d="2026-11-20"]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => ehLetivo('2026-11-20')), 'tocar num feriado o repõe como dia letivo');
  await p.click('td[data-d="2026-11-20"]'); await p.waitForTimeout(300);
  // exceção só da turma
  await p.click('[data-a=letModo][data-v=turma]'); await p.waitForTimeout(200);
  await p.click('td[data-d="2026-11-26"]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => !ehLetivo('2026-11-26', IX.turmas.t26) && ehLetivo('2026-11-26', IX.turmas.t25)), 'exceção só da turma: o dia sai só para ela');
  await p.click('td[data-d="2026-11-26"]'); await p.waitForTimeout(300);
  const tot = await p.evaluate(() => /Total: (\d+) dias letivos/.exec(document.querySelector('#app').textContent)[1]);
  certo(Number(tot) > 150 && /mínimo legal/.test(await texto()), 'total do ano com o mínimo legal (' + tot + ' dias)');
  // frequência só leitura e coerente
  await p.evaluate(() => { CFG.prefs.periodos = ['fevereiro', 'março', 'abril', 'maio', 'junho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro']; ir('faltas'); }); await p.waitForTimeout(300);
  const fq = await p.evaluate(() => ({ inputs: document.querySelectorAll('#gradeFaltas [data-b^="diasLetivos."]').length, calc: document.querySelectorAll('#gradeFaltas td.dl-calc').length, dl: diasLetivosDaTurma(IX.turmas.t26), nov: diasLetivos('2026-11-01', '2026-11-30', IX.turmas.t26).length }));
  certo(fq.inputs === 0 && fq.calc >= 10 && fq.dl[8] === fq.nov, 'Faltas: dias letivos calculados pelo calendário, só leitura (novembro: ' + fq.nov + ')');
  await p.evaluate(() => A.abrirRel({ k: 'freq' })); await p.waitForTimeout(300);
  certo(await semErro() && await p.locator('#app [data-b^="diasLetivos."]').count() === 0 && /só para leitura/.test(await texto()), 'Relatórios › Frequência: dias letivos só para leitura');
  // relatório anual
  await p.evaluate(() => A.abrirRel({ k: 'letivos' })); await p.waitForTimeout(400);
  const ra = await p.evaluate(() => ({ meses: document.querySelectorAll('#app .cal-ano-mes').length, txt: document.querySelector('#app').textContent }));
  certo(ra.meses === 12 && /Agenda da turma/.test(ra.txt) && /Agenda da escola/.test(ra.txt), 'relatório anual: 12 meses numa folha e as agendas da turma e da escola');
  await p.uncheck('[data-c=relLetEscola]'); await p.dispatchEvent('[data-c=relLetEscola]', 'change'); await p.waitForTimeout(300);
  certo(!/Agenda da escola/.test(await texto()), 'a agenda da escola pode ficar de fora');
  certo(await p.evaluate(async () => { const r = REL.letivos(IX.turmas.t26), bl = await docxBlob(r.doc); return bl.size > 1000 && r.doc.blocos.filter(x => x.t === 'quebra').length >= 1; }), 'relatório anual em Word e com quebra de folha antes da agenda');

  // ---------- 4. reuniões com as famílias ----------
  await p.evaluate(() => { UI.sub = null; UI.reuMes = '2026-11'; ir('reunioes'); }); await p.waitForTimeout(300);
  certo(await semErro() && await p.locator('td.dia-reu.desab[data-d]').count() === 0 && await p.locator('td.dia-reu.clic[data-d="2026-11-24"]').count() === 1 && await p.locator('td.dia-reu.desab').count() > 0, 'grade das reuniões: só dias letivos habilitados');
  await p.click('td[data-d="2026-11-23"]'); await p.waitForTimeout(300); await p.click('[data-a=reuIndisp]'); await p.waitForTimeout(300);
  certo(await p.evaluate(() => (IX.turmas.t26.reunioesIndisp || []).includes('2026-11-23') && ehLetivo('2026-11-23')), 'dia indisponível só para a agenda das reuniões (continua letivo)');
  await p.click('td[data-d="2026-11-24"]'); await p.waitForTimeout(300); await p.click('[data-a=reuNova]'); let m = await modal();
  await m.locator('#reuAluno').selectOption('ana'); await p.waitForTimeout(150); await m.locator('[name=hora]').fill('14:00'); await m.locator('[name=horaFim]').fill('14:40'); await m.locator('[name=convidado]').fill('Rita, psicóloga (fictícia)'); await m.locator('[name=assunto]').fill('conversa do 2º semestre');
  certo(await m.locator('[name=resp]').count() >= 1, 'responsáveis da criança aparecem para marcar (primeiro nome)');
  await m.locator('button.pri').click(); await p.waitForTimeout(500);
  const r = await p.evaluate(() => D.eventos.find(v => v.familia));
  certo(r && r.alunoId === 'ana' && r.resp.length >= 1 && r.convidado && r.tipo === 'reuniao' && r.turmaId === 't26' && r.situacao === 'agendada', 'reunião marcada com criança, família, convidado e situação');
  certo(await p.evaluate(id => itensAgenda('2026-11-01', '2026-11-30').some(x => x.id === id), r.id), 'a reunião aparece no calendário');
  certo(await p.locator('td[data-d="2026-11-24"] .reu-chip').count() === 1, 'a reunião aparece na grade do mês');
  // convite
  let html = ''; await p.evaluate(() => { window._sd = saidaDocumento; window.saidaDocumento = (d) => { window._conv = d; }; });
  await p.click('[data-a=reuConvite]'); await p.waitForTimeout(200);
  html = await p.evaluate(() => JSON.stringify(window._conv.blocos)); await p.evaluate(() => { window.saidaDocumento = window._sd; });
  certo(/Convite para conversa/.test(html) && /24\/11\/2026/.test(html) && /14h00/.test(html) && /Rita/.test(html), 'convite para a família com data, horário e convidado');
  // ata
  await p.click('#app [data-a=reuAta]'); await p.waitForTimeout(600);
  const at = await p.evaluate(id => { const r = IX.eventos[id], a = IX.atas[r.ataId], c = IX.contatos[r.contatoId]; return { tela: UI.tela, ata: a && { tipo: a.tipo, data: a.data, inicio: a.inicio, cats: a.participantes.map(x => x.categoria), conv: a.participantes.some(x => /Rita/.test(x.nome)) }, cont: c && { meio: c.meio, ata: c.ataId === r.ataId }, sit: r.situacao }; }, r.id);
  certo(at.tela === 'atas' && at.ata && at.ata.tipo === 'familias' && at.ata.data === '2026-11-24' && at.ata.inicio === '14:00' && at.ata.cats.includes('Familiar') && at.ata.conv, 'Registrar ata: ata de reunião com as famílias já preenchida (data, horário, participantes e convidado)');
  certo(at.cont && at.cont.meio === 'reuniao' && at.cont.ata && at.sit === 'realizada', 'registro no Acompanhamento ligado à ata; reunião marcada como realizada');
  // impressão
  const imp = await p.evaluate(() => { const o = window.saidaDocumento, r = []; window.saidaDocumento = d => r.push(d); A.reuImprimir({ v: 'lista' }); A.reuImprimir({ v: 'grade' }); window.saidaDocumento = o; return r.map(d => d.blocos.map(x => x.t).join(',')); });
  certo(/tabela/.test(imp[0]) && /calMes/.test(imp[1]), 'impressão em lista e em grade mês a mês');
  certo(await p.evaluate(async () => { const o = window.saidaDocumento; let d; window.saidaDocumento = x => d = x; A.reuImprimir({ v: 'grade' }); window.saidaDocumento = o; const h = htmlDoc(d, true), bl = await docxBlob(d); return /cal-mes/.test(h) && bl.size > 1000; }), 'grade das reuniões no PDF e no Word');
  await p.evaluate(() => A.abrirRel({ k: 'reunioes' })); await p.waitForTimeout(300);
  certo(await semErro() && /Ana Clara/.test(await texto()), 'Relatórios › Reuniões com as famílias');
  // cópia de segurança leva os dias letivos
  certo(await p.evaluate(async () => { const o = JSON.parse(await pacoteCopia()); return !!(o.dados.config.prefs.letivos && o.dados.config.prefs.letivos['2026']); }), 'o arquivo .tecela guarda os dias letivos');
  // telas sem erro
  for (const tela of ['painel', 'agenda', 'letivos', 'reunioes', 'faltas', 'bol', 'planej']) { await p.evaluate(t => { UI.sub = null; ir(t); }, tela); if (!(await semErro())) erros.push('tela ' + tela); }
  await p.evaluate(() => ir('planej', null, 'ano')); certo(await semErro(), 'Planejamento › Ano letivo sem erro com os dias letivos definidos');

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
