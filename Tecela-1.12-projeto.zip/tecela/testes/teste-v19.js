// Testes da versão 1.9: chamada de dias anteriores (setas, data, dias sem aula, período certo, aviso de total
// digitado à mão) e tabelas largas com a linha de títulos e a coluna dos nomes fixas (Faltas, Frequência, Boletins).
// Uso: LOG=log.txt node testes/teste-v19.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const ctx = await b.newContext({ viewport: { width: 1280, height: 700 }, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo' });
  await ctx.addInitScript(() => { const F = new Date('2026-11-19T12:00:00-03:00').getTime(), R = Date; class D2 extends R { constructor(...a) { super(...(a.length ? a : [F])); } static now() { return F; } } window.Date = D2; });
  const p = await ctx.newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const card = () => p.textContent('#cartao-chamada');
  await p.goto(APP); await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  await p.evaluate(() => { CFG.prefs.turmaId = 't26'; UI.chamada = null; ir('painel'); }); await p.waitForTimeout(300);
  let t = await card(); certo(/Chamada de hoje/.test(t) && await p.locator('[data-a=chamadaDia][data-v="-1"]').count() === 1 && await p.locator('[data-c=chamadaData]').count() === 1, 'chamada com setas e campo de data');
  // dia letivo anterior
  await p.click('[data-a=chamadaDia][data-v="-1"]'); await p.waitForTimeout(300);
  const d1 = await p.inputValue('[data-c=chamadaData]'); t = await card();
  certo(d1 < '2026-11-20' && t.includes('Chamada de ' + d1.split('-').reverse().join('/')) && await p.evaluate(d => ehLetivo(d), d1), 'seta ◀ vai para o dia letivo anterior (' + d1 + ')');
  // data de um período anterior: a falta entra no período daquela data
  const alvo = await p.evaluate(() => { const ps = periodosComDatas(IX.turmas.t26); const pp = ps.find(x => x.i === 0); let d = pp.ini; while (!ehLetivo(d)) d = somaDias(d, 1); return { d: somaDias(d, 0), p0: periodoDaData(IX.turmas.t26, hojeISO()) }; });
  await p.fill('[data-c=chamadaData]', alvo.d); await p.dispatchEvent('[data-c=chamadaData]', 'change'); await p.waitForTimeout(300);
  const antes = await p.evaluate(() => { const m = matricula('t26', 'davi'); return comoLista(m.faltas).slice(); });
  await p.click('#cartao-chamada [data-a=chamada][data-al=davi]'); await p.waitForTimeout(400);
  const dep = await p.evaluate(d => { const m = matricula('t26', 'davi'); return { aus: (m.ausencias || []).includes(d), f: comoLista(m.faltas).slice() }; }, alvo.d);
  certo(dep.aus && (Number(dep.f[0]) || 0) === (Number(antes[0]) || 0) + 1 && (alvo.p0 === 0 || (Number(dep.f[alvo.p0]) || 0) === (Number(antes[alvo.p0]) || 0)), 'falta de dia anterior entra no período daquela data, não no de hoje');
  certo(/faltou/.test(await card()), 'a criança aparece como faltou naquele dia');
  // desfazer
  await p.click('#cartao-chamada [data-a=chamada][data-al=davi]'); await p.waitForTimeout(400);
  certo(await p.evaluate(([d, a0]) => { const m = matricula('t26', 'davi'); return !(m.ausencias || []).includes(d) && (Number(comoLista(m.faltas)[0]) || 0) === (Number(a0) || 0); }, [alvo.d, antes[0]]), 'tocar de novo desfaz a falta daquele dia');
  // domingo: sem aula
  await p.fill('[data-c=chamadaData]', '2026-11-15'); await p.dispatchEvent('[data-c=chamadaData]', 'change'); await p.waitForTimeout(300);
  t = await card(); certo(/Sem aula neste dia/.test(t) && await p.locator('#cartao-chamada [data-a=chamada]').count() === 0, 'dia sem aula aparece bloqueado, com o motivo');
  // futuro
  await p.fill('[data-c=chamadaData]', '2026-11-25'); await p.dispatchEvent('[data-c=chamadaData]', 'change'); await p.waitForTimeout(300);
  certo(/Chamada de hoje/.test(await card()), 'data futura não é aceita: volta para hoje');
  // aviso de total digitado à mão
  await p.evaluate(async d => { const m = matricula('t26', 'cecilia'); m.faltas = comoLista(m.faltas); m.faltas[0] = 5; m.ausencias = []; await salvar('matriculas', m); UI.chamada = { t: 't26', d }; render(); }, alvo.d); await p.waitForTimeout(300);
  certo(/foi digitado na tela Faltas/.test(await card()) && /Cecília|Cecilia/.test(await card()), 'aviso quando o total do período foi digitado à mão na tela Faltas');
  await p.click('[data-a=chamadaHoje]'); await p.waitForTimeout(300);
  certo(/Chamada de hoje/.test(await card()), 'botão Hoje volta para a chamada do dia');

  // tabelas largas: cabeçalho e primeira coluna fixos
  await p.evaluate(async () => { await prefs({ periodos: ['fevereiro', 'março', 'abril', 'maio', 'junho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro', 'extra 1', 'extra 2'] }); UI.sub = null; ir('faltas'); }); await p.waitForTimeout(400);
  const fx = await p.evaluate(() => { const c = document.querySelector('.grade-fixa'), th = c && c.querySelector('th'), n = c && c.querySelector('tr:nth-child(3)>:first-child'); if (!c) return null; const cs = getComputedStyle(c); c.scrollLeft = 400; c.scrollTop = 200; const r0 = c.getBoundingClientRect(), r1 = n.getBoundingClientRect(), r2 = th.getBoundingClientRect(); return { overflow: cs.overflow, larga: c.scrollWidth > c.clientWidth, alta: c.clientHeight <= innerHeight, nome: Math.abs(r1.left - r0.left) < 3, titulo: Math.abs(r2.top - r0.top) < 20 }; });
  certo(fx && /auto/.test(fx.overflow) && fx.alta, 'Faltas: tabela com rolagem própria, que cabe na tela');
  certo(fx && fx.larga && fx.nome, 'Faltas: ao rolar para o lado, a coluna dos nomes fica fixa');
  certo(fx && fx.titulo, 'Faltas: ao rolar para baixo, a linha dos meses fica fixa');
  await p.evaluate(() => A.abrirRel({ k: 'freq' })); await p.waitForTimeout(400);
  certo(await p.locator('#app .grade-fixa table').count() >= 1, 'Relatórios › Frequência com a tabela de rolagem fixa');
  await p.evaluate(() => { UI.aba.bol = 'lista'; UI.sub = null; ir('bol'); }); await p.waitForTimeout(400);
  certo(await p.locator('#app .grade-fixa .tabela.conf').count() === 1, 'Boletins: painel de conferência com a tabela de rolagem fixa');
  certo(!/Erro ao montar/.test(await p.textContent('#app')), 'telas sem erro');

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
