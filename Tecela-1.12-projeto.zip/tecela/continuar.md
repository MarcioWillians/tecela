# Tecelã — como continuar o projeto em uma nova conversa

## 1. O que enviar

- **Tecela-(versão)-projeto.zip**: a pasta inteira do projeto. Dentro dela já estão este arquivo, o `README.md` e o `Tecelã — Especificação do projeto.docx`.
- (opcional) Um arquivo `.tecela` de **teste**, só com dados fictícios. Nunca envie dados reais de crianças: os arquivos reais ficam só no aparelho da professora.
- (opcional) A fonte `antrf___.ttf` (Antropos), só se for preciso redesenhar o logotipo.
- (opcional) O PDF "BNCC Computação — completo diagramado", só se for preciso gerar de novo as habilidades de Computação.

## 2. Texto para colar no início da conversa

> Atue como especialista em pedagogia Waldorf e Antroposofia, pedagogo, especialista em administração escolar e desenvolvedor web.
>
> Estou anexando o código-fonte da Tecelã ("Fio a fio, tecendo as linhas da vida escolar"), versão 1.12: um app em HTML único, offline, para a professora ou o professor de classe Waldorf (uma professora, uma turma, acompanhada do 1º ao 8º ano). Leia primeiro o `continuar.md` e o `README.md`.
>
> O que eu quero agora: [descreva a mudança, a correção ou a nova função]
>
> Ao terminar, me entregue o projeto todo em .zip (com `continuar.md`, `README.md` e a especificação .docx atualizados) e, à parte, o HTML único.

## 3. Regras do projeto

- HTML único, sem internet (só o envio por e-mail usa a rede), em português do Brasil.
- Tela inicial: Continuar, Abrir arquivo, Novo, Novo a partir de boletins anteriores, Modelo de demonstração e Computador de terceiros.
- Os dados ficam no IndexedDB (gravados a cada digitação) e num arquivo `.tecela` salvo pela professora; "💾 Salvar" (Ctrl+S) grava sempre no mesmo arquivo. O indicador no topo (`htmlEstadoSalvo`) e o texto `TEXTO_SALVAR` explicam a diferença.
- Senha opcional: AES-256-GCM com PBKDF2 (250.000 iterações) e chave de recuperação.
- Cópia de segurança (`cuidados.js`): arquivo à parte, `Tecela_COPIA_….tecela`, com `copiaSeg: true`, sempre cifrado. Com a senha da Tecelã, usa a mesma chave; sem ela, a "senha das cópias" (criada na primeira cópia, com chave de recuperação) fica só no aparelho, em `CFG.prefs.copiaSegCripto` e `copiaSegDk`, que não estão na lista de prefs de `pacoteCopia` e nunca vão no arquivo do Salvar. Ligar a senha da Tecelã apaga a senha das cópias (passa a valer a da Tecelã). Lembrete a cada `CFG.prefs.lembreteCopia` dias (padrão 5; 0 desliga) desde `ultimaCopiaSeg`: Painel, topo e Sair. Ao abrir uma cópia de segurança, a professora escolhe continuar com senha ou sem (aí a senha da cópia vira a senha das cópias); a cópia aberta não vira o arquivo de trabalho (sem `arquivoNome` nem caminho). No celular, a cópia vai pelo compartilhamento do sistema (`navigator.share` com arquivo).
- Desfazer nos textos (`cuidados.js`): histórico da sessão (`HIST`, até 60) das alterações em campos de texto com `data-rec` + `data-b`, registrado ao sair do campo; ↶ no topo e Ctrl+Z fora de campo desfazem a última; apagar 40 ou mais caracteres de uma vez mostra "Trecho apagado · Desfazer"; "Histórico" lista as versões. Respeita `bloqueado()` (ata e boletim finalizados).
- Digitalizados (`digitais.js`): fotos reduzidas no navegador (lado maior 1600 px, JPEG 0,72, miniatura de 320 px); PDF até 3 MB, recusado acima; medidor amarelo acima de 50 MB e vermelho acima de 100 MB; o diálogo de inclusão mostra quanto o arquivo vai crescer (`pesoNoArquivo`: base64, cerca de 1/3 maior) e Ajustes → Armazenamento mostra digitalizados × todo o resto (`pesoDados`), com o texto `AVISO_PESO_DIG`. Ficam no arquivo e na cópia de segurança, nunca na partilha (`PARTILHA.nunca`).
- LGPD: nada sai do aparelho sem ação da professora. Dados reais são processados só no aparelho dela, nunca na conversa.
- Documentos finalizados (atas e boletins) não mudam: usa-se "Em tempo" ou nova versão, com impressão digital SHA-256.
- Android: o `Tecela.html` aberto pelo gerenciador de arquivos fica em `content://`, e nesse modo o Chrome não entrega à página o arquivo escolhido. Pelo endereço https do GitHub Pages (`https://marciowillians.github.io/tecela/Tecela.html`) o arquivo abre normalmente (testado em 07/11/2026); no celular, “Salvar” baixa uma cópia nova (o Android não deixa a página gravar de volta no arquivo).
- Seletor do `.tecela` (`ACEITA_TECELA` em `nucleo.js`): no Android, tipos de documento (`application/octet-stream`, JSON, texto), porque o sistema trata `.tecela` como "Arquivo em BIN"; filtrar só por `.tecela` deixa o arquivo cinza, e não filtrar faz o Chrome abrir só Câmera e Galeria. No iPhone e no iPad, sem filtro ("Escolher arquivo"). No computador, filtro pela extensão. O conteúdo é sempre conferido ao ler.
- Exportação em PDF (impressão do navegador), DOCX (biblioteca docx embutida), CSV e ZIP.
- Cada criança é comparada só com ela mesma; a turma, só com ela mesma.
- Pontos de atenção e anotações sigilosas nunca entram no boletim; em relatórios, só se a professora marcar.
- Cadastros: item sem uso é excluído; item com uso é arquivado, para não perder relações e histórico.
- Biblioteca: verbetes da professora podem ser excluídos; verbetes que vêm com o app são ocultados, não excluídos; a BNCC é só leitura.
- A professora deve trabalhar o mínimo possível: sugerir, pré-preencher e deixar desfazer.
- Fora do escopo: ditado por voz, banco de poemas, importação da planilha de observação e do calendário da escola.
- Logotipo: nome em Antropos (Lutz Baar) e slogan em Poppins, os dois já convertidos em curvas. O arquivo da Antropos não pode ser embutido (uso cultural, embutimento restrito).
- Modelo de demonstração: "Escola Waldorf Tecelã", com "(fictício)" após o nome da professora e de cada criança. Ao mudar o modelo, aumente `DEMO_VERSAO` em `src/demo.js`.
- Autor e idealizador: Márcio Willians Barreto de Andrade (marciowillians@gmail.com). Licença GNU GPL v3 com termos adicionais da seção 7 (arquivo `LICENSE`): o aviso de autoria (`AUTORIA`, em `nucleo.js`) tem de ficar visível na tela inicial e nos Créditos, e versões modificadas devem se identificar e isentar o autor original. O `build.py` embute o `LICENSE` no app (`__LICENCA__`).
- Os mínimos de dias letivos e de horas (`minDias()`, `minHoras()` em `rotina.js`) vêm de Ajustes; o padrão é o da LDB (200 e 800).
- 9º ano oculto por padrão (`seriesVisiveis()`; Ajustes → Anos mostrados): na tradição Waldorf, o 9º ano já é o início do ensino médio.
- Campos de data que redesenham a tela (`data-rr` ou `data-c`) só redesenham ao sair do campo: o navegador considera válido o ano parcial (0002…) enquanto se digita.
- **Partilha pedagógica (regra permanente):** a cada atualização, revise `PARTILHA` em `src/partilha.js`. Toda coleção de `STORES` tem de estar em `PARTILHA.pode` (com cada campo em `vai` ou `fica`, inclusive as seções dos documentos e as informações da vivência) ou em `PARTILHA.nunca`. Coleção ou campo novo fica fora da partilha até ser incluído de propósito; dados de pessoas, da escola, de saúde, datas do calendário e vínculos nunca vão. O `teste-partilha.js` falha se algo ficar sem classificação. Em cada entrega, informe o que foi classificado e em qual lista.
- A partilha só acrescenta: nada existente é alterado; repetidos são pulados; mesmo nome com conteúdo diferente ganha "(recebido)"; cada importação tem uma etiqueta (`partilha: {id, de, em}`) e "Remover o que veio desta partilha" apaga só os itens dela. Planejamento anual, plano de época e modelo de boletim recebidos não tomam o lugar dos da professora (`anualDe`, `planoEpocaDe` e `modeloDaSerie` dão preferência aos próprios).
- **Numeração das versões (versionamento semântico, MAIOR.MENOR.CORREÇÃO):**
  - MAIOR (1 → 2): mudança que quebra a compatibilidade, como um formato de arquivo que versões anteriores não abrem, ou uma reorganização grande do app.
  - MENOR (1.6 → 1.7): qualquer função nova, mesmo pequena, ou mudança visível no comportamento; o terceiro número volta a zero e não é escrito (1.7, não 1.7.0).
  - CORREÇÃO (1.7 → 1.7.1): só correções, ajustes de texto, avisos e documentação, sem função nova.
  - Atualizar sempre juntos: `VERSAO` e `DATA_VERSAO` em `nucleo.js`, README, este arquivo (texto para colar e tabela de versões), a Especificação (cabeçalho e histórico) e a tag da versão no GitHub (`v1.7.1`).
- Distribuição: GitHub, em <https://github.com/MarcioWillians/tecela/releases> (`LINK_VERSOES` em `nucleo.js` aponta para `releases/latest`). Cada versão é publicada como uma Release com o `Tecela.html` e o zip do projeto (a GPL pede o código-fonte junto). O GitHub Pages está ligado e serve o `Tecela.html` da página principal do repositório em `https://marciowillians.github.io/tecela/Tecela.html` (uso no celular e sem baixar); os dados digitados por esse endereço ficam no navegador, separados dos do arquivo baixado.
- Contato e avisos: `contatoHtml()` (Ajuda → Sobre, sugestões e versões; link da tela inicial; rodapé do menu) e `avisoBnccHtml()` (aba BNCC e verbete da Biblioteca), com o texto `NAO_ENVIE`. A BNCC não é editável no app; mudanças do MEC entram numa versão nova, extraída do documento oficial pelos scripts de `ferramentas/`.
- Dias letivos: uma única fonte, `ehLetivo(iso, t)` (em `calendario.js`). Sem intervalos definidos no ano, vale `ehLetivoSimples` (dias úteis menos feriados, mais sábados letivos); com eles, `estadoDiaEscola` e as exceções da turma (`letivos.js`). Tudo o que conta dias (frequência, chamada, plano de época, diário, contagem do ano) passa por ela. Com dias letivos definidos, os dias letivos da frequência são calculados (`diasLetivosDaTurma`) e não se editam.
- Períodos das faltas com nome de mês usam as datas reais do mês (`mesesDoRotulo` em `rotina.js`); os demais dividem o ano.
- Boletim: “Atualizar faltas” escreve a frase das faltas (`fraseFaltas`, com o nome de chamada) na primeira linha da seção escolhida (`secaoFaltasDe`); o Finalizar só fica disponível enquanto a frase está de acordo com as faltas atuais (`faltasAtualizadas`).
- Sempre gere de novo o HTML com `python3 build.py` e rode todos os testes.

## 4. Como o código está organizado

| Arquivo | O que faz |
|---|---|
| `build.py` | Junta tudo em `dist/Tecela.html`, na ordem da lista `ORDEM`, e injeta os logotipos e o texto da licença |
| `src/index.html`, `src/estilo.css` | Página-modelo e estilos (paleta, celular, impressão) |
| `src/nucleo.js` | Utilidades, criptografia, IndexedDB (versão 6), salvar/apagar com "Desfazer", diálogos, vínculo de campos (`data-rec` + `data-b`), arquivo `.tecela`, ZIP, impressão, e-mail |
| `src/cadastros.js` | Listas personalizáveis, "onde é usado" (`ondeUsado`), excluir/arquivar, migrações únicas (`mig12`, `mig13`) |
| `src/bncc-dados.js` | 1.304 habilidades da BNCC (gerado por `ferramentas/extrair_bncc.py`) |
| `src/bncc-computacao-dados.js` | 104 habilidades de Computação (83 por ano e 21 por etapa) com eixo, objeto, explicação e exemplos, e as 7 competências (gerado por `ferramentas/extrair_computacao.py`) |
| `src/bncc-computacao.js` | Liga e desliga a Computação (`aplicarComputacao`), eixos e blocos de documento |
| `src/docmotor.js` | Documentos editáveis com seções (`TIPOS_DOC`): editor, ↻ por seção, versões com impressão digital, exportação |
| `src/apoio.js` | Aniversariantes, poemas, pauta da reunião, reforço e bilhete, informações completas da vivência |
| `src/turmadocs.js` | Combinados da turma (com versões e “repetir o do ano anterior”) e PEI |
| `src/planejamento.js` | Conteúdo programático, horário semanal (aulas com horário, Aula principal, impressão em tabela), Planejamento anual e Plano de época (com repertório, avaliação da época e notas de quem já deu a época) |
| `src/partilha.js` | Partilha pedagógica: classificação `PARTILHA` (o que pode ir, campo a campo, e o que nunca vai), troca de nomes conhecidos por marcadores, tela Conferir a partilha (edição só para o arquivo), arquivo `.tecela-partilha` com senha opcional, importação seletiva sem alterar nada, Material recebido e desfazer |
| `src/familia.js` | Saúde e segurança do aluno, ficha de emergência e autorização da vivência, entrevista com a família, estudo de criança, contatos com as famílias (tela Acompanhamento) e comunicados com modelos |
| `src/repertorio.js` | Repertório da turma (versos, canções, histórias…), com usos e épocas; acompanha a turma de ano em ano |
| `src/rotina.js` | Períodos das faltas com datas, chamada no Painel (hoje e dias anteriores), roteiro do professor substituto, contagem de dias letivos e carga horária, festas do ano, lista de materiais, conferência dos textos do boletim |
| `src/cuidados.js` | Cópia de segurança com senha (senha das cópias, lembrete no Painel, no topo e no Sair, cartão em Ajustes, explicação no primeiro Salvar) e Desfazer nos textos (histórico da sessão, ↶, Ctrl+Z, trecho apagado) |
| `src/digitais.js` | Digitalizados: inclusão de fotos (redução e miniatura) e PDF (até 3 MB), câmera no celular, álbuns, ligações (criança, ata, vivência, reunião), visualizador com zoom, medidor de espaço; `blocoDigitais` nos editores e `A.reuDigitais` nas reuniões |
| `src/letivos.js` | Dias letivos do ano (intervalos, sábados e domingos, grade mês a mês, exceções da turma), relatório anual dos dias letivos com as agendas da turma e da escola, Reuniões com as famílias (grade, indisponíveis, convite, ata e acompanhamento, impressão em lista e em grade); blocos `calAno` e `calMes` (no Word, viram tabelas por `blocosParaWord`) |
| `src/planejamento-dados.js`, `src/programa-dados.js` | Textos de base de cada ano, épocas de referência e o conteúdo programático de referência (gerado por `ferramentas/extrair_programa.py`, sem identificar a escola) |
| `src/documentos.js` | Blocos de documento → HTML/PDF e DOCX; ata, boletim, timbrado, grade do mês |
| `src/biblioteca.js` | Verbetes da Biblioteca Waldorf (`BIBLIO`), com fontes |
| `src/telas-base.js` | Casca (montada uma vez; a cada mudança só `#corpo` e o topo são redesenhados, e o menu guarda a rolagem), menu (`GRUPOS`, grupos recolhíveis, Recentes), atalhos de teclado, indicador de salvamento, tela inicial (versão e autoria), senha, Painel, Turma e alunos (arquivar e excluir turma), virada do ano (com pendências) |
| `src/telas-docs.js` | Anotações, Atas, Boletins (rascunho da observação, poema do ano, ZIP, finalizar os prontos; painel de conferência com células que abrem o boletim na seção, `A.abrirBol` com `d.sec` e `UI.mapaBol` para a volta; `A.copiarSec`, o 📋 de cada seção) |
| `src/telas-perfis.js` | Perfil do aluno, perfil e evolução da turma, Biblioteca (com a categoria BNCC, novo verbete, ocultar) |
| `src/observacao.js` | Observação do período: roteiro, períodos, rascunho do boletim, sugestão do perfil |
| `src/conselho.js` | Conselho de classe: pré-conselho, registro, pós-conselho |
| `src/rapido.js` | ✎ Anotar, grade de faltas, busca, pendências do Painel |
| `src/calendario.js` | Calendário (repetição e exceções), vivências, tarefas, avisos, `.ics` |
| `src/curriculo.js` | Currículo da escola, consulta à BNCC, sugestões, comparação |
| `src/relatorios.js` | Ficha da criança, observação, perfil e evolução da turma e demais relatórios |
| `src/telas-config.js` | Papel timbrado, Ajustes, Ajuda |
| `src/importar.js` | Importador de boletins `.docx`, dentro do app |
| `src/ajuda.js` | Manual, créditos e licenças, privacidade, sobre |
| `src/demo.js`, `src/app.js` | Modelo de demonstração e inicialização |
| `vendor/` | docx 9.7.1 (MIT) e sua licença |
| `assets/` | Logotipos, ícone e prancha; `gera.py` e `palavra.py` redesenham o logotipo |
| `ferramentas/` | `extrair_bncc.py`, `extrair_computacao.py` e `extrair_programa.py` |
| `testes/` | Testes com Playwright (ver o `README.md`) |

**Dados.** Bancos IndexedDB `tecela` (dados) e `tecela-demo` (modelo). Coleções: config, timbrado, turmas, alunos, matriculas, anotacoes, atas, marcacoes, modelosBoletim, boletins, perfisAluno, perfisTurma, biblioteca, cadastros, eventos, vivencias, tarefas, curriculo, observacoes, conselhos, documentos, reforcos, programa, repertorio, contatos, comunicados, digitais (IndexedDB versão 6). Com senha, cada registro é gravado como `{ id, _e: { iv, d } }`. Arquivo `.tecela`: `{ app: "Tecela", formato: 1, versao, guardado, copiaSeg?, cripto?, dados }` (`copiaSeg: true` na cópia de segurança). O nome leva a data e a hora (`nomeComData`, que limpa as anteriores com `semCarimbo`) e o arquivo é entregue com o tipo `application/octet-stream` (`TIPO_TECELA`): com `application/json`, o Chrome do Android acrescenta “.json”. Ícones novos: usar só emojis que existem no Windows 10 ou desenhar em SVG (como a `BOIA`).

Campos que merecem atenção:
- `observacoes`: `{ id: 'obs:turma:aluno:2026-S1', marcas: { item: 'c'|'d'|'a' }, notas }`.
- `conselhos`: `{ id: 'cons:turma:periodo', alunos: { aluno: { situacao, fala, proposta, resp, prazo } } }`.
- `eventos`: `repete`, `repeteAte`, `excecoes`, `origemSerie`.
- `documentos`: `{ tipo: 'combinados'|'pei'|'anual'|'epoca'|'refAnual'|'refEpoca'|'entrevista'|'estudo'|'materiais', turmaId?, alunoId?, serie?, epocaId?, titulo, cab, secoes, versoes }`. Seção com `manual: true` não tem ↻; com `naoImprimir: true` fica fora do impresso.
- `reforcos`: `{ turmaId, alunos, componente, topico, datas, encontros: { data: 'realizado'|'faltou'|'cancelado' }, hora, saida: 'HH:MM', situacao }`; só as datas sem marcação de um reforço previsto vão à agenda (`datasPendentesRef`).
- `turmas.materias`: `[{ nome, quem: 'PC'|'PM', prof }]`; `turmas.grade`: `{ 1..6: { itens: [{ m, ini, fim }] } }` e `turmas.gradeObs`; os formatos antigos (`{ aulas, pc }` e `{ lista, obs }`) são convertidos por `gradeDe`. “Aula principal” (`AULA_PRINCIPAL`) é sempre PC. `turmas.arquivada` tira a turma do seletor.
- `alunos.seg`: `{ alergias, medicamentos, plano, emergencia, buscam }` (sai impresso na ficha de emergência e no roteiro do substituto). `matriculas.ausencias`: datas marcadas na chamada (cada uma soma 1 em `faltas[período]`).
- `repertorio`: `{ turmaId, tipo, titulo, autor, epocaId, rotina, texto, obs, usos: [datas] }`; `contatos`: `{ turmaId, alunoId, data, meio, quem, assunto, texto, combinados, sigilo }`; `comunicados`: modelos editados ou próprios `{ chave, nome, texto }`.
- Dias letivos: `CFG.prefs.letivos[ano]` = `{ faixas: [{ ini, fim }], semSab, semDom, fora: [datas], dentro: [datas] }` (vai no arquivo `.tecela`); exceções da turma em `turmas.letivosExc[ano]` = `{ fora, dentro }`.
- Reuniões com as famílias: eventos `{ tipo: 'reuniao', familia: true, turmaId, data, hora, horaFim, alunoId, resp: [primeiros nomes], convidado, local, modo, assunto, obs, situacao, ataId, contatoId }`; dias indisponíveis só desta agenda em `turmas.reunioesIndisp`. A ata criada leva `reuniaoId`, e o contato no Acompanhamento, `ataId`.
- `digitais`: `{ turmaId, titulo, album (lista `albuns` dos Cadastros), tipo: 'img'|'pdf', mime, dados (data URL), mini, tamanho, largura, altura, data, obs, alunoId, ataId, vivenciaId, reuniaoId }`.
- Modelo do boletim: `secaoFaltas` ('auto', 'nenhuma' ou a chave da seção).
- Eventos de festa: `festa` (chave da festa, para não repetir). Festas do ano: `CFG.prefs.festas` = `[{ k, nome, quando: 'MM-DD'|'pascoa:±n'|'advento:±n', passos: [[dias antes, texto]] }]`; nula = lista padrão (`FESTAS_PADRAO`, em `rotina.js`).
- `biblioteca`: `origem` (original, editado, branco, proprio) e `oculto`.
- BNCC: `[código, componente, anos, texto, meta?]`. Na Computação, `meta = { e, o, x, ex, etapa?, eq? }`; as habilidades por etapa ficam fora das sugestões e da comparação.

**Nova tela.** `T.nome = () => html`; botões com `data-a="acao"` e `A.acao = (dataset, el) => {}`; campos com `data-rec` e `data-b`; `data-i` só para o gatilho de `C_` no evento input. Inclua a tela em `GRUPOS` (ou abra-a por um botão, como Dias letivos, Reuniões com as famílias e Partilha pedagógica) e uma parte no manual com o id `m-` + nome da tela, que é para onde vai o botão `?`.

**Texto da Release no GitHub (modelo fixo, sempre igual).** Toda versão publicada leva exatamente esta estrutura e estes textos; muda só o número da versão e a lista de “Novidades desta versão” (itens curtos, com o nome da função em negrito e dois-pontos; correções no fim, como “**Correção:**”). Se houver um cuidado que a professora precisa saber ao atualizar (por exemplo, não voltar para uma versão anterior), ele entra como uma linha em negrito logo depois dos passos de “Para atualizar”. Entregar: tag (`vX.Y` ou `vX.Y.Z`), título (`Tecelã X.Y`) e a descrição num bloco para copiar, seguidos dos passos de publicação (anexar `Tecela.html` e `Tecela-X.Y-projeto.zip`, marcar “Set as the latest release”, substituir o `Tecela.html` da página principal).

```markdown
## Tecelã X.Y — para professoras e professores

### ⬇️ Recomendado: baixe o arquivo **Tecela.html**
Ele está logo abaixo, em **Assets**. É o aplicativo completo, num único arquivo, e funciona **sempre sem internet**, no seu computador.

Os itens **"Source code (zip)"** e **"Source code (tar.gz)"** são o código-fonte, para programadores e desenvolvedores. **Você não precisa deles.**

#### Primeira vez
1. Clique em **Tecela.html** para baixar.
2. Guarde o arquivo numa pasta fixa do computador (por exemplo, Documentos › Tecelã).
3. Abra com dois cliques. Funciona no navegador, sem internet.

#### Já usa a Tecelã? Para atualizar
1. Abra a Tecelã que você já usa e toque em **💾 Salvar**.
2. Baixe o novo **Tecela.html**.
3. Substitua o antigo **na mesma pasta, com o mesmo nome**. Se o arquivo baixado vier como "Tecela (1).html", renomeie para **Tecela.html** antes.
4. Abra com dois cliques. Seus dados continuam lá.

### 🌐 Opcional: usar online, sem baixar
Endereço: **https://marciowillians.github.io/tecela/Tecela.html**

É sempre a versão mais recente (se aparecer uma antiga, recarregue a página) e é o jeito de usar no **celular Android**.

**Sobre os seus dados nesta forma de uso:**
- O endereço entrega **só o programa**. **Os dados que você digita não vão para a internet**: ficam guardados no navegador do aparelho que você está usando.
- Esses dados ficam **separados** dos dados do Tecela.html baixado. Para levar de um para o outro, toque em **💾 Salvar** num deles e use **Abrir outro arquivo** no outro.
- Como ficam só no navegador, **podem se perder** se os dados de navegação forem limpos, se você usar janela anônima ou trocar de navegador ou de aparelho. **Salve o arquivo .tecela com frequência**: ele é a sua cópia de segurança.
- Depois que a página abriu, dá para desligar a internet e continuar trabalhando. Só não feche nem recarregue a página enquanto estiver sem internet: para abrir de novo, ela precisa da conexão.

### Novidades desta versão
- **Função:** o que ela faz, numa ou duas frases.
- **Correção:** o que foi corrigido.

### Sugestões e problemas
Escreva para **(e-mail do autor, `CONTATO`)**. Não envie dados de crianças, seus ou da entidade, nem prints com nomes.
```

## 5. Ideias para depois

- Quando a Federação das Escolas Waldorf no Brasil publicar a parte do Ensino Fundamental do documento sobre Pedagogia Waldorf e BNCC (em novembro de 2026, a versão pública ia só até a Educação Infantil), conferir de novo os verbetes `serie-1` a `serie-9`. Mudar `BIBLIO` atualiza sozinho os verbetes que a professora não editou.

## 6. Versões

| Versão | Data | Principais mudanças |
|---|---|---|
| 1.12 | 23/11/2026 | Painel de conferência dos boletins: tocar na bolinha abre o boletim da criança já na seção, com o cursor no texto individual e a seção destacada (a coluna Poema abre no poema); “← Boletins” volta ao mapa no mesmo ponto. Botão 📋 Copiar em cada seção do boletim. Tela inicial no celular: botão “Continuar” com o nome do arquivo encurtado embaixo. Nome do arquivo: cada Salvar tira as datas, horas, extensões e “(1)” acumulados (`semCarimbo`) e o arquivo vai com tipo genérico (`TIPO_TECELA`), para o Android não acrescentar “.json”. Boia da cópia de segurança desenhada (`BOIA`, SVG), porque o emoji 🛟 não existe no Windows 10. Teste `teste-v112.js` |
| 1.11.1 | 21/11/2026 | Aviso de que os digitalizados são o que mais ocupa espaço: no diálogo de inclusão (quanto o arquivo e cada cópia vão crescer), na tela Digitalizados (texto fixo e medidor verde, amarelo acima de 50 MB e vermelho acima de 100 MB) e em Ajustes → Armazenamento (digitalizados × todo o resto) |
| 1.11 | 21/11/2026 | Cópia de segurança (boia): arquivo à parte, sempre com senha (a da Tecelã ou a senha das cópias, criada na primeira vez, com chave de recuperação, guardada só no aparelho), lembrete a cada 5 dias (ajustável) no Painel, no topo e no Sair, explicação no primeiro Salvar, compartilhamento no celular; ao abrir a cópia, continuar com ou sem senha. Desfazer nos textos: ↶ no topo e Ctrl+Z fora do campo, mesmo depois de trocar de tela; “Trecho apagado · Desfazer”; histórico da sessão. Digitalizados (A turma): fotos reduzidas e PDF até 3 MB, câmera no celular, álbuns, ligação com criança, ata, vivência e reunião, visualizador com zoom, medidor; nunca na partilha. IndexedDB versão 6 (coleção `digitais`). Teste `teste-v111.js` |
| 1.10 | 21/11/2026 | Correção dos períodos com nome de mês (usam as datas do mês). Faltas no boletim: “Atualizar faltas” (individual e de todos) escreve “Até o presente momento, Nome teve N faltas.” na primeira linha da seção de assiduidade, e o Finalizar só fica disponível com a frase em dia. Calendário › Dias letivos: intervalos, sábados/domingos, grade mês a mês para tirar e devolver dias, exceções por turma; frequência com dias letivos calculados, só leitura. Relatório “Dias letivos do ano” (calendário anual numa folha e as agendas da turma e da escola). Calendário › Reuniões com as famílias: grade com dias letivos, dias indisponíveis, reunião com criança, família, convidado, local e situação, convite, ata preenchida e registro no Acompanhamento, impressão em lista e em grade. Teste `teste-v110.js` |
| 1.9 | 20/11/2026 | Chamada de dias anteriores: setas ◀ ▶, campo de data (até hoje, no ano da turma) e "Hoje"; a falta entra no período da data escolhida (`periodoDaData`); dias sem aula bloqueados, com o motivo; aviso quando o total do período foi digitado à mão na tela Faltas (`UI.chamada`, `dataChamada`). Campo de data com `data-imediato`: aplica na hora quando vem do calendário do navegador, e espera sair do campo quando digitado. Tabelas largas com `.grade-fixa`: rolagem própria, linha de títulos e primeira coluna fixas (Faltas, Relatórios › Frequência com `fixa: true` no bloco de tabela, painel de conferência dos Boletins). Teste `teste-v19.js` |
| 1.8.1 | 20/11/2026 | Correção: numa turma sem dias letivos nem faltas, digitar esses números gravava um objeto em vez de uma lista, e as telas Faltas e Relatórios › Frequência quebravam ("dl.slice is not a function"). `setP` passou a criar lista quando a chave seguinte é número; `comoLista` protege a leitura; `consertarListas` (em `indexar`) conserta dados já gravados ao abrir. Ao mudar os períodos das faltas com números já digitados, a Tecelã avisa para conferir. Teste `teste-v181.js` |
| 1.8 | 15/11/2026 | Boletim: recuo na primeira linha dos parágrafos (`turmas.boletim.recuo`) e prévia dos textos da turma; título da seção como subtítulo (`modelosBoletim.secoes[].subtitulo`) e título do poema como subtítulo (`modelosBoletim.poemaSubtitulo`); dica do corretor ortográfico (botão direito). Busca nos textos da turma e na citação do boletim. "PEI – PDI" no menu, nos títulos e no manual. Enquanto se digita num campo, o botão ✎ Anotar e a barra do celular saem da frente e a página rola para manter a linha à vista (`body.digitando`, `cursorVisivel`). Teste `teste-v18.js` |
| 1.7.1 | 06/11/2026 | Avisos de contato: "Sugestões e novas versões" (tela inicial, rodapé do menu e Ajuda → Sobre, sugestões e versões) com o e-mail do autor, o link das versões no GitHub e como atualizar; aviso da BNCC na aba BNCC e no verbete da Biblioteca; regra de numeração das versões registrada. Teste `teste-v171.js` |
| 1.7 | 06/11/2026 | Partilha pedagógica: compartilhar planejamentos, repertório, biblioteca própria, modelos, comunicados, vivências e festas sem dados de pessoas ou da escola (lista fechada do que pode sair, nomes trocados por marcadores, revisão com destaque do que conferir, assinatura e senha opcionais); receber sem alterar nada, com repetidos pulados, "(recebido)" nos nomes iguais, avisos resumidos, resumo da importação e desfazer por partilha. Teste `teste-partilha.js` com a classificação obrigatória de toda coleção e campo |
| 1.6.2 | 06/11/2026 | Festas do ano editáveis: editar, incluir e excluir festas, com data fixa ou ligada à Páscoa ou ao Advento, e os passos da preparação (`CFG.prefs.festas`; sem ela, vale `FESTAS_PADRAO`); correção: o botão “Autorização” da vivência não abria (bloco `centro` sem `linhas`) |
| 1.6.1 | 06/11/2026 | Mínimo de dias letivos e mínimo de horas em Ajustes → Ano letivo (`minDias`, `minHoras`; definidos pela legislação, hoje 200 e 800); “Grade semanal” passa a “Horário semanal” em todo o app, no manual e nos documentos (os nomes internos `grade`, `gradeDe` e `gradeObs` continuam); vídeo de apresentação refeito com as telas da 1.6 |
| 1.6 | 06/11/2026 | Correções: ano da data de nascimento (e da vivência) ao digitar; menu mantém a rolagem; saída do reforço em campo de horário; encontro de reforço realizado, com falta ou cancelado sai da agenda; PDF com o nome do documento. Pedidos: versão e autoria na tela inicial; “Guardar” vira “💾 Salvar”, com indicador e explicação do salvamento automático; finalizar os boletins prontos; arquivar e excluir turma; virada mostra pendências e cria tarefas; 9º ano oculto por padrão; horário semanal nova (horários, Aula principal, PC/PM, observações, impressão em tabela com matérias em folha separada); licença GPL v3 com termos adicionais. Interface: editor de documentos mais limpo, caixas que crescem, menu recolhível com Recentes, atalhos (Ctrl+S, Ctrl+K, Alt+N), prévia antes de exportar, áreas de toque maiores, redesenho só do conteúdo. Novas: chamada rápida, roteiro do substituto, ficha de emergência e autorização, saúde e segurança, entrevista com a família, estudo de criança, contatos com as famílias, comunicados, repertório, avaliação da época, dias letivos e carga horária, festas do ano, lista de materiais, conferência dos textos do boletim |
| 1.5.2 | 05/11/2026 | Revisão geral: busca também nos documentos (planos, diários, PEI, combinados), nos reforços e no currículo; “Ir para o diário” e contagem de dias preenchidos na lista de épocas; a virada do ano leva as matérias do horário semanal; a Biblioteca acrescenta verbetes novos que faltam em arquivos antigos; teste de tela vazia em todas as telas e relatórios; manual (30 partes) e especificação atualizados |
| 1.5.1 | 05/11/2026 | Rascunhos de todos os anos de uma vez; links do plano de época para Currículo e BNCC e para colar épocas; matérias do ano com Professor de Classe ou de Matéria e horário semanal impressa; período anual na observação e no conselho; lista dos alunos com colunas escolhidas; vivência separada em antes (famílias) e depois (relatório) |
| 1.5 | 05/11/2026 | Planejamento anual e Plano de época (referência por ano e documento da turma, datas e diário pelo calendário, horário semanal); conteúdo programático de referência; épocas de referência do 1º ao 9º ano; PEI; reforço com bilhete; combinados da turma com versões; aniversariantes; poemas; pauta da reunião; informações completas da vivência; fontes dos documentos impressos; nome do arquivo com data e hora; Biblioteca com “Para a estruturação do ensino” |
| 1.4.2 | 04/11/2026 | Android: o seletor abre direto os arquivos do sistema (tipos de documento), em vez de Câmera e Galeria, com o `.tecela` habilitado |
| 1.4.1 | 04/11/2026 | Correção: no celular (Android, iPhone, iPad), o arquivo `.tecela` aparecia cinza e não podia ser aberto; agora o seletor mostra todos os arquivos e a Tecelã confere o conteúdo |
| 1.4 | 04/11/2026 | Computação com o texto oficial, objeto de conhecimento, explicação e exemplos, mais as habilidades por etapa; BNCC como categoria de leitura na Biblioteca; novo verbete com "Inserir na Biblioteca" e escolha de categoria; excluir (próprios) e ocultar (originais) verbetes; Cadastros com botão Excluir/Arquivar e "onde é usado"; `continuar.md` e `README.md` no lugar dos `.txt` |
| 1.3 | 03/11/2026 | Currículo da Biblioteca conferido; Computação (resumida); exceções em eventos que se repetem; slogan nos logotipos |
| 1.2 | 03/11/2026 | Tela inicial e arquivo `.tecela`; importador dentro do app; observação do período; poema do ano; conselho de classe; relatórios reorganizados; atalhos; revisão geral |
| 1.1 | 03/11/2026 | Cadastros, pontos de atenção, calendário, vivências, tarefas, currículo e BNCC, relatórios de evolução |
| 1.0 | 02/11/2026 | Primeira versão completa |
