/* ==========================================================================
   Tecelã — Digitalizados: fotos e documentos escaneados, em álbuns.
   Store "digitais": { turmaId, titulo, album, tipo:'img'|'pdf', mime, dados (dataURL),
   mini (miniatura), tamanho (bytes), largura, altura, data, obs,
   alunoId, ataId, vivenciaId, reuniaoId }.
   Fotos são reduzidas (lado maior até 1600 px, JPEG 0,72). PDF até 3 MB.
   Nunca entram na partilha pedagógica (PARTILHA.nunca).
   ========================================================================== */
'use strict';
const DIG_LADO = 1600, DIG_JPEG = 0.72, DIG_PDF_MAX = 3 * 1024 * 1024, DIG_ALERTA = 100 * 1024 * 1024;
const tamanhoTxt = n => n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
const bytesDataUrl = u => Math.round((u.length - u.indexOf(',') - 1) * 3 / 4);
const totalDigitais = () => D.digitais.reduce((s, x) => s + (x.tamanho || 0), 0);
const DIG_MEIO = 50 * 1024 * 1024;
/* peso no arquivo .tecela (a foto vai como texto base64, cerca de 1/3 maior), para comparar com o resto dos dados */
const pesoNoArquivo = x => (x.dados || '').length + (x.mini || '').length;
function pesoDados() { const dig = D.digitais.reduce((s, x) => s + pesoNoArquivo(x), 0); let resto = 0; DADOS.forEach(s => { if (s !== 'digitais') try { resto += JSON.stringify(D[s]).length; } catch (x) { } }); return { dig, resto }; }
const AVISO_PESO_DIG = 'Fotos e PDFs são, de longe, o que mais ocupa espaço na Tecelã: uma foto pesa mais que centenas de anotações. Esse peso vai para o seu arquivo e para cada cópia de segurança, e deixa salvar e copiar mais lentos. Inclua só o que precisa guardar aqui.';
function lerComoDataUrl(f) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(f); }); }
function carregarImagem(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('imagem ilegível')); i.src = src; }); }
function reduzirImagem(img, lado, q) {
  const k = Math.min(1, lado / Math.max(img.naturalWidth, img.naturalHeight)), w = Math.max(1, Math.round(img.naturalWidth * k)), h = Math.max(1, Math.round(img.naturalHeight * k));
  const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(img, 0, 0, w, h);
  return { url: c.toDataURL('image/jpeg', q), w, h };
}
/* prepara um arquivo escolhido: foto reduzida + miniatura; PDF conferido pelo tamanho */
async function prepararDigital(f) {
  const nome = f.name ? f.name.replace(/\.[^.]+$/, '') : 'Foto';
  if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name || '')) {
    if (f.size > DIG_PDF_MAX) return { erro: '“' + f.name + '” tem ' + tamanhoTxt(f.size) + '. O limite para PDF é 3 MB: reduza o arquivo (por exemplo, escaneando em preto e branco ou com menos resolução) ou fotografe as páginas.' };
    const url = (await lerComoDataUrl(f)).replace(/^data:[^;,]*/, 'data:application/pdf');
    return { titulo: nome, tipo: 'pdf', mime: 'application/pdf', dados: url, tamanho: f.size };
  }
  if (!/^image\//.test(f.type) && !/\.(jpe?g|png|webp|gif|heic|bmp)$/i.test(f.name || '')) return { erro: '“' + f.name + '” não é foto nem PDF.' };
  let img; try { img = await carregarImagem(await lerComoDataUrl(f)); } catch (x) { return { erro: 'Não foi possível ler “' + f.name + '”. Se for uma foto HEIC do iPhone, ela é convertida sozinha quando enviada pelo próprio iPhone; no computador, salve-a como JPEG.' }; }
  const g = reduzirImagem(img, DIG_LADO, DIG_JPEG), m = reduzirImagem(img, 320, 0.7);
  return { titulo: nome, tipo: 'img', mime: 'image/jpeg', dados: g.url, mini: m.url, tamanho: bytesDataUrl(g.url), largura: g.w, altura: g.h };
}
const opcoesAlunosDig = t => [['', '— nenhuma —']].concat(alunosDaTurma(t.id).map(a => [a.id, a.nome]));
const opcoesAtasDig = t => [['', '— nenhuma —']].concat(D.atas.filter(a => a.turmaId === t.id).sort((a, b) => (b.data || '').localeCompare(a.data || '')).map(a => [a.id, nomeReuniao(a) + ' · ' + dataBR(a.data)]));
const opcoesVivDig = t => [['', '— nenhuma —']].concat(D.vivencias.filter(v => v.turmaId === t.id).sort((a, b) => (b.data || '').localeCompare(a.data || '')).map(v => [v.id, v.titulo + ' · ' + dataBR(v.data)]));
const opcoesReuDig = t => [['', '— nenhuma —']].concat(reunioesDaTurma(t).slice().reverse().map(r => [r.id, dataBR(r.data) + ' · ' + (IX.alunos[r.alunoId] ? primeiroNome(IX.alunos[r.alunoId]) : r.titulo || 'reunião')]));
const selDig = (nome, val, ops) => '<select name="' + nome + '">' + ops.map(([v, r]) => '<option value="' + e(v) + '"' + (v === (val || '') ? ' selected' : '') + '>' + e(r) + '</option>').join('') + '</select>';
function camposDig(t, x, varios) {
  return (varios ? '' : campo('Título', '<input name="titulo" value="' + e(x.titulo || '') + '" autofocus>')) +
    '<div class="duas">' + campo('Álbum', selDig('album', x.album || 'outros', opcoesLista('albuns', '', x.album))) + campo('Data', '<input type="date" name="data" value="' + e(x.data || hojeISO()) + '">') + '</div>' +
    '<p class="dica" style="margin:.6rem 0 .2rem">Ligar a (opcional): o digitalizado aparece também nesses lugares.</p>' +
    '<div class="duas">' + campo('Criança', selDig('alunoId', x.alunoId, opcoesAlunosDig(t))) + campo('Ata', selDig('ataId', x.ataId, opcoesAtasDig(t))) + '</div>' +
    '<div class="duas">' + campo('Vivência', selDig('vivenciaId', x.vivenciaId, opcoesVivDig(t))) + campo('Reunião com a família', selDig('reuniaoId', x.reuniaoId, opcoesReuDig(t))) + '</div>' +
    campo('Observação', '<textarea name="obs" style="min-height:3rem">' + e(x.obs || '') + '</textarea>');
}
const camposLigacao = v => ({ album: v.album, data: v.data, alunoId: v.alunoId || null, ataId: v.ataId || null, vivenciaId: v.vivenciaId || null, reuniaoId: v.reuniaoId || null, obs: (v.obs || '').trim() });
/* incluir: d pode trazer a ligação já feita (al, ata, viv, reu, album) e camera=1 */
A.digIncluir = async d => {
  d = d || {}; const t = turmaAtual(); if (!t) return aviso('Cadastre uma turma primeiro.');
  const fs = await escolherDigitais(d.camera === '1'); if (!fs || !fs.length) return;
  const preparados = [], erros = [];
  aviso('Preparando ' + fs.length + ' arquivo(s)…');
  for (const f of fs) { try { const p = await prepararDigital(f); if (p.erro) erros.push(p.erro); else preparados.push(p); } catch (x) { erros.push('“' + (f.name || 'arquivo') + '”: ' + (x.message || 'erro')); } }
  if (!preparados.length) return informar('Nada foi incluído', erros.map(x => '<p>' + e(x) + '</p>').join(''));
  const um = preparados.length === 1, base = { titulo: um ? preparados[0].titulo : '', album: d.album || (d.ata ? 'atas' : d.viv ? 'vivencias' : 'outros'), data: hojeISO(), alunoId: d.al || '', ataId: d.ata || '', vivenciaId: d.viv || '', reuniaoId: d.reu || '' };
  const tot = preparados.reduce((s, p) => s + p.tamanho, 0), noArq = preparados.reduce((s, p) => s + pesoNoArquivo(p), 0);
  const v = await dlg({ titulo: um ? 'Incluir digitalizado' : 'Incluir ' + preparados.length + ' digitalizados', largo: true, ok: 'Incluir', corpo: (erros.length ? '<div class="alerta verm">' + erros.map(e).join('<br>') + '</div>' : '') + '<p class="dica">' + (um ? (preparados[0].tipo === 'img' ? 'Foto reduzida para ' + preparados[0].largura + '×' + preparados[0].altura + ' px' : 'PDF') + ', ' + tamanhoTxt(tot) : preparados.length + ' arquivos, ' + tamanhoTxt(tot) + ' no total. Os títulos ficam com o nome de cada arquivo (você pode mudar depois)') + '.</p><p class="alerta aviso-peso">' + (um ? 'Isto' : 'Estes arquivos') + ' acrescenta' + (um ? '' : 'm') + ' cerca de <b>' + tamanhoTxt(noArq) + '</b> ao seu arquivo e a cada cópia de segurança. ' + AVISO_PESO_DIG.split(': ')[0] + '. Inclua só o que precisa guardar aqui.</p>' + camposDig(t, base, !um) });
  if (!v) return;
  for (const p of preparados) await salvar('digitais', Object.assign({ turmaId: t.id }, p, camposLigacao(v), um ? { titulo: (v.titulo || '').trim() || p.titulo } : {}));
  render(); aviso(preparados.length === 1 ? 'Digitalizado incluído.' : preparados.length + ' digitalizados incluídos.');
  if (totalDigitais() > DIG_ALERTA) setTimeout(() => aviso('Os digitalizados já somam ' + tamanhoTxt(totalDigitais()) + '. O arquivo fica mais pesado para salvar e copiar.'), 4000);
};
function escolherDigitais(camera) {
  return new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.multiple = !camera; i.accept = camera ? 'image/*' : 'image/*,application/pdf,.pdf'; if (camera) i.setAttribute('capture', 'environment'); i.style.display = 'none'; document.body.appendChild(i); i.addEventListener('change', () => { res([...i.files]); i.remove(); }); i.addEventListener('cancel', () => { res(null); i.remove(); }); i.click(); });
}
const TOQUE = ANDROID || APPLE_TOQUE;
function botoesIncluirDig(lig, rot) {
  const a = Object.entries(lig || {}).map(([k, v]) => ' data-' + k + '="' + e(v) + '"').join('');
  return '<button class="btn" data-a="digIncluir"' + a + '>' + (rot || '+ Incluir foto ou PDF') + '</button>' + (TOQUE ? '<button class="btn" data-a="digIncluir" data-camera="1"' + a + '>📷 Fotografar</button>' : '');
}
const miniDig = x => '<button type="button" class="dig-mini" data-a="digVer" data-id="' + x.id + '" title="' + e(x.titulo) + '">' + (x.tipo === 'img' ? '<img src="' + (x.mini || x.dados) + '" alt="' + e(x.titulo) + '" loading="lazy">' : '<span class="dig-pdf">PDF</span>') + '<span class="dig-tit">' + e(x.titulo) + '</span><span class="dica">' + dataBR(x.data) + ' · ' + tamanhoTxt(x.tamanho || 0) + '</span></button>';
/* bloco para os editores (ata, vivência, criança): os digitalizados ligados e o botão para incluir já ligado */
function blocoDigitais(campoLig, id, lig, titulo) {
  const xs = D.digitais.filter(x => x[campoLig] === id).sort((a, b) => (b.data || '').localeCompare(a.data || ''));
  return '<div class="cartao"><h3>' + (titulo || 'Digitalizados') + ' <span class="dica">(' + xs.length + ')</span></h3>' + (xs.length ? '<div class="dig-grade">' + xs.map(miniDig).join('') + '</div>' : '<p class="dica">Nenhuma foto ou documento ligado aqui.</p>') + '<div class="linha">' + botoesIncluirDig(lig, '+ Incluir aqui') + '</div></div>';
}
T.digitais = () => {
  const t = turmaAtual(); if (!t) return '<h1>Digitalizados</h1>' + vazio('Cadastre uma turma primeiro.');
  const f = UI.filtro, alb = f.digAlb || '', al = f.digAl || '', q = norm(f.digQ || '');
  const todos = D.digitais.filter(x => x.turmaId === t.id), xs = todos.filter(x => (!alb || x.album === alb) && (!al || x.alunoId === al) && (!q || norm([x.titulo, x.obs].join(' ')).includes(q))).sort((a, b) => (b.data || '').localeCompare(a.data || '') || (b.criado || '').localeCompare(a.criado || ''));
  const tot = totalDigitais(), pct = Math.min(100, tot / DIG_ALERTA * 100), faixa = tot > DIG_ALERTA ? ' cheio' : tot > DIG_MEIO ? ' meio' : '';
  let h = '<h1>Digitalizados</h1><p>Fotos e documentos escaneados da turma (atas assinadas, a caderneta, bilhetes, trabalhos das crianças), organizados em álbuns. As fotos são reduzidas sozinhas para não pesar; PDF até 3 MB. Ficam no seu arquivo e na cópia de segurança, <b>nunca</b> na partilha pedagógica.</p>';
  h += '<div class="linha">' + botoesIncluirDig({}, '+ Incluir fotos ou PDF') + '<span class="espaco"></span><a href="#" data-a="ir" data-t="cadastros" class="dica">Editar os álbuns</a></div>';
  h += '<div class="cartao"><div class="dica">Espaço usado pelos digitalizados (todas as turmas): <b>' + tamanhoTxt(tot) + '</b>' + (tot > DIG_ALERTA ? ' · <b>acima de 100 MB</b>: o arquivo fica pesado para salvar e copiar. Apague o que não precisa mais, ou guarde os originais fora da Tecelã.' : tot > DIG_MEIO ? ' · <b>acima de 50 MB</b>: o arquivo já está ficando pesado.' : ' de 100 MB recomendados') + '</div><div class="medidor' + faixa + '"><span style="width:' + pct.toFixed(1) + '%"></span></div><p class="dica" style="margin:.5rem 0 0">' + AVISO_PESO_DIG + '</p></div>';
  h += '<div class="linha">' + '<select data-c="digAlb" aria-label="Álbum"><option value="">Todos os álbuns (' + todos.length + ')</option>' + itensLista('albuns').map(i => { const n = todos.filter(x => x.album === i.chave).length; return '<option value="' + e(i.chave) + '"' + (alb === i.chave ? ' selected' : '') + '>' + e(i.nome) + ' (' + n + ')</option>'; }).join('') + '</select>' +
    '<select data-c="digAl" aria-label="Criança"><option value="">Todas as crianças</option>' + alunosDaTurma(t.id).map(a => '<option value="' + a.id + '"' + (al === a.id ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select>' +
    '<input type="search" data-c="digQ" placeholder="Procurar pelo título" value="' + e(f.digQ || '') + '"></div>';
  if (!xs.length) return h + vazio(todos.length ? 'Nada neste filtro.' : 'Nenhum digitalizado em ' + e(rotuloTurma(t)) + '.');
  if (alb) return h + '<div class="dig-grade">' + xs.map(miniDig).join('') + '</div>';
  /* sem filtro de álbum: agrupado por álbum */
  return h + itensLista('albuns', true).map(i => [i, xs.filter(x => x.album === i.chave)]).concat([[{ nome: 'Sem álbum' }, xs.filter(x => !IX.cadastros['albuns:' + x.album])]]).filter(([, ys]) => ys.length).map(([i, ys]) => '<h3>' + e(i.nome) + ' <span class="dica">(' + ys.length + ')</span></h3><div class="dig-grade">' + ys.map(miniDig).join('') + '</div>').join('');
};
C_.digAlb = el => { UI.filtro.digAlb = el.value; render(); };
C_.digAl = el => { UI.filtro.digAl = el.value; render(); };
C_.digQ = el => { UI.filtro.digQ = el.value; render(); };
function blobDeDataUrl(u) { const k = u.indexOf(','), bin = atob(u.slice(k + 1)), b = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i); return new Blob([b], { type: (u.slice(5, k).split(';')[0]) || 'application/octet-stream' }); }
const nomeArqDig = x => nomeArq(x.titulo || 'digitalizado') + (x.tipo === 'pdf' ? '.pdf' : '.jpg');
const ligacoesDig = x => [x.alunoId && IX.alunos[x.alunoId] ? 'Criança: ' + IX.alunos[x.alunoId].nome : '', x.ataId && IX.atas[x.ataId] ? 'Ata: ' + nomeReuniao(IX.atas[x.ataId]) + ' · ' + dataBR(IX.atas[x.ataId].data) : '', x.vivenciaId && IX.vivencias[x.vivenciaId] ? 'Vivência: ' + IX.vivencias[x.vivenciaId].titulo : '', x.reuniaoId && IX.eventos[x.reuniaoId] ? 'Reunião com a família: ' + dataBR(IX.eventos[x.reuniaoId].data) : ''].filter(Boolean);
A.digVer = async d => {
  const x = IX.digitais[d.id]; if (!x) return; let z = 1;
  const lig = ligacoesDig(x);
  const v = await dlg({ titulo: x.titulo, largo: true, ok: false, cancelar: 'Fechar', corpo: '<p class="dica">' + e(nomeItem('albuns', x.album) || 'Sem álbum') + ' · ' + dataBR(x.data) + ' · ' + tamanhoTxt(x.tamanho || 0) + (x.largura ? ' · ' + x.largura + '×' + x.altura + ' px' : '') + '</p>' + (lig.length ? '<p class="dica">' + lig.map(e).join(' · ') + '</p>' : '') + (x.obs ? '<p>' + e(x.obs) + '</p>' : '') +
    (x.tipo === 'img' ? '<div class="linha"><button type="button" class="btn peq" id="zMenos" aria-label="Diminuir">−</button><button type="button" class="btn peq" id="zMais" aria-label="Aumentar">+</button><button type="button" class="btn peq" id="zAjustar">Ajustar à janela</button></div><div class="dig-ver"><img id="digImg" src="' + x.dados + '" alt="' + e(x.titulo) + '"></div>' : '<p>Documento PDF. Use “Abrir em tamanho real” para ver as páginas no leitor de PDF do navegador.</p>'),
    extra: '<button type="button" class="btn" data-x="apagar">Excluir</button><button type="button" class="btn" data-x="editar">Editar</button><button type="button" class="btn" data-x="baixar">Baixar</button><button type="button" class="btn pri" id="digAbrir">Abrir em tamanho real</button>',
    aoAbrir: f => {
      const img = $('#digImg', f), zoom = k => { z = Math.max(.25, Math.min(4, k)); img.style.width = (z * 100) + '%'; img.style.maxWidth = z > 1 ? 'none' : '100%'; };
      if (img) { $('#zMais', f).onclick = () => zoom(z * 1.4); $('#zMenos', f).onclick = () => zoom(z / 1.4); $('#zAjustar', f).onclick = () => zoom(1); img.onclick = () => zoom(z > 1 ? 1 : 2); }
      $('#digAbrir', f).onclick = () => { const u = URL.createObjectURL(blobDeDataUrl(x.dados)), w = window.open(u, '_blank'); if (!w) baixar(nomeArqDig(x), blobDeDataUrl(x.dados)); setTimeout(() => URL.revokeObjectURL(u), 60000); };
    } });
  if (!v) return;
  if (v._botao === 'baixar') { baixar(nomeArqDig(x), blobDeDataUrl(x.dados)); return; }
  if (v._botao === 'editar') return A.digEditar(d);
  if (v._botao === 'apagar') return apagarComDesfazer('digitais', x.id, 'Digitalizado excluído.');
};
A.digEditar = async d => {
  const x = IX.digitais[d.id], t = IX.turmas[x.turmaId] || turmaAtual(); if (!x || !t) return;
  const v = await dlg({ titulo: 'Editar digitalizado', largo: true, ok: 'Salvar', corpo: camposDig(t, x, false) }); if (!v) return;
  Object.assign(x, camposLigacao(v), { titulo: (v.titulo || '').trim() || x.titulo }); await salvar('digitais', x); render(); aviso('Digitalizado atualizado.');
};
/* reunião com a família: ver os ligados e incluir já ligado (à reunião e à criança) */
A.reuDigitais = async d => {
  const r = IX.eventos[d.id]; if (!r) return; const xs = D.digitais.filter(x => x.reuniaoId === r.id);
  const v = await dlg({ titulo: 'Digitalizados da reunião de ' + dataBR(r.data), largo: true, ok: false, cancelar: 'Fechar', corpo: xs.length ? '<div class="dig-grade">' + xs.map(miniDig).join('') + '</div>' : '<p class="dica">Nenhuma foto ou documento ligado a esta reunião.</p>', extra: '<button type="button" class="btn pri" data-x="incluir">+ Incluir aqui</button>' });
  if (v && v._botao === 'incluir') return A.digIncluir({ reu: r.id, al: r.alunoId || '' });
};
