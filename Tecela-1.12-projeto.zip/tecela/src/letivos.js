/* ==========================================================================
   Tecelã — Dias letivos (Calendário › Dias letivos), relatório anual dos dias
   letivos e Reuniões com as famílias (Calendário › Reuniões com as famílias).

   Dias letivos da escola, por ano, em CFG.prefs.letivos[ano]:
     { faixas: [{ ini, fim }], semSab, semDom, fora: [datas retiradas], dentro: [datas repostas] }
   Exceções de uma turma em turma.letivosExc[ano] = { fora: [], dentro: [] }.
   Sem nenhum intervalo definido no ano, vale a regra simples (ehLetivoSimples).

   Reuniões com as famílias: eventos com tipo 'reuniao' e familia: true
   { data, hora, horaFim, alunoId, resp: [primeiros nomes], convidado, local, modo,
     titulo, obs, situacao, ataId, contatoId }. Dias indisponíveis da professora,
   só para esta agenda, em turma.reunioesIndisp = [datas].
   ========================================================================== */
'use strict';
const letivosAno = ano => { const c = (CFG.prefs.letivos || {})[String(ano)]; return c && (c.faixas || []).some(f => f.ini && f.fim) ? c : null; };
const cfgLetivos = ano => { const L = CFG.prefs.letivos || {}; return L[String(ano)] || { faixas: [], semSab: false, semDom: true, fora: [], dentro: [] }; };
async function gravarLetivos(ano, c) { const L = Object.assign({}, CFG.prefs.letivos || {}); L[String(ano)] = c; await prefs({ letivos: L }); marcarPendente(); }
/* estado de um dia no calendário da escola: letivo, retirado (tirado à mão), feriado, fds (sábado/domingo excluído) ou fora (fora dos intervalos) */
function estadoDiaEscola(iso, cfg) {
  const dentroFaixa = (cfg.faixas || []).some(f => f.ini && f.fim && iso >= f.ini && iso <= f.fim);
  if (!dentroFaixa) return 'fora';
  if ((cfg.dentro || []).includes(iso)) return 'letivo';
  const w = new Date(iso + 'T12:00').getDay();
  if ((w === 0 && cfg.semDom !== false) || (w === 6 && cfg.semSab && !sabadoLetivo(iso))) return 'fds';
  if (semAula(iso)) return 'feriado';
  if ((cfg.fora || []).includes(iso)) return 'retirado';
  return 'letivo';
}
/* estado para a turma: o da escola com as exceções da turma por cima */
function estadoDia(iso, t) {
  const cfg = letivosAno(iso.slice(0, 4)); if (!cfg) return ehLetivoSimples(iso) ? 'letivo' : (new Date(iso + 'T12:00').getDay() % 6 === 0 ? 'fds' : 'feriado');
  const ex = t && t.letivosExc && t.letivosExc[iso.slice(0, 4)];
  if (ex && (ex.fora || []).includes(iso)) return 'retiradoTurma';
  if (ex && (ex.dentro || []).includes(iso)) return 'letivoTurma';
  return estadoDiaEscola(iso, cfg);
}
const LETIVO_TXT = { letivo: 'dia letivo', letivoTurma: 'dia letivo só desta turma', retirado: 'retirado dos dias letivos', retiradoTurma: 'retirado só nesta turma', feriado: 'feriado ou recesso (toque para repor)', fds: 'fim de semana excluído', fora: 'fora dos intervalos' };
const COR_DIA = { letivo: '#D7E8F6', letivoTurma: '#C9E6C6', retirado: '#F8E2A8', retiradoTurma: '#F8E2A8', feriado: '#F6D2CB', fds: '#EFECE4', fora: '#F7F5EF' };
/* dias letivos de cada período das faltas: calculados pelo calendário quando há dias letivos definidos; senão, os digitados */
function diasLetivosDaTurma(t) {
  if (!t || !letivosAno(t.ano)) return comoLista(t && t.diasLetivos);
  return periodosComDatas(t).map(p => diasLetivos(p.ini, p.fim, t).length);
}
const diasLetivosCalculados = t => !!(t && letivosAno(t.ano));

/* ---------- grade de um mês (tela e impressão) ---------- */
function htmlGradeMes(ano, mes, celula, opc) {
  opc = opc || {}; const pri = new Date(ano, mes - 1, 1).getDay(), nd = new Date(ano, mes, 0).getDate();
  let h = '<table class="cal-mes' + (opc.peq ? ' peq' : '') + '"><tr>' + DIAS_CURTO.map(d => '<th>' + d + '</th>').join('') + '</tr><tr>';
  for (let i = 0; i < pri; i++) h += '<td class="vazio"></td>';
  for (let d = 1; d <= nd; d++) { const iso = ano + '-' + String(mes).padStart(2, '0') + '-' + String(d).padStart(2, '0'); h += celula(iso, d); if ((pri + d) % 7 === 0 && d < nd) h += '</tr><tr>'; }
  const resto = (7 - (pri + nd) % 7) % 7; for (let i = 0; i < resto; i++) h += '<td class="vazio"></td>';
  return h + '</tr></table>';
}
const nomeMes = (ano, mes) => MESES[mes - 1][0].toUpperCase() + MESES[mes - 1].slice(1) + ' de ' + ano;

/* ---------- TELA: DIAS LETIVOS ---------- */
T.letivos = () => {
  const t = turmaAtual(); if (!t) return '<h1>Dias letivos</h1>' + vazio('Cadastre uma turma primeiro.');
  const ano = String(t.ano), cfg = cfgLetivos(ano), ativo = !!letivosAno(ano), modo = UI.letModo === 'turma' ? 'turma' : 'escola';
  UI.letMes = UI.letMes && UI.letMes.startsWith(ano) ? UI.letMes : (hojeISO().startsWith(ano) ? hojeISO().slice(0, 7) : ((cfg.faixas[0] || {}).ini || ano + '-02-01').slice(0, 7));
  const [, mes] = UI.letMes.split('-').map(Number);
  let h = '<div class="linha"><button class="btn" data-a="ir" data-t="agenda">← Calendário</button><h1 style="margin:0">Dias letivos de ' + ano + '</h1></div>';
  h += '<p>Defina os intervalos de aula do ano. Os dias de cada intervalo contam como letivos; feriados e recessos do calendário e os fins de semana marcados abaixo ficam de fora. Na grade, toque num dia letivo para tirá-lo, e toque de novo para devolvê-lo. Estes dias são a base da frequência, da chamada, dos planos de época e da contagem do ano letivo.</p>';
  h += '<div class="cartao"><h3>Intervalos de aula (valem para todas as turmas)</h3>' + (cfg.faixas.length ? cfg.faixas.map((f, i) => '<div class="linha faixa-let"><span class="dica">De</span><input type="date" data-c="letFaixa" data-i="' + i + '" data-k="ini" value="' + e(f.ini || '') + '" min="' + ano + '-01-01" max="' + ano + '-12-31"><span class="dica">até</span><input type="date" data-c="letFaixa" data-i="' + i + '" data-k="fim" value="' + e(f.fim || '') + '" min="' + ano + '-01-01" max="' + ano + '-12-31"><button class="icone-btn" data-a="letRemFaixa" data-i="' + i + '" title="Remover este intervalo" aria-label="Remover este intervalo">✕</button></div>').join('') : '<p class="dica">Nenhum intervalo ainda. Enquanto não houver, a Tecelã conta como letivos os dias úteis, menos os feriados e recessos do calendário.</p>') +
    '<div class="linha"><button class="btn" data-a="letNovaFaixa">+ Intervalo de datas</button></div>' +
    '<label class="ck"><input type="checkbox" data-c="letSemSab"' + (cfg.semSab ? ' checked' : '') + '> <span>Excluir sábados <span class="dica">(sábados marcados no calendário como letivos continuam contando)</span></span></label>' +
    '<label class="ck"><input type="checkbox" data-c="letSemDom"' + (cfg.semDom !== false ? ' checked' : '') + '> <span>Excluir domingos</span></label></div>';
  if (!ativo) return h;
  /* resumo */
  const meses = [...Array(12)].map((_, i) => { const a = ano + '-' + String(i + 1).padStart(2, '0') + '-01', b = ano + '-' + String(i + 1).padStart(2, '0') + '-' + String(new Date(Number(ano), i + 1, 0).getDate()).padStart(2, '0'); return diasLetivos(a, b, t).length; }), tot = meses.reduce((s, x) => s + x, 0);
  h += '<div class="cartao"><div class="linha" style="margin:0"><h3 style="margin:0">Total: ' + tot + ' dias letivos em ' + e(rotuloTurma(t)) + '</h3><span class="etq ' + (tot >= minDias() ? 'fin' : 'sig') + '">mínimo legal: ' + minDias() + '</span><span class="espaco"></span><button class="btn" data-a="abrirRel" data-k="letivos">Relatório do ano</button></div><div class="meses-let">' + meses.map((n, i) => n ? '<span><b>' + MESES[i].slice(0, 3) + '</b> ' + n + '</span>' : '').join('') + '</div></div>';
  /* grade */
  h += '<div class="cartao"><div class="linha" style="margin:0 0 .6rem"><div class="opcoes" role="tablist"><button class="btn peq' + (modo === 'escola' ? ' pri' : '') + '" data-a="letModo" data-v="escola">Escola (todas as turmas)</button><button class="btn peq' + (modo === 'turma' ? ' pri' : '') + '" data-a="letModo" data-v="turma">Só ' + e(rotuloTurma(t)) + ' (exceções)</button></div><span class="espaco"></span><button class="btn" data-a="letMes" data-v="-1" aria-label="Mês anterior">‹</button><b style="min-width:10rem;text-align:center">' + nomeMes(ano, mes) + '</b><button class="btn" data-a="letMes" data-v="1" aria-label="Próximo mês">›</button></div>';
  h += '<p class="dica">' + (modo === 'escola' ? 'Tocando aqui, a mudança vale para todas as turmas.' : 'Tocando aqui, a mudança vale só para esta turma: por exemplo, um dia de passeio só dela ou uma reposição.') + '</p>';
  h += htmlGradeMes(Number(ano), mes, (iso, d) => {
    const st = modo === 'escola' ? estadoDiaEscola(iso, cfg) : estadoDia(iso, t), clic = modo === 'escola' ? ['letivo', 'retirado', 'feriado'].includes(st) || (cfg.dentro || []).includes(iso) : st !== 'fora';
    return '<td class="dia-let st-' + st + (clic ? ' clic' : '') + '"' + (clic ? ' data-a="letDia" data-d="' + iso + '" role="button" tabindex="0"' : ' aria-disabled="true"') + ' title="' + dataBR(iso) + ': ' + e(LETIVO_TXT[st] + (st === 'feriado' && semAula(iso) ? ' — ' + semAula(iso) : '')) + '"><span>' + d + '</span></td>';
  });
  h += '<p class="legenda-let">' + ['letivo', 'letivoTurma', 'retirado', 'feriado', 'fds', 'fora'].map(k => '<span><i style="background:' + COR_DIA[k] + '"></i>' + e(LETIVO_TXT[k].replace(' (toque para repor)', '')) + '</span>').join('') + '</p></div>';
  return h;
};
A.letNovaFaixa = async () => { const t = turmaAtual(), c = clone(cfgLetivos(t.ano)), ult = c.faixas[c.faixas.length - 1]; c.faixas.push({ ini: ult && ult.fim ? somaDias(ult.fim, 1) : t.ano + '-02-01', fim: ult && ult.fim ? t.ano + '-12-15' : t.ano + '-07-10' }); if (c.semDom === undefined) c.semDom = true; if (c.semSab === undefined) c.semSab = false; await gravarLetivos(t.ano, c); render(); };
A.letRemFaixa = async d => { const t = turmaAtual(), c = clone(cfgLetivos(t.ano)); if (!(await confirmar('Remover o intervalo?', 'Os dias dele deixam de contar como letivos.', 'Remover'))) return; c.faixas.splice(Number(d.i), 1); await gravarLetivos(t.ano, c); render(); };
C_.letFaixa = async el => { const t = turmaAtual(), c = clone(cfgLetivos(t.ano)), f = c.faixas[Number(el.dataset.i)]; if (!f || !el.value) return; if (el.value.slice(0, 4) !== String(t.ano)) { aviso('Use datas de ' + t.ano + '.'); return render(); } f[el.dataset.k] = el.value; if (f.ini && f.fim && f.fim < f.ini) { aviso('O fim do intervalo vem antes do início. Confira as datas.'); } await gravarLetivos(t.ano, c); render(); };
C_.letSemSab = async el => { const t = turmaAtual(), c = clone(cfgLetivos(t.ano)); c.semSab = el.checked; await gravarLetivos(t.ano, c); render(); };
C_.letSemDom = async el => { const t = turmaAtual(), c = clone(cfgLetivos(t.ano)); c.semDom = el.checked; await gravarLetivos(t.ano, c); render(); };
A.letModo = d => { UI.letModo = d.v; render(); };
A.letMes = d => { const t = turmaAtual(); let [a, m] = UI.letMes.split('-').map(Number); m += Number(d.v); if (m < 1) m = 1; if (m > 12) m = 12; UI.letMes = a + '-' + String(m).padStart(2, '0'); render(); };
const alternar = (xs, v) => { const i = xs.indexOf(v); if (i < 0) xs.push(v); else xs.splice(i, 1); return xs; };
A.letDia = async d => {
  const t = turmaAtual(), ano = String(t.ano), iso = d.d;
  if (UI.letModo === 'turma') {
    t.letivosExc = t.letivosExc || {}; const ex = t.letivosExc[ano] = t.letivosExc[ano] || { fora: [], dentro: [] }, base = estadoDiaEscola(iso, cfgLetivos(ano));
    if (ex.fora.includes(iso)) alternar(ex.fora, iso); else if (ex.dentro.includes(iso)) alternar(ex.dentro, iso); else if (base === 'letivo') ex.fora.push(iso); else ex.dentro.push(iso);
    await salvar('turmas', t); return render();
  }
  const c = clone(cfgLetivos(ano)); c.fora = c.fora || []; c.dentro = c.dentro || [];
  const st = estadoDiaEscola(iso, c);
  if (c.dentro.includes(iso)) alternar(c.dentro, iso); else if (st === 'letivo') c.fora.push(iso); else if (st === 'retirado') alternar(c.fora, iso); else if (st === 'feriado') c.dentro.push(iso);
  await gravarLetivos(ano, c); render();
};

/* ---------- RELATÓRIO: dias letivos do ano (calendário anual numa folha) + agendas da turma e da escola ---------- */
function blocoCalAno(t) {
  const ano = Number(t.ano), meses = [];
  for (let m = 1; m <= 12; m++) { const nd = new Date(ano, m, 0).getDate(), dias = []; for (let d = 1; d <= nd; d++) { const iso = ano + '-' + String(m).padStart(2, '0') + '-' + String(d).padStart(2, '0'); dias.push({ d, iso, st: estadoDia(iso, t) }); } meses.push({ m, pri: new Date(ano, m - 1, 1).getDay(), dias, n: dias.filter(x => x.st === 'letivo' || x.st === 'letivoTurma').length }); }
  return { t: 'calAno', ano, meses };
}
function linhasAgenda(itens) { return itens.map(x => [dataBR(x.data) + (x.fim && x.fim !== x.data ? ' a ' + dataBR(x.fim) : ''), diaSemana(x.data), x.hora || '', x.titulo + (x.obs ? ' — ' + x.obs : '')]); }
REL.letivos = t => {
  const ano = Number(t.ano), cal = blocoCalAno(t), tot = cal.meses.reduce((s, m) => s + m.n, 0), f = UI.filtro;
  const todos = itensAgenda(ano + '-01-01', ano + '-12-31'), daTurma = todos.filter(x => x.origem !== 'escola'), daEscola = todos.filter(x => x.origem === 'escola');
  const ctr = '<div class="linha"><label class="ck"><input type="checkbox" data-c="relLetTurma"' + (f.relLetTurma !== false ? ' checked' : '') + '> <span>Juntar a agenda da turma (outra folha)</span></label><label class="ck"><input type="checkbox" data-c="relLetEscola"' + (f.relLetEscola !== false ? ' checked' : '') + '> <span>Juntar a agenda da escola (outra folha)</span></label><button class="btn" data-a="ir" data-t="letivos">Editar os dias letivos</button></div>' + (letivosAno(ano) ? '' : '<p class="alerta">Os dias letivos de ' + ano + ' ainda não foram definidos em Calendário › Dias letivos. O relatório usa a regra simples: dias úteis menos feriados e recessos.</p>');
  const b = [{ t: 'p', txt: rotuloTurma(t) + ' · ' + tot + ' dias letivos no ano (mínimo legal: ' + minDias() + ').' }, cal];
  if (f.relLetTurma !== false) b.push({ t: 'quebra' }, { t: 'h', txt: 'Agenda da turma — ' + rotuloTurma(t) }, daTurma.length ? { t: 'tabela', cab: ['Data', 'Dia', 'Horário', 'Evento'], linhas: linhasAgenda(daTurma) } : { t: 'p', txt: 'Nenhum evento da turma no ano.' });
  if (f.relLetEscola !== false) b.push({ t: 'quebra' }, { t: 'h', txt: 'Agenda da escola — ' + ano }, daEscola.length ? { t: 'tabela', cab: ['Data', 'Dia', 'Horário', 'Evento'], linhas: linhasAgenda(daEscola) } : { t: 'p', txt: 'Nenhum evento da escola no ano.' });
  const csv = { cab: ['Mês', 'Dias letivos'], linhas: cal.meses.map(m => [MESES[m.m - 1], m.n]).concat([['Total', tot]]) };
  return { controles: ctr, doc: Object.assign(docBase('Dias_letivos_' + ano, 'Dias letivos de ' + ano, b), { papel: 'A4' }), csv };
};
C_.relLetTurma = el => { UI.filtro.relLetTurma = el.checked; render(); };
C_.relLetEscola = el => { UI.filtro.relLetEscola = el.checked; render(); };
(() => { const i = RELATORIOS.findIndex(r => r[0] === 'freq'); RELATORIOS.splice(i + 1, 0, ['letivos', 'Dias letivos do ano', 'O calendário do ano numa folha, com os dias letivos de cada mês; junto, se quiser, a agenda da turma e a da escola, cada uma numa folha.']); RELATORIOS.splice(i + 2, 0, ['reunioes', 'Reuniões com as famílias', 'A agenda das reuniões com as famílias, em lista ou em grade mês a mês.']); })();

/* blocos especiais: calendário anual e grade mensal (na tela e no PDF); no Word, viram tabelas */
function htmlCalAno(x) {
  return '<div class="cal-ano">' + x.meses.map(m => '<div class="cal-ano-mes"><div class="cal-ano-tit">' + MESES[m.m - 1][0].toUpperCase() + MESES[m.m - 1].slice(1) + ' <span>' + m.n + ' dia' + (m.n === 1 ? '' : 's') + '</span></div><table><tr>' + DIAS_CURTO.map(d => '<th>' + d[0] + '</th>').join('') + '</tr><tr>' +
    '<td></td>'.repeat(m.pri) + m.dias.map((d, i) => '<td style="background:' + COR_DIA[d.st] + (d.st === 'fora' || d.st === 'fds' ? ';color:#A39E92' : '') + '">' + d.d + '</td>' + ((m.pri + i + 1) % 7 === 0 && i < m.dias.length - 1 ? '</tr><tr>' : '')).join('') + '</tr></table></div>').join('') +
    '</div><p class="cal-ano-leg">' + ['letivo', 'retirado', 'feriado', 'fds', 'fora'].map(k => '<span><i style="background:' + COR_DIA[k] + '"></i>' + LETIVO_TXT[k].replace(' (toque para repor)', '') + '</span>').join('') + '</p>';
}
function htmlCalMes(x) {
  return '<h3 style="margin:.6em 0 .3em">' + nomeMes(x.ano, x.mes) + '</h3>' + htmlGradeMes(x.ano, x.mes, (iso, d) => '<td style="vertical-align:top;height:4.2em;border:1px solid #ccc;padding:2px;' + (x.desab && x.desab.includes(iso) ? 'background:#EFECE4;color:#A39E92' : '') + '"><b>' + d + '</b>' + ((x.itens || {})[iso] || []).map(s => '<div style="font-size:.78em;line-height:1.2">' + e(s) + '</div>').join('') + '</td>', { peq: true });
}
function blocosParaWord(x) {
  if (x.t === 'calAno') return x.meses.map(m => ({ t: 'tabela', cab: [MESES[m.m - 1] + ' (' + m.n + ')', '', '', '', '', '', ''].map((c, i) => i ? DIAS_CURTO[i] : c), linhas: (() => { const ls = [], cel = Array(m.pri).fill('').concat(m.dias.map(d => d.st === 'letivo' || d.st === 'letivoTurma' ? String(d.d) : '(' + d.d + ')')); while (cel.length) ls.push(cel.splice(0, 7).concat(Array(7).fill('')).slice(0, 7)); return ls; })() })).concat([{ t: 'nota', txt: 'Entre parênteses: dias sem aula.' }]);
  if (x.t === 'calMes') { const nd = new Date(x.ano, x.mes, 0).getDate(), ls = []; for (let d = 1; d <= nd; d++) { const iso = x.ano + '-' + String(x.mes).padStart(2, '0') + '-' + String(d).padStart(2, '0'), it = (x.itens || {})[iso]; if (it && it.length) ls.push([dataBR(iso) + ' (' + diaSemana(iso) + ')', it.join('\n')]); } return [{ t: 'h', txt: nomeMes(x.ano, x.mes) }, ls.length ? { t: 'tabela', cab: ['Dia', 'Reuniões'], linhas: ls } : { t: 'p', txt: 'Nenhuma reunião.' }]; }
  return [x];
}

/* ---------- TELA: REUNIÕES COM AS FAMÍLIAS ---------- */
const reunioesDaTurma = t => D.eventos.filter(v => v.familia && v.turmaId === t.id).sort((a, b) => (a.data + (a.hora || '')).localeCompare(b.data + (b.hora || '')));
const SIT_REU = [['agendada', 'Agendada'], ['realizada', 'Realizada'], ['remarcada', 'Remarcada'], ['cancelada', 'Cancelada']];
const rotSitReu = k => (SIT_REU.find(x => x[0] === k) || SIT_REU[0])[1];
const tituloReuniao = (a, resp) => 'Reunião com a família de ' + (a ? primeiroNome(a) : '…') + (resp && resp.length ? ' (' + juntarLista(resp) + ')' : '');
const resumoReu = r => { const a = IX.alunos[r.alunoId]; return (r.hora || '') + (r.horaFim ? '–' + r.horaFim : '') + ' ' + (a ? primeiroNome(a) : '') + (r.resp && r.resp.length ? ' · ' + r.resp.join(', ') : '') + (r.convidado ? ' · conv.: ' + r.convidado : ''); };
const diaReuniaoHabilitado = (t, iso) => ehLetivo(iso, t) && !(t.reunioesIndisp || []).includes(iso);
T.reunioes = () => {
  const t = turmaAtual(); if (!t) return '<h1>Reuniões com as famílias</h1>' + vazio('Cadastre uma turma primeiro.');
  const ano = String(t.ano); UI.reuMes = UI.reuMes && UI.reuMes.startsWith(ano) ? UI.reuMes : (hojeISO().startsWith(ano) ? hojeISO().slice(0, 7) : ano + '-02');
  const [, mes] = UI.reuMes.split('-').map(Number), rs = reunioesDaTurma(t), doMes = rs.filter(r => r.data.startsWith(UI.reuMes)), dia = UI.reuDia && UI.reuDia.startsWith(UI.reuMes) ? UI.reuDia : null;
  let h = '<div class="linha"><button class="btn" data-a="ir" data-t="agenda">← Calendário</button><h1 style="margin:0">Reuniões com as famílias</h1></div>';
  h += '<p>Toque num dia para marcar uma reunião. Só os dias letivos ficam disponíveis; para deixar um dia fora desta agenda (por exemplo, um dia em que você não pode), toque nele e use “Indisponível neste dia”. Cada reunião aparece no calendário, gera o convite para a família e, depois, a ata já preenchida.</p>';
  h += '<div class="linha"><button class="btn" data-a="reuImprimir" data-v="lista">Imprimir em lista</button><button class="btn" data-a="reuImprimir" data-v="grade">Imprimir em grade, mês a mês</button></div>';
  h += '<div class="cartao"><div class="linha" style="margin:0 0 .6rem"><button class="btn" data-a="reuMes" data-v="-1" aria-label="Mês anterior">‹</button><b style="min-width:10rem;text-align:center">' + nomeMes(ano, mes) + '</b><button class="btn" data-a="reuMes" data-v="1" aria-label="Próximo mês">›</button><span class="espaco"></span><span class="dica">' + doMes.filter(r => r.situacao !== 'cancelada').length + ' reunião(ões) no mês</span></div>';
  h += htmlGradeMes(Number(ano), mes, (iso, d) => {
    const hab = diaReuniaoHabilitado(t, iso), ind = (t.reunioesIndisp || []).includes(iso), xs = rs.filter(r => r.data === iso), clic = hab || ind;
    return '<td class="dia-reu' + (hab ? ' clic' : ' desab') + (ind ? ' indisp' : '') + (iso === dia ? ' sel' : '') + '"' + (clic ? ' data-a="reuDia" data-d="' + iso + '" role="button" tabindex="0"' : ' aria-disabled="true"') + ' title="' + dataBR(iso) + (ind ? ': indisponível nesta agenda' : hab ? '' : ': sem aula') + '"><span>' + d + '</span>' + xs.map(r => '<div class="reu-chip sit-' + (r.situacao || 'agendada') + '">' + e((r.hora || '') + ' ' + (IX.alunos[r.alunoId] ? primeiroNome(IX.alunos[r.alunoId]) : '')) + '</div>').join('') + '</td>';
  });
  h += '<p class="legenda-let"><span><i style="background:var(--folha);border:1px solid var(--linha)"></i>disponível</span><span><i style="background:#EFECE4"></i>sem aula</span><span><i style="background:#F8E2A8"></i>indisponível nesta agenda</span></p></div>';
  if (dia) {
    const ind = (t.reunioesIndisp || []).includes(dia), xs = rs.filter(r => r.data === dia);
    h += '<div class="cartao" id="reu-dia"><div class="linha" style="margin:0"><h3 style="margin:0">' + dataBR(dia) + ' · ' + diaSemana(dia) + '</h3><span class="espaco"></span>' + (ind ? '' : '<button class="btn pri" data-a="reuNova" data-d="' + dia + '">+ Reunião neste dia</button>') + '<button class="btn" data-a="reuIndisp" data-d="' + dia + '">' + (ind ? 'Disponível neste dia' : 'Indisponível neste dia') + '</button></div>' + (xs.length ? tabelaReunioes(xs) : '<p class="dica">Nenhuma reunião neste dia.</p>') + '</div>';
  }
  h += '<h2>Reuniões de ' + MESES[mes - 1] + '</h2>' + (doMes.length ? '<div class="cartao">' + tabelaReunioes(doMes) + '</div>' : vazio('Nenhuma reunião marcada neste mês.'));
  return h;
};
function tabelaReunioes(xs) {
  return '<div class="rolagem"><table class="tabela"><tr><th>Data</th><th>Horário</th><th>Criança</th><th>Família</th><th>Convidado</th><th>Situação</th><th></th></tr>' + xs.map(r => { const a = IX.alunos[r.alunoId], ata = r.ataId && IX.atas[r.ataId];
    return '<tr><td>' + dataBR(r.data) + '</td><td>' + e((r.hora || '') + (r.horaFim ? '–' + r.horaFim : '')) + '</td><td>' + e(a ? a.nome : '—') + '</td><td>' + e((r.resp || []).join(', ')) + '</td><td>' + e(r.convidado || '') + '</td><td><span class="etq ' + (r.situacao === 'realizada' ? 'fin' : r.situacao === 'cancelada' ? 'sig' : 'rasc') + '">' + rotSitReu(r.situacao) + '</span>' + (r.assunto ? '<br><span class="dica">' + e(r.assunto) + '</span>' : '') + '</td><td style="white-space:nowrap"><button class="btn peq" data-a="reuEditar" data-id="' + r.id + '">Editar</button><button class="btn peq" data-a="reuConvite" data-id="' + r.id + '">Convite</button><button class="btn peq" data-a="reuAta" data-id="' + r.id + '">' + (ata ? 'Abrir a ata' : 'Registrar ata') + '</button><button class="btn peq" data-a="reuDigitais" data-id="' + r.id + '" title="Fotos e documentos desta reunião">📎' + (D.digitais.some(x => x.reuniaoId === r.id) ? ' ' + D.digitais.filter(x => x.reuniaoId === r.id).length : '') + '</button><button class="icone-btn" data-a="reuExcluir" data-id="' + r.id + '" title="Excluir" aria-label="Excluir">✕</button></td></tr>'; }).join('') + '</table></div>';
}
A.reuMes = d => { const t = turmaAtual(); let [a, m] = UI.reuMes.split('-').map(Number); m += Number(d.v); if (m < 1) m = 1; if (m > 12) m = 12; UI.reuMes = a + '-' + String(m).padStart(2, '0'); UI.reuDia = null; render(); };
A.reuDia = d => { UI.reuDia = d.d; render(); setTimeout(() => { const c = $('#reu-dia'); if (c) c.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, 40); };
A.reuIndisp = async d => { const t = turmaAtual(); t.reunioesIndisp = alternar(t.reunioesIndisp || [], d.d); await salvar('turmas', t); render(); };
async function dialogoReuniao(r, t) {
  const al = alunosDaTurma(t.id), a0 = IX.alunos[r.alunoId] || null;
  const respDe = a => (a && a.responsaveis || []).map(x => primeiro(x.nome)).filter(Boolean);
  const corpoResp = a => respDe(a).map(n => '<label class="ck"><input type="checkbox" name="resp" data-multi="1" value="' + e(n) + '"' + ((r.resp || []).includes(n) || !r.id ? ' checked' : '') + '> ' + e(n) + '</label>').join('') || '<p class="dica">Sem responsáveis cadastrados para esta criança.</p>';
  const v = await dlg({ titulo: r.id ? 'Editar reunião' : 'Nova reunião com a família', largo: true, ok: 'Salvar',
    corpo: '<div class="grade" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">' + campo('Data', '<input type="date" name="data" value="' + e(r.data) + '">') + campo('Início', '<input type="time" name="hora" value="' + e(r.hora || '') + '">') + campo('Fim', '<input type="time" name="horaFim" value="' + e(r.horaFim || '') + '">') + campo('Situação', '<select name="situacao">' + SIT_REU.map(([k, n]) => '<option value="' + k + '"' + ((r.situacao || 'agendada') === k ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>') + '</div>' +
      campo('Criança', '<select name="alunoId" id="reuAluno"><option value="">— escolha —</option>' + al.map(a => '<option value="' + a.id + '"' + (a.id === r.alunoId ? ' selected' : '') + '>' + e(a.nome) + '</option>').join('') + '</select>') +
      campo('Quem da família participa (primeiro nome)', '<div id="reuResp" class="lista-sel">' + corpoResp(a0) + '</div>') +
      '<div class="duas">' + campo('Convidado', '<input name="convidado" value="' + e(r.convidado || '') + '" placeholder="Outra pessoa que participa e não está no sistema">') + campo('Local', '<input name="local" value="' + e(r.local || '') + '" placeholder="ex.: sala da classe">') + '</div>' +
      '<div class="duas">' + campo('Formato', '<select name="modo"><option value="presencial"' + (r.modo !== 'online' ? ' selected' : '') + '>Presencial</option><option value="online"' + (r.modo === 'online' ? ' selected' : '') + '>On-line</option></select>') + campo('Assunto', '<input name="assunto" value="' + e(r.assunto || '') + '" placeholder="ex.: conversa do 1º semestre">') + '</div>' +
      campo('Observações (só para você)', '<textarea name="obs" style="min-height:3rem">' + e(r.obs || '') + '</textarea>'),
    aoAbrir: f => { const s = $('#reuAluno', f); s.addEventListener('change', () => { $('#reuResp', f).innerHTML = corpoResp(IX.alunos[s.value]); }); },
    validar: x => !x.data ? 'Escolha a data.' : !x.alunoId ? 'Escolha a criança.' : x.hora && x.horaFim && x.horaFim <= x.hora ? 'O fim deve ser depois do início.' : null });
  return v;
}
A.reuNova = async d => {
  const t = turmaAtual(), v = await dialogoReuniao({ data: d.d, situacao: 'agendada', local: 'sala da classe' }, t); if (!v) return;
  if (!diaReuniaoHabilitado(t, v.data) && !(await confirmar('Dia sem aula ou indisponível', dataBR(v.data) + ' não está disponível nesta agenda. Marcar mesmo assim?', 'Marcar'))) return;
  const r = await salvar('eventos', Object.assign(dadosReuniao(v, t), { turmaId: t.id, tipo: 'reuniao', familia: true }));
  UI.reuDia = r.data; UI.reuMes = r.data.slice(0, 7); render(); aviso('Reunião marcada. Ela já aparece no calendário.');
};
function dadosReuniao(v, t) { const a = IX.alunos[v.alunoId], resp = v.resp || []; return { data: v.data, hora: v.hora, horaFim: v.horaFim, duracao: v.hora && v.horaFim ? duracaoTxt(v.hora, v.horaFim) : '', alunoId: v.alunoId, resp, convidado: v.convidado.trim(), local: v.local.trim(), modo: v.modo, assunto: v.assunto.trim(), obs: v.obs, situacao: v.situacao, titulo: tituloReuniao(a, resp) }; }
function duracaoTxt(a, b) { const m = (Number(b.slice(0, 2)) * 60 + Number(b.slice(3, 5))) - (Number(a.slice(0, 2)) * 60 + Number(a.slice(3, 5))); return m > 0 ? (m >= 60 ? Math.floor(m / 60) + 'h' + (m % 60 ? String(m % 60).padStart(2, '0') : '') : m + 'min') : ''; }
A.reuEditar = async d => { const t = turmaAtual(), r = IX.eventos[d.id]; if (!r) return; const v = await dialogoReuniao(r, t); if (!v) return; Object.assign(r, dadosReuniao(v, t)); await salvar('eventos', r); UI.reuDia = r.data; UI.reuMes = r.data.slice(0, 7); render(); aviso('Reunião salva.'); };
A.reuExcluir = d => apagarComDesfazer('eventos', d.id, 'Reunião excluída.');
/* convite para a família, pronto para imprimir ou enviar */
A.reuConvite = d => {
  const r = IX.eventos[d.id], t = turmaAtual(), a = IX.alunos[r.alunoId]; if (!a) return;
  const quando = dataBR(r.data) + ' (' + diaSemana(r.data) + ')' + (r.hora ? ', às ' + r.hora.replace(':', 'h') : '') + (r.horaFim ? ', até ' + r.horaFim.replace(':', 'h') : '');
  const ola = (r.resp || []).length ? 'Olá, ' + juntarLista(r.resp) + '!' : 'Olá, família!';
  const bl = [{ t: 'tit', txt: 'Convite para conversa' }, { t: 'p', txt: ola }, { t: 'p', txt: substituir('Gostaria de convidar vocês para uma conversa sobre {nome}' + (r.assunto ? ' (' + r.assunto + ')' : '') + ', no dia ' + quando + (r.modo === 'online' ? ', on-line' : r.local ? ', na ' + r.local.replace(/^(na|no|em)\s+/i, '') : '') + '.', a, t) }];
  if (r.convidado) bl.push({ t: 'p', txt: 'Participará também: ' + r.convidado + '.' });
  bl.push({ t: 'p', txt: 'Se o horário não for possível, por favor me avisem para combinarmos outro.' }, { t: 'p', txt: 'Um abraço,' }, { t: 'p', txt: (t.professora || '').replace(/\s*\(fict[íi]ci[oa]\)/i, '') });
  const para = (a.responsaveis || []).filter(x => (r.resp || []).includes(primeiro(x.nome)) && x.email).map(x => x.email);
  saidaDocumento({ nome: nomeArq('Convite_' + primeiroNome(a) + '_' + r.data), titulo: 'Convite para conversa — ' + primeiroNome(a), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: bl }, { para, assunto: 'Convite para conversa sobre ' + primeiroNome(a) });
};
/* depois da reunião: ata já preenchida (Reunião com as famílias) e registro no Acompanhamento */
A.reuAta = async d => {
  const r = IX.eventos[d.id], t = turmaAtual(), a = IX.alunos[r.alunoId]; if (!r) return;
  if (r.ataId && IX.atas[r.ataId]) { UI.sub = r.ataId; return ir('atas', r.ataId); }
  const resp = (a && a.responsaveis || []).filter(x => (r.resp || []).includes(primeiro(x.nome)));
  const part = [{ nome: t.professora || profTit(t), categoria: 'Professor(a)', presente: true }].concat(resp.map(x => ({ nome: x.nome, categoria: 'Familiar', presente: true, email: x.email || '' })), r.convidado ? [{ nome: r.convidado, categoria: 'Convidado', presente: true }] : []);
  const tipos = tiposAta(), tipo = tipos.familias ? 'familias' : Object.keys(tipos)[0], num = String(D.atas.filter(x => x.turmaId === t.id && x.tipo === tipo).length + 1).padStart(2, '0');
  const ata = await salvar('atas', { turmaId: t.id, tipo, subtipo: '', numero: num, data: r.data, inicio: r.hora || '', fim: r.horaFim || '', local: r.modo === 'online' ? 'on-line' : (r.local || ''), assunto: r.assunto || ('conversa sobre ' + (a ? primeiroNome(a) : 'a criança')), pauta: '', participantes: part, texto: '', deliberacoes: '', conclusao: '', encaminhamentos: [], estado: 'rascunho', reuniaoId: r.id });
  r.ataId = ata.id; if (r.situacao === 'agendada') r.situacao = 'realizada';
  if (a && !r.contatoId) { const c = await salvar('contatos', { turmaId: t.id, alunoId: a.id, data: r.data, meio: 'reuniao', quem: juntarLista(r.resp || []) || 'a família', assunto: r.assunto || 'Reunião com a família', texto: 'Reunião registrada na ata nº ' + num + '.', combinados: '', sigilo: false, ataId: ata.id }); r.contatoId = c.id; }
  await salvar('eventos', r); aviso('Ata criada com data, horário e participantes. Escreva o que foi conversado.'); ir('atas', ata.id);
};
/* impressão: lista completa ou grade mês a mês */
A.reuImprimir = d => {
  const t = turmaAtual(), rs = reunioesDaTurma(t).filter(r => r.situacao !== 'cancelada');
  if (!rs.length) return aviso('Nenhuma reunião marcada.');
  let b = [{ t: 'p', txt: rotuloTurma(t) + ' · ' + rs.length + ' reunião(ões)' }];
  if (d.v === 'lista') b.push({ t: 'tabela', cab: ['Data', 'Horário', 'Criança', 'Família', 'Convidado', 'Local', 'Assunto', 'Situação'], linhas: rs.map(r => [dataBR(r.data) + ' (' + diaSemana(r.data).slice(0, 3) + ')', (r.hora || '') + (r.horaFim ? '–' + r.horaFim : ''), (IX.alunos[r.alunoId] || {}).nome || '', (r.resp || []).join(', '), r.convidado || '', r.modo === 'online' ? 'on-line' : (r.local || ''), r.assunto || '', rotSitReu(r.situacao)]) });
  else { const meses = [...new Set(rs.map(r => r.data.slice(0, 7)))].sort(); meses.forEach((m, i) => { const [a, mm] = m.split('-').map(Number), itens = {}, desab = []; rs.filter(r => r.data.startsWith(m)).forEach(r => (itens[r.data] = itens[r.data] || []).push(resumoReu(r))); const nd = new Date(a, mm, 0).getDate(); for (let k = 1; k <= nd; k++) { const iso = m + '-' + String(k).padStart(2, '0'); if (!diaReuniaoHabilitado(t, iso)) desab.push(iso); } if (i) b.push({ t: 'quebra' }); b.push({ t: 'calMes', ano: a, mes: mm, itens, desab }); }); }
  saidaDocumento({ nome: 'Reunioes_familias_' + t.serie + 'ano' + (t.letra || '') + '_' + t.ano, titulo: 'Reuniões com as famílias — ' + rotuloTurma(t), papel: TIM('atas').papel, timbrado: TIM('atas'), blocos: [{ t: 'tit', txt: 'Reuniões com as famílias — ' + rotuloTurma(t) }].concat(b) });
};
REL.reunioes = t => {
  const rs = reunioesDaTurma(t), f = UI.filtro;
  const ctr = '<div class="linha"><button class="btn" data-a="ir" data-t="reunioes">Abrir a agenda das reuniões</button><button class="btn" data-a="reuImprimir" data-v="lista">Imprimir em lista</button><button class="btn" data-a="reuImprimir" data-v="grade">Imprimir em grade, mês a mês</button></div>';
  const linhas = rs.map(r => [dataBR(r.data), (r.hora || '') + (r.horaFim ? '–' + r.horaFim : ''), (IX.alunos[r.alunoId] || {}).nome || '', (r.resp || []).join(', '), r.convidado || '', rotSitReu(r.situacao)]);
  return { controles: ctr, doc: docBase('Reunioes_familias_' + t.ano, 'Reuniões com as famílias — ' + rotuloTurma(t), rs.length ? [{ t: 'tabela', cab: ['Data', 'Horário', 'Criança', 'Família', 'Convidado', 'Situação'], linhas }] : [{ t: 'p', txt: 'Nenhuma reunião marcada.' }]), csv: { cab: ['Data', 'Horário', 'Criança', 'Família', 'Convidado', 'Situação'], linhas } };
};
