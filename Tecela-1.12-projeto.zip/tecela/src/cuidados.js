/* ==========================================================================
   Tecelã — Cuidados com os dados: cópia de segurança com senha (para guardar
   fora do computador) com lembrete, e desfazer nos campos de texto.

   Cópia de segurança: arquivo .tecela com copiaSeg: true, sempre cifrado.
   Com a senha da Tecelã ligada, usa a mesma chave. Sem ela, usa a "senha das
   cópias" (criada na primeira cópia, com chave de recuperação), guardada só no
   aparelho em CFG.prefs.copiaSegCripto / copiaSegDk, que NÃO vão no arquivo.
   Lembrete: CFG.prefs.lembreteCopia dias (padrão 5) desde CFG.prefs.ultimaCopiaSeg.
   ========================================================================== */
'use strict';
/* a boia desenhada aqui: o emoji 🛟 não existe no Windows 10 */
const BOIA = '<svg class="ico-boia" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" fill="none" stroke="#D9533A" stroke-width="5"/><circle cx="12" cy="12" r="8" fill="none" stroke="#fff" stroke-width="5" stroke-dasharray="4.19 8.38" stroke-dashoffset="2.1"/><circle cx="12" cy="12" r="10.5" fill="none" stroke="#8A3B2E" stroke-width=".8"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#8A3B2E" stroke-width=".8"/></svg>';
const diasDesdeCopia = () => { const u = CFG.prefs.ultimaCopiaSeg; if (!u) return null; return Math.floor((new Date(new Date().toDateString()) - new Date(new Date(u).toDateString())) / 864e5); };
function copiaVencida() {
  if (SE.demo || !D.turmas) return false;
  if (!D.turmas.length && !D.alunos.length) return false; /* base vazia: nada a proteger ainda */
  const n = Number(CFG.prefs.lembreteCopia); if (n === 0) return false; const lim = n > 0 ? n : 5, d = diasDesdeCopia();
  return d === null || d >= lim;
}
const textoCopiaVencida = () => { const d = diasDesdeCopia(); return d === null ? 'Você ainda não fez uma cópia de segurança fora deste computador' : 'Faz ' + d + ' dia' + (d === 1 ? '' : 's') + ' que você não faz uma cópia de segurança fora deste computador'; };
const avisoCopiaPainel = () => copiaVencida() ? '<div class="alerta amar">' + BOIA + ' <b>' + e(textoCopiaVencida()) + '.</b> Se este computador estragar ou for perdido, a cópia guardada em outro lugar é o que salva o seu trabalho. <button class="btn peq pri" data-a="copiaSeg">Fazer a cópia de segurança</button></div>' : '';
const usaSenhaDaTecela = () => !!(CFG.cripto && SE.dk);
async function chaveDasCopias() {
  if (usaSenhaDaTecela()) return { dk: SE.dk, cripto: CFG.cripto };
  if (CFG.prefs.copiaSegCripto && CFG.prefs.copiaSegDk) return { dk: ub64(CFG.prefs.copiaSegDk), cripto: CFG.prefs.copiaSegCripto };
  if (!temCripto()) { await informar('Criptografia indisponível', '<p>Este navegador não oferece a criptografia necessária para proteger a cópia com senha. Use uma versão recente do Chrome, Edge, Firefox ou Safari.</p>'); return null; }
  const v = await definirSenha('Senha das cópias de segurança', 'A cópia de segurança vai para fora deste computador (pendrive, nuvem, e-mail). Por isso ela é sempre protegida por senha, mesmo que a Tecelã seja usada sem senha aqui. Crie a senha das cópias: ela será pedida só para abrir uma cópia.');
  if (!v) return null;
  const dk = crypto.getRandomValues(new Uint8Array(32)), chave = novaChave(), a = await embrulhar(dk, v.s1), b = await embrulhar(dk, normChave(chave));
  await prefs({ copiaSegCripto: { s1: a.s, w1: a.w, s2: b.s, w2: b.w, dica: v.dica.trim() }, copiaSegDk: b64(dk) });
  await mostrarChave(chave);
  return { dk, cripto: CFG.prefs.copiaSegCripto };
}
A.copiaSeg = async () => {
  if (SE.demo) return aviso('O modelo de demonstração não faz cópia de segurança.');
  await descarregarFila();
  const ok = await dlg({ titulo: 'Cópia de segurança', ok: 'Fazer a cópia', corpo: '<p>A cópia de segurança é um arquivo à parte, <b>protegido por senha</b>, com todo o seu trabalho. Ela serve para o dia em que este computador estragar, for roubado ou for formatado.</p><p><b>Guarde-a fora deste computador:</b> num pendrive, na pasta do Google Drive ou do OneDrive, ou mande para o seu próprio e-mail.</p>' + (usaSenhaDaTecela() ? '<p class="dica">Ela usa a mesma senha da Tecelã.</p>' : CFG.prefs.copiaSegCripto ? '<p class="dica">Ela usa a senha das cópias de segurança, que você já criou.</p>' : '<p class="dica">Na primeira vez, você cria a senha das cópias e recebe uma chave de recuperação.</p>') });
  if (!ok) return false;
  const ch = await chaveDasCopias(); if (!ch) return false;
  const txt = await pacoteCopia({ dk: ch.dk, cripto: ch.cripto, copiaSeg: true }), nome = 'Tecela_COPIA_' + nomeArq(CFG.escola.nome || 'turma') + '_' + carimbo() + '.tecela';
  let feito = false, onde = '';
  /* no celular: compartilhar direto para o Drive, o OneDrive, o e-mail ou o WhatsApp */
  if ((ANDROID || APPLE_TOQUE) && navigator.canShare) {
    try { const f = new File([txt], nome, { type: 'application/octet-stream' }); if (navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Cópia de segurança da Tecelã' }); feito = true; onde = 'compartilhada'; } } catch (x) { if (x && x.name === 'AbortError') return aviso('A cópia não foi feita: o compartilhamento foi cancelado.'); }
  }
  if (!feito) { const r = await salvarComo(nome, txt, TIPO_TECELA, 'Cópia de segurança da Tecelã'); if (!r) { aviso('A cópia não foi feita: a janela de salvar foi cancelada.'); return false; } feito = true; onde = r.escolheu ? 'salva como ' + r.nome : 'salva na pasta de downloads: ' + r.nome; }
  await prefs({ ultimaCopiaSeg: new Date().toISOString() }); render();
  await informar('Cópia de segurança feita', '<p>Cópia ' + e(onde) + '.</p><p><b>Agora, leve-a para fora deste computador</b>, se ainda não estiver:</p><ul><li>copie para um <b>pendrive</b>, ou</li><li>arraste para a pasta do <b>Google Drive</b> ou do <b>OneDrive</b>, ou</li><li>envie para o seu próprio <b>e-mail</b>, como anexo.</li></ul><p class="dica">Para abrir a cópia, use “Abrir um arquivo da Tecelã” e a senha ' + (usaSenhaDaTecela() ? 'da Tecelã' : 'das cópias') + ' (ou a chave de recuperação). A próxima lembrança vem em ' + (Number(CFG.prefs.lembreteCopia) || 5) + ' dias.</p>');
  return true;
};
/* no primeiro Salvar, uma explicação única sobre o arquivo e a cópia em outro lugar */
async function explicarCopiaUmaVez() {
  if (CFG.prefs.explicouCopia || SE.demo) return; await prefs({ explicouCopia: true });
  await informar('O seu arquivo foi salvo', '<p>O arquivo <b>.tecela</b> guarda todo o seu trabalho. Use <b>💾 Salvar</b> sempre que terminar.</p><p>Mas um arquivo só, num computador só, se perde junto com ele. Por isso, de vez em quando, faça também uma <b>' + BOIA + ' cópia de segurança</b> e guarde fora deste computador (pendrive, Google Drive, OneDrive ou o seu e-mail). A Tecelã lembra você a cada ' + (Number(CFG.prefs.lembreteCopia) || 5) + ' dias.</p><p class="dica">Dica: se o seu computador tem a pasta do Google Drive ou do OneDrive, salve o arquivo de trabalho dentro dela: assim ele ganha uma cópia na nuvem sozinho.</p>');
}
/* Ajustes */
function cartaoCopiaSeg() {
  const u = CFG.prefs.ultimaCopiaSeg;
  return '<div class="cartao" id="m-copiaseg-aj"><h3>' + BOIA + ' Cópia de segurança</h3><p>' + (u ? 'Última cópia de segurança: <b>' + new Date(u).toLocaleString('pt-BR') + '</b>.' : 'Nenhuma cópia de segurança feita ainda.') + ' A cópia é sempre protegida por senha (' + (usaSenhaDaTecela() ? 'a mesma da Tecelã' : CFG.prefs.copiaSegCripto ? 'a senha das cópias' : 'você cria a senha das cópias na primeira vez') + ') e deve ser guardada fora deste computador.</p>' +
    '<div class="linha"><button class="btn pri" data-a="copiaSeg">Fazer a cópia de segurança</button>' + (!usaSenhaDaTecela() && CFG.prefs.copiaSegCripto ? '<button class="btn" data-a="trocarSenhaCopias">Trocar a senha das cópias</button>' : '') + '</div>' +
    campo('Lembrar de fazer a cópia a cada (dias)', '<input type="number" min="0" max="60" data-c="lembreteCopia" value="' + (CFG.prefs.lembreteCopia == null ? 5 : Number(CFG.prefs.lembreteCopia)) + '" style="width:6rem">', 'Use 0 para não lembrar (não recomendado).') + '</div>';
}
C_.lembreteCopia = async el => { const n = Math.max(0, Math.min(60, Math.round(Number(el.value) || 0))); await prefs({ lembreteCopia: n }); aviso(n ? 'A Tecelã vai lembrar a cada ' + n + ' dias.' : 'Lembrete da cópia de segurança desligado.'); render(); };
A.trocarSenhaCopias = async () => {
  const c = CFG.prefs.copiaSegCripto; if (!c) return; let ok = false;
  const v = await dlg({ titulo: 'Trocar a senha das cópias', ok: 'Continuar', corpo: campo('Senha atual das cópias', '<input type="password" name="s" autofocus>'), validar: async v => { try { await desembrulhar(c.s1, c.w1, v.s); ok = true; } catch (x) { return 'Senha incorreta.'; } } });
  if (!v || !ok) return; const n = await definirSenha('Nova senha das cópias', 'Vale para as próximas cópias. As cópias antigas continuam abrindo com a senha antiga ou com a chave de recuperação, que continua a mesma.'); if (!n) return;
  const a = await embrulhar(ub64(CFG.prefs.copiaSegDk), n.s1); await prefs({ copiaSegCripto: Object.assign({}, c, { s1: a.s, w1: a.w, dica: n.dica.trim() }) }); aviso('Senha das cópias alterada.');
};

/* ---------- DESFAZER NOS TEXTOS ----------
   Cada alteração de um campo de texto (data-rec + data-b) entra num histórico da sessão:
   ↶ (no alto) ou Ctrl+Z fora do campo desfaz a última; apagar um trecho grande de uma vez
   mostra na hora o aviso “Trecho apagado · Desfazer”. */
const HIST = []; const CAMPO_HIST = 'textarea[data-b], input[data-b]:not([type]), input[data-b][type=text]';
function rotuloCampo(el) {
  const l = el.closest('label.cp'); if (l && $('.r', l)) return $('.r', l).textContent.trim();
  const s = el.closest('.secao-bol,.sec-doc,.cartao,details'); const h = s && s.querySelector('h4,h3,input.tit-sec,summary');
  return h ? (h.value || h.textContent).trim().slice(0, 60) : 'texto';
}
function registroDoCampo(el) { const c = el.closest('[data-rec]'); if (!c) return null; const k = c.dataset.rec.indexOf(':'); return { store: c.dataset.rec.slice(0, k), id: c.dataset.rec.slice(k + 1), path: el.dataset.b }; }
document.addEventListener('focusin', ev => { const el = ev.target; if (el.matches && el.matches(CAMPO_HIST)) { el._antes = el.value; el._ult = el.value; } });
function anotarMudanca(el) {
  if (el._antes == null || el.value === el._antes) return; const reg = registroDoCampo(el); if (!reg) return;
  HIST.push(Object.assign(reg, { antes: el._antes, depois: el.value, rot: rotuloCampo(el), tela: UI.tela, sub: UI.sub, quando: new Date() })); if (HIST.length > 60) HIST.shift();
  el._antes = el.value;
}
document.addEventListener('change', ev => { const el = ev.target; if (el.matches && el.matches(CAMPO_HIST)) anotarMudanca(el); }, true);
document.addEventListener('focusout', ev => { const el = ev.target; if (el.matches && el.matches(CAMPO_HIST)) anotarMudanca(el); }, true);
/* apagou um trecho grande de uma vez (um parágrafo, por exemplo): oferece desfazer na hora */
document.addEventListener('input', ev => {
  const el = ev.target; if (!el.matches || !el.matches(CAMPO_HIST)) return;
  const antes = el._ult == null ? el.value : el._ult; el._ult = el.value;
  if (antes.length - el.value.length >= 40) { const guardado = antes; aviso('Trecho apagado.', 'Desfazer', () => { if (el.isConnected) { el.value = guardado; el._ult = guardado; vincular(el, false); el.focus(); } else { const reg = registroDoCampo(el) || {}; const r = reg.store && IX[reg.store] && IX[reg.store][reg.id]; if (r) { setP(r, reg.path, guardado); salvar(reg.store, r); render(); } } aviso('Trecho de volta.'); }); }
});
const valorEm = (o, p) => p.split('.').reduce((x, k) => x == null ? x : x[k], o);
async function aplicarVersao(h, valor) {
  const r = IX[h.store] && IX[h.store][h.id]; if (!r) return aviso('Esse registro não existe mais.');
  if (bloqueado(h.store, r)) return aviso('Esse documento está finalizado e não muda mais.');
  const atual = valorEm(r, h.path); setP(r, h.path, valor); await salvar(h.store, r);
  HIST.push(Object.assign({}, h, { antes: atual == null ? '' : String(atual), depois: valor, quando: new Date(), refeito: true }));
  render();
}
A.desfazerTexto = async () => {
  const a = document.activeElement; if (a && a.matches && a.matches(CAMPO_HIST)) anotarMudanca(a);
  const h = HIST.pop(); if (!h) return aviso('Nada para desfazer nesta sessão.');
  const r = IX[h.store] && IX[h.store][h.id]; if (!r) return aviso('Esse registro não existe mais.');
  if (bloqueado(h.store, r)) return aviso('Esse documento está finalizado e não muda mais.');
  setP(r, h.path, h.antes); await salvar(h.store, r); render();
  aviso('Desfeito: ' + h.rot + '.', 'Histórico', () => A.historicoTextos());
};
A.historicoTextos = async () => {
  if (!HIST.length) return informar('Histórico dos textos', '<p>Nenhuma alteração de texto nesta sessão.</p>');
  const xs = HIST.map((h, i) => [h, i]).reverse().slice(0, 30), cort = s => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > 90 ? s.slice(0, 90) + '…' : (s || '(vazio)'); };
  const v = await dlg({ titulo: 'Histórico dos textos (desta sessão)', largo: true, ok: false, cancelar: 'Fechar', corpo: '<p class="dica">As alterações de texto desde que a Tecelã foi aberta, da mais recente para a mais antiga. “Voltar a esta versão” põe de volta o texto como estava antes daquela alteração (e isso também pode ser desfeito).</p><table class="tabela"><tr><th>Quando</th><th>Campo</th><th>Antes</th><th></th></tr>' + xs.map(([h, i]) => '<tr><td style="white-space:nowrap">' + h.quando.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + '</td><td>' + e(h.rot) + '</td><td class="dica">' + e(cort(h.antes)) + '</td><td><button type="button" class="btn peq" data-x="v' + i + '">Voltar a esta versão</button></td></tr>').join('') + '</table>' });
  if (!v || !v._botao) return; const h = HIST[Number(v._botao.slice(1))]; if (h) { await aplicarVersao(h, h.antes); aviso('Versão anterior de volta: ' + h.rot + '.', 'Desfazer', () => A.desfazerTexto()); }
};
/* Ctrl+Z fora de um campo de texto desfaz pela Tecelã (dentro do campo, vale o desfazer do navegador) */
document.addEventListener('keydown', ev => {
  if ((ev.ctrlKey || ev.metaKey) && !ev.shiftKey && ev.key.toLowerCase() === 'z') { const a = document.activeElement; if (a && (a.matches('input, textarea, select') || a.isContentEditable)) return; if (!SE.app) return; ev.preventDefault(); A.desfazerTexto(); }
});
