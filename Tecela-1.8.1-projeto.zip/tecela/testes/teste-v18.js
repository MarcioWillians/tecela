// Testes da versão 1.8: dica do corretor, recuo e prévia dos textos da turma, títulos de seção e do poema como
// subtítulo, busca nos textos da turma, PEI – PDI e o botão Anotar que sai da frente enquanto se digita.
// Uso: LOG=log.txt node testes/teste-v18.js
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../dist/Tecela.html'), LOG = process.env.LOG || '/dev/null';
(async () => {
  const b = await chromium.launch({ args: ['--lang=pt-BR'] }), erros = [];
  const certo = (c, msg) => { if (!c) erros.push(msg); fs.appendFileSync(LOG, (c ? 'ok  ' : 'ERRO ') + msg + '\n'); };
  const p = await (await b.newContext({ viewport: { width: 1280, height: 800 }, locale: 'pt-BR' })).newPage();
  p.on('pageerror', x => erros.push('pageerror: ' + x.message)); p.on('console', m => { if (m.type() === 'error') erros.push('console: ' + m.text()); });
  const texto = () => p.textContent('#app');
  const DICA = 'clique com o botão direito na palavra sublinhada para ver sugestões';
  await p.goto(APP); await p.waitForTimeout(400);
  certo(/Versão 1\.8\b/.test(await p.textContent('.versao')), 'tela inicial mostra a versão 1.8');
  await p.click('[data-a=entrarDemo]'); await p.waitForTimeout(2600);
  await p.evaluate(async () => { CFG.prefs.turmaId = 't26'; const t = IX.turmas.t26; t.boletim = t.boletim || {}; t.boletim.textos = t.boletim.textos || {}; const k = modeloDaSerie(t.serie).secoes.find(s => s.ativa && s.key !== 'intro').key; window._k = k; t.boletim.textos[k] = 'Neste ano, {nome} e a turma cultivaram a horta xiloguarda com alegria.\nSegundo parágrafo da turma.'; await salvar('turmas', t); });

  // dica do corretor
  await p.evaluate(() => { UI.aba.bol = 'turma'; ir('bol'); }); let t = await texto();
  certo(t.includes(DICA), 'dica do corretor nos textos da turma');
  await p.evaluate(async () => { const b = await boletimDe(IX.turmas.t26, IX.alunos.ana); ir('bol', b.id); }); t = await texto();
  certo(t.includes(DICA), 'dica do corretor no editor do boletim da criança');

  // recuo e prévia
  await p.evaluate(() => { UI.sub = null; UI.aba.bol = 'turma'; ir('bol'); });
  certo(/Aparência do texto/.test(await texto()), 'cartão Aparência do texto nos textos da turma');
  await p.check('[data-b="boletim.recuo"]'); await p.waitForTimeout(700);
  const rec = await p.evaluate(async () => { await descarregarFila(); const d = docBoletim(await boletimDe(IX.turmas.t26, IX.alunos.ana)); return { flag: IX.turmas.t26.boletim.recuo === true, ps: d.blocos.filter(x => x.t === 'p' && x.recuo).length, html: /text-indent:1\.25cm/.test(htmlDoc(d, true)) }; });
  certo(rec.flag && rec.ps > 0 && rec.html, 'recuo na primeira linha: gravado, nos parágrafos e na impressão');
  const docxOk = await p.evaluate(async () => { const d = docBoletim(await boletimDe(IX.turmas.t26, IX.alunos.ana)), bl = await docxBlob(d); const u = new Uint8Array(await bl.arrayBuffer()); return u.length > 1000 && u[0] === 0x50 && u[1] === 0x4b; });
  certo(docxOk, 'Word do boletim gerado com o recuo');
  await p.click('[data-a=previaTurma]'); await p.waitForSelector('#modais .modal'); let m = p.locator('#modais .modal').last(), mt = await m.textContent();
  certo(/Prévia dos textos da turma/.test(mt) && /horta xiloguarda/.test(mt) && !/\{nome\}/.test(mt) && await m.locator('.previa p[style*="text-indent"]').count() > 0, 'prévia dos textos da turma, com o nome no marcador e o recuo');
  await m.locator('button.pri').click(); await p.waitForTimeout(200);
  await p.uncheck('[data-b="boletim.recuo"]'); await p.waitForTimeout(700);
  certo(await p.evaluate(async () => { await descarregarFila(); const d = docBoletim(await boletimDe(IX.turmas.t26, IX.alunos.ana)); return !d.blocos.some(x => x.recuo); }), 'sem a opção, o boletim fica sem recuo');

  // títulos das seções e do poema como subtítulo
  await p.evaluate(() => { UI.aba.bol = 'secoes'; ir('bol'); }); t = await texto();
  certo(/Subtítulo/.test(t) && await p.locator('[data-b$=".subtitulo"]').count() > 3, 'coluna Subtítulo nas seções do ano');
  const antes = await p.evaluate(async () => { const d = docBoletim(await boletimDe(IX.turmas.t26, IX.alunos.ana)); return { h: d.blocos.filter(x => x.t === 'h').length, centro: d.blocos.some(x => x.t === 'centro' && x.linhas[0] === 'Poema') }; });
  const i = await p.evaluate(() => modeloDaSerie(3).secoes.findIndex(s => s.key === window._k));
  await p.check('[data-b="secoes.' + i + '.subtitulo"]'); await p.check('[data-b="poemaSubtitulo"]'); await p.waitForTimeout(700);
  const dep = await p.evaluate(async () => { await descarregarFila(); const m = modeloDaSerie(3), s = m.secoes.find(x => x.key === window._k), bol = await boletimDe(IX.turmas.t26, IX.alunos.ana), d = docBoletim(bol), k = d.blocos.findIndex(x => x.t === 'h' && x.txt === s.titulo); return { sub: k >= 0 && d.blocos[k + 1] && /horta xiloguarda/.test(d.blocos[k + 1].txt), poema: d.blocos.some(x => x.t === 'h' && x.txt === (bol.poemaTitulo || 'Poema')) && !d.blocos.some(x => x.t === 'centro' && x.linhas[0] === 'Poema'), vazias: d.blocos.filter(x => x.t === 'h').length }; });
  certo(!antes.h && antes.centro, 'sem marcar, o boletim fica como antes (sem subtítulos; poema centralizado)');
  certo(dep.sub, 'seção marcada: o título aparece como subtítulo antes do texto');
  certo(dep.poema, 'poema marcado: o título do poema aparece como subtítulo');

  // busca nos textos da turma
  await p.evaluate(() => { UI.filtro.busca = 'xiloguarda'; ir('busca'); }); t = await texto();
  certo(/texto da turma/.test(t), 'a busca encontra o texto da turma do boletim');
  await p.locator('[data-a=abrirTextosTurma]').first().click(); await p.waitForTimeout(500);
  certo(await p.evaluate(() => UI.tela === 'bol' && UI.aba.bol === 'turma' && document.activeElement && document.activeElement.dataset.b === 'boletim.textos.' + window._k), 'o resultado abre os textos da turma no campo certo');

  // PEI – PDI
  certo(/PEI – PDI/.test(await p.textContent('nav.nav')), 'menu mostra PEI – PDI');
  await p.evaluate(() => { UI.sub = null; ir('pei'); }); t = await texto();
  certo(/PEI – PDI/.test(t) && /Plano de Desenvolvimento Individual/.test(t), 'tela do PEI – PDI explica as duas siglas');

  // o botão Anotar sai da frente enquanto se digita
  await p.evaluate(() => { UI.aba.bol = 'turma'; ir('bol'); });
  const ta = p.locator('[data-b="boletim.textos.' + await p.evaluate(() => window._k) + '"]');
  await ta.scrollIntoViewIfNeeded(); await ta.click();
  certo(await p.evaluate(() => document.body.classList.contains('digitando') && getComputedStyle(document.querySelector('.fab')).display === 'none'), 'ao digitar num campo, o botão Anotar some');
  await p.click('h1'); await p.waitForTimeout(100);
  certo(await p.evaluate(() => !document.body.classList.contains('digitando') && getComputedStyle(document.querySelector('.fab')).display !== 'none'), 'ao sair do campo, o botão Anotar volta');
  // a linha escrita fica visível (tela de celular)
  const q = await (await b.newContext({ viewport: { width: 390, height: 700 }, locale: 'pt-BR', isMobile: true, hasTouch: true })).newPage();
  q.on('pageerror', x => erros.push('celular pageerror: ' + x.message));
  await q.goto(APP); await q.click('[data-a=entrarDemo]'); await q.waitForTimeout(2600);
  await q.evaluate(() => { CFG.prefs.turmaId = 't26'; UI.aba.bol = 'turma'; ir('bol'); });
  const ultimo = q.locator('.secao-bol textarea').last(); await ultimo.scrollIntoViewIfNeeded(); await ultimo.click();
  await q.evaluate(() => { const el = document.activeElement; el.selectionStart = el.selectionEnd = el.value.length; });
  for (let k = 0; k < 14; k++) await q.keyboard.type('Linha ' + k + ' do texto da turma.\n', { delay: 1 });
  await q.waitForTimeout(300);
  const vis = await q.evaluate(() => { const r = document.activeElement.getBoundingClientRect(); return r.bottom <= innerHeight + 2; });
  certo(vis, 'no celular, a linha que se escreve fica à vista enquanto o campo cresce');
  certo(await q.evaluate(() => getComputedStyle(document.querySelector('.barra-movel')).display === 'none'), 'no celular, a barra de baixo sai da frente enquanto se digita');

  fs.appendFileSync(LOG, erros.length ? 'ERROS: ' + erros.join(' | ') + '\n' : 'Sem erros\n'); await b.close();
})().catch(x => { fs.appendFileSync(LOG, 'FALHOU ' + x.stack + '\n'); process.exit(1); });
